$ErrorActionPreference = 'Stop'

$flutterCommand = Get-Command flutter -ErrorAction Stop
$flutterRoot = Split-Path (Split-Path $flutterCommand.Source -Parent) -Parent
$androidSdk = $env:ANDROID_SDK_ROOT
if (-not $androidSdk) { $androidSdk = $env:ANDROID_HOME }
if (-not $androidSdk) { $androidSdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }

if (-not (Test-Path (Join-Path $flutterRoot 'packages\flutter_tools\gradle'))) {
    throw "Could not locate Flutter SDK at $flutterRoot"
}
if (-not (Test-Path $androidSdk)) {
    throw "Android SDK not found at $androidSdk. Set ANDROID_SDK_ROOT."
}

function Escape-PropertiesPath([string]$value) {
    return $value.Replace('\', '\\').Replace(':', '\:')
}

$flutterPath = Escape-PropertiesPath $flutterRoot
$sdkPath = Escape-PropertiesPath $androidSdk
@("flutter.sdk=$flutterPath", "sdk.dir=$sdkPath") | Set-Content -Encoding ASCII (Join-Path $PSScriptRoot 'android\local.properties')

Push-Location (Join-Path $PSScriptRoot 'android')
try {
    if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
        throw 'Gradle 9.5.0 is not on PATH. Install Gradle 9.5.0 or generate the wrapper using Android Studio.'
    }
    gradle wrapper --gradle-version 9.5.0
} finally {
    Pop-Location
}

Write-Host 'Android Gradle wrapper created. You can now run flutter build apk --release --target-platform android-arm.'
