allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}

subprojects {
    project.evaluationDependsOn(":app")
}

// F14 (v1.1.0): tflite_flutter 0.12.x does not pin its Kotlin JVM target,
// which makes Gradle fail with "Inconsistent JVM-target compatibility
// ... 'compileDebugJavaWithJavac' (11) and 'compileDebugKotlin' (N)".
// Pin it to JVM 11 to match the plugin's own Java target (per the
// wake_word_flutter README). No other plugin needs this.
subprojects {
    if (name == "tflite_flutter") {
        tasks.withType(org.jetbrains.kotlin.gradle.tasks.KotlinCompile::class.java).configureEach {
            compilerOptions.jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_11)
        }
    }
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
