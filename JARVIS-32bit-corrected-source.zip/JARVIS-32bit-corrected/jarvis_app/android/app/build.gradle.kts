import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.flutter.flutter-gradle-plugin")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
val hasReleaseKeystore = if (keystorePropertiesFile.isFile) {
    keystorePropertiesFile.inputStream().use { keystoreProperties.load(it) }
    val requiredValuesPresent = listOf("keyAlias", "keyPassword", "storeFile", "storePassword")
        .all { !keystoreProperties.getProperty(it).isNullOrBlank() }
    requiredValuesPresent && file(keystoreProperties.getProperty("storeFile")).isFile
} else false

android {
    namespace = "com.jarvis.jarvis_app"
    // v1.1.0 CI fix: flutter_local_notifications 23.x, permission_handler_android
    // 14.x and androidx.core:core(-ktx) 1.19.0 require compiling against API 37
    // (CI run #15: checkReleaseAarMetadata failed on android-36). Flutter
    // 3.50.0's flutter.compileSdkVersion defaults to 36, so pin 37 explicitly.
    // AGP 9.3.1 supports up to API 37 (min AGP for 37 is 9.1.1, per the
    // official AGP/API compatibility table). targetSdk stays at
    // flutter.targetSdkVersion (36) — compileSdk does not change runtime
    // behaviour on devices.
    compileSdk = 37
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // F7 (v1.1.0): flutter_local_notifications uses java.time below
        // API 26 — core-library desugaring makes it work on minSdk 24.
        isCoreLibraryDesugaringEnabled = true
    }

    dependencies {
        coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    }

    kotlin {
        compilerOptions {
            jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
        }
    }

    // Release lint crashes on AGP 9.x (NoSuchMethodError in lint's CommentDetector
    // on url_launcher_android) — a lint tooling bug, not app code. Skip it.
    lint {
        checkReleaseBuilds = false
    }

    defaultConfig {
        applicationId = "com.jarvis.jarvis_app"
        minSdk = 24
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        ndk {
            abiFilters += listOf("armeabi-v7a")
        }
    }

    signingConfigs {
        if (hasReleaseKeystore) {
            create("release") {
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
                storeFile = file(keystoreProperties.getProperty("storeFile"))
                storePassword = keystoreProperties.getProperty("storePassword")
            }
        }
    }

    buildTypes {
        getByName("release") {
            // A local debug certificate keeps first-time release builds installable.
            // Supply android/key.properties for a production release/update channel.
            signingConfig = if (hasReleaseKeystore) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

flutter {
    source = "../.."
}
