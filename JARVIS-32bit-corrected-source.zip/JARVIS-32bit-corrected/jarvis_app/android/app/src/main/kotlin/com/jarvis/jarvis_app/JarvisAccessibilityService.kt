package com.jarvis.jarvis_app

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Phase 8 (v1.1.0) — F41 Accessibility service.
 *
 * Jarvis can tap by text, type text, go back, and scroll inside other
 * apps — but ONLY when the user tells it to by voice in the current
 * session, and ONLY when the user has switched Jarvis on both in the
 * app's Settings and in Android Settings → Accessibility. The service
 * never acts on its own: it does nothing in onAccessibilityEvent, and
 * only performs an action when the Dart side calls performAction
 * through the "com.jarvis.jarvis_app/accessibility" MethodChannel in
 * MainActivity.kt (which first checks both switches).
 *
 * Pattern: ansaribilal14/jarvis (Accessibility-driven phone
 * automation) and tokenarc/open-jarvis (Accessibility Service).
 * Fresh implementation — no code copied.
 *
 * Registered in AndroidManifest.xml with
 * res/xml/accessibilityservice.xml. Native code cannot be
 * compile-verified in this sandbox — CI must confirm it.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        // Deliberately empty: the service never reacts to screen
        // events on its own. It only acts on an explicit voice
        // command relayed through performAction below.
    }

    override fun onInterrupt() {
        // Nothing to clean up: no ongoing action is held here.
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** Tap the first node whose visible text contains [text]. */
    fun tapByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = findNode(root) { node ->
            val nodeText = node.text?.toString().orEmpty()
            val contentDescription = node.contentDescription?.toString().orEmpty()
            nodeText.contains(text, ignoreCase = true) ||
                contentDescription.contains(text, ignoreCase = true)
        } ?: return false
        return clickNodeOrClickableAncestor(target)
    }

    /** Type [text] into the focused / first editable field on screen. */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        // Prefer the focused editable field; fall back to the first
        // editable field on screen.
        val editable = findNode(root) { it.isFocused && it.isEditable }
            ?: findNode(root) { it.isEditable }
            ?: return false
        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        return editable.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun goBack(): Boolean =
        performGlobalAction(GLOBAL_ACTION_BACK)

    fun scrollDown(): Boolean = scroll(forward = true)

    fun scrollUp(): Boolean = scroll(forward = false)

    private fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findNode(root) { it.isScrollable }
            ?: return root.performAction(
                if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            )
        return scrollable.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    /** Depth-first search for the first node matching [predicate]. */
    private fun findNode(
        node: AccessibilityNodeInfo,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNode(child, predicate)
            if (found != null) return found
        }
        return null
    }

    /**
     * Click [node] itself when it is clickable, otherwise the nearest
     * clickable ancestor (labels are often plain TextViews inside a
     * clickable row). Returns false when neither exists.
     */
    private fun clickNodeOrClickableAncestor(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }
}
