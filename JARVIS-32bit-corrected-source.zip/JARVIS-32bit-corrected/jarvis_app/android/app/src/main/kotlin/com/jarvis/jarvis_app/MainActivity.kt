package com.jarvis.jarvis_app

import android.app.Activity
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.app.AppOpsManager
import android.app.role.RoleManager
import android.app.usage.UsageStatsManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.CalendarContract
import android.provider.Telephony
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.security.KeyStore
import java.util.Calendar
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.jarvis.jarvis_app/secure_storage"
        private const val APPS_CHANNEL = "com.jarvis.jarvis_app/apps"
        private const val DEVICE_CHANNEL = "com.jarvis.jarvis_app/device"
        private const val LAUNCH_CHANNEL = "com.jarvis.jarvis_app/launch"
        // Phase 7 (v1.1.0): F27 calendar, F29 SMS, F30 network,
        // F31 telemetry. One small channel per domain, same pattern as
        // the channels above.
        private const val NETWORK_CHANNEL = "com.jarvis.jarvis_app/network"
        private const val TELEMETRY_CHANNEL =
            "com.jarvis.jarvis_app/telemetry"
        private const val CALENDAR_CHANNEL = "com.jarvis.jarvis_app/calendar"
        private const val SMS_CHANNEL = "com.jarvis.jarvis_app/sms"
        // Phase 7b (v1.1.0): F32 proximity sensor (air gestures) and
        // F37 last-known location (commute start point). Same channel
        // pattern as above; no new dependency, no native .so.
        private const val SENSOR_CHANNEL = "com.jarvis.jarvis_app/sensors"
        private const val PROXIMITY_CHANNEL =
            "com.jarvis.jarvis_app/proximity"
        private const val LOCATION_CHANNEL =
            "com.jarvis.jarvis_app/location"
        // Phase 8 (v1.1.0): F41 Accessibility service (tap / type /
        // go back / scroll), driven only by voice commands and only
        // when the user has it switched on. Same channel pattern.
        private const val ACCESSIBILITY_CHANNEL =
            "com.jarvis.jarvis_app/accessibility"
        private const val KEY_ALIAS = "jarvis_gemini_api_key_v1"
        private const val PREFS = "jarvis_secure_store"
        private const val VALUE_KEY = "encrypted_api_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_SIZE = 12
        private const val TAG_SIZE = 128
        // Phase 7 (F24): request code for the assistant-role dialog
        // (createRequestRoleIntent), answered in onActivityResult.
        private const val REQUEST_ASSISTANT_ROLE = 9001
    }

    // Set by the home-screen widget (or a cold start from it): open the app
    // and start a conversation right away. Read once by Dart, then cleared.
    private var startConversationRequested = false

    // Held while the system assistant-role dialog (F24) is on screen;
    // completed in onActivityResult below. Never faked as granted.
    private var pendingRoleResult: MethodChannel.Result? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startConversationRequested =
            intent?.getBooleanExtra("jarvis_start_conversation", false) == true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        startConversationRequested =
            intent.getBooleanExtra("jarvis_start_conversation", false)
    }

    // The assistant-role request (F24) is an activity, not a callback:
    // the system dialog's answer arrives here. startActivityForResult
    // is deprecated in API 30+, but it is the only result API a plain
    // android.app.Activity (FlutterActivity) offers — the Activity
    // Result API needs a ComponentActivity.
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_ASSISTANT_ROLE) return
        val pending = pendingRoleResult
        pendingRoleResult = null
        if (pending == null) return
        // RESULT_OK is what the system returns when the role was
        // granted; confirm with RoleManager so the answer reflects
        // reality rather than trusting the code alone.
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager =
                getSystemService(Context.ROLE_SERVICE) as RoleManager
            resultCode == Activity.RESULT_OK &&
                roleManager.isRoleHeld(RoleManager.ROLE_ASSISTANT)
        } else {
            false
        }
        pending.success(granted)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "saveApiKey" -> {
                            val apiKey = call.argument<String>("apiKey")?.trim()
                            if (apiKey.isNullOrEmpty()) {
                                result.error("INVALID_ARGUMENT", "API key is empty", null)
                            } else {
                                encryptAndStore(KEY_ALIAS, VALUE_KEY, apiKey)
                                result.success(null)
                            }
                        }
                        "readApiKey" -> result.success(readAndDecrypt(KEY_ALIAS, VALUE_KEY))
                        "clearApiKey" -> {
                            clearSecret(KEY_ALIAS, VALUE_KEY)
                            result.success(null)
                        }
                        // Phase 6 (F19/F20, v1.1.0): other providers' keys
                        // (currently only the free NVIDIA NIM key) use the
                        // SAME AndroidKeyStore AES/GCM mechanism, one
                        // key alias + prefs entry per named secret. Only
                        // names on the allowlist below are accepted.
                        "saveSecret" -> {
                            val name = call.argument<String>("name")?.trim()
                            val value = call.argument<String>("value")?.trim()
                            val secret = secretSpec(name)
                            if (secret == null || value.isNullOrEmpty()) {
                                result.error("INVALID_ARGUMENT", "Unknown secret or empty value", null)
                            } else {
                                encryptAndStore(secret.first, secret.second, value)
                                result.success(null)
                            }
                        }
                        "readSecret" -> {
                            val secret = secretSpec(call.argument<String>("name")?.trim())
                            if (secret == null) {
                                result.error("INVALID_ARGUMENT", "Unknown secret", null)
                            } else {
                                result.success(readAndDecrypt(secret.first, secret.second))
                            }
                        }
                        "clearSecret" -> {
                            val secret = secretSpec(call.argument<String>("name")?.trim())
                            if (secret == null) {
                                result.error("INVALID_ARGUMENT", "Unknown secret", null)
                            } else {
                                clearSecret(secret.first, secret.second)
                                result.success(null)
                            }
                        }
                        else -> result.notImplemented()
                    }
                } catch (error: Exception) {
                    result.error("SECURE_STORAGE_ERROR", "Secure storage operation failed", error.javaClass.simpleName)
                }
            }
        // Lists every launchable app on the phone (label + package) so the
        // user can pick which apps Jarvis may open. Nothing leaves the phone.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, APPS_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "getInstalledApps") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                try {
                    val launchIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                    }
                    val apps = packageManager.queryIntentActivities(launchIntent, 0)
                        .map { info ->
                            mapOf(
                                "label" to (info.loadLabel(packageManager)?.toString()
                                    ?: info.activityInfo.packageName),
                                "package" to info.activityInfo.packageName
                            )
                        }
                        .sortedBy { (it["label"] as String).lowercase() }
                    result.success(apps)
                } catch (error: Exception) {
                    result.error("APPS_ERROR", "Could not list apps", error.javaClass.simpleName)
                }
            }
        // Device controls: lock screen (device admin), flashlight, volume.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, DEVICE_CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "isDeviceAdminActive" -> {
                            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                            result.success(dpm.isAdminActive(deviceAdminComponent()))
                        }
                        "requestDeviceAdmin" -> {
                            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, deviceAdminComponent())
                                putExtra(
                                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                    "Jarvis needs device admin only to lock your phone when you say so."
                                )
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                            result.success(null)
                        }
                        "lockPhone" -> {
                            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                            if (!dpm.isAdminActive(deviceAdminComponent())) {
                                result.error("NOT_ADMIN", "Device admin is not active", null)
                            } else {
                                dpm.lockNow()
                                result.success(null)
                            }
                        }
                        "setTorch" -> {
                            val on = call.argument<Boolean>("on") ?: false
                            if (ContextCompat.checkSelfPermission(
                                    this,
                                    android.Manifest.permission.CAMERA
                                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                            ) {
                                result.success("NO_PERMISSION")
                            } else {
                                val cameraManager =
                                    getSystemService(Context.CAMERA_SERVICE) as CameraManager
                                val cameraId = cameraManager.cameraIdList.firstOrNull()
                                if (cameraId == null) {
                                    result.error("NO_CAMERA", "No camera found", null)
                                } else {
                                    cameraManager.setTorchMode(cameraId, on)
                                    result.success("OK")
                                }
                            }
                        }
                        "setVolume" -> {
                            val direction = call.argument<String>("direction") ?: ""
                            val audioManager =
                                getSystemService(Context.AUDIO_SERVICE) as AudioManager
                            val adjustment = when (direction) {
                                "up" -> AudioManager.ADJUST_RAISE
                                "down" -> AudioManager.ADJUST_LOWER
                                "mute" -> AudioManager.ADJUST_MUTE
                                else -> null
                            }
                            if (adjustment == null) {
                                result.error(
                                    "INVALID_ARGUMENT",
                                    "Unknown volume direction",
                                    null
                                )
                            } else {
                                audioManager.adjustVolume(
                                    adjustment,
                                    AudioManager.FLAG_SHOW_UI
                                )
                                result.success(null)
                            }
                        }
                        // Phase 7 (F24, v1.1.0): default-assistant role
                        // via RoleManager (API 29+; guarded — minSdk is
                        // 24, his phone is API 34). The system shows
                        // the grant/decline dialog; declining changes
                        // nothing. Eligibility needs the ASSIST
                        // activity (AssistActivity.kt + manifest).
                        "isAssistantRoleHeld" -> {
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                result.success(false)
                            } else {
                                val roleManager =
                                    getSystemService(Context.ROLE_SERVICE) as RoleManager
                                result.success(
                                    roleManager.isRoleHeld(RoleManager.ROLE_ASSISTANT)
                                )
                            }
                        }
                        "requestAssistantRole" -> {
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                result.error(
                                    "UNSUPPORTED",
                                    "Default assistant needs Android 10 or newer",
                                    null
                                )
                            } else if (pendingRoleResult != null) {
                                result.error(
                                    "ALREADY_REQUESTING",
                                    "An assistant-role request is already in progress",
                                    null
                                )
                            } else {
                                val roleManager =
                                    getSystemService(Context.ROLE_SERVICE) as RoleManager
                                if (!roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                                    result.error(
                                        "UNAVAILABLE",
                                        "Assistant role is not available on this phone",
                                        null
                                    )
                                } else {
                                    // RoleManager has no callback API:
                                    // the request is a system dialog
                                    // launched as an activity, and the
                                    // answer comes back in
                                    // onActivityResult below. The
                                    // MethodChannel result is held
                                    // until then — never faked.
                                    // (FlutterActivity is a plain
                                    // android.app.Activity, so the
                                    // Activity Result API is not
                                    // available; startActivityForResult
                                    // is the correct call here.)
                                    val intent = roleManager.createRequestRoleIntent(
                                        RoleManager.ROLE_ASSISTANT
                                    )
                                    startActivityForResult(intent, REQUEST_ASSISTANT_ROLE)
                                    pendingRoleResult = result
                                }
                            }
                        }
                        else -> result.notImplemented()
                    }
                } catch (error: Exception) {
                    result.error("DEVICE_ERROR", "Device operation failed", error.javaClass.simpleName)
                }
            }
        // Home-screen widget: the widget opens the app asking it to start
        // a conversation right away. Read once, then cleared.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, LAUNCH_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method == "getStartConversation") {
                    val start = startConversationRequested
                    startConversationRequested = false
                    result.success(start)
                } else {
                    result.notImplemented()
                }
            }
        // Phase 7b (F32, v1.1.0): proximity sensor. Method channel
        // answers "does this phone have one?"; the event channel
        // streams true (hand near) / false (hand far) while Dart is
        // listening. The listener is registered only while a Dart
        // subscription exists, so the sensor costs nothing when the
        // air gesture is off.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SENSOR_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "hasProximitySensor") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                try {
                    val sensorManager =
                        getSystemService(Context.SENSOR_SERVICE) as SensorManager
                    result.success(
                        sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY) != null
                    )
                } catch (error: Exception) {
                    result.error("SENSOR_ERROR", "Could not check the proximity sensor", error.javaClass.simpleName)
                }
            }
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, PROXIMITY_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                private var listener: SensorEventListener? = null

                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    try {
                        val sensorManager =
                            getSystemService(Context.SENSOR_SERVICE) as SensorManager
                        val sensor =
                            sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
                        if (sensor == null) {
                            events?.error("NO_SENSOR", "No proximity sensor on this phone", null)
                            return
                        }
                        val sink = events ?: return
                        listener = object : SensorEventListener {
                            override fun onSensorChanged(event: SensorEvent?) {
                                if (event == null) return
                                // Near when the reading is below the
                                // sensor's maximum range (most phone
                                // sensors report 0 near / max far).
                                sink.success(event.values[0] < sensor.maximumRange)
                            }

                            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
                        }
                        sensorManager.registerListener(
                            listener,
                            sensor,
                            SensorManager.SENSOR_DELAY_NORMAL
                        )
                    } catch (error: Exception) {
                        events?.error("SENSOR_ERROR", "Could not start the proximity sensor", error.javaClass.simpleName)
                    }
                }

                override fun onCancel(arguments: Any?) {
                    try {
                        val sensorManager =
                            getSystemService(Context.SENSOR_SERVICE) as SensorManager
                        listener?.let { sensorManager.unregisterListener(it) }
                    } catch (_: Exception) {
                    }
                    listener = null
                }
            })
        // Phase 7b (F37, v1.1.0): last-known location for the commute
        // start point. Read-only, never requests a fresh fix — the
        // Dart side asks the user for a starting place when this
        // returns null. Needs ACCESS_FINE_LOCATION (already in the
        // manifest; requested in Dart before this call).
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, LOCATION_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "getLastLocation") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                if (ContextCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.ACCESS_FINE_LOCATION
                    ) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                    ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    result.success(null)
                    return@setMethodCallHandler
                }
                try {
                    val locationManager =
                        getSystemService(Context.LOCATION_SERVICE) as LocationManager
                    val location =
                        locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                            ?: locationManager.getLastKnownLocation(
                                LocationManager.NETWORK_PROVIDER
                            )
                    if (location == null) {
                        result.success(null)
                    } else {
                        result.success(
                            mapOf(
                                "latitude" to location.latitude,
                                "longitude" to location.longitude
                            )
                        )
                    }
                } catch (error: Exception) {
                    result.error("LOCATION_ERROR", "Could not read the location", error.javaClass.simpleName)
                }
            }
        // Phase 8 (v1.1.0): F41 Accessibility service. The Dart side
        // only calls performAction after checking its own toggle;
        // the Kotlin side also refuses when the service is not
        // enabled in Android Settings (instance is null then).
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, ACCESSIBILITY_CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "isServiceEnabled" -> {
                            val manager = getSystemService(
                                Context.ACCESSIBILITY_SERVICE
                            ) as AccessibilityManager
                            val enabled = manager.isEnabled &&
                                manager.getEnabledAccessibilityServiceList(
                                    android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_GENERIC
                                ).any {
                                    it.resolveInfo.serviceInfo.packageName == packageName &&
                                        it.resolveInfo.serviceInfo.name.contains(
                                            "JarvisAccessibilityService"
                                        )
                                }
                            result.success(enabled)
                        }
                        "openAccessibilitySettings" -> {
                            val intent = Intent(
                                Settings.ACTION_ACCESSIBILITY_SETTINGS
                            ).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                            result.success(null)
                        }
                        "performAction" -> {
                            val service = JarvisAccessibilityService.instance
                            if (service == null) {
                                result.error(
                                    "NOT_ENABLED",
                                    "Jarvis is not enabled in Android Accessibility settings",
                                    null
                                )
                                return@setMethodCallHandler
                            }
                            val action = call.argument<String>("action") ?: ""
                            val text = call.argument<String>("text") ?: ""
                            val done = when (action) {
                                "tapByText" -> service.tapByText(text)
                                "typeText" -> service.typeText(text)
                                "goBack" -> service.goBack()
                                "scrollDown" -> service.scrollDown()
                                "scrollUp" -> service.scrollUp()
                                else -> false
                            }
                            result.success(done)
                        }
                        else -> result.notImplemented()
                    }
                } catch (error: Exception) {
                    result.error("ACCESSIBILITY_ERROR", "Accessibility operation failed", error.javaClass.simpleName)
                }
            }
        // Phase 7 (F30, v1.1.0): the phone's own Wi-Fi info
        // (WifiManager). Display only — no scanning, no probing.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, NETWORK_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "getWifiInfo") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                try {
                    val wifiManager =
                        applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    val info = wifiManager.connectionInfo
                    result.success(
                        mapOf(
                            "ssid" to (info.ssid?.removeSurrounding("\"") ?: ""),
                            "ipAddress" to info.ipAddress,
                            "rssi" to info.rssi
                        )
                    )
                } catch (error: Exception) {
                    result.error("NETWORK_ERROR", "Could not read Wi-Fi info", error.javaClass.simpleName)
                }
            }
        // Phase 7 (F31, v1.1.0): battery/charging state (BatteryManager)
        // and today's app-usage stats (UsageStatsManager). Read-only;
        // usage stats need the user to grant Usage access in Settings.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, TELEMETRY_CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "getBatteryInfo" -> {
                            val batteryManager =
                                getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                            val level = batteryManager.getIntProperty(
                                BatteryManager.BATTERY_PROPERTY_CAPACITY
                            )
                            val batteryIntent = registerReceiver(
                                null,
                                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
                            )
                            val status = batteryIntent?.getIntExtra(
                                BatteryManager.EXTRA_STATUS, -1
                            ) ?: -1
                            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                                status == BatteryManager.BATTERY_STATUS_FULL
                            val plugged = batteryIntent?.getIntExtra(
                                BatteryManager.EXTRA_PLUGGED, -1
                            ) ?: -1
                            val pluggedLabel = when (plugged) {
                                BatteryManager.BATTERY_PLUGGED_AC -> "AC charger"
                                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                                else -> "Not plugged in"
                            }
                            result.success(
                                mapOf(
                                    "level" to level,
                                    "charging" to charging,
                                    "plugged" to pluggedLabel
                                )
                            )
                        }
                        "hasUsageStatsPermission" -> {
                            val appOps =
                                getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                            val mode = appOps.checkOpNoThrow(
                                AppOpsManager.OPSTR_GET_USAGE_STATS,
                                Process.myUid(),
                                packageName
                            )
                            result.success(mode == AppOpsManager.MODE_ALLOWED)
                        }
                        "getUsageStats" -> {
                            val limit = call.argument<Int>("limit") ?: 10
                            val usageStatsManager = getSystemService(
                                Context.USAGE_STATS_SERVICE
                            ) as UsageStatsManager
                            val dayStart = Calendar.getInstance().apply {
                                set(Calendar.HOUR_OF_DAY, 0)
                                set(Calendar.MINUTE, 0)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }.timeInMillis
                            val stats = usageStatsManager.queryUsageStats(
                                UsageStatsManager.INTERVAL_DAILY,
                                dayStart,
                                System.currentTimeMillis()
                            ) ?: emptyList()
                            val rows = stats
                                .filter { it.totalTimeInForeground > 0 }
                                .sortedByDescending { it.totalTimeInForeground }
                                .take(limit)
                                .map {
                                    mapOf(
                                        "package" to it.packageName,
                                        "label" to appLabel(it.packageName),
                                        "minutes" to (it.totalTimeInForeground / 60000).toInt()
                                    )
                                }
                            result.success(rows)
                        }
                        else -> result.notImplemented()
                    }
                } catch (error: Exception) {
                    result.error("TELEMETRY_ERROR", "Telemetry read failed", error.javaClass.simpleName)
                }
            }
        // Phase 7 (F27, v1.1.0): today's calendar events, read-only
        // (CalendarContract.Instances). Needs READ_CALENDAR.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CALENDAR_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "getTodayEvents") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                if (ContextCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.READ_CALENDAR
                    ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    result.error("NO_PERMISSION", "Calendar permission not granted", null)
                    return@setMethodCallHandler
                }
                try {
                    val dayStart = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    val dayEnd = dayStart + 24L * 60L * 60L * 1000L
                    val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
                        .appendPath(dayStart.toString())
                        .appendPath(dayEnd.toString())
                        .build()
                    val projection = arrayOf(
                        CalendarContract.Events.TITLE,
                        CalendarContract.Instances.BEGIN,
                        CalendarContract.Instances.END,
                        CalendarContract.Events.CALENDAR_DISPLAY_NAME,
                        CalendarContract.Events.ALL_DAY
                    )
                    val events = mutableListOf<Map<String, Any>>()
                    contentResolver.query(
                        uri,
                        projection,
                        null,
                        null,
                        "${CalendarContract.Instances.BEGIN} ASC"
                    )?.use { cursor ->
                        val titleIndex =
                            cursor.getColumnIndex(CalendarContract.Events.TITLE)
                        val beginIndex =
                            cursor.getColumnIndex(CalendarContract.Instances.BEGIN)
                        val endIndex =
                            cursor.getColumnIndex(CalendarContract.Instances.END)
                        val calendarIndex = cursor.getColumnIndex(
                            CalendarContract.Events.CALENDAR_DISPLAY_NAME
                        )
                        val allDayIndex =
                            cursor.getColumnIndex(CalendarContract.Events.ALL_DAY)
                        while (cursor.moveToNext()) {
                            events.add(
                                mapOf(
                                    "title" to (if (titleIndex >= 0) cursor.getString(titleIndex) else null).orEmpty(),
                                    "start" to (if (beginIndex >= 0) cursor.getLong(beginIndex) else 0L),
                                    "end" to (if (endIndex >= 0) cursor.getLong(endIndex) else 0L),
                                    "calendar" to (if (calendarIndex >= 0) cursor.getString(calendarIndex) else null).orEmpty(),
                                    "allDay" to (allDayIndex >= 0 && cursor.getInt(allDayIndex) == 1)
                                )
                            )
                        }
                    }
                    result.success(events)
                } catch (error: Exception) {
                    result.error("CALENDAR_ERROR", "Could not read the calendar", error.javaClass.simpleName)
                }
            }
        // Phase 7 (F29, v1.1.0): recent SMS bodies for bank-debit
        // parsing. Only runs when the user switched SMS parsing on in
        // Settings; needs READ_SMS. Read on-device only, never uploaded.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SMS_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "getRecentSms") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                if (ContextCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.READ_SMS
                    ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    result.error("NO_PERMISSION", "SMS permission not granted", null)
                    return@setMethodCallHandler
                }
                try {
                    val limit = call.argument<Int>("limit") ?: 100
                    val projection = arrayOf(
                        Telephony.Sms.ADDRESS,
                        Telephony.Sms.BODY,
                        Telephony.Sms.DATE
                    )
                    val messages = mutableListOf<Map<String, Any>>()
                    contentResolver.query(
                        Telephony.Sms.Inbox.CONTENT_URI,
                        projection,
                        null,
                        null,
                        "${Telephony.Sms.DATE} DESC LIMIT $limit"
                    )?.use { cursor ->
                        val addressIndex =
                            cursor.getColumnIndex(Telephony.Sms.ADDRESS)
                        val bodyIndex =
                            cursor.getColumnIndex(Telephony.Sms.BODY)
                        val dateIndex =
                            cursor.getColumnIndex(Telephony.Sms.DATE)
                        while (cursor.moveToNext()) {
                            messages.add(
                                mapOf(
                                    "address" to (if (addressIndex >= 0) cursor.getString(addressIndex) else null).orEmpty(),
                                    "body" to (if (bodyIndex >= 0) cursor.getString(bodyIndex) else null).orEmpty(),
                                    "date" to (if (dateIndex >= 0) cursor.getLong(dateIndex) else 0L)
                                )
                            )
                        }
                    }
                    result.success(messages)
                } catch (error: Exception) {
                    result.error("SMS_ERROR", "Could not read SMS", error.javaClass.simpleName)
                }
            }
    }

    private fun deviceAdminComponent(): ComponentName =
        ComponentName(this, JarvisDeviceAdminReceiver::class.java)

    // Phase 7 (F31): human label for a package, falling back to the
    // package name when it cannot be resolved.
    private fun appLabel(packageName: String): String {
        return try {
            val info = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(info)?.toString() ?: packageName
        } catch (_: Exception) {
            packageName
        }
    }

    // Phase 6 (F19/F20): named secrets stored through the same
    // AndroidKeyStore AES/GCM mechanism as the Gemini key. Returns the
    // (key alias, prefs key) for a known secret name, or null.
    private fun secretSpec(name: String?): Pair<String, String>? = when (name) {
        "nvidia_nim" -> Pair("jarvis_secret_nvidia_nim_v1", "encrypted_secret_nvidia_nim")
        // Phase 7 (F28): the Gmail OAuth access token, same mechanism.
        "gmail_oauth" -> Pair("jarvis_secret_gmail_oauth_v1", "encrypted_secret_gmail_oauth")
        else -> null
    }

    private fun clearSecret(alias: String, prefsKey: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(prefsKey).apply()
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (keyStore.containsAlias(alias)) keyStore.deleteEntry(alias)
    }

    private fun getOrCreateSecretKey(alias: String): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(alias, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun encryptAndStore(alias: String, prefsKey: String, plainText: String) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey(alias))
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val payload = cipher.iv + encrypted
        val encoded = Base64.encodeToString(payload, Base64.NO_WRAP)
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(prefsKey, encoded).apply()
    }

    private fun readAndDecrypt(alias: String, prefsKey: String): String {
        val encoded = getSharedPreferences(PREFS, MODE_PRIVATE).getString(prefsKey, null) ?: return ""
        val payload = Base64.decode(encoded, Base64.NO_WRAP)
        if (payload.size <= IV_SIZE) throw IllegalStateException("Stored secret is invalid")
        val iv = payload.copyOfRange(0, IV_SIZE)
        val encrypted = payload.copyOfRange(IV_SIZE, payload.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(alias), GCMParameterSpec(TAG_SIZE, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }
}

/** Device admin receiver: only used so Jarvis can lock the screen on the
 *  user's command. No other admin policy is requested. */
class JarvisDeviceAdminReceiver : DeviceAdminReceiver()
