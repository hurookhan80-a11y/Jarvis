package com.jarvis.jarvis_app

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.jarvis.jarvis_app/secure_storage"
        private const val KEY_ALIAS = "jarvis_gemini_api_key_v1"
        private const val PREFS = "jarvis_secure_store"
        private const val VALUE_KEY = "encrypted_api_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_SIZE = 12
        private const val TAG_SIZE = 128
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "saveApiKey" -> {
                            val apiKey = call.argument<String>("apiKey")?.trim()
                            if (apiKey.isNullOrEmpty()) {
                                result.error("INVALID_ARGUMENT", "API key is empty", null)
                            } else {
                                encryptAndStore(apiKey)
                                result.success(null)
                            }
                        }
                        "readApiKey" -> result.success(readAndDecrypt())
                        "clearApiKey" -> {
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(VALUE_KEY).apply()
                            val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                            if (keyStore.containsAlias(KEY_ALIAS)) keyStore.deleteEntry(KEY_ALIAS)
                            result.success(null)
                        }
                        else -> result.notImplemented()
                    }
                } catch (error: Exception) {
                    result.error("SECURE_STORAGE_ERROR", "Secure storage operation failed", error.javaClass.simpleName)
                }
            }
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun encryptAndStore(plainText: String) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val payload = cipher.iv + encrypted
        val encoded = Base64.encodeToString(payload, Base64.NO_WRAP)
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(VALUE_KEY, encoded).apply()
    }

    private fun readAndDecrypt(): String {
        val encoded = getSharedPreferences(PREFS, MODE_PRIVATE).getString(VALUE_KEY, null) ?: return ""
        val payload = Base64.decode(encoded, Base64.NO_WRAP)
        if (payload.size <= IV_SIZE) throw IllegalStateException("Stored API key is invalid")
        val iv = payload.copyOfRange(0, IV_SIZE)
        val encrypted = payload.copyOfRange(IV_SIZE, payload.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(TAG_SIZE, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }
}
