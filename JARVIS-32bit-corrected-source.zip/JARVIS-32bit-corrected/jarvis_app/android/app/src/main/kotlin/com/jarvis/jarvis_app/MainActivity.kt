package com.jarvis.jarvis_app

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.jarvis.jarvis_app/secure_storage"
        private const val APPS_CHANNEL = "com.jarvis.jarvis_app/apps"
        private const val DEVICE_CHANNEL = "com.jarvis.jarvis_app/device"
        private const val LAUNCH_CHANNEL = "com.jarvis.jarvis_app/launch"
        private const val KEY_ALIAS = "jarvis_gemini_api_key_v1"
        private const val PREFS = "jarvis_secure_store"
        private const val VALUE_KEY = "encrypted_api_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_SIZE = 12
        private const val TAG_SIZE = 128
    }

    // Set by the home-screen widget (or a cold start from it): open the app
    // and start a conversation right away. Read once by Dart, then cleared.
    private var startConversationRequested = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startConversationRequested =
            intent?.getBooleanExtra("jarvis_start_conversation", false) == true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        startConversationRequested =
            intent.getBooleanExtra("jarvis_start_conversation", false)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "saveApiKey" -> {
                            val apiKey = call.argument<String>("apiKey")?.trim()
                            if (apiKey.isNullOrEmpty()) {
                                result.error("INVALID_ARGUMENT", "API key is empty", null)
                            } else {
                                encryptAndStore(apiKey)
                                result.success(null)
                            }
                        }
                        "readApiKey" -> result.success(readAndDecrypt())
                        "clearApiKey" -> {
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(VALUE_KEY).apply()
                            val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                            if (keyStore.containsAlias(KEY_ALIAS)) keyStore.deleteEntry(KEY_ALIAS)
                            result.success(null)
                        }
                        else -> result.notImplemented()
                    }
                } catch (error: Exception) {
                    result.error("SECURE_STORAGE_ERROR", "Secure storage operation failed", error.javaClass.simpleName)
                }
            }
        // Lists every launchable app on the phone (label + package) so the
        // user can pick which apps Jarvis may open. Nothing leaves the phone.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, APPS_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method != "getInstalledApps") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                try {
                    val launchIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                    }
                    val apps = packageManager.queryIntentActivities(launchIntent, 0)
                        .map { info ->
                            mapOf(
                                "label" to (info.loadLabel(packageManager)?.toString()
                                    ?: info.activityInfo.packageName),
                                "package" to info.activityInfo.packageName
                            )
                        }
                        .sortedBy { (it["label"] as String).lowercase() }
                    result.success(apps)
                } catch (error: Exception) {
                    result.error("APPS_ERROR", "Could not list apps", error.javaClass.simpleName)
                }
            }
        // Device controls: lock screen (device admin), flashlight, volume.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, DEVICE_CHANNEL)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "isDeviceAdminActive" -> {
                            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                            result.success(dpm.isAdminActive(deviceAdminComponent()))
                        }
                        "requestDeviceAdmin" -> {
                            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, deviceAdminComponent())
                                putExtra(
                                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                    "Jarvis needs device admin only to lock your phone when you say so."
                                )
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                            result.success(null)
                        }
                        "lockPhone" -> {
                            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                            if (!dpm.isAdminActive(deviceAdminComponent())) {
                                result.error("NOT_ADMIN", "Device admin is not active", null)
                            } else {
                                dpm.lockNow()
                                result.success(null)
                            }
                        }
                        "setTorch" -> {
                            val on = call.argument<Boolean>("on") ?: false
                            if (ContextCompat.checkSelfPermission(
                                    this,
                                    android.Manifest.permission.CAMERA
                                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                            ) {
                                result.success("NO_PERMISSION")
                            } else {
                                val cameraManager =
                                    getSystemService(Context.CAMERA_SERVICE) as CameraManager
                                val cameraId = cameraManager.cameraIdList.firstOrNull()
                                if (cameraId == null) {
                                    result.error("NO_CAMERA", "No camera found", null)
                                } else {
                                    cameraManager.setTorchMode(cameraId, on)
                                    result.success("OK")
                                }
                            }
                        }
                        "setVolume" -> {
                            val direction = call.argument<String>("direction") ?: ""
                            val audioManager =
                                getSystemService(Context.AUDIO_SERVICE) as AudioManager
                            val adjustment = when (direction) {
                                "up" -> AudioManager.ADJUST_RAISE
                                "down" -> AudioManager.ADJUST_LOWER
                                "mute" -> AudioManager.ADJUST_MUTE
                                else -> null
                            }
                            if (adjustment == null) {
                                result.error(
                                    "INVALID_ARGUMENT",
                                    "Unknown volume direction",
                                    null
                                )
                            } else {
                                audioManager.adjustVolume(
                                    adjustment,
                                    AudioManager.FLAG_SHOW_UI
                                )
                                result.success(null)
                            }
                        }
                        else -> result.notImplemented()
                    }
                } catch (error: Exception) {
                    result.error("DEVICE_ERROR", "Device operation failed", error.javaClass.simpleName)
                }
            }
        // Home-screen widget: the widget opens the app asking it to start
        // a conversation right away. Read once, then cleared.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, LAUNCH_CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method == "getStartConversation") {
                    val start = startConversationRequested
                    startConversationRequested = false
                    result.success(start)
                } else {
                    result.notImplemented()
                }
            }
    }

    private fun deviceAdminComponent(): ComponentName =
        ComponentName(this, JarvisDeviceAdminReceiver::class.java)

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun encryptAndStore(plainText: String) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val payload = cipher.iv + encrypted
        val encoded = Base64.encodeToString(payload, Base64.NO_WRAP)
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(VALUE_KEY, encoded).apply()
    }

    private fun readAndDecrypt(): String {
        val encoded = getSharedPreferences(PREFS, MODE_PRIVATE).getString(VALUE_KEY, null) ?: return ""
        val payload = Base64.decode(encoded, Base64.NO_WRAP)
        if (payload.size <= IV_SIZE) throw IllegalStateException("Stored API key is invalid")
        val iv = payload.copyOfRange(0, IV_SIZE)
        val encrypted = payload.copyOfRange(IV_SIZE, payload.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(TAG_SIZE, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }
}

/** Device admin receiver: only used so Jarvis can lock the screen on the
 *  user's command. No other admin policy is requested. */
class JarvisDeviceAdminReceiver : DeviceAdminReceiver()
