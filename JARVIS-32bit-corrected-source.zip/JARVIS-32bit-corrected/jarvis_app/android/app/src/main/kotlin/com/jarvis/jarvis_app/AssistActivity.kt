package com.jarvis.jarvis_app

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Phase 7 (F24, v1.1.0): the ASSIST activity that makes Jarvis
 *  eligible for the Android default-assistant role (RoleManager,
 *  API 29+). Long-pressing home / the assist gesture opens this
 *  activity, which immediately hands off to MainActivity and asks it
 *  to start a conversation right away. It shows nothing itself.
 *
 *  Declared in AndroidManifest.xml with the android.intent.action.ASSIST
 *  intent-filter. Without it, RoleManager reports the assistant role
 *  as unavailable for this app. */
class AssistActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra("jarvis_start_conversation", true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(intent)
        finish()
    }
}
