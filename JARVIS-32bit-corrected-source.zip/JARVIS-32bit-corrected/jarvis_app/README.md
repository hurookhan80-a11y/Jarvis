# J.A.R.V.I.S — ARMv7 Flutter Android project

This is the corrected Flutter source project for the Android **32-bit ARMv7** target (`armeabi-v7a`). The Android application ID remains `com.jarvis.jarvis_app` so an update can retain the same package identity. This source archive does not include a signed APK or anyone's release keystore.

## Requirements

- Flutter SDK with Dart 3.14 or later (the original project notes used Flutter 3.50.0 / Dart 3.14.0)
- JDK 17
- Android SDK Platform 36 or later and Android Build Tools
- Android Gradle Plugin 9.3.1, Gradle 9.5.0, and Kotlin Gradle Plugin 2.4.20 (wrapper files can be generated with the bootstrap command below)

## Build on Windows

1. Install Flutter, Android Studio / Android SDK, and JDK 17.
2. Open a terminal in this `jarvis_app` folder.
3. Run:

```powershell
flutter doctor
flutter pub get
.\bootstrap_android.ps1
flutter build apk --release --target-platform android-arm
```

The output should be at `build\app\outputs\flutter-apk\app-release.apk`.

For a debug install:

```powershell
flutter run --debug -d <your-device-id> --target-platform android-arm
```

The bootstrap script writes machine-local `android/local.properties` and generates the Gradle 9.5.0 wrapper. If `gradle` is not on PATH, install Gradle 9.5.0 once or use Android Studio's Gradle tooling to generate the wrapper. Do not copy a wrapper JAR from an unrelated Gradle version.

## ARMv7 verification

The Android app Gradle configuration filters native builds to `armeabi-v7a`, with `minSdk 24`. Verify the finished APK before installing:

```bash
apkanalyzer apk summary build/app/outputs/flutter-apk/app-release.apk
unzip -l build/app/outputs/flutter-apk/app-release.apk | grep 'lib/armeabi-v7a/'
```

The APK should contain ARMv7 native libraries and should not require `arm64-v8a`. Test on a real 32-bit Android device; an x86_64 emulator with translation is not a substitute for a device test.

## Gemini setup and security

- Default model: `gemini-3.8-flash` (the original `gemini-2.0-flash` was shut down on June 1, 2026).
- No Gemini key is embedded in the source or APK.
- Open Settings in Jarvis and enter your own Gemini API key.
- The key is encrypted with AES/GCM using a key generated in Android Keystore; only the encrypted payload is stored in app-private preferences.
- `android:allowBackup="false"` prevents Android cloud backup from copying the encrypted key without its device-bound keystore key.
- A key embedded in a mobile app cannot be treated as a server-grade secret: a determined attacker controlling a rooted/compromised device can inspect app memory while the app is running. For a public production app, proxy Gemini requests through a secured backend and enforce per-user quotas.

Gemini requests use Google’s `generateContent` REST endpoint through the maintained `http` package, with the API key sent in the `x-goog-api-key` header. This avoids the archived `google_generative_ai` Dart SDK. Google recommends Firebase AI Logic for managed Flutter integrations; this project uses direct REST because the original app lets each user supply their own Gemini API key. For a multi-user public release, consider Firebase AI Logic or a secured backend with authentication, quotas, and abuse controls.

## Voice / timer / alarm limitations

- Microphone permission and an Android speech-recognition service are required.
- Wake-word listening is best-effort while the app is open and the device permits microphone access. Android may suspend microphone use when the app is backgrounded or the screen is off. This project does **not** claim always-on background wake-word detection.
- The in-app countdown is process-local. Keep Jarvis open; force-stopping or killing the app can stop the countdown. It is not an exact, reboot-persistent system alarm.
- Alarm requests use Android's standard `ACTION_SET_ALARM` intent. The Clock app must support that intent, and the user may need to confirm/save the alarm there.
- Weather opens a browser search; it is not a native live-weather data integration.
- App package names differ between manufacturers and Android builds; some app shortcuts may need device-specific package mapping.

## Signing a production update

For a production APK, place a private `key.properties` file at `android/key.properties` (never commit it) with:

```properties
storePassword=YOUR_STORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=YOUR_KEY_ALIAS
storeFile=../path/to/your-upload-keystore.jks
```

Use the exact original release keystore if this APK must update an already-installed build. If that keystore is lost, Android will not accept the new APK as an in-place update; users would need to uninstall the old app (which can erase app data) before installing a differently signed build. The default release fallback uses the local debug signing key for test installs only and is not suitable for distribution.

## Project layout

- `lib/main.dart` — Flutter UI, speech, Gemini chat, app launch, timer, and alarm commands
- `android/app/src/main/kotlin/.../MainActivity.kt` — Android Keystore-backed encrypted API-key storage channel
- `android/app/src/main/AndroidManifest.xml` — permissions, launcher activity, and package visibility queries
- `assets/sounds/` — generated short original startup and wake tones
- `test/` — lightweight tests

## Tests

Run:

```bash
flutter analyze
flutter test
```

Then build and test on the target ARMv7 phone. This archive was prepared without a Flutter/Android SDK toolchain in the editing environment, so a successful Gradle build, APK install, microphone test, and real-device crash-free launch have **not** been claimed. Those checks must be completed on a machine with the required toolchain and target device.
