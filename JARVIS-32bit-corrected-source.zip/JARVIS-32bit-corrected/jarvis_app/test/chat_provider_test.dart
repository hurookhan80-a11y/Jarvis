// Phase 6 (v1.1.0) — F18 provider interface + fallback trigger logic.
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:jarvis_app/chat_provider.dart';
import 'package:jarvis_app/gemini_client.dart';

/// A controllable provider double: answers with [answer], or throws
/// [error] when set.
class FakeChatProvider extends ChatProvider {
  FakeChatProvider({
    required this.providerName,
    this.answer,
    this.error,
  });

  final String providerName;
  String? answer;
  ChatProviderException? error;
  var sendMessageCalls = 0;
  var cancelled = false;
  var disposed = false;

  @override
  String get name => providerName;

  @override
  Future<String> sendMessage({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  }) async {
    sendMessageCalls++;
    final thrown = error;
    if (thrown != null) throw thrown;
    return answer ?? '';
  }

  @override
  Stream<String> sendMessageStream({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  }) async* {
    yield answer ?? '';
  }

  @override
  void cancel() => cancelled = true;

  @override
  void dispose() => disposed = true;
}

void main() {
  group('isTransientProviderError', () {
    test('429, 503, overload, high demand and timeouts are transient', () {
      expect(isTransientProviderError('Gemini returned HTTP 429.'), isTrue);
      expect(isTransientProviderError('The model is overloaded.'), isTrue);
      expect(isTransientProviderError('high demand, try again later'),
          isTrue);
      expect(
          isTransientProviderError('Gemini timed out. Check your connection.'),
          isTrue);
      expect(isTransientProviderError('Service unavailable (503).'), isTrue);
    });

    test('auth and empty-answer errors are not transient', () {
      expect(isTransientProviderError('API key not valid'), isFalse);
      expect(isTransientProviderError('Gemini returned no readable text.'),
          isFalse);
      expect(isTransientProviderError(''), isFalse);
    });
  });

  group('mergeSystemInstruction', () {
    test('empty extra context leaves the base untouched', () {
      expect(mergeSystemInstruction('base', null), 'base');
      expect(mergeSystemInstruction('base', '  '), 'base');
    });

    test('extra context is appended after a blank line', () {
      expect(
        mergeSystemInstruction('base', 'extra'),
        'base\n\nextra',
      );
    });
  });

  group('GeminiChatProvider', () {
    test('passes the merged system instruction and history to Gemini',
        () async {
      var seenBody = <String, dynamic>{};
      final mock = MockClient((request) async {
        seenBody = jsonDecode(request.body) as Map<String, dynamic>;
        return http.Response(
          jsonEncode({
            'candidates': [
              {
                'content': {
                  'parts': [
                    {'text': 'Hello, sir.'},
                  ],
                },
              },
            ],
          }),
          200,
          headers: {'content-type': 'application/json'},
        );
      });

      final provider = GeminiChatProvider(
        apiKey: 'test-key',
        modelName: 'gemini-3.8-flash',
        systemInstruction: 'base instruction',
        httpClient: mock,
      );
      final answer = await provider.sendMessage(
        message: 'Hi',
        history: const [ChatMessage(role: 'model', text: 'Welcome back.')],
        extraSystemContext: 'Remember: exam on 5 December.',
      );
      expect(answer, 'Hello, sir.');
      final instruction =
          seenBody['systemInstruction']['parts'][0]['text'] as String;
      expect(instruction, contains('base instruction'));
      expect(instruction, contains('exam on 5 December'));
      mock.close();
      provider.dispose();
    });

    test('maps a Gemini 429 to a fallback-eligible error', () async {
      final mock = MockClient(
        (request) async => http.Response(
          jsonEncode({
            'error': {'message': 'Resource exhausted (429).'},
          }),
          429,
        ),
      );
      final provider = GeminiChatProvider(
        apiKey: 'test-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      try {
        await provider.sendMessage(message: 'Hi', history: const []);
        fail('expected a ChatProviderException');
      } on ChatProviderException catch (e) {
        expect(e.fallbackEligible, isTrue);
        expect(e.message, contains('429'));
      }
      mock.close();
      provider.dispose();
    });

    test('maps a Gemini 400 to a non-eligible error', () async {
      final mock = MockClient(
        (request) async => http.Response(
          jsonEncode({
            'error': {'message': 'API key not valid'},
          }),
          400,
        ),
      );
      final provider = GeminiChatProvider(
        apiKey: 'bad-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      try {
        await provider.sendMessage(message: 'Hi', history: const []);
        fail('expected a ChatProviderException');
      } on ChatProviderException catch (e) {
        expect(e.fallbackEligible, isFalse);
      }
      mock.close();
      provider.dispose();
    });
  });

  group('FallbackChatProvider', () {
    test('primary success never touches the fallback', () async {
      final primary = FakeChatProvider(
        providerName: 'Gemini',
        answer: 'Primary answer.',
      );
      final fallback = FakeChatProvider(
        providerName: 'NVIDIA NIM',
        answer: 'Fallback answer.',
      );
      final router =
          FallbackChatProvider(primary: primary, fallback: fallback);
      final answer =
          await router.sendMessage(message: 'Hi', history: const []);
      expect(answer, 'Primary answer.');
      expect(router.lastAnswerWasFallback, isFalse);
      expect(fallback.sendMessageCalls, 0);
      router.dispose();
    });

    test('transient primary failure falls back and flags the answer',
        () async {
      final primary = FakeChatProvider(
        providerName: 'Gemini',
        error: const ChatProviderException(
          'The model is overloaded.',
          fallbackEligible: true,
        ),
      );
      final fallback = FakeChatProvider(
        providerName: 'NVIDIA NIM',
        answer: 'Fallback answer.',
      );
      final router =
          FallbackChatProvider(primary: primary, fallback: fallback);
      final answer =
          await router.sendMessage(message: 'Hi', history: const []);
      expect(answer, 'Fallback answer.');
      expect(router.lastAnswerWasFallback, isTrue);
      expect(fallback.sendMessageCalls, 1);
      router.dispose();
    });

    test('non-transient primary failure does not fall back', () async {
      final primary = FakeChatProvider(
        providerName: 'Gemini',
        error: const ChatProviderException(
          'API key not valid',
          fallbackEligible: false,
        ),
      );
      final fallback = FakeChatProvider(
        providerName: 'NVIDIA NIM',
        answer: 'Fallback answer.',
      );
      final router =
          FallbackChatProvider(primary: primary, fallback: fallback);
      await expectLater(
        () => router.sendMessage(message: 'Hi', history: const []),
        throwsA(isA<ChatProviderException>().having(
          (e) => e.message,
          'message',
          'API key not valid',
        )),
      );
      expect(router.lastAnswerWasFallback, isFalse);
      expect(fallback.sendMessageCalls, 0);
      router.dispose();
    });

    test('no fallback configured rethrows the primary error', () async {
      final primary = FakeChatProvider(
        providerName: 'Gemini',
        error: const ChatProviderException(
          'The model is overloaded.',
          fallbackEligible: true,
        ),
      );
      final router = FallbackChatProvider(primary: primary);
      expect(router.fallbackAvailable, isFalse);
      await expectLater(
        () => router.sendMessage(message: 'Hi', history: const []),
        throwsA(isA<ChatProviderException>()),
      );
      expect(router.lastAnswerWasFallback, isFalse);
      router.dispose();
    });

    test('fallback failure reports both errors', () async {
      final primary = FakeChatProvider(
        providerName: 'Gemini',
        error: const ChatProviderException(
          'The model is overloaded.',
          fallbackEligible: true,
        ),
      );
      final fallback = FakeChatProvider(
        providerName: 'NVIDIA NIM',
        error: const ChatProviderException('NVIDIA NIM returned HTTP 401.'),
      );
      final router =
          FallbackChatProvider(primary: primary, fallback: fallback);
      await expectLater(
        () => router.sendMessage(message: 'Hi', history: const []),
        throwsA(isA<ChatProviderException>().having(
          (e) => e.message,
          'message',
          contains('fallback model also failed'),
        )),
      );
      expect(router.lastAnswerWasFallback, isFalse);
      router.dispose();
    });

    test('the flag resets on the next primary success', () async {
      final primary = FakeChatProvider(
        providerName: 'Gemini',
        error: const ChatProviderException(
          'The model is overloaded.',
          fallbackEligible: true,
        ),
      );
      final fallback = FakeChatProvider(
        providerName: 'NVIDIA NIM',
        answer: 'Fallback answer.',
      );
      final router =
          FallbackChatProvider(primary: primary, fallback: fallback);
      await router.sendMessage(message: 'Hi', history: const []);
      expect(router.lastAnswerWasFallback, isTrue);
      primary.error = null;
      primary.answer = 'Primary is back.';
      final answer =
          await router.sendMessage(message: 'Hi', history: const []);
      expect(answer, 'Primary is back.');
      expect(router.lastAnswerWasFallback, isFalse);
      router.dispose();
    });

    test('cancel and dispose reach both providers', () {
      final primary = FakeChatProvider(providerName: 'Gemini');
      final fallback = FakeChatProvider(providerName: 'NVIDIA NIM');
      final router =
          FallbackChatProvider(primary: primary, fallback: fallback);
      router.cancel();
      expect(primary.cancelled, isTrue);
      expect(fallback.cancelled, isTrue);
      router.dispose();
      expect(primary.disposed, isTrue);
      expect(fallback.disposed, isTrue);
    });
  });

  group('ChatMessage', () {
    test('round-trips through GeminiChatMessage', () {
      const message = ChatMessage(role: 'model', text: 'Hello.');
      expect(message.toGemini().role, 'model');
      expect(message.toGemini().text, 'Hello.');
      expect(
        ChatMessage.fromGemini(
          const GeminiChatMessage(role: 'user', text: 'Hi'),
        ).role,
        'user',
      );
    });
  });
}
