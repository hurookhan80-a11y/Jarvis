// Phase 7 (v1.1.0) — F32–F39: pure helpers for air gestures, macros,
// message drafting, form drafting, the multi-task queue, commute
// parsing, the local router, and the Shizuku allowlist.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/air_gesture_service.dart';
import 'package:jarvis_app/commute_service.dart';
import 'package:jarvis_app/form_draft_service.dart';
import 'package:jarvis_app/local_router.dart';
import 'package:jarvis_app/macro_service.dart';
import 'package:jarvis_app/message_draft_service.dart';
import 'package:jarvis_app/multi_task_service.dart';
import 'package:jarvis_app/shizuku_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  group('WaveDetector (F32)', () {
    test('near then far within the window is one wave', () {
      final detector = WaveDetector();
      final start = DateTime(2026, 11, 22, 20, 0, 0);
      expect(detector.onEvent(true, start), isFalse);
      expect(
        detector.onEvent(false, start.add(const Duration(milliseconds: 400))),
        isTrue,
      );
    });

    test('far without a near first is not a wave', () {
      final detector = WaveDetector();
      expect(detector.onEvent(false, DateTime.now()), isFalse);
    });

    test('near then far after the window is not a wave', () {
      final detector = WaveDetector();
      final start = DateTime(2026, 11, 22, 20, 0, 0);
      detector.onEvent(true, start);
      expect(
        detector.onEvent(false, start.add(const Duration(seconds: 5))),
        isFalse,
      );
    });

    test('a second wave inside the cooldown is ignored', () {
      final detector = WaveDetector();
      final start = DateTime(2026, 11, 22, 20, 0, 0);
      detector.onEvent(true, start);
      expect(detector.onEvent(false, start.add(const Duration(milliseconds: 300))), isTrue);
      detector.onEvent(true, start.add(const Duration(milliseconds: 500)));
      expect(
        detector.onEvent(false, start.add(const Duration(milliseconds: 800))),
        isFalse,
      );
    });
  });

  group('macro parsers + store (F33)', () {
    test('record macro extracts the name, or empty when unnamed', () {
      expect(parseMacroRecordName('record macro morning routine'), 'morning routine');
      expect(parseMacroRecordName('start recording macro study time'), 'study time');
      expect(parseMacroRecordName('record macro'), isNull);
      expect(parseMacroRecordName('run morning routine'), isNull);
    });

    test('run macro extracts the name and drops the article', () {
      expect(parseMacroRunName('run morning routine'), 'morning routine');
      expect(parseMacroRunName('run macro morning routine'), 'morning routine');
      expect(parseMacroRunName('run the morning routine'), 'morning routine');
      expect(parseMacroRunName('run'), isNull);
    });

    test('delete macro extracts the name', () {
      expect(parseMacroDeleteName('delete macro morning routine'), 'morning routine');
      expect(parseMacroDeleteName('remove macro study'), 'study');
      expect(parseMacroDeleteName('delete macro'), isNull);
    });

    test('findMacro matches case-insensitively; store round-trips', () async {
      const service = MacroService();
      await service.saveMacro(
        Macro(
          name: 'Morning Routine',
          steps: const ['what time is it', 'show my expenses'],
          createdAt: DateTime(2026, 11, 22),
        ),
      );
      final macros = await service.loadMacros();
      expect(macros.length, 1);
      expect(findMacro(macros, 'morning routine')?.steps.length, 2);
      expect(findMacro(macros, 'evening'), isNull);
      expect(await service.deleteMacro('MORNING ROUTINE'), isTrue);
      expect(await service.loadMacros(), isEmpty);
      expect(await service.deleteMacro('morning routine'), isFalse);
    });

    test('parseStoredMacros drops malformed entries', () {
      expect(parseStoredMacros('not json'), isEmpty);
      expect(
        parseStoredMacros('[{"name":"","steps":["x"]},{"name":"ok","steps":[]}]'),
        isEmpty,
      );
      expect(
        parseStoredMacros('[{"name":"ok","steps":["a"],"createdAt":"2026-11-22T00:00:00.000"}]').length,
        1,
      );
    });
  });

  group('message draft parsing + URIs (F34)', () {
    test('message Ami that ... splits recipient and body', () {
      final request = parseMessageDraft("message Ami that I'll be late");
      expect(request, isNotNull);
      expect(request!.recipientName, 'Ami');
      expect(request.body, "I'll be late");
      expect(request.channel, DraftChannel.unspecified);
    });

    test('whatsapp / sms channel words are honoured', () {
      final wa = parseMessageDraft('whatsapp Ami that I am on my way');
      expect(wa!.channel, DraftChannel.whatsapp);
      expect(wa.recipientName, 'Ami');
      final sms = parseMessageDraft('sms Ami: I will be late');
      expect(sms!.channel, DraftChannel.sms);
      expect(sms.body, 'I will be late');
    });

    test('text Ami I will be late splits on the first word', () {
      final request = parseMessageDraft('text Ami I will be late');
      expect(request!.recipientName, 'Ami');
      expect(request.body, 'I will be late');
    });

    test('message Ami with no text leaves the body empty', () {
      final request = parseMessageDraft('message Ami');
      expect(request!.recipientName, 'Ami');
      expect(request.body, isEmpty);
    });

    test('non-draft utterances return null', () {
      expect(parseMessageDraft('call Ami'), isNull);
      expect(parseMessageDraft('message'), isNull);
      expect(parseMessageDraft('what is the time'), isNull);
    });

    test('SMS and WhatsApp URIs carry the prefilled text, nothing is sent', () {
      final sms = buildSmsDraftUri('03001234567', "I'll be late");
      expect(sms.scheme, 'sms');
      expect(sms.queryParameters['body'], "I'll be late");
      final wa = buildWhatsAppDraftUri('03001234567', "I'll be late");
      expect(wa.toString().startsWith('https://wa.me/923001234567?text='), isTrue);
      expect(wa.toString(), contains(Uri.encodeComponent("I'll be late")));
    });

    test('matchDraftContacts matches by name and by bare number', () {
      const all = [
        DraftContact(name: 'Ami', number: '03001234567'),
        DraftContact(name: 'Ami Jan', number: '03007654321'),
      ];
      expect(matchDraftContacts(all, 'ami').length, 2);
      // "ami jan" matches both "Ami" and "Ami Jan" (substring either
      // way, like voice calling) — main.dart asks which one instead
      // of guessing.
      expect(matchDraftContacts(all, 'ami jan').length, 2);
      expect(matchDraftContacts(all, '03001234567').length, 1);
      expect(matchDraftContacts(all, 'nobody'), isEmpty);
    });
  });

  group('form drafting (F35)', () {
    test('parseFormStart picks the leave template', () {
      expect(parseFormStart('help me fill a leave application')?.id, 'leave');
      expect(parseFormStart('fill a form')?.id, 'general');
      expect(parseFormStart('what is the time'), isNull);
    });

    test('renderFormDraft fills every field and names gaps', () {
      final template = findFormTemplate('leave')!;
      final rendered = renderFormDraft(template, {
        'name': 'Habib Ullah',
        'dates': '24th to 26th November',
        'reason': 'family function',
      });
      expect(rendered, contains('Habib Ullah'));
      expect(rendered, contains('24th to 26th November'));
      expect(rendered, contains('family function'));
      expect(rendered, contains('Application for leave'));
      final gapped = renderFormDraft(template, {'name': 'Habib Ullah'});
      expect(gapped, contains('[not given]'));
    });

    test('form drafts round-trip through the store', () async {
      const service = FormDraftService();
      final saved = await service.saveDraft('Leave application', 'Dear Sir, ...');
      expect((await service.loadDrafts()).length, 1);
      expect(await service.deleteDraft(saved.id), isTrue);
      expect(await service.loadDrafts(), isEmpty);
    });
  });

  group('multi-task queue (F36)', () {
    test('explicit do-these-things list splits on commas and and', () {
      expect(
        splitCompoundSteps('do these three things: open WhatsApp, remind me at 7 to study, and tell me the time'),
        ['open WhatsApp', 'remind me at 7 to study', 'tell me the time'],
      );
      expect(
        splitCompoundSteps('do these things: open WhatsApp and tell me the time'),
        ['open WhatsApp', 'tell me the time'],
      );
    });

    test('implicit A and B splits only when both halves look like commands', () {
      expect(
        splitCompoundSteps('open WhatsApp and remind me at 7 to study'),
        ['open WhatsApp', 'remind me at 7 to study'],
      );
      expect(splitCompoundSteps('fish and chips'), isNull);
      expect(splitCompoundSteps('what is the time'), isNull);
    });

    test('a message body containing "and" is not split into a queue', () {
      expect(
        splitCompoundSteps("message Ami that I'll be late and call me"),
        isNull,
      );
      expect(splitCompoundSteps('how long to FMU and back'), isNull);
    });

    test('runTaskQueue continues after a failure', () async {
      final results = await runTaskQueue(
        ['step one', 'step two', 'step three'],
        (step) async => step == 'step two'
            ? const StepResult.failed('step two', 'could not open it')
            : StepResult.done(step),
      );
      expect(results.length, 3);
      expect(results[0].succeeded, isTrue);
      expect(results[1].succeeded, isFalse);
      expect(results[2].succeeded, isTrue);
      expect(formatQueueReport(results), contains('2 of 3 steps done'));
      expect(formatQueueReport(results), contains('failed: could not open it'));
      expect(formatQueueSpokenSummary(results), contains('1 of 3 steps failed'));
    });

    test('all-done report says so plainly', () {
      final results = [StepResult.done('open WhatsApp'), StepResult.done('tell me the time')];
      expect(formatQueueReport(results), contains('All 2 steps done.'));
    });
  });

  group('commute parsing (F37)', () {
    test('parseCommuteDestination extracts destination and mode', () {
      final driving = parseCommuteDestination('how long to Faisalabad Medical University?');
      expect(driving?.destination, 'Faisalabad Medical University');
      expect(driving?.mode, CommuteMode.driving);
      final walking = parseCommuteDestination('how long does it take to walk to FMU?');
      expect(walking?.mode, CommuteMode.walking);
      expect(parseCommuteDestination('what is the time'), isNull);
      expect(parseCommuteDestination('how long to bake a cake'), isNotNull);
    });

    test('parseNominatimResponse takes the first result', () {
      const raw = '[{"lat":"31.4504","lon":"73.1350","display_name":"Faisalabad Medical University, Faisalabad"}]';
      final point = parseNominatimResponse(raw);
      expect(point?.lat, 31.4504);
      expect(point?.lon, 73.1350);
      expect(parseNominatimResponse('[]'), isNull);
      expect(parseNominatimResponse('not json'), isNull);
    });

    test('parseOsrmResponse reads distance and duration', () {
      const raw = '{"code":"Ok","routes":[{"distance":12500,"duration":1500}]}';
      final route = parseOsrmResponse(raw, CommuteMode.driving);
      expect(route?.distanceKm, 12.5);
      expect(route?.durationMinutes, 25);
      expect(route?.distanceText, '12.5 km');
      expect(route?.etaText, '25 min');
      expect(parseOsrmResponse('{"code":"NoRoute","routes":[]}', CommuteMode.driving), isNull);
    });

    test('formatRouteSummary states no live traffic', () {
      final service = CommuteService();
      final summary = service.formatRouteSummary(
        fromLabel: 'your location',
        toLabel: 'Faisalabad Medical University',
        route: const RouteSummary(distanceKm: 12.5, durationMinutes: 25, mode: CommuteMode.driving),
      );
      expect(summary, contains('12.5 km'));
      expect(summary, contains('25 min'));
      expect(summary, contains('No live traffic'));
    });
  });

  group('local router (F38)', () {
    test('instant answers never reach Gemini', () {
      expect(classifyCommand('what time is it'), LocalRoute.time);
      expect(classifyCommand('what is the date today'), LocalRoute.date);
      expect(classifyCommand('what is the weather'), LocalRoute.weather);
    });

    test('tool commands route locally', () {
      expect(classifyCommand('set timer for 5 minutes'), LocalRoute.timer);
      expect(classifyCommand('call Ami'), LocalRoute.call);
      expect(classifyCommand('remind me at 7 to study'), LocalRoute.reminder);
      expect(classifyCommand('open WhatsApp'), LocalRoute.openApp);
      expect(classifyCommand('spent 500 on groceries'), LocalRoute.finance);
      expect(classifyCommand('lock phone'), LocalRoute.deviceControl);
      expect(classifyCommand('remember my exam is in December'), LocalRoute.memory);
    });

    test('Phase 7b commands route to their handlers', () {
      expect(classifyCommand('record macro morning routine'), LocalRoute.macro);
      expect(classifyCommand('run morning routine'), LocalRoute.macro);
      expect(classifyCommand("message Ami that I'll be late"), LocalRoute.messageDraft);
      expect(classifyCommand('help me fill a leave application'), LocalRoute.formDraft);
      expect(classifyCommand('how long to Faisalabad Medical University'), LocalRoute.commute);
      expect(classifyCommand('force stop WhatsApp'), LocalRoute.shizuku);
      expect(classifyCommand('open WhatsApp and remind me at 7 to study'), LocalRoute.multiTask);
    });

    test('anything else falls through to Gemini', () {
      expect(classifyCommand('explain photosynthesis'), LocalRoute.gemini);
      expect(classifyCommand('why is the sky blue'), LocalRoute.gemini);
      expect(isLocalCommand('what time is it'), isTrue);
      expect(isLocalCommand('explain photosynthesis'), isFalse);
    });
  });

  group('Shizuku allowlist (F39)', () {
    test('force-stop builds only for valid packages', () {
      expect(
        buildShizukuCommand(ShizukuControl.forceStopApp, package: 'com.whatsapp'),
        'am force-stop com.whatsapp',
      );
      expect(buildShizukuCommand(ShizukuControl.forceStopApp, package: 'com.whatsapp; rm -rf /'), isNull);
      expect(buildShizukuCommand(ShizukuControl.forceStopApp, package: 'WhatsApp'), isNull);
      expect(buildShizukuCommand(ShizukuControl.forceStopApp, package: 'com.jarvis.jarvis_app'), isNull);
      expect(buildShizukuCommand(ShizukuControl.forceStopApp, package: 'com.android.systemui'), isNull);
    });

    test('mobile data toggle builds only with a bool', () {
      expect(buildShizukuCommand(ShizukuControl.toggleMobileData, enable: true), 'svc data enable');
      expect(buildShizukuCommand(ShizukuControl.toggleMobileData, enable: false), 'svc data disable');
      expect(buildShizukuCommand(ShizukuControl.toggleMobileData), isNull);
    });

    test('parseShizukuCommand reads voice controls', () {
      final force = parseShizukuCommand('force stop WhatsApp');
      expect(force?.control, ShizukuControl.forceStopApp);
      expect(force?.appName, 'whatsapp');
      final data = parseShizukuCommand('turn mobile data off');
      expect(data?.control, ShizukuControl.toggleMobileData);
      expect(data?.enable, isFalse);
      expect(parseShizukuCommand('force stop'), isNull);
      expect(parseShizukuCommand('what is the time'), isNull);
    });
  });
}
