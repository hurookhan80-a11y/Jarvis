// Phase 7 (v1.1.0) — F30 network audit: ARP parsing, IP
// formatting, signal labels.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/network_audit.dart';

void main() {
  group('parseArpTable', () {
    test('parses real devices, skips header and zero MACs', () {
      const table = '''
IP address       HW type     Flags       HW address            Mask     Device
192.168.1.1      0x1         0x2         aa:bb:cc:dd:ee:ff     *        wlan0
192.168.1.5      0x1         0x2         00:00:00:00:00:00     *        wlan0
192.168.1.10     0x1         0x2         11:22:33:44:55:66     *        wlan0
''';
      final devices = parseArpTable(table);
      expect(devices.length, 2);
      expect(devices[0].ip, '192.168.1.1');
      expect(devices[0].mac, 'aa:bb:cc:dd:ee:ff');
      expect(devices[0].device, 'wlan0');
      expect(devices[1].ip, '192.168.1.10');
    });

    test('empty or garbage input returns []', () {
      expect(parseArpTable(''), isEmpty);
      expect(parseArpTable('not an arp table'), isEmpty);
    });
  });

  group('formatIpv4', () {
    test('little-endian WifiInfo int to dotted address', () {
      // 192.168.1.10 as Android reports it (little-endian).
      final ip = (10 << 24) | (1 << 16) | (168 << 8) | 192;
      expect(formatIpv4(ip), '192.168.1.10');
    });

    test('0.0.0.0', () {
      expect(formatIpv4(0), '0.0.0.0');
    });
  });

  group('signalStrengthLabel', () {
    test('RSSI bands', () {
      expect(signalStrengthLabel(-40), 'Excellent');
      expect(signalStrengthLabel(-55), 'Good');
      expect(signalStrengthLabel(-65), 'Fair');
      expect(signalStrengthLabel(-85), 'Weak');
    });
  });

  group('WifiInfo.fromMap', () {
    test('formats the int IP and keeps SSID/RSSI', () {
      final ip = (10 << 24) | (1 << 16) | (168 << 8) | 192;
      final info = WifiInfo.fromMap(<String, dynamic>{
        'ssid': 'HomeWifi',
        'ipAddress': ip,
        'rssi': -55,
      });
      expect(info.ssid, 'HomeWifi');
      expect(info.ipAddress, '192.168.1.10');
      expect(info.rssi, -55);
      expect(info.ssidKnown, isTrue);
    });

    test('unknown SSID is not "known"', () {
      final info = WifiInfo.fromMap(<String, dynamic>{
        'ssid': '<unknown ssid>',
        'ipAddress': 0,
        'rssi': 0,
      });
      expect(info.ssidKnown, isFalse);
    });
  });
}
