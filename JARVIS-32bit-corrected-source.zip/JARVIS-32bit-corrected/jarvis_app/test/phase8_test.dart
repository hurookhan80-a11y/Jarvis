// Phase 8 (v1.1.0) — F40 agent loop verify/report, F41 accessibility
// parsing, F42 confirmation state machine.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/accessibility_service.dart';
import 'package:jarvis_app/agent_loop.dart';
import 'package:jarvis_app/confirmation_gate.dart';
import 'package:jarvis_app/multi_task_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  group('agent loop planning + DIRECT fast path (F40)', () {
    test('multi-step requests are recognised; plain Q&A is direct', () {
      expect(
        isMultiStepRequest('open WhatsApp and remind me at 7 to study'),
        isTrue,
      );
      expect(
        isMultiStepRequest('do these things: open WhatsApp and tell me the time'),
        isTrue,
      );
      expect(isMultiStepRequest('what is the time'), isFalse);
      expect(isMultiStepRequest('explain photosynthesis'), isFalse);
      expect(isDirectFastPath('explain photosynthesis'), isTrue);
      expect(isDirectFastPath('why is the sky blue'), isTrue);
      expect(
        isDirectFastPath('open WhatsApp and remind me at 7 to study'),
        isFalse,
      );
      expect(isDirectFastPath('call Ami'), isFalse);
      expect(isDirectFastPath('message Ami that I am late'), isFalse);
    });

    test('planAgentSteps splits a compound command into its steps', () {
      expect(
        planAgentSteps(
          'do these three things: open WhatsApp, remind me at 7 to study, and tell me the time',
        ),
        ['open whatsapp', 'remind me at 7 to study', 'tell me the time'],
      );
      expect(planAgentSteps('what time is it'), ['what time is it']);
    });
  });

  group('agent loop verification (F40)', () {
    test('a reminder step counts only when the reminder was set', () {
      expect(
        verifyAgentStep(
          'remind me at 7 to study',
          ['Reminder set for 7:00 PM: study'],
        ).succeeded,
        isTrue,
      );
      expect(
        verifyAgentStep(
          'remind me at 7 to study',
          ['I could not understand the reminder time.'],
        ).succeeded,
        isFalse,
      );
      // Ran, but no evidence it was scheduled: never assumed done.
      expect(
        verifyAgentStep('remind me at 7 to study', ['Okay.']).succeeded,
        isFalse,
      );
    });

    test('a call step counts only when the dialer opened', () {
      expect(
        verifyAgentStep('call Ami', ['Calling Ami…']).succeeded,
        isTrue,
      );
      expect(
        verifyAgentStep('call Ami', ['I could not open the dialer.'])
            .succeeded,
        isFalse,
      );
    });

    test('an alarm step counts when the Clock app opened for confirmation', () {
      expect(
        verifyAgentStep(
          'set alarm for 7 am',
          ['Opening your clock app to create the alarm for 7:00 AM. Confirm and save it in the Clock app.'],
        ).succeeded,
        isTrue,
      );
      expect(
        verifyAgentStep(
          'set alarm for 7 am',
          ['I could not open a compatible Clock app.'],
        ).succeeded,
        isFalse,
      );
    });

    test('an open-app step counts only when the app opened', () {
      expect(
        verifyAgentStep('open WhatsApp', ['Opening WhatsApp']).succeeded,
        isTrue,
      );
      expect(
        verifyAgentStep('open WhatsApp', ["I couldn't open WhatsApp."])
            .succeeded,
        isFalse,
      );
    });

    test('a message-draft step counts only when the draft was shown', () {
      expect(
        verifyAgentStep(
          'message Ami that I am late',
          ['Draft for Ami (WhatsApp):\n"I am late"'],
        ).succeeded,
        isTrue,
      );
      expect(
        verifyAgentStep(
          'message Ami that I am late',
          ['I could not find a contact named "Ami".'],
        ).succeeded,
        isFalse,
      );
    });

    test('no result at all is a failure, never a silent success', () {
      final result = verifyAgentStep('tell me the time', []);
      expect(result.succeeded, isFalse);
      expect(result.reason, contains('No result'));
    });

    test('a failure marker anywhere in the step output fails the step', () {
      final result = verifyAgentStep(
        'tell me the time',
        ['The time is 8:00 PM.', 'I could not reach the network.'],
      );
      expect(result.succeeded, isFalse);
      expect(result.reason, contains('could not'));
    });
  });

  group('agent loop runner + honest report (F40)', () {
    test('runAgentLoop logs every step and continues after a failure',
        () async {
      final seen = <AgentStepLogEntry>[];
      final results = await runAgentLoop(
        ['open WhatsApp', 'remind me at 7 to study', 'tell me the time'],
        (step) async => step.startsWith('remind')
            ? const StepResult.failed(
                'remind me at 7 to study',
                'I could not understand the reminder time.',
              )
            : StepResult.done(step),
        onLog: seen.add,
      );
      expect(results.length, 3);
      expect(results.where((r) => r.succeeded).length, 2);
      // One running + one outcome entry per step.
      expect(seen.length, 6);
      expect(
        seen.where((e) => e.status == AgentStepStatus.failed).length,
        1,
      );
      expect(
        seen.where((e) => e.status == AgentStepStatus.done).length,
        2,
      );
      expect(
        formatAgentReport(results),
        'Done: open WhatsApp, tell me the time. '
        'Could not do: remind me at 7 to study because '
        'I could not understand the reminder time.',
      );
      expect(
        formatAgentSpokenSummary(results),
        contains('2 of 3 steps done'),
      );
    });

    test('all-done and all-failed reports say so plainly', () {
      expect(
        formatAgentReport([StepResult.done('open WhatsApp')]),
        'Done: open WhatsApp.',
      );
      expect(
        formatAgentReport(
          [const StepResult.failed('call Ami', 'I could not open the dialer.')],
        ),
        'Could not do: call Ami because I could not open the dialer.',
      );
      expect(formatAgentReport([]), 'Nothing was done.');
    });
  });

  group('confirmation gate state machine (F42)', () {
    const request = ConfirmationRequest(
      kind: ConfirmationKind.message,
      summary: 'Message Ami (WhatsApp)',
      detail: 'I am on my way',
    );
    final start = DateTime(2026, 11, 22, 20, 0, 0);

    test('pending → confirmed → executed', () {
      final gate = ConfirmationGate();
      gate.request(request, now: start);
      expect(gate.isPending, isTrue);
      expect(gate.confirm(now: start.add(const Duration(seconds: 5))),
          isTrue);
      expect(gate.state, ConfirmationState.confirmed);
      gate.markExecuted(true);
      expect(gate.state, ConfirmationState.executed);
    });

    test('a failed execution is reported as failed, not done', () {
      final gate = ConfirmationGate();
      gate.request(request, now: start);
      expect(gate.confirm(now: start), isTrue);
      gate.markExecuted(false);
      expect(gate.state, ConfirmationState.failed);
    });

    test('no answer within 15 s times out and cannot be confirmed after', () {
      final gate = ConfirmationGate();
      gate.request(request, now: start);
      expect(
        gate.isTimedOut(now: start.add(const Duration(seconds: 15))),
        isTrue,
      );
      expect(gate.isTimedOut(now: start.add(const Duration(seconds: 14))),
          isFalse);
      expect(
        gate.confirm(now: start.add(const Duration(seconds: 16))),
        isFalse,
      );
      expect(gate.state, ConfirmationState.timedOut);
    });

    test('the 15 s timer firing marks the request timed out', () {
      final gate = ConfirmationGate();
      gate.request(request, now: start);
      expect(gate.markTimedOut(), isTrue);
      expect(gate.state, ConfirmationState.timedOut);
      expect(gate.confirm(), isFalse);
    });

    test('saying no cancels; nothing executes afterwards', () {
      final gate = ConfirmationGate();
      gate.request(request, now: start);
      expect(gate.decline(), isTrue);
      expect(gate.state, ConfirmationState.cancelled);
      expect(gate.confirm(), isFalse);
      gate.markExecuted(true);
      expect(gate.state, ConfirmationState.cancelled);
    });

    test('confirm / decline / timeout with nothing pending do nothing', () {
      final gate = ConfirmationGate();
      expect(gate.confirm(), isFalse);
      expect(gate.decline(), isFalse);
      expect(gate.markTimedOut(), isFalse);
      expect(gate.state, ConfirmationState.idle);
    });

    test('a call request prompt names the action and the 15 s terms', () {
      const call = ConfirmationRequest(
        kind: ConfirmationKind.call,
        summary: 'Call Ami (03001234567)',
        detail: '03001234567',
      );
      expect(call.prompt, contains('Make this call?'));
      expect(call.prompt, contains('15 seconds'));
      expect(call.cancelledText, contains('was not made'));
      expect(request.prompt, contains('Send this message?'));
      expect(request.cancelledText, contains('was not sent'));
    });

    test('yes/no answers parse in English and Roman Urdu', () {
      expect(parseConfirmationAnswer('yes'), ConfirmationAnswer.yes);
      expect(parseConfirmationAnswer('haan'), ConfirmationAnswer.yes);
      expect(parseConfirmationAnswer('ji'), ConfirmationAnswer.yes);
      expect(parseConfirmationAnswer('yes, send it'), ConfirmationAnswer.yes);
      expect(parseConfirmationAnswer('send it'), ConfirmationAnswer.yes);
      expect(parseConfirmationAnswer('no'), ConfirmationAnswer.no);
      expect(parseConfirmationAnswer('nahi'), ConfirmationAnswer.no);
      expect(parseConfirmationAnswer('cancel'), ConfirmationAnswer.no);
      expect(parseConfirmationAnswer('maybe later'), ConfirmationAnswer.other);
      expect(parseConfirmationAnswer('what time is it'), ConfirmationAnswer.other);
    });
  });

  group('accessibility command parsing (F41)', () {
    test('tap / type / go back / scroll parse', () {
      expect(parseAccessibilityCommand('tap send')?.action,
          AccessibilityAction.tapByText);
      expect(parseAccessibilityCommand('tap send')?.text, 'send');
      expect(parseAccessibilityCommand('click ok')?.action,
          AccessibilityAction.tapByText);
      expect(parseAccessibilityCommand('type hello there')?.action,
          AccessibilityAction.typeText);
      expect(parseAccessibilityCommand('type hello there')?.text,
          'hello there');
      expect(parseAccessibilityCommand('go back')?.action,
          AccessibilityAction.goBack);
      expect(parseAccessibilityCommand('scroll down')?.action,
          AccessibilityAction.scrollDown);
      expect(parseAccessibilityCommand('scroll up')?.action,
          AccessibilityAction.scrollUp);
    });

    test('non-accessibility utterances return null', () {
      expect(parseAccessibilityCommand('what is the time'), isNull);
      expect(parseAccessibilityCommand('tap'), isNull);
      expect(parseAccessibilityCommand('type'), isNull);
      expect(parseAccessibilityCommand('open WhatsApp'), isNull);
    });

    test('the service toggle defaults OFF and round-trips', () async {
      final service = AccessibilityService();
      expect(await service.isEnabled(), isFalse);
      await service.setEnabled(true);
      expect(await service.isEnabled(), isTrue);
      await service.setEnabled(false);
      expect(await service.isEnabled(), isFalse);
    });

    test('an action with the toggle off is refused and logged', () async {
      final service = AccessibilityService();
      expect(await service.isEnabled(), isFalse);
      expect(
        await service.performAction(AccessibilityAction.tapByText, text: 'send'),
        isFalse,
      );
      expect(service.log.length, 1);
      expect(service.log.first.succeeded, isFalse);
      expect(service.log.first.reason, contains('switched off'));
    });

    test('log lines name the action and its outcome', () {
      final entry = AccessibilityActionLogEntry(
        action: AccessibilityAction.tapByText,
        detail: 'send',
        succeeded: true,
        reason: '',
        at: DateTime(2026, 11, 22, 20, 0, 0),
      );
      expect(entry.line, 'Tap "send" — done');
      final failed = AccessibilityActionLogEntry(
        action: AccessibilityAction.scrollDown,
        detail: '',
        succeeded: false,
        reason: 'The service could not do it on this screen.',
        at: DateTime(2026, 11, 22, 20, 0, 0),
      );
      expect(failed.line, contains('failed:'));
    });
  });
}
