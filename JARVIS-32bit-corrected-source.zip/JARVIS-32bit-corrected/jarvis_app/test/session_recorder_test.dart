import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/session_recorder.dart';

class _FakeAudioRecorder implements SessionAudioRecorder {
  _FakeAudioRecorder({this.failStart = false});

  final bool failStart;
  bool started = false;
  bool stopped = false;

  @override
  Future<void> dispose() async {}

  @override
  Future<bool> hasPermission() async => true;

  @override
  Future<void> start(String path) async {
    if (failStart) throw StateError('recorder unavailable');
    started = true;
    await File(path).writeAsString('fake-wav');
  }

  @override
  Future<String?> stop() async {
    stopped = true;
    return null;
  }
}

void main() {
  group('formatTranscriptLine', () {
    test('formats role and text with a timestamp', () {
      final line = formatTranscriptLine(
        DateTime(2026, 11, 22, 9, 5, 7),
        'user',
        'Hello Jarvis',
      );
      expect(line, '[09:05:07] USER: Hello Jarvis');
    });
  });

  group('SessionRecorder', () {
    late Directory tempDir;

    setUp(() {
      tempDir = Directory.systemTemp.createTempSync('jarvis_session_test');
    });

    tearDown(() {
      if (tempDir.existsSync()) tempDir.deleteSync(recursive: true);
    });

    test('writes the transcript file when audio recording works', () async {
      final fake = _FakeAudioRecorder();
      final recorder = SessionRecorder(
        audioRecorder: fake,
        directoryOverride: tempDir,
      );
      expect(await recorder.startSession(), isTrue);
      expect(recorder.isRecording, isTrue);
      expect(recorder.audioFailed, isFalse);
      recorder.addTranscript('user', 'What time is it?');
      recorder.addTranscript('jarvis', 'It is nine o clock.');
      await recorder.stopSession();
      expect(recorder.isRecording, isFalse);
      expect(fake.started, isTrue);
      expect(fake.stopped, isTrue);
      final transcriptPath = recorder.lastTranscriptPath;
      expect(transcriptPath, isNotNull);
      final contents = await File(transcriptPath!).readAsString();
      expect(contents, contains('USER: What time is it?'));
      expect(contents, contains('JARVIS: It is nine o clock.'));
    });

    test('falls back to transcript-only when audio recording fails', () async {
      final fake = _FakeAudioRecorder(failStart: true);
      final recorder = SessionRecorder(
        audioRecorder: fake,
        directoryOverride: tempDir,
      );
      expect(await recorder.startSession(), isTrue);
      expect(recorder.isRecording, isTrue);
      expect(recorder.audioFailed, isTrue);
      recorder.addTranscript('user', 'Hello Jarvis');
      await recorder.stopSession();
      expect(recorder.lastAudioPath, isNull);
      final transcriptPath = recorder.lastTranscriptPath;
      expect(transcriptPath, isNotNull);
      final contents = await File(transcriptPath!).readAsString();
      expect(contents, contains('USER: Hello Jarvis'));
    });

    test('ignores transcript lines when no session is recording', () async {
      final recorder = SessionRecorder(
        audioRecorder: _FakeAudioRecorder(),
        directoryOverride: tempDir,
      );
      recorder.addTranscript('user', 'Should not be recorded.');
      await recorder.stopSession();
      expect(recorder.lastTranscriptPath, isNull);
    });

    test('stopSession without a session is a no-op', () async {
      final recorder = SessionRecorder(
        audioRecorder: _FakeAudioRecorder(),
        directoryOverride: tempDir,
      );
      await recorder.stopSession();
      expect(recorder.isRecording, isFalse);
    });
  });
}
