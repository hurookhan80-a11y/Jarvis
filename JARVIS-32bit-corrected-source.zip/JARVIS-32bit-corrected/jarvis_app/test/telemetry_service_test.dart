// Phase 7 (v1.1.0) — F31 telemetry formatting.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/telemetry_service.dart';

void main() {
  group('formatUsageDuration', () {
    test('minutes only', () {
      expect(formatUsageDuration(45), '45m');
      expect(formatUsageDuration(0), '0m');
      expect(formatUsageDuration(-5), '0m');
    });

    test('hours and minutes', () {
      expect(formatUsageDuration(60), '1h');
      expect(formatUsageDuration(135), '2h 15m');
    });
  });

  group('formatBatterySummary', () {
    test('charging on USB', () {
      const info = BatteryInfo(
        level: 78,
        charging: true,
        plugged: 'USB',
      );
      expect(formatBatterySummary(info), '78% · Charging (USB)');
    });

    test('not charging', () {
      const info = BatteryInfo(
        level: 42,
        charging: false,
        plugged: 'Not plugged in',
      );
      expect(
        formatBatterySummary(info),
        '42% · Not charging (Not plugged in)',
      );
    });

    test('unknown level', () {
      const info = BatteryInfo(level: -1, charging: false, plugged: '');
      expect(formatBatterySummary(info), '? · Not charging');
    });
  });

  group('fromMap parsing', () {
    test('BatteryInfo.fromMap', () {
      final info = BatteryInfo.fromMap(<String, dynamic>{
        'level': 90,
        'charging': true,
        'plugged': 'AC charger',
      });
      expect(info.level, 90);
      expect(info.charging, isTrue);
      expect(info.plugged, 'AC charger');
    });

    test('AppUsageEntry.fromMap', () {
      final entry = AppUsageEntry.fromMap(<String, dynamic>{
        'package': 'com.whatsapp',
        'label': 'WhatsApp',
        'minutes': 95,
      });
      expect(entry.packageName, 'com.whatsapp');
      expect(entry.label, 'WhatsApp');
      expect(entry.minutes, 95);
    });
  });
}
