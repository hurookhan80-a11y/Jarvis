// v1.2.0 (G10) — assistant personality: defaults, JSON round-trip,
// tolerant parsing, and the system-instruction section.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/assistant_settings.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  group('AssistantSettings defaults', () {
    test('defaults are Jarvis / short / no instructions', () {
      const settings = AssistantSettings();
      expect(settings.displayName, 'Jarvis');
      expect(settings.tone, 'short');
      expect(settings.customInstructions, '');
      expect(settings.isDefault, isTrue);
    });

    test('any change makes the settings non-default', () {
      expect(
        const AssistantSettings(displayName: 'Friday').isDefault,
        isFalse,
      );
      expect(const AssistantSettings(tone: 'friendly').isDefault, isFalse);
      expect(
        const AssistantSettings(customInstructions: 'Be brief.').isDefault,
        isFalse,
      );
    });

    test('copyWith keeps the untouched fields', () {
      const settings = AssistantSettings(
        displayName: 'Friday',
        tone: 'formal',
        customInstructions: 'Use Urdu.',
      );
      final changed = settings.copyWith(tone: 'friendly');
      expect(changed.displayName, 'Friday');
      expect(changed.tone, 'friendly');
      expect(changed.customInstructions, 'Use Urdu.');
    });
  });

  group('parseAssistantSettings / encodeAssistantSettings', () {
    test('JSON round-trip keeps every field', () {
      const settings = AssistantSettings(
        displayName: 'Friday',
        tone: 'detailed',
        customInstructions: 'Always cite sources.',
      );
      final parsed = parseAssistantSettings(encodeAssistantSettings(settings));
      expect(parsed, settings);
    });

    test('missing keys and malformed JSON fall back to defaults', () {
      expect(parseAssistantSettings(null), const AssistantSettings());
      expect(parseAssistantSettings(''), const AssistantSettings());
      expect(parseAssistantSettings('not json'), const AssistantSettings());
      expect(
        parseAssistantSettings('{"tone":"friendly"}'),
        const AssistantSettings(tone: 'friendly'),
      );
    });

    test('unknown tone and blank name fall back to defaults', () {
      final parsed = parseAssistantSettings(
        '{"displayName":"   ","tone":"shouty","customInstructions":123}',
      );
      expect(parsed.displayName, 'Jarvis');
      expect(parsed.tone, 'short');
      expect(parsed.customInstructions, '');
    });
  });

  group('buildPersonalitySection', () {
    test('returns empty for default settings', () {
      expect(buildPersonalitySection(const AssistantSettings()), '');
    });

    test('names a custom display name', () {
      final section = buildPersonalitySection(
        const AssistantSettings(displayName: 'Friday'),
      );
      expect(section, contains('Your name is Friday.'));
    });

    test('describes each non-default tone', () {
      expect(
        buildPersonalitySection(const AssistantSettings(tone: 'detailed')),
        contains('detailed'),
      );
      expect(
        buildPersonalitySection(const AssistantSettings(tone: 'friendly')),
        contains('friendly'),
      );
      expect(
        buildPersonalitySection(const AssistantSettings(tone: 'formal')),
        contains('formal'),
      );
    });

    test('includes custom instructions verbatim', () {
      final section = buildPersonalitySection(
        const AssistantSettings(customInstructions: 'Answer in Roman Urdu.'),
      );
      expect(section, contains('Answer in Roman Urdu.'));
    });

    test('combines name, tone and instructions in one block', () {
      final section = buildPersonalitySection(
        const AssistantSettings(
          displayName: 'Friday',
          tone: 'friendly',
          customInstructions: 'Keep it simple.',
        ),
      );
      expect(section, contains('Your name is Friday.'));
      expect(section, contains('friendly'));
      expect(section, contains('Keep it simple.'));
    });
  });

  group('AssistantSettingsService', () {
    test('load returns defaults when nothing is saved', () async {
      const service = AssistantSettingsService();
      expect(await service.loadSettings(), const AssistantSettings());
    });

    test('save then load returns the saved settings', () async {
      const service = AssistantSettingsService();
      const settings = AssistantSettings(
        displayName: 'Friday',
        tone: 'formal',
        customInstructions: 'Be precise.',
      );
      await service.saveSettings(settings);
      expect(await service.loadSettings(), settings);
    });
  });
}
