// Phase 6 (v1.1.0) — F17 long-term memory: store, voice-command
// parsers, and the system-instruction section.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/memory_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await const MemoryService().clearAll();
  });

  group('parseRememberCommand', () {
    test('remember / remember that / please remember save the fact', () {
      expect(parseRememberCommand('remember my exam is on 5 December'),
          'my exam is on 5 December');
      expect(parseRememberCommand('Remember that my exam is on 5 December'),
          'my exam is on 5 December');
      expect(parseRememberCommand('please remember I like short answers'),
          'I like short answers');
      expect(parseRememberCommand('Jarvis remember my Ami cooks well'),
          'my Ami cooks well');
    });

    test('remind me is a reminder, not a remember command', () {
      expect(parseRememberCommand('remind me at 7 to study'), isNull);
      expect(parseRememberCommand('what is the time'), isNull);
      expect(parseRememberCommand('remember'), isNull);
      expect(parseRememberCommand('remember   '), isNull);
    });
  });

  group('isForgetAllCommand / parseForgetCommand', () {
    test('forget everything is the clear-all command', () {
      expect(isForgetAllCommand('forget everything'), isTrue);
      expect(
          isForgetAllCommand('forget everything I told you'), isTrue);
      expect(isForgetAllCommand('forget my exam date'), isFalse);
    });

    test('forget <phrase> extracts the phrase', () {
      expect(parseForgetCommand('forget my exam date'), 'my exam date');
      expect(parseForgetCommand('forget that my exam is in December'),
          'my exam is in December');
      expect(parseForgetCommand('please forget my old phone'), 'my old phone');
      expect(parseForgetCommand('forget everything'), isNull);
      expect(parseForgetCommand('forget'), isNull);
    });
  });

  group('isWhatDoYouRememberCommand', () {
    test('matches the list-questions only', () {
      expect(isWhatDoYouRememberCommand('what do you remember about me'),
          isTrue);
      expect(isWhatDoYouRememberCommand('what do you remember'), isTrue);
      expect(isWhatDoYouRememberCommand('what have you remembered'),
          isTrue);
      expect(isWhatDoYouRememberCommand('do you remember the capital'),
          isFalse);
      expect(isWhatDoYouRememberCommand('what is the time'), isFalse);
    });
  });

  group('buildMemorySection', () {
    test('empty facts give an empty section', () {
      expect(buildMemorySection(const []), '');
    });

    test('facts are listed, one per line, and capped', () {
      final facts = List.generate(
        60,
        (i) => SavedFact(
          text: 'fact $i',
          savedAt: DateTime(2026, 11, 22),
        ),
      );
      final section = buildMemorySection(facts);
      expect(section, contains('Things you remember about the user'));
      expect(section, contains('- fact 59'));
      // Capped at 50: the oldest facts fall off.
      expect(section, isNot(contains('- fact 0')));
      expect(section, isNot(contains('- fact 9')));
      expect(section, contains('- fact 10'));
    });

    test('very long facts are truncated in the instruction', () {
      final fact = SavedFact(
        text: 'x' * 300,
        savedAt: DateTime(2026, 11, 22),
      );
      final section = buildMemorySection([fact]);
      // The 300-char fact must not appear whole; it is cut at 200 chars.
      expect(section, isNot(contains('x' * 300)));
      expect(section, contains('x' * 200));
      expect(section, contains('…'));
    });
  });

  group('parseSavedFacts / encodeSavedFacts', () {
    test('round-trips and drops empty or malformed entries', () {
      const raw = '[{"text":"exam on 5 December",'
          '"savedAt":"2026-11-22T10:00:00.000"},'
          '{"text":""}, {"text": 42}, "junk", 7]';
      final facts = parseSavedFacts(raw);
      expect(facts.map((f) => f.text), ['exam on 5 December']);
      expect(encodeSavedFacts(facts), contains('exam on 5 December'));
      expect(parseSavedFacts(null), isEmpty);
      expect(parseSavedFacts('not json'), isEmpty);
    });
  });

  group('MemoryService store', () {
    const service = MemoryService();

    test('add, load, delete and clear', () async {
      await service.addFact('my exam is on 5 December');
      await service.addFact('I like short answers');
      var facts = await service.loadFacts();
      expect(facts.map((f) => f.text), [
        'my exam is on 5 December',
        'I like short answers',
      ]);

      expect(await service.deleteFact('I LIKE SHORT ANSWERS'), isTrue);
      facts = await service.loadFacts();
      expect(facts.map((f) => f.text), ['my exam is on 5 December']);

      expect(await service.deleteFact('not saved'), isFalse);
      await service.clearAll();
      expect(await service.loadFacts(), isEmpty);
    });

    test('an exact duplicate refreshes instead of doubling', () async {
      await service.addFact('my exam is on 5 December');
      await service.addFact('My Exam Is On 5 December');
      final facts = await service.loadFacts();
      expect(facts, hasLength(1));
      expect(facts.first.text, 'My Exam Is On 5 December');
    });

    test('forgetMatching deletes by substring, case-insensitive',
        () async {
      await service.addFact('my exam is on 5 December');
      await service.addFact('my exam hall is in Faisalabad');
      await service.addFact('I like short answers');
      expect(await service.forgetMatching('EXAM'), 2);
      final facts = await service.loadFacts();
      expect(facts.map((f) => f.text), ['I like short answers']);
      expect(await service.forgetMatching('nothing here'), 0);
    });

    test('empty facts are rejected', () async {
      await expectLater(
        () => service.addFact('   '),
        throwsArgumentError,
      );
    });
  });
}
