// Phase 6 (v1.1.0) — F22 knowledge files: file-name sanitising,
// keyword overlap, excerpt selection and the 2,000-char cap.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/knowledge_service.dart';

void main() {
  group('sanitizeKnowledgeFileName', () {
    test('keeps a plain name and adds .txt', () {
      expect(sanitizeKnowledgeFileName('anatomy notes'), 'anatomy notes.txt');
      expect(sanitizeKnowledgeFileName('Krebs cycle.txt'), 'Krebs cycle.txt');
    });

    test('strips unsafe characters and leading dots', () {
      expect(sanitizeKnowledgeFileName('a/b\\c:d*e?f'), 'abcdef.txt');
      expect(sanitizeKnowledgeFileName('...hidden'), 'hidden.txt');
      expect(sanitizeKnowledgeFileName('   '), 'note.txt');
      expect(sanitizeKnowledgeFileName(''), 'note.txt');
    });
  });

  group('knowledgeKeywords', () {
    test('lowercases, drops short words and stopwords', () {
      expect(
        knowledgeKeywords('What is the Krebs cycle and how does it work?'),
        ['krebs', 'cycle', 'work'],
      );
      expect(knowledgeKeywords('a b c'), isEmpty);
      expect(knowledgeKeywords('What is it?'), isEmpty);
    });
  });

  const krebs = KnowledgeFile(
    name: 'biochemistry.txt',
    content: 'The Krebs cycle is a series of reactions in the mitochondria. '
        'It produces ATP from acetyl-CoA and is also called the citric acid cycle.',
  );
  const anatomy = KnowledgeFile(
    name: 'anatomy.txt',
    content: 'The heart has four chambers: two atria and two ventricles. '
        'The left ventricle pumps blood to the whole body.',
  );

  group('selectKnowledgeExcerpt', () {
    test('picks the file with the most keyword overlap', () {
      final picked = selectKnowledgeExcerpt(
        'how does the Krebs cycle produce ATP?',
        [anatomy, krebs],
      );
      expect(picked, isNotNull);
      expect(picked!.fileName, 'biochemistry.txt');
      expect(picked.excerpt, contains('Krebs cycle'));
    });

    test('returns null when no file shares a keyword', () {
      expect(
        selectKnowledgeExcerpt(
          'what is the capital of France?',
          [anatomy, krebs],
        ),
        isNull,
      );
      expect(selectKnowledgeExcerpt('Krebs cycle', const []), isNull);
      expect(selectKnowledgeExcerpt('what is it?', [krebs]), isNull);
    });

    test('excerpt is capped at 2,000 characters', () {
      final long = KnowledgeFile(
        name: 'long.txt',
        content: "Krebs ${'filler text. ' * 500}",
      );
      final picked = selectKnowledgeExcerpt('Krebs cycle', [long]);
      expect(picked, isNotNull);
      expect(picked!.excerpt.length,
          lessThanOrEqualTo(kJarvisKnowledgeExcerptMaxChars + 1));
    });

    test('excerpt is centred on the keyword hit', () {
      final content =
          "${'padding word. ' * 100}Krebs cycle starts here. ${'tail. ' * 100}";
      final picked = selectKnowledgeExcerpt(
        'Krebs cycle',
        [KnowledgeFile(name: 'n.txt', content: content)],
      );
      expect(picked, isNotNull);
      expect(picked!.excerpt, contains('Krebs cycle starts here'));
      expect(picked.excerpt, startsWith('…'));
    });
  });

  group('buildKnowledgeContext', () {
    test('quotes the excerpt and cites the file name', () {
      final context = buildKnowledgeContext(
        'how does the Krebs cycle produce ATP?',
        [anatomy, krebs],
      );
      expect(context, contains('biochemistry.txt'));
      expect(context, contains('Krebs cycle'));
    });

    test('empty when nothing is relevant', () {
      expect(
        buildKnowledgeContext('capital of France', [anatomy, krebs]),
        '',
      );
    });
  });
}
