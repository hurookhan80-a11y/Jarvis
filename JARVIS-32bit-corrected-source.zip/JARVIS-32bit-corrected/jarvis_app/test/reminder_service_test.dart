import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/reminder_service.dart';

void main() {
  group('reminderWorkName', () {
    test('is unique per reminder id', () {
      expect(reminderWorkName(123), 'jarvis_reminder_123');
      expect(reminderWorkName(123), isNot(reminderWorkName(456)));
    });
  });

  group('reminderNotificationId', () {
    test('folds epoch-millis ids into the 31-bit Android range', () {
      const id = 1793000000000; // a realistic reminder id (epoch millis)
      final notificationId = reminderNotificationId(id);
      expect(notificationId, greaterThanOrEqualTo(0));
      expect(notificationId, lessThan(2147483647));
      // Deterministic: same reminder id, same notification id.
      expect(reminderNotificationId(id), notificationId);
    });
  });

  group('parseStoredReminders', () {
    final now = DateTime(2026, 11, 22, 12, 0);

    test('parses valid entries and keeps the stored shape', () {
      final raw = jsonEncode([
        {
          'id': 1,
          'text': 'study',
          'fireAt': DateTime(2026, 11, 22, 19, 0).toIso8601String(),
        },
      ]);
      final parsed = parseStoredReminders(raw, now: now);
      expect(parsed, hasLength(1));
      expect(parsed.first['id'], 1);
      expect(parsed.first['text'], 'study');
      expect(parsed.first['fireAt'],
          DateTime(2026, 11, 22, 19, 0).toIso8601String());
    });

    test('drops entries with a bad id, empty text, or bad fire time', () {
      final raw = jsonEncode([
        {'id': 0, 'text': 'no id', 'fireAt': '2026-11-22T19:00:00.000'},
        {'text': 'missing id', 'fireAt': '2026-11-22T19:00:00.000'},
        {'id': 2, 'text': '', 'fireAt': '2026-11-22T19:00:00.000'},
        {'id': 3, 'text': 'bad time', 'fireAt': 'not-a-date'},
        {
          'id': 4,
          'text': 'good one',
          'fireAt': '2026-11-22T19:00:00.000',
        },
      ]);
      final parsed = parseStoredReminders(raw, now: now);
      expect(parsed.map((r) => r['id']), [4]);
    });

    test('drops reminders whose fire time is already past', () {
      final raw = jsonEncode([
        {
          'id': 5,
          'text': 'past',
          'fireAt': DateTime(2026, 11, 22, 11, 0).toIso8601String(),
        },
        {
          'id': 6,
          'text': 'future',
          'fireAt': DateTime(2026, 11, 22, 13, 0).toIso8601String(),
        },
      ]);
      final parsed = parseStoredReminders(raw, now: now);
      expect(parsed.map((r) => r['id']), [6]);
    });

    test('returns empty for null, empty, or malformed input', () {
      expect(parseStoredReminders(null, now: now), isEmpty);
      expect(parseStoredReminders('', now: now), isEmpty);
      expect(parseStoredReminders('not json', now: now), isEmpty);
      expect(parseStoredReminders('{"id": 1}', now: now), isEmpty);
      expect(parseStoredReminders('[1, 2, 3]', now: now), isEmpty);
    });
  });

  group('encodeReminders', () {
    test('round-trips through parseStoredReminders', () {
      final reminders = [
        {
          'id': 7,
          'text': 'drink water',
          'fireAt': DateTime(2026, 11, 22, 15, 30).toIso8601String(),
        },
      ];
      final now = DateTime(2026, 11, 22, 12, 0);
      final parsed = parseStoredReminders(encodeReminders(reminders), now: now);
      expect(parsed, hasLength(1));
      expect(parsed.first['text'], 'drink water');
    });
  });
}
