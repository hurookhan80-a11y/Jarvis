import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:jarvis_app/gemini_client.dart';

void main() {
  group('GeminiRestClient', () {
    test(
      'sends secure-key header, system instruction, history, and user message',
      () async {
        final mock = MockClient((request) async {
          expect(request.url.host, 'generativelanguage.googleapis.com');
          expect(
            request.url.path,
            '/v1beta/models/gemini-3.8-flash:generateContent',
          );
          expect(request.headers['x-goog-api-key'], 'test-api-key');
          final body = jsonDecode(request.body) as Map<String, dynamic>;
          expect(
            body['systemInstruction']['parts'][0]['text'],
            contains('J.A.R.V.I.S.'),
          );
          final contents = body['contents'] as List<dynamic>;
          expect(contents, hasLength(2));
          expect(contents[0]['role'], 'model');
          expect(contents[1]['role'], 'user');
          expect(contents[1]['parts'][0]['text'], 'Hello Jarvis');
          return http.Response(
            jsonEncode({
              'candidates': [
                {
                  'content': {
                    'parts': [
                      {'text': 'Hello, sir.'},
                    ],
                  },
                },
              ],
            }),
            200,
            headers: {'content-type': 'application/json'},
          );
        });

        final client = GeminiRestClient(
          apiKey: 'test-api-key',
          modelName: 'gemini-3.8-flash',
          httpClient: mock,
        );
        final answer = await client.sendMessage(
          message: 'Hello Jarvis',
          history: const [
            GeminiChatMessage(role: 'model', text: 'Welcome back.'),
          ],
        );
        expect(answer, 'Hello, sir.');
        mock.close();
        client.dispose();
      },
    );

    test('surfaces API error messages', () async {
      final mock = MockClient(
        (request) async => http.Response(
          jsonEncode({
            'error': {'message': 'API key not valid'},
          }),
          400,
        ),
      );
      final client = GeminiRestClient(
        apiKey: 'bad-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      expect(
        () => client.sendMessage(message: 'Hello', history: const []),
        throwsA(
          isA<GeminiApiException>().having(
            (e) => e.message,
            'message',
            'API key not valid',
          ),
        ),
      );
      mock.close();
      client.dispose();
    });

    test('rejects unsafe model names before making a request', () async {
      final mock = MockClient((request) async => http.Response('{}', 200));
      final client = GeminiRestClient(
        apiKey: 'test-key',
        modelName: '../bad-model',
        httpClient: mock,
      );
      expect(
        () => client.sendMessage(message: 'Hello', history: const []),
        throwsA(isA<GeminiApiException>()),
      );
      mock.close();
      client.dispose();
    });

    test('cancel() is safe on a disposed client and leaves an injected client alone', () async {
      var mockCalls = 0;
      final mock = MockClient((request) async {
        mockCalls++;
        return http.Response(
          jsonEncode({
            'candidates': [
              {
                'content': {
                  'parts': [
                    {'text': 'Still works.'},
                  ],
                },
              },
            ],
          }),
          200,
          headers: {'content-type': 'application/json'},
        );
      });
      final client = GeminiRestClient(
        apiKey: 'test-api-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      // Cancelling must not close a client this object does not own.
      client.cancel();
      final answer = await client.sendMessage(
        message: 'Hello',
        history: const [],
      );
      expect(answer, 'Still works.');
      expect(mockCalls, 1);
      client.dispose();
      // Cancelling after dispose is a no-op, never an error.
      client.cancel();
      mock.close();
    });

    test('cancel() on an owned client does not throw', () {
      final client = GeminiRestClient(
        apiKey: 'test-api-key',
        modelName: 'gemini-3.8-flash',
      );
      client.cancel();
      client.cancel();
      client.dispose();
    });
  });

  group('parseSseTextDeltas', () {
    String sse(String text) => jsonEncode({
      'candidates': [
        {
          'content': {
            'parts': [
              {'text': text},
            ],
          },
        },
      ],
    });

    test('extracts text from data lines and skips [DONE]', () {
      final chunk =
          'data: ${sse('Hello ')}\n'
          'data: ${sse('sir.')}\n'
          'data: [DONE]\n';
      expect(parseSseTextDeltas(chunk), ['Hello ', 'sir.']);
    });

    test('ignores empty lines, comments, and malformed JSON', () {
      final chunk =
          '\n'
          ': ping\n'
          'data: not-json\n'
          'data: ${sse('Fine.')}\n';
      expect(parseSseTextDeltas(chunk), ['Fine.']);
    });

    test('accepts a bare JSON object line', () {
      expect(parseSseTextDeltas(sse('Bare.')), ['Bare.']);
    });

    test('returns empty for a response with no candidate text', () {
      expect(parseSseTextDeltas('data: {"candidates": []}\n'), isEmpty);
    });
  });

  group('splitCompleteSentences', () {
    test('splits on sentence ends and keeps the remainder', () {
      final split = splitCompleteSentences('Hello sir. How are you? Fine');
      expect(split.sentences, ['Hello sir.', 'How are you?']);
      expect(split.remainder, ' Fine');
    });

    test('does not split on decimals', () {
      final split = splitCompleteSentences('The value is 3.5 today.');
      expect(split.sentences, ['The value is 3.5 today.']);
      expect(split.remainder, '');
    });

    test('returns the whole text as remainder with no sentence end', () {
      final split = splitCompleteSentences('Still thinking');
      expect(split.sentences, isEmpty);
      expect(split.remainder, 'Still thinking');
    });

    test('handles exclamation marks and newlines', () {
      final split = splitCompleteSentences('Great!\nNext one here.');
      expect(split.sentences, ['Great!', 'Next one here.']);
      expect(split.remainder, '');
    });
  });

  group('sendMessageStream', () {
    String sse(String text) =>
        'data: ${jsonEncode({
          'candidates': [
            {
              'content': {
                'parts': [
                  {'text': text},
                ],
              },
            },
          ],
        })}\n';

    test('yields text deltas from an SSE response', () async {
      final fake = _SseFakeClient(
        '${sse('Hello ')}${sse('sir.')}data: [DONE]\n',
      );
      final client = GeminiRestClient(
        apiKey: 'test-api-key',
        modelName: 'gemini-3.8-flash',
        httpClient: fake,
      );
      final deltas = await client
          .sendMessageStream(message: 'Hi', history: const [])
          .toList();
      expect(deltas, ['Hello ', 'sir.']);
      expect(
        fake.lastRequest?.url.path,
        '/v1beta/models/gemini-3.8-flash:streamGenerateContent',
      );
      expect(fake.lastRequest?.url.queryParameters['alt'], 'sse');
      client.dispose();
    });

    test('reassembles a data line split across chunks', () async {
      final full = sse('Split across.');
      final cut = full.length ~/ 2;
      final fake = _SseFakeClient(
        '',
        chunks: <String>[full.substring(0, cut), full.substring(cut)],
      );
      final client = GeminiRestClient(
        apiKey: 'test-api-key',
        modelName: 'gemini-3.8-flash',
        httpClient: fake,
      );
      final deltas = await client
          .sendMessageStream(message: 'Hi', history: const [])
          .toList();
      expect(deltas, ['Split across.']);
      client.dispose();
    });

    test('throws a readable error on an HTTP error status', () async {
      final fake = _SseFakeClient(
        jsonEncode({
          'error': {'message': 'API key not valid'},
        }),
        statusCode: 400,
      );
      final client = GeminiRestClient(
        apiKey: 'bad-key',
        modelName: 'gemini-3.8-flash',
        httpClient: fake,
      );
      // expectLater, not expect: the async* body only runs once the
      // stream is listened to, so the throw must be awaited.
      await expectLater(
        client.sendMessageStream(message: 'Hi', history: const []).toList(),
        throwsA(
          isA<GeminiApiException>().having(
            (e) => e.message,
            'message',
            'API key not valid',
          ),
        ),
      );
      client.dispose();
    });
  });
}

/// Fake HTTP client that answers with a canned SSE body, optionally
/// split into several chunks to mimic network chunking.
class _SseFakeClient extends http.BaseClient {
  _SseFakeClient(this.body, {this.statusCode = 200, List<String>? chunks})
    : _chunks = chunks ?? <String>[body];

  final String body;
  final int statusCode;
  final List<String> _chunks;
  http.BaseRequest? lastRequest;

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    lastRequest = request;
    final stream = Stream<List<int>>.fromIterable(_chunks.map(utf8.encode));
    return http.StreamedResponse(
      stream,
      statusCode,
      headers: {'content-type': 'text/event-stream'},
    );
  }
}
