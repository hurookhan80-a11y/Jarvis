import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:jarvis_app/gemini_client.dart';

void main() {
  group('GeminiRestClient', () {
    test('sends secure-key header, system instruction, history, and user message', () async {
      final mock = MockClient((request) async {
        expect(request.url.host, 'generativelanguage.googleapis.com');
        expect(request.url.path, '/v1beta/models/gemini-3.8-flash:generateContent');
        expect(request.headers['x-goog-api-key'], 'test-api-key');
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        expect(body['systemInstruction']['parts'][0]['text'], contains('J.A.R.V.I.S.'));
        final contents = body['contents'] as List<dynamic>;
        expect(contents, hasLength(2));
        expect(contents[0]['role'], 'model');
        expect(contents[1]['role'], 'user');
        expect(contents[1]['parts'][0]['text'], 'Hello Jarvis');
        return http.Response(
          jsonEncode({
            'candidates': [
              {
                'content': {
                  'parts': [
                    {'text': 'Hello, sir.'}
                  ]
                }
              }
            ]
          }),
          200,
          headers: {'content-type': 'application/json'},
        );
      });

      final client = GeminiRestClient(
        apiKey: 'test-api-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      final answer = await client.sendMessage(
        message: 'Hello Jarvis',
        history: const [GeminiChatMessage(role: 'model', text: 'Welcome back.')],
      );
      expect(answer, 'Hello, sir.');
      mock.close();
      client.dispose();
    });

    test('surfaces API error messages', () async {
      final mock = MockClient((request) async => http.Response(
            jsonEncode({'error': {'message': 'API key not valid'}}),
            400,
          ));
      final client = GeminiRestClient(
        apiKey: 'bad-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      expect(
        () => client.sendMessage(message: 'Hello', history: const []),
        throwsA(isA<GeminiApiException>().having((e) => e.message, 'message', 'API key not valid')),
      );
      mock.close();
      client.dispose();
    });

    test('rejects unsafe model names before making a request', () async {
      final mock = MockClient((request) async => http.Response('{}', 200));
      final client = GeminiRestClient(
        apiKey: 'test-key',
        modelName: '../bad-model',
        httpClient: mock,
      );
      expect(
        () => client.sendMessage(message: 'Hello', history: const []),
        throwsA(isA<GeminiApiException>()),
      );
      mock.close();
      client.dispose();
    });
  });
}
