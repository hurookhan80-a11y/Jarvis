// v1.2.0 (G15-data) — theme mode parsing/naming and the two
// ThemeData objects (dark = current look, light = soft light).
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/app_theme.dart';

void main() {
  group('parseThemeMode / themeModeName', () {
    test('parses light and dark, case-insensitively', () {
      expect(parseThemeMode('light'), JarvisThemeMode.light);
      expect(parseThemeMode('Light'), JarvisThemeMode.light);
      expect(parseThemeMode('dark'), JarvisThemeMode.dark);
    });

    test('unknown, empty and null values fall back to dark', () {
      expect(parseThemeMode(null), JarvisThemeMode.dark);
      expect(parseThemeMode(''), JarvisThemeMode.dark);
      expect(parseThemeMode('sepia'), JarvisThemeMode.dark);
    });

    test('themeModeName round-trips through parseThemeMode', () {
      for (final mode in JarvisThemeMode.values) {
        expect(parseThemeMode(themeModeName(mode)), mode);
      }
      expect(themeModeName(JarvisThemeMode.dark), 'dark');
      expect(themeModeName(JarvisThemeMode.light), 'light');
    });
  });

  group('jarvisDarkTheme', () {
    test('is the current dark look: dark, near-black, cyan accent', () {
      expect(jarvisDarkTheme.brightness, Brightness.dark);
      expect(
        jarvisDarkTheme.scaffoldBackgroundColor,
        const Color(0xFF121212),
      );
      expect(jarvisDarkTheme.colorScheme.primary, kJarvisAccent);
      expect(jarvisDarkTheme.colorScheme.onSurface, Colors.white);
      expect(
        jarvisDarkTheme.appBarTheme.backgroundColor,
        const Color(0xFF121212),
      );
      expect(
        jarvisDarkTheme.textTheme.bodyMedium?.color,
        Colors.white,
      );
    });
  });

  group('jarvisLightTheme', () {
    test('is a soft light look: light, pale background, ink text', () {
      expect(jarvisLightTheme.brightness, Brightness.light);
      expect(
        jarvisLightTheme.scaffoldBackgroundColor,
        const Color(0xFFF4F7F9),
      );
      expect(
        jarvisLightTheme.colorScheme.primary,
        const Color(0xFF0B5A6B),
      );
      expect(
        jarvisLightTheme.colorScheme.onSurface,
        const Color(0xFF1C2B33),
      );
      expect(
        jarvisLightTheme.appBarTheme.backgroundColor,
        const Color(0xFFF4F7F9),
      );
      expect(
        jarvisLightTheme.textTheme.bodyMedium?.color,
        const Color(0xFF1C2B33),
      );
    });
  });

  test('the two themes differ in brightness and background', () {
    expect(
      jarvisDarkTheme.brightness,
      isNot(jarvisLightTheme.brightness),
    );
    expect(
      jarvisDarkTheme.scaffoldBackgroundColor,
      isNot(jarvisLightTheme.scaffoldBackgroundColor),
    );
  });
}
