// v1.2.0 — G6 specialist agent modes.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/specialist_modes.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  group('modeSystemPrompt', () {
    test('general mode adds nothing', () {
      expect(modeSystemPrompt(AgentMode.general), '');
    });

    test('research mode asks for web search, sources, honesty', () {
      final prompt = modeSystemPrompt(AgentMode.research);
      expect(prompt.toLowerCase(), contains('web search'));
      expect(prompt.toLowerCase(), contains('cite'));
      expect(prompt.toLowerCase(), contains('unconfirmed'));
    });

    test('writer mode drafts in the user\'s voice and offers to save', () {
      final prompt = modeSystemPrompt(AgentMode.writer);
      expect(prompt.toLowerCase(), contains('voice'));
      expect(prompt.toLowerCase(), contains('save'));
    });

    test('publisher mode saves and reports where', () {
      final prompt = modeSystemPrompt(AgentMode.publisher);
      expect(prompt.toLowerCase(), contains('save'));
      expect(prompt.toLowerCase(), contains('exactly where'));
    });

    test('every mode has a short prompt', () {
      for (final mode in AgentMode.values) {
        expect(modeSystemPrompt(mode).length, lessThan(400));
      }
    });
  });

  group('parseModeCommand', () {
    test('plain mode names switch', () {
      expect(parseModeCommand('research mode'), AgentMode.research);
      expect(parseModeCommand('writer mode'), AgentMode.writer);
      expect(parseModeCommand('publisher mode'), AgentMode.publisher);
      expect(parseModeCommand('general mode'), AgentMode.general);
      expect(parseModeCommand('normal mode'), AgentMode.general);
      expect(parseModeCommand('assistant mode'), AgentMode.general);
    });

    test('switch/go/turn-on prefixes switch', () {
      expect(
        parseModeCommand('switch to research mode'),
        AgentMode.research,
      );
      expect(parseModeCommand('go to writer mode'), AgentMode.writer);
      expect(
        parseModeCommand('turn on publisher mode'),
        AgentMode.publisher,
      );
      expect(parseModeCommand('enable research mode'), AgentMode.research);
      expect(parseModeCommand('set mode to writer mode'), AgentMode.writer);
    });

    test('case and surrounding space do not matter', () {
      expect(
        parseModeCommand('  Switch To Research Mode '),
        AgentMode.research,
      );
    });

    test('non-mode utterances return null', () {
      expect(parseModeCommand(''), isNull);
      expect(parseModeCommand('research'), isNull);
      expect(parseModeCommand('research the spina bifida cure'), isNull);
      expect(parseModeCommand('write me a poem'), isNull);
      expect(parseModeCommand('publish this'), isNull);
      expect(parseModeCommand('expert mode'), isNull);
      expect(parseModeCommand('research mode please do it'), isNull);
    });
  });

  group('AgentModeService persistence', () {
    test('defaults to general, round-trips every mode', () async {
      final service = AgentModeService();
      expect(await service.loadMode(), AgentMode.general);
      for (final mode in AgentMode.values) {
        await service.saveMode(mode);
        expect(await service.loadMode(), mode);
      }
    });

    test('unknown saved value falls back to general', () async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        kAgentModePrefsKey: 'superhero',
      });
      expect(await AgentModeService().loadMode(), AgentMode.general);
    });
  });
}
