// Phase 9 (v1.2.0) — G5 scheduled workflows.
//
// Pure helpers (due/next-run) are tested with fixed dates — Monday
// 23 Nov 2026 and Saturday 28 Nov 2026 — and the store with mocked
// SharedPreferences. Notification registration only needs to
// complete without throwing here: the Workmanager calls are wrapped
// in try/catch in the service, and the real task runs on-device.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/scheduled_workflow_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  // Monday 23 Nov 2026, 08:30 — the "now" most due-tests use.
  final mondayMorning = DateTime(2026, 11, 23, 8, 30);

  ScheduledWorkflow entry({
    String id = 's1',
    String workflowId = 'builtin-morning-briefing',
    int hour = 8,
    int minute = 0,
    Set<int> weekdays = const {},
    bool enabled = true,
    DateTime? lastRun,
  }) => ScheduledWorkflow(
    id: id,
    workflowId: workflowId,
    hour: hour,
    minute: minute,
    weekdays: weekdays,
    enabled: enabled,
    lastRun: lastRun,
  );

  group('ScheduledWorkflow JSON', () {
    test('round-trips, including weekdays and lastRun', () {
      final restored = ScheduledWorkflow.fromJson(
        entry(
          weekdays: {1, 3, 5},
          lastRun: DateTime(2026, 11, 23, 8, 0),
        ).toJson(),
      );
      expect(restored.id, 's1');
      expect(restored.workflowId, 'builtin-morning-briefing');
      expect(restored.hour, 8);
      expect(restored.minute, 0);
      expect(restored.weekdays, {1, 3, 5});
      expect(restored.enabled, isTrue);
      expect(restored.lastRun, DateTime(2026, 11, 23, 8, 0));
    });

    test('null lastRun stays null; empty weekdays means every day', () {
      final restored = ScheduledWorkflow.fromJson(entry().toJson());
      expect(restored.lastRun, isNull);
      expect(restored.weekdays, isEmpty);
    });

    test('parseStoredScheduled drops invalid entries', () {
      expect(parseStoredScheduled(null), isEmpty);
      expect(parseStoredScheduled('garbage'), isEmpty);
      final parsed = parseStoredScheduled(
        '[{"id":"ok","workflowId":"w","hour":8,"minute":0,"weekdays":[1,8,0],"enabled":true},'
        '{"id":"","workflowId":"w","hour":8,"minute":0},'
        '{"id":"bad-hour","workflowId":"w","hour":24,"minute":0},'
        '{"id":"bad-min","workflowId":"w","hour":8,"minute":60},'
        '{"id":"no-workflow","workflowId":"","hour":8,"minute":0}]',
      );
      expect(parsed.map((s) => s.id), ['ok']);
      // Only the valid weekday values (1..7) survive.
      expect(parsed.first.weekdays, {1});
    });

    test('encodeScheduled round-trips a list', () {
      final list = [entry(), entry(id: 's2', hour: 19, minute: 30)];
      final restored = parseStoredScheduled(encodeScheduled(list));
      expect(restored.length, 2);
      expect(restored[1].hour, 19);
    });
  });

  group('dueWorkflows', () {
    test('due when enabled, time passed, never run', () {
      expect(dueWorkflows([entry()], mondayMorning).length, 1);
    });

    test('not due before its time today', () {
      final early = DateTime(2026, 11, 23, 7, 59);
      expect(dueWorkflows([entry()], early), isEmpty);
    });

    test('due exactly at its scheduled time', () {
      final atTime = DateTime(2026, 11, 23, 8, 0);
      expect(dueWorkflows([entry()], atTime).length, 1);
    });

    test('not due again after running for today\'s occurrence', () {
      final ran = entry(lastRun: DateTime(2026, 11, 23, 8, 5));
      expect(dueWorkflows([ran], mondayMorning), isEmpty);
    });

    test('due again when last run was for an earlier day', () {
      final ranYesterday = entry(lastRun: DateTime(2026, 11, 22, 8, 5));
      expect(dueWorkflows([ranYesterday], mondayMorning).length, 1);
    });

    test('last run exactly at today\'s scheduled time counts as run', () {
      final ranAtTime = entry(lastRun: DateTime(2026, 11, 23, 8, 0));
      expect(dueWorkflows([ranAtTime], mondayMorning), isEmpty);
    });

    test('disabled schedules are never due', () {
      expect(dueWorkflows([entry(enabled: false)], mondayMorning), isEmpty);
    });

    test('weekday set restricts the days', () {
      // Monday 23 Nov: in the set -> due; Saturday 28 Nov: not in it.
      final mondaysOnly = entry(weekdays: {DateTime.monday});
      expect(dueWorkflows([mondaysOnly], mondayMorning).length, 1);
      final saturday = DateTime(2026, 11, 28, 8, 30);
      expect(dueWorkflows([mondaysOnly], saturday), isEmpty);
      // Empty weekdays = every day, including Saturday.
      expect(dueWorkflows([entry()], saturday).length, 1);
    });

    test('only the due ones are returned', () {
      final list = [
        entry(id: 'due', hour: 8, minute: 0),
        entry(id: 'later', hour: 19, minute: 0),
        entry(id: 'off', hour: 8, minute: 0, enabled: false),
      ];
      expect(dueWorkflows(list, mondayMorning).map((s) => s.id), ['due']);
    });
  });

  group('nextRunAfter', () {
    test('later today when the time has not passed', () {
      expect(
        nextRunAfter(entry(), DateTime(2026, 11, 23, 7, 0)),
        DateTime(2026, 11, 23, 8, 0),
      );
    });

    test('tomorrow when today\'s time has passed', () {
      expect(
        nextRunAfter(entry(), mondayMorning),
        DateTime(2026, 11, 24, 8, 0),
      );
    });

    test('strictly after the given time, never equal to it', () {
      expect(
        nextRunAfter(entry(), DateTime(2026, 11, 23, 8, 0)),
        DateTime(2026, 11, 24, 8, 0),
      );
    });

    test('skips to the next matching weekday', () {
      // Mondays only, asked on Monday after the time: next Monday.
      final mondaysOnly = entry(weekdays: {DateTime.monday});
      expect(
        nextRunAfter(mondaysOnly, mondayMorning),
        DateTime(2026, 11, 30, 8, 0),
      );
      // Asked on Saturday before the time: the coming Monday.
      expect(
        nextRunAfter(mondaysOnly, DateTime(2026, 11, 28, 7, 0)),
        DateTime(2026, 11, 30, 8, 0),
      );
    });

    test('disabled schedules have no next run', () {
      expect(nextRunAfter(entry(enabled: false), mondayMorning), isNull);
    });
  });

  group('notification naming helpers', () {
    test('work name is unique per schedule id', () {
      expect(workflowNotificationWorkName('abc'), 'jarvis_workflow_abc');
      expect(
        workflowNotificationWorkName('abc'),
        isNot(workflowNotificationWorkName('xyz')),
      );
    });

    test('notification id is deterministic and in 31-bit range', () {
      final first = workflowNotificationId('schedule-1');
      expect(workflowNotificationId('schedule-1'), first);
      expect(first, greaterThanOrEqualTo(0));
      expect(first, lessThan(2147483647));
      expect(
        workflowNotificationId('schedule-1'),
        isNot(workflowNotificationId('schedule-2')),
      );
    });
  });

  group('ScheduledWorkflowService store', () {
    const service = ScheduledWorkflowService();

    test('save assigns an id when empty and load returns it, sorted', () async {
      final saved = await service.saveScheduled(entry(id: ''));
      expect(saved, isNotNull);
      expect(saved!.id.isNotEmpty, isTrue);
      await service.saveScheduled(entry(id: 'evening', hour: 19));
      final loaded = await service.loadScheduled();
      expect(loaded.map((s) => s.hour), [8, 19]);
    });

    test('save with no workflow id or a bad time is ignored', () async {
      expect(await service.saveScheduled(entry(workflowId: ' ')), isNull);
      expect(await service.saveScheduled(entry(hour: 24)), isNull);
      expect(await service.saveScheduled(entry(minute: 60)), isNull);
      expect(await service.loadScheduled(), isEmpty);
    });

    test('saving the same id replaces it', () async {
      await service.saveScheduled(entry());
      await service.saveScheduled(entry(hour: 9, minute: 15));
      final loaded = await service.loadScheduled();
      expect(loaded.length, 1);
      expect(loaded.first.hour, 9);
      expect(loaded.first.minute, 15);
    });

    test('markRun records the run and stops a second due', () async {
      await service.saveScheduled(entry());
      expect(await service.markRun('missing'), isFalse);
      expect(
        await service.markRun('s1', at: DateTime(2026, 11, 23, 8, 5)),
        isTrue,
      );
      final loaded = await service.loadScheduled();
      expect(loaded.first.lastRun, DateTime(2026, 11, 23, 8, 5));
      expect(dueWorkflows(loaded, mondayMorning), isEmpty);
    });

    test('delete and clearAll', () async {
      await service.saveScheduled(entry());
      expect(await service.deleteScheduled('nope'), isFalse);
      expect(await service.deleteScheduled('s1'), isTrue);
      expect(await service.loadScheduled(), isEmpty);
      await service.saveScheduled(entry());
      await service.clearAll();
      expect(await service.loadScheduled(), isEmpty);
    });

    test('cap of 20 schedules is enforced', () async {
      for (var i = 0; i < 25; i++) {
        await service.saveScheduled(entry(id: 'cap-$i', hour: i % 24));
      }
      expect(
        (await service.loadScheduled()).length,
        kJarvisMaxScheduledWorkflows,
      );
    });

    test('notification calls complete without throwing (no plugin here)',
        () async {
      // The Workmanager calls are guarded in the service; in a unit
      // test there is no initialized plugin, so they must simply
      // no-op rather than throw.
      await service.scheduleNotification(entry(), 'morning briefing');
      await service.cancelNotification('s1');
      await service.cancelAllNotifications();
    });
  });
}
