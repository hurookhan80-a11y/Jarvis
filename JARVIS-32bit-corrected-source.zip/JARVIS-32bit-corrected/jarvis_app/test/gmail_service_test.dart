// Phase 7 (v1.1.0) — F28 Gmail triage: response parsing and the
// read-only REST client (mock HTTP, mock secure-storage channel).
import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:jarvis_app/gmail_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  var storedGmailToken = '';
  const channel =
      MethodChannel('com.jarvis.jarvis_app/secure_storage');

  setUp(() async {
    storedGmailToken = '';
    SharedPreferences.setMockInitialValues(<String, Object>{});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
      switch (call.method) {
        case 'readSecret':
          return storedGmailToken;
        case 'saveSecret':
          storedGmailToken = (call.arguments as Map)['value'] as String;
          return null;
        case 'clearSecret':
          storedGmailToken = '';
          return null;
        default:
          return null;
      }
    });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  group('parseMessageListResponse', () {
    test('extracts ids, skips blanks', () {
      final ids = parseMessageListResponse(<String, dynamic>{
        'messages': [
          {'id': 'abc'},
          {'id': 'def'},
          {'id': ''},
          {'other': 'x'},
        ],
      });
      expect(ids, ['abc', 'def']);
    });

    test('no messages key returns []', () {
      expect(parseMessageListResponse(<String, dynamic>{}), isEmpty);
    });
  });

  group('parseMessageDetail', () {
    test('reads Subject/From/Date headers and snippet', () {
      final message = parseMessageDetail(<String, dynamic>{
        'id': 'abc',
        'snippet': 'Hello there…',
        'payload': {
          'headers': [
            {'name': 'Subject', 'value': 'Your exam result'},
            {'name': 'From', 'value': 'FMU <info@fmu.edu.pk>'},
            {'name': 'Date', 'value': 'Sat, 22 Nov 2026 09:00:00 +0500'},
          ],
        },
      });
      expect(message.id, 'abc');
      expect(message.subject, 'Your exam result');
      expect(message.sender, 'FMU <info@fmu.edu.pk>');
      expect(message.snippet, 'Hello there…');
      expect(message.date, contains('22 Nov 2026'));
    });

    test('missing headers fall back to placeholders', () {
      final message = parseMessageDetail(<String, dynamic>{'id': 'x'});
      expect(message.subject, '(No subject)');
      expect(message.sender, '(Unknown sender)');
      expect(message.snippet, '');
    });
  });

  group('GmailService', () {
    test('cannot switch on without a token', () async {
      final service = GmailService(client: MockClient((_) async {
        return http.Response('{}', 200);
      }));
      expect(await service.hasToken(), isFalse);
      expect(await service.setEnabled(true), isFalse);
      expect(await service.isEnabled(), isFalse);
      service.dispose();
    });

    test('listUnread reads list then details, read-only GETs', () async {
      final requested = <Uri>[];
      final client = MockClient((request) async {
        requested.add(request.url);
        if (request.url.path.endsWith('/messages')) {
          return http.Response(
            jsonEncode({
              'messages': [
                {'id': 'm1'},
                {'id': 'm2'},
              ],
            }),
            200,
          );
        }
        return http.Response(
          jsonEncode({
            'id': request.url.pathSegments.last,
            'snippet': 'snip',
            'payload': {
              'headers': [
                {'name': 'Subject', 'value': 'Subj'},
                {'name': 'From', 'value': 'a@b.com'},
                {'name': 'Date', 'value': 'Sat, 22 Nov 2026'},
              ],
            },
          }),
          200,
        );
      });
      final service = GmailService(client: client);
      await service.saveToken('ya29-test-token');
      expect(await service.setEnabled(true), isTrue);
      final messages = await service.listUnread();
      expect(messages.length, 2);
      expect(messages.first.subject, 'Subj');
      expect(messages.first.sender, 'a@b.com');
      // Only GETs, and every call carries the token.
      expect(requested.length, 3);
      service.dispose();
    });

    test('expired token (401) throws a plain-language error', () async {
      final client = MockClient((_) async {
        return http.Response('{"error": "invalid"}', 401);
      });
      final service = GmailService(client: client);
      await service.saveToken('ya29-expired');
      expect(
        service.listUnread(),
        throwsA(
          isA<GmailException>().having(
            (e) => e.message,
            'message',
            contains('expired'),
          ),
        ),
      );
      service.dispose();
    });

    test('clearing the token switches triage off', () async {
      final service = GmailService(
        client: MockClient((_) async => http.Response('{}', 200)),
      );
      await service.saveToken('ya29-test');
      await service.setEnabled(true);
      await service.clearToken();
      expect(await service.hasToken(), isFalse);
      expect(await service.isEnabled(), isFalse);
      service.dispose();
    });
  });
}
