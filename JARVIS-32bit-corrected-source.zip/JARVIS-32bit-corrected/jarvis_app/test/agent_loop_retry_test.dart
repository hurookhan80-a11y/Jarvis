// v1.2.0 — G13 agent loop retry with diagnosis.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/agent_loop.dart';
import 'package:jarvis_app/multi_task_service.dart';

void main() {
  group('runAgentLoopWithRetry', () {
    test('all steps pass: no diagnose call, no retry', () async {
      var diagnoseCalls = 0;
      final results = await runAgentLoopWithRetry(
        ['open WhatsApp', 'tell me the time'],
        (_) async => const StepResult.done('ok'),
        diagnose: (_, _) async {
          diagnoseCalls++;
          return 'fixed';
        },
      );
      expect(results.length, 2);
      expect(results.every((r) => r.succeeded), isTrue);
      expect(results.every((r) => !r.retried), isTrue);
      expect(diagnoseCalls, 0);
    });

    test('failed step retried with the diagnosed fix and succeeds',
        () async {
      final attempted = <String>[];
      final log = <AgentStepLogEntry>[];
      final results = await runAgentLoopWithRetry(
        ['remind me at 7 to study', 'tell me the time'],
        (step) async {
          attempted.add(step);
          if (step == 'remind me at 7 to study') {
            return StepResult.failed(step, 'No confirmation that it happened.');
          }
          return StepResult.done(step);
        },
        onLog: log.add,
        diagnose: (failedStep, reason) async {
          expect(failedStep, 'remind me at 7 to study');
          expect(reason, contains('No confirmation'));
          return 'set reminder at 7 to study';
        },
      );
      expect(results.length, 2);
      expect(results[0].succeeded, isTrue);
      expect(results[0].retried, isTrue);
      expect(results[0].command, 'set reminder at 7 to study');
      expect(results[1].succeeded, isTrue);
      expect(results[1].retried, isFalse);
      expect(attempted, [
        'remind me at 7 to study',
        'tell me the time',
        'set reminder at 7 to study',
      ]);
      // The retry is logged at the original step's index.
      final retryEntry = log.firstWhere(
        (e) => e.detail.startsWith('retry:'),
      );
      expect(retryEntry.index, 0);
    });

    test('diagnose returning null keeps the original failure', () async {
      var executeCalls = 0;
      final results = await runAgentLoopWithRetry(
        ['call Ami'],
        (_) async {
          executeCalls++;
          return StepResult.failed('call Ami', 'No confirmation.');
        },
        diagnose: (_, _) async => null,
      );
      expect(results.length, 1);
      expect(results[0].succeeded, isFalse);
      expect(results[0].reason, 'No confirmation.');
      expect(results[0].retried, isFalse);
      expect(executeCalls, 1);
    });

    test('diagnose returning empty keeps the original failure', () async {
      var executeCalls = 0;
      final results = await runAgentLoopWithRetry(
        ['call Ami'],
        (_) async {
          executeCalls++;
          return StepResult.failed('call Ami', 'No confirmation.');
        },
        diagnose: (_, _) async => '   ',
      );
      expect(results[0].succeeded, isFalse);
      expect(executeCalls, 1);
    });

    test('a retry that still fails reports the latest reason', () async {
      final results = await runAgentLoopWithRetry(
        ['call Ami'],
        (step) async {
          if (step == 'call Ami') {
            return StepResult.failed(step, 'First failure.');
          }
          return StepResult.failed(step, 'Second failure.');
        },
        diagnose: (_, _) async => 'call Ami again',
      );
      expect(results.length, 1);
      expect(results[0].succeeded, isFalse);
      expect(results[0].retried, isTrue);
      expect(results[0].reason, 'Second failure.');
      expect(
        formatAgentReport(results),
        contains('Second failure'),
      );
    });

    test('at most one retry per step', () async {
      var diagnoseCalls = 0;
      var executeCalls = 0;
      final results = await runAgentLoopWithRetry(
        ['call Ami'],
        (_) async {
          executeCalls++;
          return StepResult.failed('call Ami', 'Still failing.');
        },
        diagnose: (_, _) async {
          diagnoseCalls++;
          return 'call Ami again';
        },
      );
      expect(executeCalls, 2, reason: 'original + exactly one retry');
      expect(diagnoseCalls, 1);
      expect(results[0].retried, isTrue);
    });

    test('no diagnose callback behaves like runAgentLoop', () async {
      final results = await runAgentLoopWithRetry(
        ['open WhatsApp', 'call Ami'],
        (step) async => step.startsWith('open')
            ? StepResult.done(step)
            : StepResult.failed(step, 'No confirmation.'),
      );
      expect(results.length, 2);
      expect(results[0].succeeded, isTrue);
      expect(results[1].succeeded, isFalse);
      expect(results.every((r) => !r.retried), isTrue);
    });

    test('a throwing diagnoser keeps the original failure', () async {
      final results = await runAgentLoopWithRetry(
        ['call Ami'],
        (_) async => StepResult.failed('call Ami', 'Original failure.'),
        diagnose: (_, _) async => throw Exception('diagnosis crashed'),
      );
      expect(results[0].succeeded, isFalse);
      expect(results[0].reason, 'Original failure.');
    });

    test('a throwing retry execute is caught and reported', () async {
      final results = await runAgentLoopWithRetry(
        ['call Ami'],
        (step) async {
          if (step == 'call Ami') {
            return StepResult.failed(step, 'Original failure.');
          }
          throw Exception('boom');
        },
        diagnose: (_, _) async => 'call Ami again',
      );
      expect(results[0].succeeded, isFalse);
      expect(results[0].retried, isTrue);
      expect(results[0].reason, contains('Error:'));
    });
  });

  group('StepResult.retried', () {
    test('defaults to false and keeps existing constructors working', () {
      const done = StepResult.done('x');
      const failed = StepResult.failed('x', 'why');
      expect(done.retried, isFalse);
      expect(failed.retried, isFalse);
      expect(
        const StepResult.done('x', retried: true).retried,
        isTrue,
      );
    });
  });
}
