// v1.2.0 (G8) — attachment classification + size guard, and the
// Gemini vision call the caller uses to send a picked image.
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:jarvis_app/attachment_service.dart';
import 'package:jarvis_app/gemini_client.dart';

void main() {
  group('classifyAttachmentByExtension', () {
    test('image extensions map to their image/* type', () {
      expect(classifyAttachmentByExtension('photo.jpg'), 'image/jpeg');
      expect(classifyAttachmentByExtension('photo.JPEG'), 'image/jpeg');
      expect(classifyAttachmentByExtension('scan.png'), 'image/png');
      expect(classifyAttachmentByExtension('pic.webp'), 'image/webp');
      expect(classifyAttachmentByExtension('anim.gif'), 'image/gif');
      expect(classifyAttachmentByExtension('old.bmp'), 'image/bmp');
    });

    test('text and pdf extensions map correctly', () {
      expect(classifyAttachmentByExtension('notes.txt'), 'text/plain');
      expect(classifyAttachmentByExtension('readme.MD'), 'text/plain');
      expect(classifyAttachmentByExtension('report.pdf'), 'application/pdf');
    });

    test('unknown or missing extensions fall back to octet-stream', () {
      expect(classifyAttachmentByExtension('data.zip'), 'application/octet-stream');
      expect(classifyAttachmentByExtension('noextension'), 'application/octet-stream');
      expect(classifyAttachmentByExtension('trailing.'), 'application/octet-stream');
      expect(classifyAttachmentByExtension(''), 'application/octet-stream');
    });
  });

  group('PickedAttachment', () {
    test('isImage follows the mime type', () {
      final image = PickedAttachment(
        name: 'a.png',
        path: '',
        mimeType: 'image/png',
        bytes: Uint8List(0),
      );
      final doc = PickedAttachment(
        name: 'a.pdf',
        path: '',
        mimeType: 'application/pdf',
        bytes: Uint8List(0),
      );
      expect(image.isImage, isTrue);
      expect(doc.isImage, isFalse);
    });
  });

  group('checkAttachmentSize', () {
    test('accepts files up to exactly 10 MB', () {
      expect(() => checkAttachmentSize(10 * 1024 * 1024), returnsNormally);
      expect(() => checkAttachmentSize(0), returnsNormally);
    });

    test('refuses files over 10 MB with a plain message', () {
      expect(
        () => checkAttachmentSize(10 * 1024 * 1024 + 1),
        throwsA(
          isA<AttachmentException>().having(
            (e) => e.message,
            'message',
            'That file is too big (over 10 MB).',
          ),
        ),
      );
    });
  });

  group('sendMessageWithImage', () {
    test('sends text + inlineData image parts to generateContent', () async {
      final imageBytes = <int>[0x89, 0x50, 0x4E, 0x47]; // PNG magic bytes
      final mock = MockClient((request) async {
        expect(request.url.host, 'generativelanguage.googleapis.com');
        expect(
          request.url.path,
          '/v1beta/models/gemini-3.8-flash:generateContent',
        );
        expect(request.headers['x-goog-api-key'], 'test-api-key');
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        final contents = body['contents'] as List<dynamic>;
        expect(contents, hasLength(1));
        final parts = contents[0]['parts'] as List<dynamic>;
        expect(parts, hasLength(2));
        expect(parts[0]['text'], 'What is in this image?');
        final inlineData = parts[1]['inlineData'] as Map<String, dynamic>;
        expect(inlineData['mimeType'], 'image/png');
        expect(inlineData['data'], base64Encode(imageBytes));
        return http.Response(
          jsonEncode({
            'candidates': [
              {
                'content': {
                  'parts': [
                    {'text': 'A cat.'},
                  ],
                },
              },
            ],
          }),
          200,
          headers: {'content-type': 'application/json'},
        );
      });

      final client = GeminiRestClient(
        apiKey: 'test-api-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      final answer = await client.sendMessageWithImage(
        message: 'What is in this image?',
        history: const [],
        imageBytes: imageBytes,
        mimeType: 'image/png',
      );
      expect(answer, 'A cat.');
      mock.close();
      client.dispose();
    });

    test('keeps history turns before the image turn', () async {
      final mock = MockClient((request) async {
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        final contents = body['contents'] as List<dynamic>;
        expect(contents, hasLength(2));
        expect(contents[0]['role'], 'model');
        expect(contents[1]['role'], 'user');
        expect((contents[1]['parts'] as List).length, 2);
        return http.Response(
          jsonEncode({
            'candidates': [
              {
                'content': {
                  'parts': [
                    {'text': 'Seen it.'},
                  ],
                },
              },
            ],
          }),
          200,
        );
      });
      final client = GeminiRestClient(
        apiKey: 'test-api-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      final answer = await client.sendMessageWithImage(
        message: 'Look again',
        history: const [GeminiChatMessage(role: 'model', text: 'Earlier.')],
        imageBytes: <int>[1, 2, 3],
        mimeType: 'image/jpeg',
      );
      expect(answer, 'Seen it.');
      mock.close();
      client.dispose();
    });

    test('rejects unsupported mime types without a request', () async {
      var calls = 0;
      final mock = MockClient((request) async {
        calls++;
        return http.Response('{}', 200);
      });
      final client = GeminiRestClient(
        apiKey: 'test-api-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      expect(
        () => client.sendMessageWithImage(
          message: 'Hi',
          history: const [],
          imageBytes: <int>[1],
          mimeType: 'image/bmp',
        ),
        throwsA(isA<GeminiApiException>()),
      );
      expect(calls, 0);
      mock.close();
      client.dispose();
    });

    test('rejects empty image bytes without a request', () async {
      var calls = 0;
      final mock = MockClient((request) async {
        calls++;
        return http.Response('{}', 200);
      });
      final client = GeminiRestClient(
        apiKey: 'test-api-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      expect(
        () => client.sendMessageWithImage(
          message: 'Hi',
          history: const [],
          imageBytes: const <int>[],
          mimeType: 'image/png',
        ),
        throwsA(
          isA<GeminiApiException>().having(
            (e) => e.message,
            'message',
            'The image is empty.',
          ),
        ),
      );
      expect(calls, 0);
      mock.close();
      client.dispose();
    });

    test('surfaces API error messages', () async {
      final mock = MockClient(
        (request) async => http.Response(
          jsonEncode({
            'error': {'message': 'API key not valid'},
          }),
          400,
        ),
      );
      final client = GeminiRestClient(
        apiKey: 'bad-key',
        modelName: 'gemini-3.8-flash',
        httpClient: mock,
      );
      expect(
        () => client.sendMessageWithImage(
          message: 'Hi',
          history: const [],
          imageBytes: <int>[1, 2],
          mimeType: 'image/webp',
        ),
        throwsA(
          isA<GeminiApiException>().having(
            (e) => e.message,
            'message',
            'API key not valid',
          ),
        ),
      );
      mock.close();
      client.dispose();
    });
  });
}
