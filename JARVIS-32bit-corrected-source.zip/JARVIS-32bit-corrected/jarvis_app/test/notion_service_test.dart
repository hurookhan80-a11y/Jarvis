// v1.2.0 (G9) — Notion search / append / read parsers, REST calls
// (MockClient), and the token-gated enable flag.
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:jarvis_app/notion_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  group('parseNotionSearch', () {
    test('reads ids and title-property plain text', () {
      final pages = parseNotionSearch({
        'results': [
          {
            'id': 'page-1',
            'properties': {
              'title': {
                'type': 'title',
                'title': [
                  {'plain_text': 'Shopping '},
                  {'plain_text': 'List'},
                ],
              },
            },
          },
          {
            'id': 'page-2',
            'properties': {
              'Name': {
                'type': 'title',
                'title': [
                  {'plain_text': 'Exam Notes'},
                ],
              },
            },
          },
        ],
      });
      expect(pages.map((p) => p.id), ['page-1', 'page-2']);
      expect(pages.map((p) => p.title), ['Shopping List', 'Exam Notes']);
    });

    test('falls back to the first rich_text property, then untitled', () {
      final pages = parseNotionSearch({
        'results': [
          {
            'id': 'page-3',
            'properties': {
              'Summary': {
                'type': 'rich_text',
                'rich_text': [
                  {'plain_text': 'A summary page'},
                ],
              },
            },
          },
          {'id': 'page-4', 'properties': <String, dynamic>{}},
          {'properties': <String, dynamic>{}}, // no id: dropped
        ],
      });
      expect(pages.map((p) => p.id), ['page-3', 'page-4']);
      expect(pages.map((p) => p.title), ['A summary page', '(Untitled page)']);
    });

    test('returns empty for a missing or empty results list', () {
      expect(parseNotionSearch(<String, dynamic>{}), isEmpty);
      expect(parseNotionSearch({'results': []}), isEmpty);
    });
  });

  group('parseNotionBlocks', () {
    test('joins readable blocks in order, skips the rest', () {
      final text = parseNotionBlocks({
        'results': [
          {
            'type': 'heading_1',
            'heading_1': {
              'rich_text': [
                {'plain_text': 'Title'},
              ],
            },
          },
          {
            'type': 'paragraph',
            'paragraph': {
              'rich_text': [
                {'plain_text': 'First '},
                {'plain_text': 'line.'},
              ],
            },
          },
          {
            'type': 'bulleted_list_item',
            'bulleted_list_item': {
              'rich_text': [
                {'plain_text': 'A point'},
              ],
            },
          },
          {
            'type': 'to_do',
            'to_do': {
              'rich_text': [
                {'plain_text': 'A task'},
              ],
              'checked': false,
            },
          },
          {
            'type': 'image',
            'image': <String, dynamic>{},
          },
          {
            'type': 'paragraph',
            'paragraph': {'rich_text': []}, // empty: skipped
          },
        ],
      });
      expect(text, 'Title\nFirst line.\nA point\nA task');
    });

    test('returns empty when there are no readable blocks', () {
      expect(parseNotionBlocks(<String, dynamic>{}), isEmpty);
      expect(parseNotionBlocks({'results': []}), isEmpty);
    });
  });

  group('NotionService REST', () {
    test('searchPages posts the query + page filter with version header', () async {
      final mock = MockClient((request) async {
        expect(request.method, 'POST');
        expect(request.url.toString(), 'https://api.notion.com/v1/search');
        expect(request.headers['Notion-Version'], '2022-06-28');
        expect(
          request.headers['Authorization'],
          'Bearer secret_notion_123',
        );
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        expect(body['query'], 'exam');
        expect(body['filter'], {
          'property': 'object',
          'value': 'page',
        });
        expect(body['page_size'], 10);
        return http.Response(
          jsonEncode({
            'results': [
              {
                'id': 'abc',
                'properties': {
                  'title': {
                    'title': [
                      {'plain_text': 'Exam Notes'},
                    ],
                  },
                },
              },
            ],
          }),
          200,
          headers: {'content-type': 'application/json'},
        );
      });
      final service = _NotionServiceWithToken(client: mock, token: 'secret_notion_123');
      final pages = await service.searchPages('exam');
      expect(pages, hasLength(1));
      expect(pages.first.id, 'abc');
      expect(pages.first.title, 'Exam Notes');
      mock.close();
      service.dispose();
    });

    test('appendToPage patches a paragraph block under the page', () async {
      final mock = MockClient((request) async {
        expect(request.method, 'PATCH');
        expect(
          request.url.toString(),
          'https://api.notion.com/v1/blocks/page-9/children',
        );
        final body = jsonDecode(request.body) as Map<String, dynamic>;
        final children = body['children'] as List<dynamic>;
        expect(children, hasLength(1));
        expect(children[0]['object'], 'block');
        expect(children[0]['type'], 'paragraph');
        final richText =
            children[0]['paragraph']['rich_text'] as List<dynamic>;
        expect(richText[0]['type'], 'text');
        expect(richText[0]['text']['content'], 'Buy milk');
        return http.Response('{}', 200);
      });
      final service = _NotionServiceWithToken(client: mock, token: 'tok');
      await service.appendToPage(pageId: 'page-9', text: 'Buy milk');
      mock.close();
      service.dispose();
    });

    test('readPage joins block text and caps at ~4000 chars', () async {
      final longLine = 'x' * 5000;
      final mock = MockClient((request) async {
        expect(request.method, 'GET');
        expect(
          request.url.toString(),
          'https://api.notion.com/v1/blocks/page-7/children',
        );
        return http.Response(
          jsonEncode({
            'results': [
              {
                'type': 'paragraph',
                'paragraph': {
                  'rich_text': [
                    {'plain_text': longLine},
                  ],
                },
              },
            ],
          }),
          200,
        );
      });
      final service = _NotionServiceWithToken(client: mock, token: 'tok');
      final text = await service.readPage(pageId: 'page-7');
      expect(text.length, kNotionReadPageMaxChars + 1); // + '…'
      expect(text.endsWith('…'), isTrue);
      mock.close();
      service.dispose();
    });

    test('401 gives the plain token message', () async {
      final mock = MockClient(
        (request) async => http.Response('{"message":"unauthorized"}', 401),
      );
      final service = _NotionServiceWithToken(client: mock, token: 'bad-tok');
      expect(
        () => service.searchPages('x'),
        throwsA(
          isA<NotionException>().having(
            (e) => e.message,
            'message',
            'Notion refused the token — check the integration token.',
          ),
        ),
      );
      mock.close();
      service.dispose();
    });

    test('empty text and empty page id are refused before any request', () async {
      var calls = 0;
      final mock = MockClient((request) async {
        calls++;
        return http.Response('{}', 200);
      });
      final service = _NotionServiceWithToken(client: mock, token: 'tok');
      expect(
        () => service.appendToPage(pageId: 'p', text: '   '),
        throwsA(isA<NotionException>()),
      );
      expect(
        () => service.readPage(pageId: '  '),
        throwsA(isA<NotionException>()),
      );
      expect(calls, 0);
      mock.close();
      service.dispose();
    });
  });

  group('NotionService enable flag', () {
    test('setEnabled(true) refuses without a token', () async {
      // No token can be stored in a unit test (secure storage is a
      // platform channel with no test double), so hasToken() is false.
      final service = NotionService(client: MockClient(
        (request) async => http.Response('{}', 200),
      ));
      expect(await service.setEnabled(true), isFalse);
      expect(await service.isEnabled(), isFalse);
      service.dispose();
    });

    test('setEnabled(false) always works', () async {
      final service = NotionService(client: MockClient(
        (request) async => http.Response('{}', 200),
      ));
      expect(await service.setEnabled(false), isTrue);
      expect(await service.isEnabled(), isFalse);
      service.dispose();
    });
  });
}

/// Test double: a NotionService whose token read is faked, so the REST
/// calls can be tested without the platform secure-storage channel.
class _NotionServiceWithToken extends NotionService {
  _NotionServiceWithToken({required super.client, required this.token});

  final String token;

  @override
  Future<String> readToken() async => token;

  @override
  Future<bool> hasToken() async => token.trim().isNotEmpty;
}
