// Phase 6 (v1.1.0) — F21 on-device index: search across chats,
// reminders, saved facts and knowledge files.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/knowledge_service.dart';
import 'package:jarvis_app/local_index.dart';
import 'package:jarvis_app/memory_service.dart';

void main() {
  final sessions = <Map<String, dynamic>>[
    {
      'id': 1,
      'title': 'Sleep questions',
      'startedAt': '2026-11-20T10:00:00.000',
      'messages': [
        {'role': 'user', 'text': 'Why do we need sleep?'},
        {'role': 'jarvis', 'text': 'Sleep clears metabolic waste.'},
      ],
    },
    {
      'id': 2,
      'title': 'Anatomy revision',
      'startedAt': '2026-11-21T10:00:00.000',
      'messages': [
        {'role': 'user', 'text': 'Name the heart chambers.'},
      ],
    },
  ];
  final reminders = <Map<String, dynamic>>[
    {
      'id': 10,
      'text': 'study anatomy at 7',
      'fireAt': '2026-11-22T19:00:00.000',
    },
  ];
  final facts = <SavedFact>[
    SavedFact(
      text: 'my exam is on 5 December',
      savedAt: DateTime(2026, 11, 22, 9),
    ),
  ];
  final files = <KnowledgeFile>[
    const KnowledgeFile(
      name: 'sleep notes.txt',
      content: 'Deep sleep consolidates memory and clears waste.',
    ),
  ];

  List<LocalSearchResult> search(String query) => searchLocalIndex(
        query: query,
        sessions: sessions,
        reminders: reminders,
        facts: facts,
        files: files,
      );

  test('empty query returns nothing', () {
    expect(search('   '), isEmpty);
  });

  test('matches are case-insensitive substrings', () {
    final results = search('SLEEP');
    expect(results.map((r) => r.type), contains(LocalSearchResultType.chat));
    expect(results.map((r) => r.type),
        contains(LocalSearchResultType.knowledge));
  });

  test('results are grouped: chat, reminder, fact, knowledge', () {
    final results = search('anatomy');
    expect(
      results.map((r) => r.type).toList(),
      [
        LocalSearchResultType.chat,
        LocalSearchResultType.reminder,
      ],
    );
    expect(results.first.title, 'Anatomy revision');
    expect(results.first.session?['id'], 2);
    expect(results.last.title, 'study anatomy at 7');
  });

  test('a fact hit carries the fact text', () {
    final results = search('5 december');
    expect(results, hasLength(1));
    expect(results.first.type, LocalSearchResultType.fact);
    expect(results.first.factText, 'my exam is on 5 December');
  });

  test('a knowledge hit carries the file name and content', () {
    final results = search('consolidates');
    expect(results, hasLength(1));
    expect(results.first.type, LocalSearchResultType.knowledge);
    expect(results.first.fileName, 'sleep notes.txt');
    expect(results.first.fileContent, contains('Deep sleep'));
    expect(results.first.subtitle, contains('consolidates'));
  });

  test('no match returns an empty list', () {
    expect(search('zebra crossing'), isEmpty);
  });

  test('a title-only chat hit is still found', () {
    final results = search('revision');
    expect(results, hasLength(1));
    expect(results.first.subtitle, 'Title matches');
  });

  group('searchSnippet', () {
    test('centres on the match and ellipsises the cuts', () {
      const text =
          'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa needle bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb';
      final snippet = searchSnippet(text, 'needle', maxChars: 40);
      expect(snippet, contains('needle'));
      expect(snippet, startsWith('…'));
      expect(snippet, endsWith('…'));
      expect(snippet.length, lessThanOrEqualTo(42));
    });

    test('falls back to the start when there is no match', () {
      expect(searchSnippet('short text', 'zzz'), 'short text');
    });
  });
}
