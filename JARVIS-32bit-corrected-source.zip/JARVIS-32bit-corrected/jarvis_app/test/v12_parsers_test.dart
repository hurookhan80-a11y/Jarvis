import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/v12_parsers.dart';

void main() {
  group('parseV12TimeOfDay', () {
    test('3 pm', () {
      expect(parseV12TimeOfDay('at 3 pm'), (hour: 15, minute: 0));
    });
    test('3:30 pm', () {
      expect(parseV12TimeOfDay('at 3:30 pm'), (hour: 15, minute: 30));
    });
    test('12 am is midnight', () {
      expect(parseV12TimeOfDay('at 12 am'), (hour: 0, minute: 0));
    });
    test('12 pm is noon', () {
      expect(parseV12TimeOfDay('at 12 pm'), (hour: 12, minute: 0));
    });
    test('24-hour form', () {
      expect(parseV12TimeOfDay('at 15:30'), (hour: 15, minute: 30));
      expect(parseV12TimeOfDay('at 9:05'), (hour: 9, minute: 5));
    });
    test('invalid times are null', () {
      expect(parseV12TimeOfDay('at 25 pm'), isNull);
      expect(parseV12TimeOfDay('at 3:99 pm'), isNull);
      expect(parseV12TimeOfDay('hello'), isNull);
    });
  });

  group('parseV12EventDateTime', () {
    // Monday 23 Nov 2026, 10:00 — pinned so weekday math is stable.
    final now = DateTime(2026, 11, 23, 10, 0);

    test('tomorrow at 3 pm', () {
      expect(parseV12EventDateTime('tomorrow at 3 pm', now),
          DateTime(2026, 11, 24, 15, 0));
    });
    test('today at 3 pm', () {
      expect(parseV12EventDateTime('today at 3 pm', now),
          DateTime(2026, 11, 23, 15, 0));
    });
    test('unnamed past time rolls to tomorrow', () {
      expect(parseV12EventDateTime('at 9 am', now),
          DateTime(2026, 11, 24, 9, 0));
    });
    test('friday at 10 am is this week', () {
      expect(parseV12EventDateTime('friday at 10 am', now),
          DateTime(2026, 11, 27, 10, 0));
    });
    test('monday at 3 pm is today', () {
      expect(parseV12EventDateTime('monday at 3 pm', now),
          DateTime(2026, 11, 23, 15, 0));
    });
    test('monday at 9 am already passed rolls to next week', () {
      expect(parseV12EventDateTime('monday at 9 am', now),
          DateTime(2026, 11, 30, 9, 0));
    });
    test('next friday at 10 am', () {
      expect(parseV12EventDateTime('next friday at 10 am', now),
          DateTime(2026, 12, 4, 10, 0));
    });
    test('no time is null', () {
      expect(parseV12EventDateTime('team meeting tomorrow', now), isNull);
    });
  });

  group('parseV12EventTitle', () {
    test('strips trigger, day and time', () {
      expect(
          parseV12EventTitle(
              'create a calendar event team meeting tomorrow at 3 pm'),
          'team meeting');
    });
    test('add event form', () {
      expect(parseV12EventTitle('add event dentist on friday at 10 am'),
          'dentist');
    });
    test('24-hour time stripped', () {
      expect(
          parseV12EventTitle('create an event call ami at 15:30'),
          'call ami');
    });
  });

  group('formatV12EventTime', () {
    test('Monday 3:30 pm', () {
      expect(formatV12EventTime(DateTime(2026, 11, 23, 15, 30)),
          'Monday, 3:30 pm');
    });
    test('midnight edge', () {
      expect(formatV12EventTime(DateTime(2026, 11, 24, 0, 5)),
          'Tuesday, 12:05 am');
    });
  });

  group('parseV12EmailCommand', () {
    test('full command keeps original case', () {
      final parsed = parseV12EmailCommand(
          'Send an email to Ami@Example.com subject Hello There body Please call me');
      expect(parsed, isNotNull);
      expect(parsed!.to, 'Ami@Example.com');
      expect(parsed.subject, 'Hello There');
      expect(parsed.body, 'Please call me');
    });
    test('about + saying forms', () {
      final parsed = parseV12EmailCommand(
          'draft an email to a@b.com about the Report saying here it is');
      expect(parsed, isNotNull);
      expect(parsed!.subject, 'the Report');
      expect(parsed.body, 'here it is');
    });
    test('address only', () {
      final parsed =
          parseV12EmailCommand('send an email to a@b.com');
      expect(parsed, isNotNull);
      expect(parsed!.to, 'a@b.com');
      expect(parsed.subject, isEmpty);
      expect(parsed.body, isEmpty);
    });
    test('no address is null', () {
      expect(parseV12EmailCommand('send an email to Ami'), isNull);
    });
  });

  group('parseV12ResearchQuery', () {
    test('search the web for', () {
      expect(
          parseV12ResearchQuery('search the web for spina bifida',
              'Search the web for Spina Bifida'),
          'Spina Bifida');
    });
    test('research prefix', () {
      expect(parseV12ResearchQuery('research black holes',
          'Research black holes'), 'black holes');
    });
    test('look up strips trailing on the web', () {
      expect(
          parseV12ResearchQuery('look up vitamin d on the web',
              'Look up Vitamin D on the web'),
          'Vitamin D');
    });
    test('non-research is null', () {
      expect(parseV12ResearchQuery('what is the time', 'What is the time'),
          isNull);
      expect(parseV12ResearchQuery('search the web for ', 'Search the web for '),
          isNull);
    });
    // 'research mode' parses to 'mode' here on purpose — the router
    // in main.dart checks the mode switch first, so it never reaches
    // the research parser as a command.
    test('research mode parses as the topic mode', () {
      expect(parseV12ResearchQuery('research mode', 'Research mode'),
          'mode');
    });
  });

  group('extractV12Topic', () {
    test('about form', () {
      expect(
          extractV12Topic('run research and save workflow about diabetes'),
          'diabetes');
    });
    test('for form', () {
      expect(extractV12Topic('run email production workflow for the team'),
          'the team');
    });
    test('no topic is null', () {
      expect(extractV12Topic('run morning briefing workflow'), isNull);
    });
  });
}
