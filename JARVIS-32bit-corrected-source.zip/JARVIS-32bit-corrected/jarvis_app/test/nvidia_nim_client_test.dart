// Phase 6 (v1.1.0) — F20 NVIDIA NIM provider: request shape, response
// parsing, SSE streaming, error mapping.
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:jarvis_app/chat_provider.dart';
import 'package:jarvis_app/nvidia_nim_client.dart';

void main() {
  group('NvidiaNimChatProvider.sendMessage', () {
    test('posts the verified endpoint, model and Bearer key', () async {
      var seenUrl = Uri();
      var seenHeaders = <String, String>{};
      var seenBody = <String, dynamic>{};
      final mock = MockClient((request) async {
        seenUrl = request.url;
        seenHeaders = request.headers;
        seenBody = jsonDecode(request.body) as Map<String, dynamic>;
        return http.Response(
          jsonEncode({
            'choices': [
              {
                'message': {'role': 'assistant', 'content': 'NIM answer.'},
              },
            ],
          }),
          200,
          headers: {'content-type': 'application/json'},
        );
      });

      final provider = NvidiaNimChatProvider(
        apiKey: 'nvapi-test-key',
        httpClient: mock,
      );
      final answer = await provider.sendMessage(
        message: 'Hello',
        history: const [
          ChatMessage(role: 'model', text: 'Welcome back.'),
          ChatMessage(role: 'user', text: 'What time is it?'),
        ],
      );
      expect(answer, 'NIM answer.');
      expect(seenUrl.toString(), kNvidiaNimEndpoint);
      expect(seenHeaders['Authorization'], 'Bearer nvapi-test-key');
      expect(seenBody['model'], 'nvidia/nemotron-3-ultra-550b-a55b');
      expect(seenBody['temperature'], 0.5);
      expect(seenBody['top_p'], 0.9);
      expect(seenBody['max_tokens'], 4096);
      expect(seenBody['stream'], isFalse);
      final messages = seenBody['messages'] as List<dynamic>;
      // History roles translate: Gemini 'model' -> OpenAI 'assistant'.
      expect(messages[0]['role'], 'assistant');
      expect(messages[0]['content'], 'Welcome back.');
      expect(messages[1]['role'], 'user');
      expect(messages[2]['role'], 'user');
      expect(messages[2]['content'], 'Hello');
      expect(provider.name, 'NVIDIA NIM');
      expect(provider.isFallback, isTrue);
      mock.close();
      provider.dispose();
    });

    test('system instruction goes first as a system message', () async {
      var seenBody = <String, dynamic>{};
      final mock = MockClient((request) async {
        seenBody = jsonDecode(request.body) as Map<String, dynamic>;
        return http.Response(
          jsonEncode({
            'choices': [
              {
                'message': {'role': 'assistant', 'content': 'ok'},
              },
            ],
          }),
          200,
        );
      });
      final provider = NvidiaNimChatProvider(
        apiKey: 'nvapi-test-key',
        systemInstruction: 'Remember: exam on 5 December.',
        httpClient: mock,
      );
      await provider.sendMessage(message: 'Hi', history: const []);
      final messages = seenBody['messages'] as List<dynamic>;
      expect(messages.first['role'], 'system');
      expect(messages.first['content'], contains('exam on 5 December'));
      mock.close();
      provider.dispose();
    });

    test('surfaces the API error message with its status code', () async {
      final mock = MockClient(
        (request) async => http.Response(
          jsonEncode({
            'error': {'message': 'Invalid API key'},
          }),
          401,
        ),
      );
      final provider = NvidiaNimChatProvider(
        apiKey: 'bad-key',
        httpClient: mock,
      );
      try {
        await provider.sendMessage(message: 'Hi', history: const []);
        fail('expected a ChatProviderException');
      } on ChatProviderException catch (e) {
        expect(e.message, 'Invalid API key');
        expect(e.statusCode, 401);
        expect(e.fallbackEligible, isFalse);
      }
      mock.close();
      provider.dispose();
    });

    test('empty key and empty message are rejected without a request',
        () async {
      var calls = 0;
      final mock = MockClient((request) async {
        calls++;
        return http.Response('{}', 200);
      });
      final noKey = NvidiaNimChatProvider(apiKey: '  ', httpClient: mock);
      await expectLater(
        () => noKey.sendMessage(message: 'Hi', history: const []),
        throwsA(isA<ChatProviderException>()),
      );
      final provider =
          NvidiaNimChatProvider(apiKey: 'nvapi-key', httpClient: mock);
      await expectLater(
        () => provider.sendMessage(message: '  ', history: const []),
        throwsA(isA<ChatProviderException>()),
      );
      expect(calls, 0);
      mock.close();
      noKey.dispose();
      provider.dispose();
    });
  });

  group('parseNimSseTextDeltas', () {
    test('parses delta content and skips [DONE] and junk lines', () {
      const chunk = '''
data: {"choices": [{"delta": {"content": "Hello"}}]}

data: {"choices": [{"delta": {"content": " world"}}]}

data: [DONE]
not json at all
''';
      expect(
        parseNimSseTextDeltas(chunk),
        ['Hello', ' world'],
      );
    });

    test('nimChoiceText reads message and delta content', () {
      expect(
        nimChoiceText({
          'choices': [
            {
              'message': {'content': 'full answer'},
            },
          ],
        }),
        'full answer',
      );
      expect(
        nimChoiceText(
          {
            'choices': [
              {
                'delta': {'content': 'partial'},
              },
            ],
          },
          streaming: true,
        ),
        'partial',
      );
      expect(nimChoiceText({'choices': []}), '');
      expect(nimChoiceText(null), '');
    });
  });

  group('NvidiaNimChatProvider.sendMessageStream', () {
    test('streams SSE deltas until [DONE]', () async {
      final mock = MockClient((request) async {
        return http.Response(
          'data: {"choices": [{"delta": {"content": "Hello"}}]}\n'
          'data: {"choices": [{"delta": {"content": " there"}}]}\n'
          'data: [DONE]\n',
          200,
          headers: {'content-type': 'text/event-stream'},
        );
      });
      final provider = NvidiaNimChatProvider(
        apiKey: 'nvapi-test-key',
        httpClient: mock,
      );
      final deltas = await provider
          .sendMessageStream(message: 'Hi', history: const [])
          .toList();
      expect(deltas, ['Hello', ' there']);
      mock.close();
      provider.dispose();
    });

    test('a streaming HTTP error throws with its status code', () async {
      final mock = MockClient(
        (request) async => http.Response(
          jsonEncode({
            'error': {'message': 'Too many requests'},
          }),
          429,
        ),
      );
      final provider = NvidiaNimChatProvider(
        apiKey: 'nvapi-test-key',
        httpClient: mock,
      );
      await expectLater(
        () => provider
            .sendMessageStream(message: 'Hi', history: const [])
            .toList(),
        throwsA(isA<ChatProviderException>().having(
          (e) => e.statusCode,
          'statusCode',
          429,
        )),
      );
      mock.close();
      provider.dispose();
    });
  });
}
