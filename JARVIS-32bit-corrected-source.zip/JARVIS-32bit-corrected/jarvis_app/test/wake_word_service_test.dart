import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/wake_word_service.dart';

/// Fake engine: no mic, no models — the service logic is what is tested.
class FakeWakeWordEngine implements WakeWordEngine {
  bool available = true;
  bool running = false;
  int ensureReadyCalls = 0;
  int startCalls = 0;
  int stopCalls = 0;
  bool disposed = false;
  final StreamController<void> detectionsController =
      StreamController<void>.broadcast();

  @override
  bool get isAvailable => available;

  @override
  bool get isRunning => running;

  @override
  Stream<void> get detections => detectionsController.stream;

  @override
  Future<bool> ensureReady() async {
    ensureReadyCalls++;
    return available;
  }

  @override
  Future<bool> start() async {
    startCalls++;
    if (!available) return false;
    running = true;
    return true;
  }

  @override
  Future<void> stop() async {
    stopCalls++;
    running = false;
  }

  @override
  Future<void> dispose() async {
    disposed = true;
    await detectionsController.close();
  }
}

void main() {
  group('WakeWordStateMachine', () {
    test('fresh wake-up from idle enters the conversation', () {
      final machine = WakeWordStateMachine();
      expect(machine.phase, WakeWordPhase.idle);
      expect(
        machine.onWakeWord(),
        WakeWordAction.enterConversation,
      );
      expect(machine.phase, WakeWordPhase.listening);
    });

    test('wake word while listening is ignored (recogniser hears it)', () {
      final machine = WakeWordStateMachine();
      machine.onConversationStarted();
      expect(machine.onWakeWord(), WakeWordAction.none);
      expect(machine.phase, WakeWordPhase.listening);
    });

    test('wake word while speaking barges in when enabled', () {
      final machine = WakeWordStateMachine(bargeInEnabled: true);
      machine.onConversationStarted();
      machine.onSpeechStarted();
      expect(machine.phase, WakeWordPhase.speaking);
      expect(machine.onWakeWord(), WakeWordAction.bargeIn);
      expect(machine.phase, WakeWordPhase.listening);
    });

    test('wake word while speaking is ignored when barge-in is off', () {
      final machine = WakeWordStateMachine(bargeInEnabled: false);
      machine.onConversationStarted();
      machine.onSpeechStarted();
      expect(machine.onWakeWord(), WakeWordAction.none);
      expect(machine.phase, WakeWordPhase.speaking);
    });

    test('answer finishing moves to the follow-up window', () {
      final machine = WakeWordStateMachine();
      machine.onConversationStarted();
      machine.onSpeechStarted();
      machine.onSpeechEnded();
      expect(machine.phase, WakeWordPhase.followUp);
    });

    test('follow-up expiry ends the conversation only from follow-up', () {
      final machine = WakeWordStateMachine();
      machine.onConversationStarted();
      machine.onSpeechStarted();
      machine.onSpeechEnded();
      expect(
        machine.onFollowUpExpired(),
        WakeWordAction.endConversation,
      );
      expect(machine.phase, WakeWordPhase.idle);

      // Expiring again (or while idle) does nothing.
      expect(machine.onFollowUpExpired(), WakeWordAction.none);
    });

    test('a follow-up command returns to listening, expiry then ignored',
        () {
      final machine = WakeWordStateMachine();
      machine.onConversationStarted();
      machine.onSpeechStarted();
      machine.onSpeechEnded();
      machine.onCommandHeard();
      expect(machine.phase, WakeWordPhase.listening);
      expect(machine.onFollowUpExpired(), WakeWordAction.none);
    });

    test('speech starting during follow-up goes back to speaking', () {
      final machine = WakeWordStateMachine();
      machine.onConversationStarted();
      machine.onSpeechStarted();
      machine.onSpeechEnded();
      machine.onSpeechStarted();
      expect(machine.phase, WakeWordPhase.speaking);
    });

    test('STOP while speaking opens the follow-up window', () {
      final machine = WakeWordStateMachine();
      machine.onConversationStarted();
      machine.onSpeechStarted();
      machine.onStopPressed();
      expect(machine.phase, WakeWordPhase.followUp);
      expect(
        machine.onFollowUpExpired(),
        WakeWordAction.endConversation,
      );
    });

    test('STOP while listening opens the follow-up window', () {
      final machine = WakeWordStateMachine();
      machine.onConversationStarted();
      machine.onStopPressed();
      expect(machine.phase, WakeWordPhase.followUp);
    });

    test('one-off speech while idle does not change the phase', () {
      // A greeting spoken before the machine heard about the wake-up,
      // or a one-off message ("Settings saved") while idle: a wake word
      // during it must still wake normally, not barge in.
      final machine = WakeWordStateMachine();
      machine.onSpeechStarted();
      expect(machine.phase, WakeWordPhase.idle);
      machine.onSpeechEnded();
      expect(machine.phase, WakeWordPhase.idle);
      expect(
        machine.onWakeWord(),
        WakeWordAction.enterConversation,
      );
    });

    test('wake word during follow-up is ignored', () {
      final machine = WakeWordStateMachine();
      machine.onConversationStarted();
      machine.onSpeechStarted();
      machine.onSpeechEnded();
      expect(machine.onWakeWord(), WakeWordAction.none);
      expect(machine.phase, WakeWordPhase.followUp);
    });

    test('reset returns to idle', () {
      final machine = WakeWordStateMachine();
      machine.onConversationStarted();
      machine.reset();
      expect(machine.phase, WakeWordPhase.idle);
    });

    test('follow-up window is 8 seconds', () {
      expect(kFollowUpWindow, const Duration(seconds: 8));
    });
  });

  group('WakeWordService', () {
    test('ensureReady/start/stop delegate to the engine', () async {
      final engine = FakeWakeWordEngine();
      final service = WakeWordService(engineFactory: () => engine);

      expect(service.isAvailable, isFalse);
      expect(await service.ensureReady(), isTrue);
      expect(service.isAvailable, isTrue);
      expect(engine.ensureReadyCalls, 1);

      expect(await service.start(), isTrue);
      expect(service.isRunning, isTrue);
      expect(engine.startCalls, 1);

      await service.stop();
      expect(service.isRunning, isFalse);
      expect(engine.stopCalls, 1);

      await service.dispose();
      expect(engine.disposed, isTrue);
    });

    test('unavailable engine reports false and never starts', () async {
      final engine = FakeWakeWordEngine()..available = false;
      final service = WakeWordService(engineFactory: () => engine);

      expect(await service.ensureReady(), isFalse);
      expect(service.isAvailable, isFalse);
      expect(await service.start(), isFalse);
      expect(service.isRunning, isFalse);
      await service.dispose();
    });

    test('detections pass through from the engine', () async {
      final engine = FakeWakeWordEngine();
      final service = WakeWordService(engineFactory: () => engine);
      await service.ensureReady();

      var seen = 0;
      final sub = service.detections.listen((_) => seen++);
      engine.detectionsController.add(null);
      engine.detectionsController.add(null);
      await Future<void>.delayed(Duration.zero);
      expect(seen, 2);
      await sub.cancel();
      await service.dispose();
    });

    test('start loads the engine lazily when ensureReady was not called',
        () async {
      final engine = FakeWakeWordEngine();
      final service = WakeWordService(engineFactory: () => engine);
      expect(await service.start(), isTrue);
      expect(engine.ensureReadyCalls, 1);
      await service.dispose();
    });
  });
}
