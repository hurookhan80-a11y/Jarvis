// v1.2.0 — G7 web research service.
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:jarvis_app/web_research_service.dart';

void main() {
  group('parseWikipediaSearch', () {
    test('parses titles and pageids in order', () {
      final body = jsonEncode({
        'query': {
          'search': [
            {'title': 'Spina bifida', 'pageid': 123},
            {'title': 'Neural tube defect', 'pageid': 456},
          ],
        },
      });
      final hits = parseWikipediaSearch(body);
      expect(hits.length, 2);
      expect(hits[0].title, 'Spina bifida');
      expect(hits[0].pageid, 123);
      expect(hits[1].title, 'Neural tube defect');
    });

    test('malformed or empty responses give []', () {
      expect(parseWikipediaSearch('not json'), isEmpty);
      expect(parseWikipediaSearch('{}'), isEmpty);
      expect(parseWikipediaSearch(jsonEncode({'query': {}})), isEmpty);
    });
  });

  group('parseWikipediaSummary', () {
    test('returns the extract', () {
      final body = jsonEncode({
        'extract': 'Spina bifida is a birth defect.',
        'title': 'Spina bifida',
      });
      expect(
        parseWikipediaSummary(body),
        'Spina bifida is a birth defect.',
      );
    });

    test('missing extract gives empty string', () {
      expect(parseWikipediaSummary('{}'), '');
      expect(parseWikipediaSummary('garbage'), '');
    });
  });

  group('parseDuckDuckGoAnswer', () {
    test('parses abstract, heading and URL', () {
      final body = jsonEncode({
        'AbstractText': 'Paris is the capital of France.',
        'Heading': 'Paris',
        'AbstractURL': 'https://en.wikipedia.org/wiki/Paris',
      });
      final result = parseDuckDuckGoAnswer(body, 'capital of France');
      expect(result, isNotNull);
      expect(result!.title, 'Paris');
      expect(result.extract, 'Paris is the capital of France.');
      expect(result.url, 'https://en.wikipedia.org/wiki/Paris');
      expect(result.source, 'duckduckgo');
    });

    test('no abstract text gives null', () {
      final body = jsonEncode({'AbstractText': '', 'Heading': 'X'});
      expect(parseDuckDuckGoAnswer(body, 'x'), isNull);
      expect(parseDuckDuckGoAnswer('{}', 'x'), isNull);
    });
  });

  group('WebResearchService.search', () {
    test('merges Wikipedia + DuckDuckGo, dedupes by URL, caps at 5',
        () async {
      var summaryCalls = 0;
      final client = MockClient((request) async {
        final url = request.url.toString();
        if (url.contains('w/api.php')) {
          return http.Response(
            jsonEncode({
              'query': {
                'search': [
                  {'title': 'Spina bifida', 'pageid': 1},
                  {'title': 'Neural tube defect', 'pageid': 2},
                  {'title': 'Folic acid', 'pageid': 3},
                  {'title': 'Hydrocephalus', 'pageid': 4},
                  {'title': 'Myelomeningocele', 'pageid': 5},
                ],
              },
            }),
            200,
          );
        }
        if (url.contains('rest_v1/page/summary')) {
          summaryCalls++;
          final title = Uri.decodeComponent(url.split('/').last);
          return http.Response(
            jsonEncode({'extract': 'Summary of $title.'}),
            200,
          );
        }
        if (url.contains('api.duckduckgo.com')) {
          // Same URL as the first Wikipedia hit: must be deduped.
          return http.Response(
            jsonEncode({
              'AbstractText': 'Spina bifida is a birth defect.',
              'Heading': 'Spina bifida',
              'AbstractURL': 'https://en.wikipedia.org/?curid=1',
            }),
            200,
          );
        }
        return http.Response('not found', 404);
      });
      final service = WebResearchService(client: client);
      final results = await service.search('spina bifida');
      expect(results.length, 5);
      expect(summaryCalls, 5);
      expect(
        results.map((r) => r.url).toSet().length,
        results.length,
        reason: 'no duplicate URLs',
      );
      expect(results.first.source, 'wikipedia');
      expect(results.first.title, 'Spina bifida');
      service.dispose();
    });

    test('empty query throws a plain WebResearchException', () async {
      final service = WebResearchService(client: MockClient((_) async {
        return http.Response('{}', 200);
      }));
      expect(
        () => service.search('   '),
        throwsA(isA<WebResearchException>()),
      );
      service.dispose();
    });

    test('network failure throws WebResearchException', () async {
      final service = WebResearchService(client: MockClient((_) async {
        throw Exception('no internet');
      }));
      expect(
        () => service.search('spina bifida'),
        throwsA(isA<WebResearchException>()),
      );
      service.dispose();
    });

    test('Wikipedia HTTP error throws WebResearchException', () async {
      final service = WebResearchService(client: MockClient((_) async {
        return http.Response('error', 500);
      }));
      expect(
        () => service.search('spina bifida'),
        throwsA(isA<WebResearchException>()),
      );
      service.dispose();
    });

    test('a missing summary extract is skipped, not fatal', () async {
      final client = MockClient((request) async {
        final url = request.url.toString();
        if (url.contains('w/api.php')) {
          return http.Response(
            jsonEncode({
              'query': {
                'search': [
                  {'title': 'No extract here', 'pageid': 9},
                  {'title': 'Has extract', 'pageid': 10},
                ],
              },
            }),
            200,
          );
        }
        if (url.contains('rest_v1/page/summary')) {
          if (url.contains('No%20extract%20here')) {
            return http.Response(jsonEncode({}), 200);
          }
          return http.Response(
            jsonEncode({'extract': 'It has one.'}),
            200,
          );
        }
        return http.Response(jsonEncode({'AbstractText': ''}), 200);
      });
      final service = WebResearchService(client: client);
      final results = await service.search('test');
      expect(results.length, 1);
      expect(results.first.title, 'Has extract');
      service.dispose();
    });
  });
}
