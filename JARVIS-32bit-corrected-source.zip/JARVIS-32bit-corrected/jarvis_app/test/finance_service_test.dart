// Phase 7 (v1.1.0) — F29 finance tracking: expense parsing, bank
// SMS parsing, totals.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/finance_service.dart';

void main() {
  group('parseExpenseCommand', () {
    test('spent 500 on groceries', () {
      final parsed = parseExpenseCommand('spent 500 on groceries');
      expect(parsed, isNotNull);
      expect(parsed!.amount, 500);
      expect(parsed.category, 'Groceries');
      expect(parsed.note, 'groceries');
    });

    test('rupees marker and commas', () {
      final parsed =
          parseExpenseCommand('I spent 1,200 rupees on fuel');
      expect(parsed, isNotNull);
      expect(parsed!.amount, 1200);
      expect(parsed.category, 'Fuel');
    });

    test('paid for lunch', () {
      final parsed = parseExpenseCommand('paid 300 for lunch');
      expect(parsed, isNotNull);
      expect(parsed!.amount, 300);
      expect(parsed.category, 'Food');
    });

    test('unknown category falls back to Other', () {
      final parsed = parseExpenseCommand('spent 250 on a haircut');
      expect(parsed, isNotNull);
      expect(parsed!.category, 'Other');
      expect(parsed.note, 'a haircut');
    });

    test('no amount returns null', () {
      expect(parseExpenseCommand('spent money on groceries'), isNull);
      expect(parseExpenseCommand('how much did I spend'), isNull);
    });

    test('zero or absurd amounts return null', () {
      expect(parseExpenseCommand('spent 0 on books'), isNull);
      expect(parseExpenseCommand('spent 999999999 on books'), isNull);
    });

    test('decimal amounts', () {
      final parsed = parseExpenseCommand('spent 49.50 on medicine');
      expect(parsed, isNotNull);
      expect(parsed!.amount, 49.5);
      expect(parsed.category, 'Medicine');
    });
  });

  group('parseBankSms', () {
    test('debit SMS with Rs amount', () {
      final parsed = parseBankSms(
        'Rs 500 debited from your account at GROCERY STORE. Avl bal Rs 12000.',
      );
      expect(parsed, isNotNull);
      expect(parsed!.amount, 500);
      expect(parsed.category, 'Groceries');
    });

    test('credit SMS is ignored', () {
      expect(
        parseBankSms('Rs 5000 credited to your account. Salary.'),
        isNull,
      );
    });

    test('non-bank SMS is ignored', () {
      expect(parseBankSms('Your OTP is 123456.'), isNull);
    });

    test('PKR marker and fuel merchant', () {
      final parsed = parseBankSms(
        'Dear customer, PKR 2,000 spent at SHELL PETROL. Thank you.',
      );
      expect(parsed, isNotNull);
      expect(parsed!.amount, 2000);
      expect(parsed.category, 'Fuel');
    });

    test('no amount returns null', () {
      expect(parseBankSms('Your card was used at a store.'), isNull);
    });
  });

  group('totals', () {
    final expenses = <ExpenseEntry>[
      ExpenseEntry(
        amount: 500,
        category: 'Groceries',
        note: 'groceries',
        loggedAt: DateTime(2026, 11, 22, 10),
      ),
      ExpenseEntry(
        amount: 300,
        category: 'Groceries',
        note: 'more',
        loggedAt: DateTime(2026, 11, 21, 10),
      ),
      ExpenseEntry(
        amount: 1200,
        category: 'Fuel',
        note: 'fuel',
        loggedAt: DateTime(2026, 11, 10, 10),
      ),
    ];

    test('totalsByCategory sums and sorts highest first', () {
      final totals = totalsByCategory(expenses);
      expect(totals['Groceries'], 800);
      expect(totals['Fuel'], 1200);
      expect(totals.keys.first, 'Fuel');
    });

    test('totalInLastDays only counts the window', () {
      final total = totalInLastDays(
        expenses,
        now: DateTime(2026, 11, 22, 12),
      );
      expect(total, 800);
    });

    test('parseStoredExpenses drops malformed entries', () {
      const raw =
          '[{"amount": 100, "category": "Food", "note": "x", "loggedAt": "2026-11-22T10:00:00.000"}, {"amount": 0, "category": "Food", "note": "y", "loggedAt": "2026-11-22T10:00:00.000"}, "junk"]';
      final parsed = parseStoredExpenses(raw);
      expect(parsed.length, 1);
      expect(parsed.first.amount, 100);
    });
  });
}
