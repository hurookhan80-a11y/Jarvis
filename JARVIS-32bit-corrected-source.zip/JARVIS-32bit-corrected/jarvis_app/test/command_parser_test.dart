import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/command_parser.dart';

void main() {
  group('parseTimerDurationSeconds', () {
    test('parses minutes in a complete command', () {
      expect(parseTimerDurationSeconds('set timer for 5 minutes'), 300);
    });

    test('parses compound hours and minutes', () {
      expect(parseTimerDurationSeconds('1 hour 20 minutes'), 4800);
    });

    test('parses seconds', () {
      expect(parseTimerDurationSeconds('timer for 45 seconds'), 45);
    });

    test('returns zero when no duration is present', () {
      expect(parseTimerDurationSeconds('set a timer'), 0);
    });
  });

  group('parseAlarmTime', () {
    test('converts afternoon time to 24-hour time', () {
      final result = parseAlarmTime('set alarm for 7:30 PM');
      expect(result?.hour24, 19);
      expect(result?.minute, 30);
    });

    test('handles noon and midnight correctly', () {
      expect(parseAlarmTime('12:00 PM')?.hour24, 12);
      expect(parseAlarmTime('12:00 AM')?.hour24, 0);
    });

    test('accepts hour-only times', () {
      expect(parseAlarmTime('wake me at 6 AM')?.minute, 0);
    });

    test('accepts punctuation after a spoken time', () {
      expect(parseAlarmTime('set alarm for 7:30 a.m.')?.hour24, 7);
    });

    test('rejects invalid clock values', () {
      expect(parseAlarmTime('13:75 PM'), isNull);
    });
  });
}
