// Phase 9 (v1.2.0) — G1/G2/G3 Google Workspace: pure parsers and
// the REST client (mock HTTP, mock secure-storage channel, mock
// Android intent channel).
import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:jarvis_app/google_workspace_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  var storedToken = '';
  const storageChannel =
      MethodChannel('com.jarvis.jarvis_app/secure_storage');

  setUp(() async {
    storedToken = 'test-token';
    SharedPreferences.setMockInitialValues(<String, Object>{});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(storageChannel, (call) async {
      switch (call.method) {
        case 'readSecret':
          return storedToken;
        case 'saveSecret':
          storedToken = (call.arguments as Map)['value'] as String;
          return null;
        case 'clearSecret':
          storedToken = '';
          return null;
        default:
          return null;
      }
    });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(storageChannel, null);
  });

  group('parseDriveFileList', () {
    test('extracts id, name, mimeType; skips blanks', () {
      final files = parseDriveFileList(<String, dynamic>{
        'files': [
          {
            'id': 'f1',
            'name': 'Notes',
            'mimeType': 'application/vnd.google-apps.document',
          },
          {'id': 'f2', 'name': 'Budget'},
          {'id': ''},
          {'name': 'No id'},
        ],
      });
      expect(files.length, 2);
      expect(files[0].id, 'f1');
      expect(files[0].name, 'Notes');
      expect(
        files[0].mimeType,
        'application/vnd.google-apps.document',
      );
      expect(files[1].mimeType, '');
    });

    test('no files key returns []', () {
      expect(parseDriveFileList(<String, dynamic>{}), isEmpty);
    });
  });

  group('parseDocCreate / parseSheetCreate / parseCalendarEventCreate / '
      'parseDraftCreate', () {
    test('returns the id field', () {
      expect(
        parseDocCreate(<String, dynamic>{'documentId': 'doc-1'}),
        'doc-1',
      );
      expect(
        parseSheetCreate(<String, dynamic>{'spreadsheetId': 'sheet-1'}),
        'sheet-1',
      );
      expect(
        parseCalendarEventCreate(<String, dynamic>{'id': 'evt-1'}),
        'evt-1',
      );
      expect(
        parseDraftCreate(<String, dynamic>{'id': 'draft-1'}),
        'draft-1',
      );
    });

    test('missing id returns empty string', () {
      expect(parseDocCreate(<String, dynamic>{}), '');
      expect(parseSheetCreate(<String, dynamic>{}), '');
      expect(parseCalendarEventCreate(<String, dynamic>{}), '');
      expect(parseDraftCreate(<String, dynamic>{}), '');
    });
  });

  group('parseDocEndIndex', () {
    test('takes the largest endIndex in the body', () {
      final index = parseDocEndIndex(<String, dynamic>{
        'body': {
          'content': [
            {'endIndex': 1},
            {'endIndex': 42},
            {'endIndex': 17},
          ],
        },
      });
      expect(index, 42);
    });

    test('missing body returns 1', () {
      expect(parseDocEndIndex(<String, dynamic>{}), 1);
      expect(
        parseDocEndIndex(<String, dynamic>{'body': <String, dynamic>{}}),
        1,
      );
    });
  });

  group('buildGmailRawMessage', () {
    test('round-trips through base64url decode', () {
      final raw = buildGmailRawMessage(
        to: 'a@example.com',
        subject: 'Hello',
        body: 'Line one\nLine two',
      );
      expect(raw.contains('='), isFalse);
      final decoded =
          utf8.decode(base64Url.decode(base64Url.normalize(raw)));
      expect(decoded, contains('To: a@example.com'));
      expect(decoded, contains('Subject: Hello'));
      expect(decoded, contains('Line one\nLine two'));
    });
  });

  group('buildRfc3339', () {
    test('keeps the local offset', () {
      final stamp = buildRfc3339(DateTime(2026, 11, 23, 14, 30));
      expect(stamp, startsWith('2026-11-23T14:30:00'));
    });

    test('UTC ends with Z', () {
      final stamp = buildRfc3339(DateTime.utc(2026, 11, 23, 9, 30));
      expect(stamp, endsWith('Z'));
    });
  });

  group('token + enabled state', () {
    test('setEnabled refuses true without a token', () async {
      storedToken = '';
      final service = GoogleWorkspaceService(client: MockClient((_) async {
        return http.Response('{}', 200);
      }));
      expect(await service.hasToken(), isFalse);
      expect(await service.setEnabled(true), isFalse);
      expect(await service.isEnabled(), isFalse);
      service.dispose();
    });

    test('setEnabled true with a token, then clearToken disables',
        () async {
      final service = GoogleWorkspaceService(client: MockClient((_) async {
        return http.Response('{}', 200);
      }));
      expect(await service.setEnabled(true), isTrue);
      expect(await service.isEnabled(), isTrue);
      await service.saveToken('  fresh-token  ');
      expect(await service.readToken(), 'fresh-token');
      await service.clearToken();
      expect(await service.hasToken(), isFalse);
      expect(await service.isEnabled(), isFalse);
      service.dispose();
    });
  });

  group('REST calls', () {
    test('createDoc posts title then inserts text at index 1', () async {
      final calls = <http.Request>[];
      final service = GoogleWorkspaceService(
        client: MockClient((request) async {
          calls.add(request);
          if (request.url.path == '/v1/documents') {
            return http.Response('{"documentId": "doc-9"}', 200);
          }
          return http.Response('{}', 200);
        }),
      );
      final docId = await service.createDoc(
        title: 'My Doc',
        text: 'Hello world',
      );
      expect(docId, 'doc-9');
      expect(calls.length, 2);
      expect(calls[0].url.host, 'docs.googleapis.com');
      expect(jsonDecode(calls[0].body)['title'], 'My Doc');
      expect(calls[1].url.path, '/v1/documents/doc-9:batchUpdate');
      final batch = jsonDecode(calls[1].body) as Map<String, dynamic>;
      final insert = (batch['requests'] as List).first
          as Map<String, dynamic>;
      expect(insert['insertText']['location']['index'], 1);
      expect(insert['insertText']['text'], 'Hello world');
      service.dispose();
    });

    test('createDoc with empty text skips the batchUpdate', () async {
      var calls = 0;
      final service = GoogleWorkspaceService(
        client: MockClient((_) async {
          calls++;
          return http.Response('{"documentId": "doc-9"}', 200);
        }),
      );
      await service.createDoc(title: 'Empty', text: '');
      expect(calls, 1);
      service.dispose();
    });

    test('appendToDoc reads the end index then inserts before it',
        () async {
      final calls = <http.Request>[];
      final service = GoogleWorkspaceService(
        client: MockClient((request) async {
          calls.add(request);
          if (request.method == 'GET') {
            return http.Response(
              '{"body": {"content": [{"endIndex": 1}, '
              '{"endIndex": 30}]}}',
              200,
            );
          }
          return http.Response('{}', 200);
        }),
      );
      await service.appendToDoc(docId: 'doc-9', text: 'More');
      expect(calls.length, 2);
      expect(calls[0].method, 'GET');
      final batch = jsonDecode(calls[1].body) as Map<String, dynamic>;
      final insert = (batch['requests'] as List).first
          as Map<String, dynamic>;
      expect(insert['insertText']['location']['index'], 29);
      expect(insert['insertText']['text'], 'More');
      service.dispose();
    });

    test('createSheet posts the title and returns the id', () async {
      http.Request? seen;
      final service = GoogleWorkspaceService(
        client: MockClient((request) async {
          seen = request;
          return http.Response('{"spreadsheetId": "sheet-7"}', 200);
        }),
      );
      final id = await service.createSheet(title: 'Budget');
      expect(id, 'sheet-7');
      expect(seen!.url.host, 'sheets.googleapis.com');
      expect(seen!.url.path, '/v4/spreadsheets');
      expect(
        jsonDecode(seen!.body)['properties']['title'],
        'Budget',
      );
      service.dispose();
    });

    test('appendSheetRow posts values with USER_ENTERED', () async {
      http.Request? seen;
      final service = GoogleWorkspaceService(
        client: MockClient((request) async {
          seen = request;
          return http.Response('{}', 200);
        }),
      );
      await service.appendSheetRow(
        spreadsheetId: 'sheet-7',
        values: ['A', 'B', 'C'],
      );
      expect(seen!.url.path, '/v4/spreadsheets/sheet-7/values/A1:append');
      expect(
        seen!.url.queryParameters['valueInputOption'],
        'USER_ENTERED',
      );
      expect(
        jsonDecode(seen!.body)['values'],
        [
          ['A', 'B', 'C']
        ],
      );
      service.dispose();
    });

    test('searchDriveFiles queries by name contains', () async {
      http.Request? seen;
      final service = GoogleWorkspaceService(
        client: MockClient((request) async {
          seen = request;
          return http.Response(
            '{"files": [{"id": "f1", "name": "Notes", '
            '"mimeType": "application/vnd.google-apps.document"}]}',
            200,
          );
        }),
      );
      final files = await service.searchDriveFiles('Notes');
      expect(files.length, 1);
      expect(files[0].name, 'Notes');
      expect(seen!.url.host, 'drive.googleapis.com');
      expect(seen!.url.path, '/drive/v3/files');
      expect(
        seen!.url.queryParameters['q'],
        "name contains 'Notes'",
      );
      expect(
        seen!.url.queryParameters['fields'],
        'files(id,name,mimeType)',
      );
      service.dispose();
    });

    test('createCalendarEvent posts RFC3339 times', () async {
      http.Request? seen;
      final service = GoogleWorkspaceService(
        client: MockClient((request) async {
          seen = request;
          return http.Response('{"id": "evt-3"}', 200);
        }),
      );
      final id = await service.createCalendarEvent(
        title: 'Study',
        start: DateTime(2026, 11, 24, 9, 0),
        end: DateTime(2026, 11, 24, 10, 0),
        description: 'Anatomy revision',
      );
      expect(id, 'evt-3');
      expect(seen!.url.host, 'calendar.googleapis.com');
      final body = jsonDecode(seen!.body) as Map<String, dynamic>;
      expect(body['summary'], 'Study');
      expect(body['description'], 'Anatomy revision');
      expect(
        (body['start'] as Map)['dateTime'],
        startsWith('2026-11-24T09:00:00'),
      );
      expect(
        (body['end'] as Map)['dateTime'],
        startsWith('2026-11-24T10:00:00'),
      );
      service.dispose();
    });

    test('draftEmail posts the base64url raw message', () async {
      http.Request? seen;
      final service = GoogleWorkspaceService(
        client: MockClient((request) async {
          seen = request;
          return http.Response('{"id": "draft-5"}', 200);
        }),
      );
      final id = await service.draftEmail(
        to: 'a@example.com',
        subject: 'Hi',
        body: 'Hello there',
      );
      expect(id, 'draft-5');
      expect(seen!.url.path, '/gmail/v1/users/me/drafts');
      final body = jsonDecode(seen!.body) as Map<String, dynamic>;
      final raw = (body['message'] as Map)['raw'] as String;
      final decoded =
          utf8.decode(base64Url.decode(base64Url.normalize(raw)));
      expect(decoded, contains('To: a@example.com'));
      expect(decoded, contains('Subject: Hi'));
      expect(decoded, contains('Hello there'));
      service.dispose();
    });

    test('sendEmail posts to messages/send', () async {
      http.Request? seen;
      final service = GoogleWorkspaceService(
        client: MockClient((request) async {
          seen = request;
          return http.Response('{"id": "msg-1"}', 200);
        }),
      );
      await service.sendEmail(
        to: 'a@example.com',
        subject: 'Hi',
        body: 'Hello there',
      );
      expect(seen!.url.path, '/gmail/v1/users/me/messages/send');
      final body = jsonDecode(seen!.body) as Map<String, dynamic>;
      final decoded = utf8.decode(
        base64Url.decode(base64Url.normalize(body['raw'] as String)),
      );
      expect(decoded, contains('To: a@example.com'));
      service.dispose();
    });

    test('401 throws the expired-token message', () async {
      final service = GoogleWorkspaceService(
        client: MockClient((_) async {
          return http.Response('Unauthorized', 401);
        }),
      );
      expect(
        () => service.createSheet(title: 'x'),
        throwsA(
          isA<GoogleWorkspaceException>().having(
            (e) => e.message,
            'message',
            contains('expired'),
          ),
        ),
      );
      service.dispose();
    });

    test('non-200 throws with the status in the message', () async {
      final service = GoogleWorkspaceService(
        client: MockClient((_) async {
          return http.Response('Bad request', 400);
        }),
      );
      expect(
        () => service.createSheet(title: 'x'),
        throwsA(
          isA<GoogleWorkspaceException>().having(
            (e) => e.message,
            'message',
            contains('400'),
          ),
        ),
      );
      service.dispose();
    });

    test('missing token throws before any HTTP call', () async {
      storedToken = '';
      var calls = 0;
      final service = GoogleWorkspaceService(
        client: MockClient((_) async {
          calls++;
          return http.Response('{}', 200);
        }),
      );
      expect(
        () => service.createSheet(title: 'x'),
        throwsA(isA<GoogleWorkspaceException>()),
      );
      expect(calls, 0);
      service.dispose();
    });
  });

  group('buildCalendarInsertIntent / openCalendarInsert', () {
    test('builds an INSERT intent with the event extras', () {
      final intent = buildCalendarInsertIntent(
        title: 'Study',
        start: DateTime(2026, 11, 24, 9, 0),
        end: DateTime(2026, 11, 24, 10, 0),
        description: 'Anatomy',
      );
      expect(intent.action, 'android.intent.action.INSERT');
      expect(intent.data, 'content://com.android.calendar/events');
      final args = intent.arguments!;
      expect(args['title'], 'Study');
      expect(args['description'], 'Anatomy');
      expect(
        args['beginTime'],
        DateTime(2026, 11, 24, 9, 0).millisecondsSinceEpoch,
      );
      expect(
        args['endTime'],
        DateTime(2026, 11, 24, 10, 0).millisecondsSinceEpoch,
      );
    });

    test('omits a blank description', () {
      final intent = buildCalendarInsertIntent(
        title: 'Study',
        start: DateTime(2026, 11, 24, 9, 0),
        end: DateTime(2026, 11, 24, 10, 0),
      );
      expect(intent.arguments!.containsKey('description'), isFalse);
    });

    test('openCalendarInsert does not throw off Android', () async {
      // AndroidIntent.launch() is a no-op when the platform is not
      // Android, so on the test host this only proves the intent
      // builds and launches without throwing.
      final service = GoogleWorkspaceService(
        client: MockClient((_) async => http.Response('{}', 200)),
      );
      await service.openCalendarInsert(
        title: 'Study',
        start: DateTime(2026, 11, 24, 9, 0),
        end: DateTime(2026, 11, 24, 10, 0),
      );
      service.dispose();
    });
  });
}
