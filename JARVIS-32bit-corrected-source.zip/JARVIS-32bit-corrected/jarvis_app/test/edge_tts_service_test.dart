import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/edge_tts_service.dart';

void main() {
  group('edgeTtsAuthToken', () {
    test('is a 64-character upper-case hex SHA-256', () {
      final token = edgeTtsAuthToken(DateTime.utc(2026, 11, 22, 14, 0, 0));
      expect(token, hasLength(64));
      expect(token, matches(RegExp(r'^[0-9A-F]{64}$')));
    });

    test('changes with time', () {
      final first = edgeTtsAuthToken(DateTime.utc(2026, 11, 22, 14, 0, 0));
      final second = edgeTtsAuthToken(DateTime.utc(2026, 11, 22, 14, 0, 1));
      expect(first, isNot(second));
    });
  });

  group('edgeTtsRequestId', () {
    test('is 32 lower-case hex characters and unique', () {
      final first = edgeTtsRequestId();
      final second = edgeTtsRequestId();
      expect(first, matches(RegExp(r'^[0-9a-f]{32}$')));
      expect(first, isNot(second));
    });
  });

  group('edgeTtsSsml', () {
    test('wraps text in the voice with rate and pitch', () {
      final ssml = edgeTtsSsml('Hello, sir.', voice: 'en-GB-SoniaNeural');
      expect(ssml, contains('name="en-GB-SoniaNeural"'));
      expect(ssml, contains('rate="-20%"'));
      expect(ssml, contains('pitch="+0Hz"'));
      expect(ssml, contains('Hello, sir.'));
      expect(ssml, startsWith('<speak '));
      expect(ssml, endsWith('</speak>'));
    });

    test('escapes XML characters in the text', () {
      final ssml = edgeTtsSsml(
        'Fish & chips <b>bold</b> "quoted"',
        voice: 'en-GB-SoniaNeural',
      );
      expect(ssml, contains('Fish &amp; chips &lt;b&gt;bold&lt;/b&gt;'));
      expect(ssml, isNot(contains('Fish & chips')));
    });

    test('formats a positive rate and a negative pitch', () {
      final ssml = edgeTtsSsml(
        'Hi',
        voice: 'en-US-AriaNeural',
        ratePercent: 10,
        pitchHertz: -5,
      );
      expect(ssml, contains('rate="+10%"'));
      expect(ssml, contains('pitch="-5Hz"'));
    });
  });

  group('edgeTtsExtractAudio', () {
    List<int> frame(String header, List<int> audio) => <int>[
      ...ascii.encode(header),
      13,
      10,
      13,
      10,
      ...audio,
    ];

    test('returns the MP3 bytes after an audio header', () {
      final message = frame(
        'X-RequestId: abc\r\nPath:audio\r\nContent-Type: audio/mpeg',
        <int>[1, 2, 3, 4],
      );
      expect(edgeTtsExtractAudio(message), <int>[1, 2, 3, 4]);
    });

    test('returns null for a non-audio frame', () {
      final message = frame('X-RequestId: abc\r\nPath:turn.start', <int>[
        1,
        2,
        3,
      ]);
      expect(edgeTtsExtractAudio(message), isNull);
    });

    test('returns null when there is no header separator', () {
      expect(edgeTtsExtractAudio(<int>[1, 2, 3]), isNull);
    });

    test('returns empty bytes for an audio frame with no payload', () {
      final message = frame('Path:audio', <int>[]);
      expect(edgeTtsExtractAudio(message), isEmpty);
    });
  });
}
