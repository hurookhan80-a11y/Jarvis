// v1.2.0 (G11) — usage stats: day keys, stored-JSON parsing,
// dashboard totals + last-7-days, and the record methods.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/usage_stats_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await const UsageStatsService().clearAll();
  });

  group('usageDayKey', () {
    test('formats a local date as yyyy-MM-dd, zero-padded', () {
      expect(usageDayKey(DateTime(2026, 11, 23)), '2026-11-23');
      expect(usageDayKey(DateTime(2026, 1, 5)), '2026-01-05');
    });
  });

  group('parseStoredUsage / encodeUsage', () {
    test('round-trips per-day buckets', () {
      final days = <String, UsageDay>{
        '2026-11-22': UsageDay(
          date: DateTime(2026, 11, 22),
          conversations: 3,
          messagesSpoken: 10,
          remindersFired: 1,
          tasksDone: 2,
          tasksFailed: 1,
        ),
      };
      final parsed = parseStoredUsage(encodeUsage(days));
      expect(parsed, hasLength(1));
      final day = parsed['2026-11-22']!;
      expect(day.conversations, 3);
      expect(day.messagesSpoken, 10);
      expect(day.remindersFired, 1);
      expect(day.tasksDone, 2);
      expect(day.tasksFailed, 1);
    });

    test('tolerates missing, malformed and wrongly-shaped data', () {
      expect(parseStoredUsage(null), isEmpty);
      expect(parseStoredUsage(''), isEmpty);
      expect(parseStoredUsage('not json'), isEmpty);
      expect(parseStoredUsage('[]'), isEmpty);
      expect(parseStoredUsage('{"not-a-date": {"conversations": 5}}'), isEmpty);
      final parsed = parseStoredUsage(
        '{"2026-11-22": {"conversations": 2}, "bad": 5}',
      );
      expect(parsed.keys, ['2026-11-22']);
      expect(parsed['2026-11-22']!.conversations, 2);
      expect(parsed['2026-11-22']!.messagesSpoken, 0);
    });
  });

  group('buildUsageDashboard', () {
    test('totals cover all stored days', () {
      final days = <String, UsageDay>{
        '2026-11-20': UsageDay(
          date: DateTime(2026, 11, 20),
          conversations: 2,
          messagesSpoken: 5,
        ),
        '2026-11-22': UsageDay(
          date: DateTime(2026, 11, 22),
          conversations: 3,
          remindersFired: 1,
          tasksDone: 4,
          tasksFailed: 1,
        ),
      };
      final dashboard = buildUsageDashboard(
        days,
        now: DateTime(2026, 11, 23),
      );
      expect(dashboard.totalConversations, 5);
      expect(dashboard.totalMessagesSpoken, 5);
      expect(dashboard.totalRemindersFired, 1);
      expect(dashboard.totalTasksDone, 4);
      expect(dashboard.totalTasksFailed, 1);
    });

    test('last 7 days are oldest-first with zeros for missing days', () {
      final days = <String, UsageDay>{
        '2026-11-23': UsageDay(
          date: DateTime(2026, 11, 23),
          conversations: 2,
        ),
        '2026-11-21': UsageDay(
          date: DateTime(2026, 11, 21),
          conversations: 1,
        ),
      };
      final dashboard = buildUsageDashboard(
        days,
        now: DateTime(2026, 11, 23),
      );
      expect(dashboard.last7Days, hasLength(7));
      expect(
        dashboard.last7Days.map((d) => usageDayKey(d.date)),
        [
          '2026-11-17',
          '2026-11-18',
          '2026-11-19',
          '2026-11-20',
          '2026-11-21',
          '2026-11-22',
          '2026-11-23',
        ],
      );
      expect(dashboard.last7Days[4].conversations, 1);
      expect(dashboard.last7Days[6].conversations, 2);
      expect(dashboard.last7Days[0].conversations, 0);
      expect(dashboard.last7Days[3].messagesSpoken, 0);
    });

    test('empty store gives all-zero totals and 7 zero days', () {
      final dashboard = buildUsageDashboard(
        <String, UsageDay>{},
        now: DateTime(2026, 11, 23),
      );
      expect(dashboard.totalConversations, 0);
      expect(dashboard.totalTasksDone, 0);
      expect(dashboard.last7Days, hasLength(7));
      expect(
        dashboard.last7Days.every((d) => d.conversations == 0),
        isTrue,
      );
    });
  });

  group('UsageStatsService record methods', () {
    test('records accumulate into today and the dashboard', () async {
      const service = UsageStatsService();
      await service.recordConversation();
      await service.recordConversation();
      await service.recordMessageSpoken();
      await service.recordReminderFired();
      await service.recordTaskDone();
      await service.recordTaskFailed();
      await service.recordTaskFailed();

      final dashboard = await service.loadDashboard();
      expect(dashboard.totalConversations, 2);
      expect(dashboard.totalMessagesSpoken, 1);
      expect(dashboard.totalRemindersFired, 1);
      expect(dashboard.totalTasksDone, 1);
      expect(dashboard.totalTasksFailed, 2);
      final today = dashboard.last7Days.last;
      expect(today.conversations, 2);
      expect(today.tasksFailed, 2);
    });

    test('clearAll wipes the dashboard', () async {
      const service = UsageStatsService();
      await service.recordConversation();
      await service.clearAll();
      final dashboard = await service.loadDashboard();
      expect(dashboard.totalConversations, 0);
      expect(dashboard.last7Days, hasLength(7));
    });
  });
}
