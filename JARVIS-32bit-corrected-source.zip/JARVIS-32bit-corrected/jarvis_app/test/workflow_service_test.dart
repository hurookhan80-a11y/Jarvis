// Phase 9 (v1.2.0) — G4 workflow templates, G12 per-workflow autonomy.
//
// Pure helpers + the SharedPreferences-backed store (mocked), in the
// same style as test/phase7b_test.dart. The service never executes
// anything, so there is nothing to mock beyond SharedPreferences.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/macro_service.dart';
import 'package:jarvis_app/workflow_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  group('WorkflowAutonomy parse/serialize (G12)', () {
    test('ask/auto round-trip', () {
      expect(workflowAutonomyToString(WorkflowAutonomy.askFirst), 'ask');
      expect(workflowAutonomyToString(WorkflowAutonomy.autonomous), 'auto');
      expect(workflowAutonomyFromString('ask'), WorkflowAutonomy.askFirst);
      expect(workflowAutonomyFromString('auto'), WorkflowAutonomy.autonomous);
    });

    test('unknown or absent values default to askFirst', () {
      expect(workflowAutonomyFromString(null), WorkflowAutonomy.askFirst);
      expect(workflowAutonomyFromString(''), WorkflowAutonomy.askFirst);
      expect(workflowAutonomyFromString('maybe'), WorkflowAutonomy.askFirst);
      expect(
        workflowAutonomyFromString('AUTONOMOUS'),
        WorkflowAutonomy.autonomous,
      );
    });
  });

  group('WorkflowTemplate JSON', () {
    test('round-trips, including autonomy', () {
      final template = WorkflowTemplate(
        id: 't1',
        name: 'evening wrap',
        description: 'Wrap up the day.',
        steps: ['any important mail', 'what time is it'],
        autonomy: WorkflowAutonomy.autonomous,
        createdAt: _created,
      );
      final restored = WorkflowTemplate.fromJson(template.toJson());
      expect(restored.id, 't1');
      expect(restored.name, 'evening wrap');
      expect(restored.description, 'Wrap up the day.');
      expect(restored.steps, ['any important mail', 'what time is it']);
      expect(restored.autonomy, WorkflowAutonomy.autonomous);
      expect(restored.createdAt, _created);
    });

    test('old JSON without an autonomy key loads as askFirst', () {
      final restored = WorkflowTemplate.fromJson(<String, dynamic>{
        'id': 'old',
        'name': 'old one',
        'description': '',
        'steps': ['what time is it'],
        'createdAt': '2026-11-23T08:00:00.000',
      });
      expect(restored.autonomy, WorkflowAutonomy.askFirst);
    });

    test('parseStoredTemplates drops malformed and empty entries', () {
      expect(parseStoredTemplates(null), isEmpty);
      expect(parseStoredTemplates(''), isEmpty);
      expect(parseStoredTemplates('not json'), isEmpty);
      expect(parseStoredTemplates('{"a":1}'), isEmpty);
      final parsed = parseStoredTemplates(
        '[{"id":"1","name":"good","steps":["what time is it"]},'
        '{"id":"2","name":"","steps":["what time is it"]},'
        '{"id":"3","name":"no steps","steps":[]},'
        '{"id":"4","name":"bad steps","steps":"nope"}]',
      );
      expect(parsed.map((t) => t.name), ['good']);
    });

    test('encodeTemplates round-trips a list', () {
      final templates = <WorkflowTemplate>[
        WorkflowTemplate(
          id: 'a',
          name: 'one',
          description: '',
          steps: ['what time is it'],
          createdAt: _created,
        ),
        WorkflowTemplate(
          id: 'b',
          name: 'two',
          description: '',
          steps: ['any important mail'],
          autonomy: WorkflowAutonomy.autonomous,
          createdAt: _created,
        ),
      ];
      expect(parseStoredTemplates(encodeTemplates(templates)).length, 2);
      expect(
        parseStoredTemplates(encodeTemplates(templates))[1].autonomy,
        WorkflowAutonomy.autonomous,
      );
    });
  });

  group('builtInTemplates (G4)', () {
    test('returns the four named templates with the specified steps', () {
      final builtIns = const WorkflowService().builtInTemplates();
      expect(builtIns.map((t) => t.name), [
        'morning briefing',
        'research and save',
        'email production',
        'make a post from this file',
      ]);
      expect(builtIns[0].steps, [
        'what is on my calendar today',
        'any important mail',
        'what time is it',
      ]);
      expect(builtIns[1].steps, ['search the web for {topic}']);
      expect(builtIns[2].steps, [
        'draft an email summary of my unread mail',
        'save it to a doc',
      ]);
      expect(builtIns[3].steps, [
        'use the attached file',
        'draft a social post',
      ]);
      // All four default to ask-first — nothing runs unannounced.
      expect(
        builtIns.every((t) => t.autonomy == WorkflowAutonomy.askFirst),
        isTrue,
      );
      // Fresh objects each call: mutating one must not leak.
      builtIns[0].steps.add('extra');
      expect(
        const WorkflowService().builtInTemplates()[0].steps.length,
        3,
      );
    });
  });

  group('workflow command parsing', () {
    test('parseRunWorkflowName handles both run forms', () {
      expect(
        parseRunWorkflowName('run workflow morning briefing'),
        'morning briefing',
      );
      expect(
        parseRunWorkflowName('run my workflow morning briefing'),
        'morning briefing',
      );
      expect(
        parseRunWorkflowName('run the morning briefing workflow'),
        'morning briefing',
      );
      expect(parseRunWorkflowName('run morning briefing workflow'),
          'morning briefing');
    });

    test('parseRunWorkflowName does not hijack macro runs', () {
      expect(parseRunWorkflowName('run morning routine'), isNull);
      expect(parseRunWorkflowName('run macro morning routine'), isNull);
      expect(parseRunWorkflowName('run workflow'), isNull);
      expect(parseRunWorkflowName('run workflow '), isNull);
      expect(parseRunWorkflowName('what time is it'), isNull);
    });

    test('parseWorkflowDeleteName', () {
      expect(
        parseWorkflowDeleteName('delete workflow morning briefing'),
        'morning briefing',
      );
      expect(
        parseWorkflowDeleteName('remove workflow morning briefing'),
        'morning briefing',
      );
      expect(parseWorkflowDeleteName('delete macro morning routine'), isNull);
      expect(parseWorkflowDeleteName('delete workflow'), isNull);
    });

    test('parseWorkflowAutonomyCommand', () {
      final auto = parseWorkflowAutonomyCommand(
        'make workflow morning briefing autonomous',
      );
      expect(auto, isNotNull);
      expect(auto!.name, 'morning briefing');
      expect(auto.autonomy, WorkflowAutonomy.autonomous);

      final ask = parseWorkflowAutonomyCommand(
        'make workflow morning briefing ask first',
      );
      expect(ask, isNotNull);
      expect(ask!.name, 'morning briefing');
      expect(ask.autonomy, WorkflowAutonomy.askFirst);

      expect(
        parseWorkflowAutonomyCommand('make workflow morning briefing'),
        isNull,
      );
      expect(
        parseWorkflowAutonomyCommand('make workflow autonomous'),
        isNull,
      );
      expect(
        parseWorkflowAutonomyCommand('make macro morning routine autonomous'),
        isNull,
      );
    });

    test('findWorkflow matches case-insensitively', () {
      final templates = const WorkflowService().builtInTemplates();
      expect(findWorkflow(templates, 'Morning Briefing')?.id,
          'builtin-morning-briefing');
      expect(findWorkflow(templates, 'no such workflow'), isNull);
      expect(
        findWorkflowById(templates, 'builtin-email-production')?.name,
        'email production',
      );
    });
  });

  group('WorkflowService store', () {
    const service = WorkflowService();

    test('save assigns an id when empty and load returns it', () async {
      final saved = await service.saveTemplate(
        WorkflowTemplate(
          id: '',
          name: 'my routine',
          description: '',
          steps: ['what time is it'],
          createdAt: _created,
        ),
      );
      expect(saved, isNotNull);
      expect(saved!.id.isNotEmpty, isTrue);
      final loaded = await service.loadTemplates();
      expect(loaded.length, 1);
      expect(loaded.first.name, 'my routine');
    });

    test('save with no name or no steps is ignored', () async {
      expect(
        await service.saveTemplate(
          WorkflowTemplate(
            id: '',
            name: ' ',
            description: '',
            steps: ['what time is it'],
            createdAt: _created,
          ),
        ),
        isNull,
      );
      expect(
        await service.saveTemplate(
          WorkflowTemplate(
            id: '',
            name: 'empty',
            description: '',
            steps: [],
            createdAt: _created,
          ),
        ),
        isNull,
      );
      expect(await service.loadTemplates(), isEmpty);
    });

    test('saving the same name replaces, keeping the cap', () async {
      await service.saveTemplate(
        WorkflowTemplate(
          id: 'first',
          name: 'routine',
          description: '',
          steps: ['what time is it'],
          createdAt: _created,
        ),
      );
      await service.saveTemplate(
        WorkflowTemplate(
          id: 'second',
          name: 'Routine',
          description: 'replaced',
          steps: ['any important mail'],
          autonomy: WorkflowAutonomy.autonomous,
          createdAt: _created,
        ),
      );
      final loaded = await service.loadTemplates();
      expect(loaded.length, 1);
      expect(loaded.first.id, 'second');
      expect(loaded.first.autonomy, WorkflowAutonomy.autonomous);
    });

    test('delete by name or id, and clearAll', () async {
      await service.saveTemplate(
        WorkflowTemplate(
          id: 'del-1',
          name: 'to delete',
          description: '',
          steps: ['what time is it'],
          createdAt: _created,
        ),
      );
      expect(await service.deleteTemplate('nope'), isFalse);
      expect(await service.deleteTemplate('TO DELETE'), isTrue);
      expect(await service.loadTemplates(), isEmpty);
      await service.saveTemplate(
        WorkflowTemplate(
          id: 'del-2',
          name: 'again',
          description: '',
          steps: ['what time is it'],
          createdAt: _created,
        ),
      );
      await service.clearAll();
      expect(await service.loadTemplates(), isEmpty);
    });

    test('cap of 50 templates is enforced', () async {
      for (var i = 0; i < 55; i++) {
        await service.saveTemplate(
          WorkflowTemplate(
            id: 'cap-$i',
            name: 'template $i',
            description: '',
            steps: const ['what time is it'],
            createdAt: _created,
          ),
        );
      }
      expect((await service.loadTemplates()).length, kJarvisMaxWorkflows);
    });
  });

  group('Macro autonomy field (G12, additive)', () {
    test('defaults to askFirst and survives a JSON round-trip', () {
      final macro = Macro(
        name: 'morning routine',
        steps: ['what time is it'],
        createdAt: _created,
      );
      expect(macro.autonomy, WorkflowAutonomy.askFirst);
      expect(Macro.fromJson(macro.toJson()).autonomy,
          WorkflowAutonomy.askFirst);
      expect(macro.toJson()['autonomy'], 'ask');
    });

    test('old stored JSON without the key still loads', () {
      final macro = Macro.fromJson(<String, dynamic>{
        'name': 'old macro',
        'steps': ['what time is it'],
        'createdAt': '2026-11-23T08:00:00.000',
      });
      expect(macro.autonomy, WorkflowAutonomy.askFirst);
      expect(macro.name, 'old macro');
    });

    test('autonomous macro stores and loads as auto', () {
      final macro = Macro(
        name: 'auto one',
        steps: ['what time is it'],
        createdAt: _created,
        autonomy: WorkflowAutonomy.autonomous,
      );
      expect(macro.toJson()['autonomy'], 'auto');
      expect(Macro.fromJson(macro.toJson()).autonomy,
          WorkflowAutonomy.autonomous);
    });
  });
}

final _created = DateTime(2026, 11, 23, 8, 0, 0);
