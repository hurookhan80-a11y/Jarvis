// Phase 6 (v1.1.0) — F19 connector hub: the "key needed" rule, toggle
// persistence, and hub rows.
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/connector_hub.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  // In-memory stand-in for the AndroidKeyStore-backed channel: the real
  // encryption lives in MainActivity.kt and cannot run in a unit test.
  var storedNimKey = '';
  const channel =
      MethodChannel('com.jarvis.jarvis_app/secure_storage');

  setUp(() async {
    storedNimKey = '';
    SharedPreferences.setMockInitialValues(<String, Object>{});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
      switch (call.method) {
        case 'readSecret':
          return storedNimKey;
        case 'saveSecret':
          storedNimKey = (call.arguments as Map)['value'] as String;
          return null;
        case 'clearSecret':
          storedNimKey = '';
          return null;
        default:
          return null;
      }
    });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  group('nimCanBeEnabled', () {
    test('NIM can only switch on when a key is stored', () {
      expect(nimCanBeEnabled(keySet: false), isFalse);
      expect(nimCanBeEnabled(keySet: true), isTrue);
    });
  });

  group('ConnectorHubService', () {
    const hub = ConnectorHubService();

    test('NIM is off by default and cannot switch on without a key',
        () async {
      expect(await hub.isNimEnabled(), isFalse);
      expect(await hub.hasNimKey(), isFalse);
      expect(await hub.setNimEnabled(true), isFalse);
      expect(await hub.isNimEnabled(), isFalse);
    });

    test('NIM switches on once a key is saved, and off again', () async {
      await hub.saveNimKey('nvapi-test-key');
      expect(await hub.hasNimKey(), isTrue);
      expect(await hub.readNimKey(), 'nvapi-test-key');
      expect(await hub.setNimEnabled(true), isTrue);
      expect(await hub.isNimEnabled(), isTrue);
      expect(await hub.setNimEnabled(false), isTrue);
      expect(await hub.isNimEnabled(), isFalse);
    });

    test('clearing the key switches NIM off', () async {
      await hub.saveNimKey('nvapi-test-key');
      await hub.setNimEnabled(true);
      await hub.clearNimKey();
      expect(await hub.hasNimKey(), isFalse);
      expect(await hub.isNimEnabled(), isFalse);
    });

    test('listConnectors: Gemini always on, Gmail never toggleable',
        () async {
      final rows = await hub.listConnectors();
      expect(rows.map((r) => r.id), [
        ConnectorId.gemini,
        ConnectorId.nvidiaNim,
        ConnectorId.gmail,
      ]);
      final gemini = rows[0];
      expect(gemini.enabled, isTrue);
      expect(gemini.canToggle, isFalse);
      expect(gemini.status, contains('Always on'));

      final nim = rows[1];
      expect(nim.needsKey, isTrue);
      expect(nim.status, contains('Key needed'));

      final gmail = rows[2];
      expect(gmail.enabled, isFalse);
      expect(gmail.canToggle, isFalse);
      expect(gmail.status, contains('Not connected'));
    });

    test('listConnectors reports NIM ready once key is saved', () async {
      await hub.saveNimKey('nvapi-test-key');
      await hub.setNimEnabled(true);
      final rows = await hub.listConnectors();
      final nim = rows[1];
      expect(nim.keySet, isTrue);
      expect(nim.enabled, isTrue);
      expect(nim.status, contains('Ready'));
    });

    test(
        'Gmail (F28): not connected without a token, switchable once a token is saved',
        () async {
      var rows = await hub.listConnectors();
      var gmail = rows[2];
      expect(gmail.enabled, isFalse);
      expect(gmail.canToggle, isFalse);
      expect(gmail.status, contains('Not connected'));
      expect(await hub.setGmailEnabled(true), isFalse);

      await hub.saveGmailToken('ya29-test-token');
      expect(await hub.hasGmailToken(), isTrue);
      rows = await hub.listConnectors();
      gmail = rows[2];
      expect(gmail.canToggle, isTrue);
      expect(gmail.keySet, isTrue);
      expect(gmail.status, contains('Token saved'));

      expect(await hub.setGmailEnabled(true), isTrue);
      rows = await hub.listConnectors();
      expect(rows[2].enabled, isTrue);
      expect(rows[2].status, contains('Connected'));

      await hub.clearGmailToken();
      expect(await hub.hasGmailToken(), isFalse);
      rows = await hub.listConnectors();
      expect(rows[2].enabled, isFalse);
      expect(rows[2].status, contains('Not connected'));
    });
  });
}
