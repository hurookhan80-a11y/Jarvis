// Phase 7 (v1.1.0) — F27 calendar helpers: next event, formatting,
// announcement reminder ids.
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_app/calendar_service.dart';

void main() {
  final events = <CalendarEvent>[
    CalendarEvent(
      title: 'Class',
      start: DateTime(2026, 11, 22, 9, 0),
      end: DateTime(2026, 11, 22, 10, 0),
      calendarName: 'College',
      allDay: false,
    ),
    CalendarEvent(
      title: 'Study',
      start: DateTime(2026, 11, 22, 19, 0),
      end: DateTime(2026, 11, 22, 20, 0),
      calendarName: 'Personal',
      allDay: false,
    ),
    CalendarEvent(
      title: 'Holiday',
      start: DateTime(2026, 11, 23, 0, 0),
      end: DateTime(2026, 11, 24, 0, 0),
      calendarName: 'Holidays',
      allDay: true,
    ),
  ];

  group('nextEvent', () {
    test('returns the next event that has not ended', () {
      final next = nextEvent(events, now: DateTime(2026, 11, 22, 8, 0));
      expect(next?.title, 'Class');
    });

    test('an in-progress event counts as next', () {
      final next = nextEvent(events, now: DateTime(2026, 11, 22, 9, 30));
      expect(next?.title, 'Class');
    });

    test('after the last event ends, returns null', () {
      final next = nextEvent(events, now: DateTime(2026, 11, 24, 1, 0));
      expect(next, isNull);
    });
  });

  group('formatEventLine', () {
    test('timed event', () {
      final line = formatEventLine(events[0]);
      expect(line, contains('Class'));
      expect(line, contains('9:00'));
    });

    test('all-day event', () {
      expect(formatEventLine(events[2]), 'Holiday · All day');
    });
  });

  group('calendarReminderId', () {
    test('deterministic per event and in the calendar range', () {
      final id1 = calendarReminderId(events[0]);
      final id2 = calendarReminderId(events[0]);
      expect(id1, id2);
      expect(id1, greaterThanOrEqualTo(1000000000));
      expect(id1, lessThan(2000000000));
      expect(calendarReminderId(events[1]), isNot(id1));
    });
  });

  group('CalendarEvent.fromMap', () {
    test('parses channel maps', () {
      final event = CalendarEvent.fromMap(<String, dynamic>{
        'title': 'Exam',
        'start': DateTime(2026, 11, 22, 9, 0).millisecondsSinceEpoch,
        'end': DateTime(2026, 11, 22, 12, 0).millisecondsSinceEpoch,
        'calendar': 'College',
        'allDay': false,
      });
      expect(event.title, 'Exam');
      expect(event.calendarName, 'College');
      expect(event.allDay, isFalse);
      expect(event.key, contains('Exam|'));
    });
  });
}
