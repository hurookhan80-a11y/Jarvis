// Phase 7 (v1.1.0) — F39 Shizuku system controls (optional).
//
// Deeper system controls via the free Shizuku app (no root): force
// stop an app, toggle mobile data, disable/enable an app. Off by
// default; the toggle lives in Settings and the controls live on the
// Shizuku screen. Every control only runs when Shizuku is installed,
// running, and authorised for Jarvis — otherwise the screen says so
// and does nothing.
//
// Verification (22 Nov 2026): shizuku_api 1.3.1 on pub.dev —
// Flutter >=3.3.0, Dart ^3.9.2, minSdk 24, pure Kotlin plugin (no
// native .so), updated 2026-10-15. It resolves cleanly against
// Flutter 3.50 / Dart 3.14. The app manifest carries the
// ShizukuProvider the plugin's README requires, and a package
// visibility entry for moe.shizuku.privileged.api.
//
// Safety: commands are built ONLY from the allowlisted templates in
// [buildShizukuCommand] — the package name is validated against a
// strict pattern and the action is one of the three below. There is
// no free-form shell input anywhere: a voice command that names an
// unknown app, or anything outside the allowlist, is refused with a
// plain message. Force-stopping or disabling the wrong app can lose
// unsaved work in that app — the screen warns about that, and
// force-stop never targets Jarvis itself or the system UI.
//
// Pattern: AbuZar-Ansarii/Jarvis + mokshith7777/Jarvis-android-
// (`shizuku_api` in pubspec). Fresh implementation — no code copied.

import 'package:shared_preferences/shared_preferences.dart';
import 'package:shizuku_api/shizuku_api.dart';

/// SharedPreferences key: are Shizuku controls switched on?
/// Default OFF; the toggle lives in Settings (F39).
const String kJarvisShizukuEnabledKey = 'jarvis_shizuku_enabled';

/// What Shizuku is (not) doing on this phone right now.
enum ShizukuStatus {
  /// The free Shizuku app is not installed.
  notInstalled,

  /// Installed, but its service is not running (wireless debugging
  /// / start via Shizuku app needed).
  notRunning,

  /// Running, but Jarvis has not been authorised in the Shizuku app.
  notAuthorised,

  /// Running and authorised — controls may run.
  ready,

  /// The check itself failed (plugin unavailable).
  unknown,
}

/// One allowlisted system control.
enum ShizukuControl {
  /// `am force-stop <package>` — stops the app at once. Unsaved
  /// work in that app is lost.
  forceStopApp,

  /// `svc data enable|disable` — mobile data on/off.
  toggleMobileData,

  /// `pm disable-user --user 0 <package>` — hides/disables the app.
  disableApp,

  /// `pm enable <package>` — re-enables a disabled app.
  enableApp,
}

/// Strict package-name check: lower-case dotted identifiers only.
/// Rejects anything with spaces, slashes, semicolons or shell
/// metacharacters, so a spoken name can never inject a command.
bool isValidPackageName(String package) => RegExp(
  r'^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$',
).hasMatch(package);

/// Builds the shell command for one allowlisted control, or null
/// when the control + arguments are not allowlisted. The package
/// name is validated here; the data toggle takes only a bool.
/// Returns null for force-stop/disable/enable of Jarvis itself or
/// the Android system UI — those are never valid targets.
String? buildShizukuCommand(
  ShizukuControl control, {
  String? package,
  bool? enable,
}) {
  const blocked = <String>{
    'com.jarvis.jarvis_app',
    'com.android.systemui',
    'android',
  };
  switch (control) {
    case ShizukuControl.forceStopApp:
    case ShizukuControl.disableApp:
    case ShizukuControl.enableApp:
      final target = (package ?? '').trim();
      if (!isValidPackageName(target) || blocked.contains(target)) {
        return null;
      }
      switch (control) {
        case ShizukuControl.forceStopApp:
          return 'am force-stop $target';
        case ShizukuControl.disableApp:
          return 'pm disable-user --user 0 $target';
        case ShizukuControl.enableApp:
          return 'pm enable $target';
        case ShizukuControl.toggleMobileData:
          return null;
      }
    case ShizukuControl.toggleMobileData:
      if (enable == null) return null;
      return 'svc data ${enable ? 'enable' : 'disable'}';
  }
}

/// Parses a Shizuku voice command: "force stop WhatsApp",
/// "force-stop WhatsApp", "turn mobile data on/off",
/// "disable WhatsApp", "enable WhatsApp". Returns the control + the
/// app's spoken name (resolved to a package by main.dart from the
/// connected-apps map), or null when this is not a Shizuku command.
/// Mobile-data commands carry no app name.
({ShizukuControl control, String? appName, bool? enable})?
parseShizukuCommand(String utterance) {
  final lower = utterance.trim().toLowerCase();
  final forceStop = RegExp(r'^force[ -]?stop (.+)$').firstMatch(lower);
  if (forceStop != null) {
    final name = (forceStop.group(1) ?? '').trim();
    if (name.isEmpty) return null;
    return (control: ShizukuControl.forceStopApp, appName: name, enable: null);
  }
  final disable = RegExp(r'^disable (?:app )?(.+)$').firstMatch(lower);
  if (disable != null) {
    final name = (disable.group(1) ?? '').trim();
    if (name.isEmpty) return null;
    return (control: ShizukuControl.disableApp, appName: name, enable: null);
  }
  final enable = RegExp(r'^enable (?:app )?(.+)$').firstMatch(lower);
  if (enable != null) {
    final name = (enable.group(1) ?? '').trim();
    if (name.isEmpty) return null;
    return (control: ShizukuControl.enableApp, appName: name, enable: null);
  }
  if (lower.contains('mobile data')) {
    if (lower.contains(' on') || lower.contains('enable')) {
      return (
        control: ShizukuControl.toggleMobileData,
        appName: null,
        enable: true,
      );
    }
    if (lower.contains(' off') || lower.contains('disable')) {
      return (
        control: ShizukuControl.toggleMobileData,
        appName: null,
        enable: false,
      );
    }
  }
  return null;
}

/// Wraps the shizuku_api plugin: status checks, authorisation, and
/// the allowlisted controls. All plugin calls are guarded — any
/// failure returns a safe value instead of throwing.
class ShizukuService {
  ShizukuService({ShizukuApi? api}) : _api = api ?? ShizukuApi();

  final ShizukuApi _api;

  Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisShizukuEnabledKey) ?? false;
  }

  Future<void> setEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisShizukuEnabledKey, enabled);
  }

  /// Current Shizuku state, in the order the setup flow needs:
  /// install -> start the service -> authorise Jarvis.
  Future<ShizukuStatus> getStatus() async {
    try {
      final installed = await _api.isShizukuInstalled() ?? false;
      if (!installed) return ShizukuStatus.notInstalled;
      final running = await _api.pingBinder() ?? false;
      if (!running) return ShizukuStatus.notRunning;
      final authorised = await _api.checkPermission() ?? false;
      if (!authorised) return ShizukuStatus.notAuthorised;
      return ShizukuStatus.ready;
    } catch (_) {
      return ShizukuStatus.unknown;
    }
  }

  /// Shows the Shizuku permission dialog. Returns true when Jarvis
  /// is authorised afterwards.
  Future<bool> requestAuthorisation() async {
    try {
      final granted = await _api.requestPermission() ?? false;
      if (granted) return true;
      return (await _api.checkPermission()) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Opens the Shizuku app (so the user can start its service).
  Future<void> openShizukuApp() async {
    try {
      await _api.openShizukuApp();
    } catch (_) {}
  }

  /// Runs one allowlisted control. Returns the command output, or
  /// null when Shizuku is not ready or the control is not allowlisted.
  /// The caller checks [isEnabled] and [getStatus] first and reports
  /// the plain-language reason when this returns null.
  Future<String?> runControl(
    ShizukuControl control, {
    String? package,
    bool? enable,
  }) async {
    final command = buildShizukuCommand(
      control,
      package: package,
      enable: enable,
    );
    if (command == null) return null;
    if (await getStatus() != ShizukuStatus.ready) return null;
    try {
      return await _api.runCommand(command);
    } catch (_) {
      return null;
    }
  }
}
