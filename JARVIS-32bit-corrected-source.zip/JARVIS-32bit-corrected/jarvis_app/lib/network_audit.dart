// Phase 7 (v1.1.0) — F30 network audit.
//
// Display-only: the phone's own Wi-Fi name, IP address and signal, and
// the devices on the same network from the on-device ARP table
// (/proc/net/arp). NO port-scanning, no probing of other devices.
//
// Wi-Fi info comes from a small platform channel in MainActivity.kt
// (WifiManager); the ARP table is read as a plain file in Dart. The
// pure helpers (parseArpTable, formatIpv4, signalStrengthLabel) are
// unit-tested directly.

import 'dart:io';

import 'package:flutter/services.dart';

/// One device seen in the ARP table.
class ArpDevice {
  const ArpDevice({
    required this.ip,
    required this.mac,
    required this.device,
  });

  final String ip;
  final String mac;

  /// Interface name from the ARP table (usually "wlan0").
  final String device;
}

/// Parses /proc/net/arp. Lines look like:
/// `192.168.1.1  0x1  0x2  aa:bb:cc:dd:ee:ff  *  wlan0`
/// The header line and entries with an all-zero MAC are skipped.
List<ArpDevice> parseArpTable(String contents) {
  final devices = <ArpDevice>[];
  for (final line in contents.split('\n')) {
    final fields = line.trim().split(RegExp(r'\s+'));
    if (fields.length < 6) continue;
    if (fields[0] == 'IP' || fields[0] == 'IP address') continue;
    final ip = fields[0];
    final mac = fields[3].toLowerCase();
    if (mac == '00:00:00:00:00:00') continue;
    if (!RegExp(r'^\d{1,3}(\.\d{1,3}){3}$').hasMatch(ip)) continue;
    if (!RegExp(r'^([0-9a-f]{2}:){5}[0-9a-f]{2}$').hasMatch(mac)) continue;
    devices.add(ArpDevice(ip: ip, mac: mac, device: fields[5]));
  }
  return devices;
}

/// Android's WifiInfo.ipAddress is a little-endian int; render it as a
/// dotted address.
String formatIpv4(int ip) {
  final a = ip & 0xFF;
  final b = (ip >> 8) & 0xFF;
  final c = (ip >> 16) & 0xFF;
  final d = (ip >> 24) & 0xFF;
  return '$a.$b.$c.$d';
}

/// Plain-language signal label for an RSSI in dBm.
String signalStrengthLabel(int rssi) {
  if (rssi >= -50) return 'Excellent';
  if (rssi >= -60) return 'Good';
  if (rssi >= -70) return 'Fair';
  return 'Weak';
}

/// The phone's own Wi-Fi connection, from the platform channel.
class WifiInfo {
  const WifiInfo({
    required this.ssid,
    required this.ipAddress,
    required this.rssi,
  });

  factory WifiInfo.fromMap(Map<String, dynamic> map) {
    final ipRaw = map['ipAddress'];
    final ipInt = ipRaw is int
        ? ipRaw
        : int.tryParse(ipRaw?.toString() ?? '') ?? 0;
    return WifiInfo(
      ssid: map['ssid']?.toString() ?? '',
      ipAddress: formatIpv4(ipInt),
      rssi: map['rssi'] is int
          ? map['rssi'] as int
          : int.tryParse(map['rssi']?.toString() ?? '') ?? 0,
    );
  }

  /// Empty or `<unknown ssid>` when Android will not reveal the name
  /// (location permission not granted on Android 10+).
  final String ssid;

  /// Dotted IP string, or '' when not connected to Wi-Fi.
  final String ipAddress;

  /// Signal strength in dBm.
  final int rssi;

  bool get ssidKnown => ssid.isNotEmpty && ssid != '<unknown ssid>';
}

class NetworkAuditService {
  const NetworkAuditService();

  static const MethodChannel _channel =
      MethodChannel('com.jarvis.jarvis_app/network');

  /// The phone's own Wi-Fi info. Returns null when the channel fails
  /// (Wi-Fi off, or the native side is unavailable).
  Future<WifiInfo?> getWifiInfo() async {
    try {
      final raw = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getWifiInfo',
      );
      if (raw == null) return null;
      final info = WifiInfo.fromMap(Map<String, dynamic>.from(raw));
      if (info.ipAddress == '0.0.0.0') return null;
      return info;
    } catch (_) {
      return null;
    }
  }

  /// Devices on the same network, from the on-device ARP table.
  /// Returns [] when the table cannot be read on this phone.
  Future<List<ArpDevice>> getArpDevices() async {
    try {
      final contents = await File('/proc/net/arp').readAsString();
      return parseArpTable(contents);
    } catch (_) {
      return [];
    }
  }
}
