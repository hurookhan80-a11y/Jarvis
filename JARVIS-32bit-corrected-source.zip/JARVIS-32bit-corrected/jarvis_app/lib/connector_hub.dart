// Phase 6 (v1.1.0) — F19 connector hub.
//
// One registry for every provider/connector (Gemini, NVIDIA NIM,
// Gmail), each with on/off state and, where one is needed, a key entry.
// Keys are stored encrypted through the SAME AndroidKeyStore
// secure-storage channel as the Gemini key (see
// android/.../MainActivity.kt): the channel gained generic
// saveSecret/readSecret/clearSecret methods beside the existing
// saveApiKey/readApiKey/clearApiKey, reusing the same AES/GCM + Keystore
// helpers. No key in code/repo ever.
//
// Rules:
//   - Gemini is the default and can never be turned off.
//   - NVIDIA NIM stays off until a key has been entered; turning it on
//     without a key shows "key needed" and stays off.
//   - Gmail (F28, Phase 7) stays off until the user pastes a Gmail
//     OAuth access token (see lib/gmail_service.dart for how to get
//     one); turning it on without a token is refused the same way.
//
// Pattern: connector registry, after mokshith7777/Jarvis-android-
// lib/services/connector_hub_service.dart + lib/screens/connectors/
// connectors_screen.dart. Fresh implementation — no code copied.

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'gmail_service.dart';

/// Which connector a row in the hub is.
enum ConnectorId { gemini, nvidiaNim, gmail }

/// SharedPreferences key: is the NVIDIA NIM fallback switched on?
const String kJarvisConnectorNimEnabledKey = 'jarvis_connector_nim_enabled';

/// The Gmail on/off key lives in lib/gmail_service.dart
/// ([kJarvisConnectorGmailEnabledKey]) and is used here through that
/// import, so there is exactly one definition.

/// Name of the NVIDIA NIM key in the secure-storage channel. Only
/// names on the channel's allowlist are accepted on the native side.
const String kJarvisNimSecretName = 'nvidia_nim';

/// One connector row for the hub screen.
class ConnectorInfo {
  const ConnectorInfo({
    required this.id,
    required this.name,
    required this.description,
    required this.enabled,
    required this.status,
    this.canToggle = true,
    this.needsKey = false,
    this.keySet = false,
  });

  final ConnectorId id;
  final String name;
  final String description;
  final bool enabled;

  /// One-line status shown under the name ("Always on", "Key needed",
  /// "Ready — used only if Gemini fails", ...).
  final String status;

  /// False for Gemini: it can never be turned off.
  final bool canToggle;

  /// True when the connector needs a key before it can be switched on.
  final bool needsKey;

  /// True when a key is stored for this connector.
  final bool keySet;
}

/// Pure rule: the NIM fallback can only be switched on when a key is
/// stored. Turning it on without a key must show "key needed" and stay
/// off (spec F19 phone test).
bool nimCanBeEnabled({required bool keySet}) => keySet;

/// The connector registry. Toggle state lives in SharedPreferences;
/// keys live encrypted in the AndroidKeyStore-backed secure storage.
class ConnectorHubService {
  const ConnectorHubService();

  static const MethodChannel _secureStorageChannel =
      MethodChannel('com.jarvis.jarvis_app/secure_storage');

  Future<bool> isNimEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisConnectorNimEnabledKey) ?? false;
  }

  /// Switches the NIM fallback on or off. Turning it on without a
  /// stored key is refused (returns false, state unchanged).
  Future<bool> setNimEnabled(bool enabled) async {
    if (enabled && !nimCanBeEnabled(keySet: await hasNimKey())) {
      return false;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisConnectorNimEnabledKey, enabled);
    return true;
  }

  Future<bool> hasNimKey() async =>
      (await readNimKey()).trim().isNotEmpty;

  Future<String> readNimKey() async {
    try {
      return await _secureStorageChannel.invokeMethod<String>(
            'readSecret',
            <String, String>{'name': kJarvisNimSecretName},
          ) ??
          '';
    } catch (_) {
      return '';
    }
  }

  Future<void> saveNimKey(String key) async {
    await _secureStorageChannel.invokeMethod<void>(
      'saveSecret',
      <String, String>{
        'name': kJarvisNimSecretName,
        'value': key.trim(),
      },
    );
  }

  Future<void> clearNimKey() async {
    try {
      await _secureStorageChannel.invokeMethod<void>(
        'clearSecret',
        <String, String>{'name': kJarvisNimSecretName},
      );
    } catch (_) {}
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisConnectorNimEnabledKey, false);
  }

  Future<bool> isGmailEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisConnectorGmailEnabledKey) ?? false;
  }

  /// Gmail's connect state lives in [GmailService] (token in the
  /// Keystore-backed secure storage). One shared instance: the hub is
  /// a const service, so the client is held statically.
  static final GmailService _gmailService = GmailService();

  Future<bool> hasGmailToken() => _gmailService.hasToken();

  /// Switches Gmail triage on or off. Turning it on without a stored
  /// access token is refused (returns false, state unchanged).
  Future<bool> setGmailEnabled(bool enabled) =>
      _gmailService.setEnabled(enabled);

  Future<void> saveGmailToken(String token) =>
      _gmailService.saveToken(token);

  Future<void> clearGmailToken() => _gmailService.clearToken();

  /// The rows for the hub screen, in display order.
  Future<List<ConnectorInfo>> listConnectors() async {
    final nimEnabled = await isNimEnabled();
    final nimKeySet = await hasNimKey();
    final gmailEnabled = await isGmailEnabled();
    final gmailTokenSet = await hasGmailToken();
    return <ConnectorInfo>[
      const ConnectorInfo(
        id: ConnectorId.gemini,
        name: 'Gemini',
        description:
            'Default AI chat (gemini-3.8-flash). Key entered in Settings.',
        enabled: true,
        status: 'Always on — default',
        canToggle: false,
      ),
      ConnectorInfo(
        id: ConnectorId.nvidiaNim,
        name: 'NVIDIA NIM (fallback)',
        description:
            'Free hosted Nemotron model. Answers only if Gemini fails with '
            'quota/overload/timeout. Needs a free NVIDIA API key.',
        enabled: nimEnabled,
        status: !nimKeySet
            ? 'Key needed — add your free NVIDIA key below'
            : nimEnabled
                ? 'Ready — used only if Gemini fails'
                : 'Key saved — switched off',
        needsKey: true,
        keySet: nimKeySet,
      ),
      ConnectorInfo(
        id: ConnectorId.gmail,
        name: 'Gmail',
        description:
            'Email triage ("any important mail?"). Read-only — never '
            'sends, deletes or marks mail read. Needs a Gmail access '
            'token from your own Google account (see the Email triage '
            'screen for how to get one).',
        enabled: gmailEnabled,
        status: !gmailTokenSet
            ? 'Not connected yet'
            : gmailEnabled
                ? 'Connected — triage is on'
                : 'Token saved — switched off',
        canToggle: gmailTokenSet,
        needsKey: true,
        keySet: gmailTokenSet,
      ),
    ];
  }
}
