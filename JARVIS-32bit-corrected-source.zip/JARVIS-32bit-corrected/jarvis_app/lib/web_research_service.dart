// v1.2.0 — G7 web research.
//
// Gemini answers from its training knowledge only, which goes
// stale: it cannot know today's news, a new paper, or a changed
// fact. This service gives it fresh web facts from two keyless
// public APIs — Wikipedia and the DuckDuckGo Instant Answer API —
// so no API key is needed anywhere. The agent loop (or a research-
// mode answer) can call [WebResearchService.search] and hand the
// results to Gemini as extra context; Gemini still writes the
// answer, and the sources travel with it so the user can check.
//
// Fresh implementation — ideas only, no code copied.

import 'dart:convert';

import 'package:http/http.dart' as http;

/// One web-research result.
class WebResult {
  const WebResult({
    required this.title,
    required this.extract,
    required this.url,
    required this.source,
  });

  /// Result title (article title or answer heading).
  final String title;

  /// Short factual text (summary extract or answer text).
  final String extract;

  /// Canonical page URL the user can open.
  final String url;

  /// Where the result came from: 'wikipedia' or 'duckduckgo'.
  final String source;
}

/// Thrown when web research fails (no network, a bad response, or
/// a timeout). The message is plain English for the chat, never a
/// raw stack trace.
class WebResearchException implements Exception {
  const WebResearchException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Per-call timeout. The APIs are fast; 15 s is enough even on a
/// slow mobile connection, and it bounds how long a research step
/// can stall the agent loop.
const Duration kWebResearchTimeout = Duration(seconds: 15);

/// Maximum results returned by [WebResearchService.search].
const int kWebResearchMaxResults = 5;

/// Parses a Wikipedia search response
/// (action=query&list=search) into (title, pageid) pairs, in
/// result order. Pure — no I/O. Returns [] for a malformed or
/// empty response instead of throwing.
List<({String title, int pageid})> parseWikipediaSearch(String body) {
  try {
    final decoded = jsonDecode(body);
    if (decoded is! Map<String, dynamic>) return const [];
    final query = decoded['query'];
    if (query is! Map<String, dynamic>) return const [];
    final search = query['search'];
    if (search is! List) return const [];
    final results = <({String title, int pageid})>[];
    for (final item in search) {
      if (item is! Map<String, dynamic>) continue;
      final title = item['title'];
      final pageid = item['pageid'];
      if (title is String && title.isNotEmpty && pageid is int) {
        results.add((title: title, pageid: pageid));
      }
    }
    return results;
  } catch (_) {
    return const [];
  }
}

/// Parses a Wikipedia REST summary response
/// (api/rest_v1/page/summary/<title>) into its extract text.
/// Pure — no I/O. Returns '' when there is no extract.
String parseWikipediaSummary(String body) {
  try {
    final decoded = jsonDecode(body);
    if (decoded is! Map<String, dynamic>) return '';
    final extract = decoded['extract'];
    return extract is String ? extract : '';
  } catch (_) {
    return '';
  }
}

/// Parses a DuckDuckGo Instant Answer response into a single
/// result, or null when the API has no direct answer for the query
/// (no AbstractText). Pure — no I/O. [query] is kept only for the
/// fallback title when the response carries no heading.
WebResult? parseDuckDuckGoAnswer(String body, String query) {
  try {
    final decoded = jsonDecode(body);
    if (decoded is! Map<String, dynamic>) return null;
    final abstractText = decoded['AbstractText'];
    if (abstractText is! String || abstractText.trim().isEmpty) {
      return null;
    }
    final heading = decoded['Heading'];
    final url = decoded['AbstractURL'];
    return WebResult(
      title: heading is String && heading.isNotEmpty ? heading : query,
      extract: abstractText.trim(),
      url: url is String && url.isNotEmpty ? url : 'https://duckduckgo.com/?q=${Uri.encodeComponent(query)}',
      source: 'duckduckgo',
    );
  } catch (_) {
    return null;
  }
}

/// Searches the web for [query]: Wikipedia first (search, then the
/// top hit's summary extract), plus the DuckDuckGo Instant Answer.
/// Results are merged, de-duplicated by URL, and capped at
/// [kWebResearchMaxResults]. A network failure on either source
/// throws [WebResearchException]; a source that simply has no
/// answer for the query contributes nothing instead of failing
/// the whole search.
class WebResearchService {
  WebResearchService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  Future<List<WebResult>> search(String query) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) {
      throw const WebResearchException('Nothing to search for.');
    }
    final results = <WebResult>[];
    final seenUrls = <String>{};

    void addResult(WebResult result) {
      if (result.extract.trim().isEmpty) return;
      if (!seenUrls.add(result.url)) return;
      if (results.length >= kWebResearchMaxResults) return;
      results.add(result);
    }

    try {
      // Wikipedia: search, then the top hit's summary extract.
      final searchUri = Uri.parse(
        'https://en.wikipedia.org/w/api.php'
        '?action=query&list=search'
        '&srsearch=${Uri.encodeComponent(trimmed)}'
        '&format=json&srlimit=5',
      );
      final searchResponse = await _client
          .get(searchUri)
          .timeout(kWebResearchTimeout);
      if (searchResponse.statusCode != 200) {
        throw WebResearchException(
          'Wikipedia search failed (HTTP ${searchResponse.statusCode}).',
        );
      }
      final hits = parseWikipediaSearch(searchResponse.body);
      for (final hit in hits) {
        if (results.length >= kWebResearchMaxResults) break;
        final summaryUri = Uri.parse(
          'https://en.wikipedia.org/api/rest_v1/page/summary/'
          '${Uri.encodeComponent(hit.title)}',
        );
        final summaryResponse = await _client
            .get(summaryUri)
            .timeout(kWebResearchTimeout);
        if (summaryResponse.statusCode != 200) continue;
        final extract = parseWikipediaSummary(summaryResponse.body);
        if (extract.trim().isEmpty) continue;
        addResult(WebResult(
          title: hit.title,
          extract: extract.trim(),
          url: 'https://en.wikipedia.org/?curid=${hit.pageid}',
          source: 'wikipedia',
        ));
      }

      // DuckDuckGo Instant Answer: one direct answer, if any.
      final ddgUri = Uri.parse(
        'https://api.duckduckgo.com/'
        '?q=${Uri.encodeComponent(trimmed)}'
        '&format=json&no_html=1&skip_disambig=1',
      );
      final ddgResponse = await _client
          .get(ddgUri)
          .timeout(kWebResearchTimeout);
      if (ddgResponse.statusCode == 200) {
        final answer = parseDuckDuckGoAnswer(ddgResponse.body, trimmed);
        if (answer != null) addResult(answer);
      }
    } on WebResearchException {
      rethrow;
    } on Exception catch (e) {
      throw WebResearchException('Web search failed: $e');
    }
    return results;
  }

  void dispose() => _client.close();
}
