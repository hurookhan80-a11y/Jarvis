// v1.2.0 (G11) — usage dashboard data.
//
// Counts, per day, how much Jarvis was used: conversations started,
// messages spoken, reminders fired, tasks done / failed. Stored on
// this phone only (SharedPreferences), as one JSON object keyed by
// date. Main.dart calls the record methods at the existing event
// sites — this file only counts and reports, it hooks nothing itself.
//
// Fresh implementation — no code copied.

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key holding the per-day usage buckets as JSON.
const String kJarvisUsageStatsKey = 'jarvis_usage_stats_v1';

/// Most days kept. Older buckets are dropped first — a phone should
/// never grow an unbounded usage log.
const int kJarvisMaxUsageDays = 60;

/// How many days the dashboard's recent list covers.
const int kJarvisUsageDashboardDays = 7;

/// Day key: local date as `yyyy-MM-dd` (zero-padded).
String usageDayKey(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-'
    '${date.month.toString().padLeft(2, '0')}-'
    '${date.day.toString().padLeft(2, '0')}';

/// One day's usage counts.
class UsageDay {
  const UsageDay({
    required this.date,
    this.conversations = 0,
    this.messagesSpoken = 0,
    this.remindersFired = 0,
    this.tasksDone = 0,
    this.tasksFailed = 0,
  });

  /// Local calendar day this bucket counts.
  final DateTime date;
  final int conversations;
  final int messagesSpoken;
  final int remindersFired;
  final int tasksDone;
  final int tasksFailed;

  /// Storage key for this day.
  String get key => usageDayKey(date);

  UsageDay increment({
    bool conversation = false,
    bool messageSpoken = false,
    bool reminderFired = false,
    bool taskDone = false,
    bool taskFailed = false,
  }) =>
      UsageDay(
        date: date,
        conversations: conversations + (conversation ? 1 : 0),
        messagesSpoken: messagesSpoken + (messageSpoken ? 1 : 0),
        remindersFired: remindersFired + (reminderFired ? 1 : 0),
        tasksDone: tasksDone + (taskDone ? 1 : 0),
        tasksFailed: tasksFailed + (taskFailed ? 1 : 0),
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'conversations': conversations,
        'messagesSpoken': messagesSpoken,
        'remindersFired': remindersFired,
        'tasksDone': tasksDone,
        'tasksFailed': tasksFailed,
      };

  factory UsageDay.fromJson(String key, Map<String, dynamic> json) {
    final parts = key.split('-');
    DateTime date;
    if (parts.length == 3) {
      date = DateTime(
        int.tryParse(parts[0]) ?? 1970,
        int.tryParse(parts[1]) ?? 1,
        int.tryParse(parts[2]) ?? 1,
      );
    } else {
      date = DateTime(1970);
    }
    int count(String field) {
      final value = json[field];
      if (value is num) return value.toInt() < 0 ? 0 : value.toInt();
      return 0;
    }

    return UsageDay(
      date: date,
      conversations: count('conversations'),
      messagesSpoken: count('messagesSpoken'),
      remindersFired: count('remindersFired'),
      tasksDone: count('tasksDone'),
      tasksFailed: count('tasksFailed'),
    );
  }
}

/// What the usage dashboard shows: all-time totals plus the last 7
/// days (oldest first, missing days as zeros).
class UsageDashboardData {
  const UsageDashboardData({
    required this.totalConversations,
    required this.totalMessagesSpoken,
    required this.totalRemindersFired,
    required this.totalTasksDone,
    required this.totalTasksFailed,
    required this.last7Days,
  });

  final int totalConversations;
  final int totalMessagesSpoken;
  final int totalRemindersFired;
  final int totalTasksDone;
  final int totalTasksFailed;

  /// Last 7 days, oldest first — always exactly 7 entries.
  final List<UsageDay> last7Days;
}

/// Parses the stored per-day buckets from [raw] JSON. Tolerant:
/// missing, malformed or wrongly-shaped data returns an empty map,
/// and bad day entries are dropped. Pure — no I/O, so unit-testable.
Map<String, UsageDay> parseStoredUsage(String? raw) {
  if (raw == null || raw.isEmpty) return <String, UsageDay>{};
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! Map) return <String, UsageDay>{};
    final days = <String, UsageDay>{};
    for (final entry in decoded.entries) {
      final key = entry.key.toString();
      if (entry.value is! Map) continue;
      // Only real `yyyy-MM-dd` keys count as day buckets.
      if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(key)) continue;
      days[key] = UsageDay.fromJson(
        key,
        Map<String, dynamic>.from(entry.value as Map),
      );
    }
    return days;
  } catch (_) {
    return <String, UsageDay>{};
  }
}

String encodeUsage(Map<String, UsageDay> days) => jsonEncode(
      days.map((key, day) => MapEntry(key, day.toJson())),
    );

/// Builds the dashboard data from stored [days] (today = [now]).
/// Totals cover all stored days; the last-7 list always has 7 entries,
/// oldest first, with zeros for days that have no bucket. Pure — no
/// I/O, so it is unit-testable.
UsageDashboardData buildUsageDashboard(
  Map<String, UsageDay> days, {
  DateTime? now,
}) {
  final today = now ?? DateTime.now();
  final todayDate = DateTime(today.year, today.month, today.day);
  var totalConversations = 0;
  var totalMessagesSpoken = 0;
  var totalRemindersFired = 0;
  var totalTasksDone = 0;
  var totalTasksFailed = 0;
  for (final day in days.values) {
    totalConversations += day.conversations;
    totalMessagesSpoken += day.messagesSpoken;
    totalRemindersFired += day.remindersFired;
    totalTasksDone += day.tasksDone;
    totalTasksFailed += day.tasksFailed;
  }
  final last7Days = <UsageDay>[
    for (var i = kJarvisUsageDashboardDays - 1; i >= 0; i--)
      days[usageDayKey(todayDate.subtract(Duration(days: i)))] ??
          UsageDay(date: todayDate.subtract(Duration(days: i))),
  ];
  return UsageDashboardData(
    totalConversations: totalConversations,
    totalMessagesSpoken: totalMessagesSpoken,
    totalRemindersFired: totalRemindersFired,
    totalTasksDone: totalTasksDone,
    totalTasksFailed: totalTasksFailed,
    last7Days: last7Days,
  );
}

/// On-device store for the per-day usage counts.
class UsageStatsService {
  const UsageStatsService();

  Future<Map<String, UsageDay>> _load() async {
    final prefs = await SharedPreferences.getInstance();
    return parseStoredUsage(prefs.getString(kJarvisUsageStatsKey));
  }

  Future<void> _save(Map<String, UsageDay> days) async {
    // Cap stored days at 60 — drop the oldest buckets first.
    if (days.length > kJarvisMaxUsageDays) {
      final keys = days.keys.toList()..sort();
      for (final key in keys.take(days.length - kJarvisMaxUsageDays)) {
        days.remove(key);
      }
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(kJarvisUsageStatsKey, encodeUsage(days));
  }

  Future<void> _record({
    bool conversation = false,
    bool messageSpoken = false,
    bool reminderFired = false,
    bool taskDone = false,
    bool taskFailed = false,
  }) async {
    final days = await _load();
    final today = DateTime.now();
    final key = usageDayKey(today);
    final current = days[key] ??
        UsageDay(date: DateTime(today.year, today.month, today.day));
    days[key] = current.increment(
      conversation: conversation,
      messageSpoken: messageSpoken,
      reminderFired: reminderFired,
      taskDone: taskDone,
      taskFailed: taskFailed,
    );
    await _save(days);
  }

  /// A conversation was started.
  Future<void> recordConversation() async =>
      _record(conversation: true);

  /// A message was spoken aloud.
  Future<void> recordMessageSpoken() async =>
      _record(messageSpoken: true);

  /// A reminder fired.
  Future<void> recordReminderFired() async =>
      _record(reminderFired: true);

  /// An agent task finished successfully.
  Future<void> recordTaskDone() async => _record(taskDone: true);

  /// An agent task failed.
  Future<void> recordTaskFailed() async => _record(taskFailed: true);

  /// Dashboard data: all-time totals + the last 7 days.
  Future<UsageDashboardData> loadDashboard() async {
    final days = await _load();
    return buildUsageDashboard(days);
  }

  /// Deletes all stored usage data.
  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(kJarvisUsageStatsKey);
  }
}
