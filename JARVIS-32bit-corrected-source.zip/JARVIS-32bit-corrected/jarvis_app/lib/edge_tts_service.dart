import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:crypto/crypto.dart';

/// Microsoft Edge read-aloud TTS (F10, v1.1.0).
///
/// Free, no API key, no account: the app talks to the same public
/// endpoint the Edge browser's read-aloud feature uses. Fresh
/// implementation of the public WebSocket protocol (no copied code):
/// the client opens
/// `wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1`,
/// authenticates each connection with a `Sec-MS-GEC` token (SHA-256 of
/// the current Windows-epoch ticks plus the public trusted-client
/// token), sends a `speech.config` frame and an SSML frame, and collects
/// the `Path:audio` binary frames (MP3) until `Path:turn.end`.
///
/// Any failure (no network, endpoint blocked, bad response) throws
/// [EdgeTtsException]; the caller ([speak] in `main.dart`) falls back
/// silently to the device TTS, so speech never breaks because Edge did.

class EdgeTtsException implements Exception {
  const EdgeTtsException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// The public trusted-client token the Edge read-aloud endpoint expects.
/// This is a well-known constant of the public service, not a secret and
/// not an API key.
const String edgeTtsTrustedClientToken = '6A5AA1D4EAFF4E9FB9E31F41654628A';

/// `Sec-MS-GEC` token for [utcNow]: SHA-256 (upper-case hex) of
/// `"<windows ticks><trusted client token>"`, where windows ticks are
/// 100-nanosecond intervals since 0001-01-01.
String edgeTtsAuthToken(DateTime utcNow) {
  final unixSeconds = utcNow.millisecondsSinceEpoch ~/ 1000;
  final ticks = (unixSeconds + 62135596800) * 10000000;
  final toHash = '$ticks$edgeTtsTrustedClientToken';
  return sha256.convert(utf8.encode(toHash)).toString().toUpperCase();
}

/// A random 32-hex-character request id, as the protocol expects.
String edgeTtsRequestId() {
  final random = Random.secure();
  final bytes = List<int>.generate(16, (_) => random.nextInt(256));
  return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
}

/// SSML for [text] in [voice]. [ratePercent] is relative to normal
/// speech (negative = slower; the app default of -20 matches its
/// slightly-slow device-TTS rate of 0.6). [pitchHertz] shifts the pitch.
String edgeTtsSsml(
  String text, {
  required String voice,
  int ratePercent = -20,
  int pitchHertz = 0,
}) {
  final escaped = const HtmlEscape(HtmlEscapeMode.element).convert(text);
  final rate = ratePercent >= 0 ? '+$ratePercent%' : '$ratePercent%';
  final pitch = pitchHertz >= 0 ? '+${pitchHertz}Hz' : '${pitchHertz}Hz';
  return '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" '
      'xmlns:mstts="https://www.w3.org/2001/mstts" xml:lang="en-GB">'
      '<voice name="$voice">'
      '<prosody rate="$rate" pitch="$pitch">$escaped</prosody>'
      '</voice></speak>';
}

/// Audio bytes from one WebSocket message, or null when the message is
/// not an audio frame. Binary frames are an ASCII header, a blank line,
/// then MP3 bytes; the header must contain `Path:audio`.
Uint8List? edgeTtsExtractAudio(List<int> message) {
  const separator = <int>[13, 10, 13, 10]; // \r\n\r\n
  var headerEnd = -1;
  for (var i = 0; i + 3 < message.length; i++) {
    if (message[i] == separator[0] &&
        message[i + 1] == separator[1] &&
        message[i + 2] == separator[2] &&
        message[i + 3] == separator[3]) {
      headerEnd = i + 4;
      break;
    }
  }
  if (headerEnd < 0) return null;
  final header = ascii.decode(
    message.sublist(0, headerEnd),
    allowInvalid: true,
  );
  if (!header.contains('Path:audio')) return null;
  return Uint8List.fromList(message.sublist(headerEnd));
}

/// Synthesises speech with Edge TTS and plays it through audioplayers.
class EdgeTtsService {
  static const String defaultVoice = 'en-GB-SoniaNeural';

  static const String _endpoint =
      'wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1';

  final AudioPlayer _player = AudioPlayer();
  WebSocket? _socket;
  Completer<bool>? _playCompleter;
  StreamSubscription<void>? _completeSub;
  bool _stopped = false;

  /// Synthesises [text] and plays it. Returns true only when the audio
  /// played to the end; false on any error or when [stop] cut it short.
  /// Callers fall back to device TTS on false (unless STOP was pressed,
  /// in which case the generation check in `speak()` already rules out
  /// any fallback speech).
  Future<bool> speak(String text, {String voice = defaultVoice}) async {
    _stopped = false;
    try {
      final audio = await synthesize(
        text,
        voice: voice,
      ).timeout(const Duration(seconds: 20));
      if (_stopped || audio.isEmpty) return false;
      final completer = Completer<bool>();
      _playCompleter = completer;
      await _completeSub?.cancel();
      _completeSub = _player.onPlayerComplete.listen((_) {
        if (!completer.isCompleted) completer.complete(true);
      });
      await _player.play(BytesSource(audio));
      // Safety cap so a stuck player can never hang speak() forever.
      final played = await completer.future.timeout(
        const Duration(seconds: 90),
        onTimeout: () => false,
      );
      return played && !_stopped;
    } catch (_) {
      return false;
    } finally {
      await _completeSub?.cancel();
      _completeSub = null;
      if (_playCompleter != null && !_playCompleter!.isCompleted) {
        _playCompleter!.complete(false);
      }
      _playCompleter = null;
    }
  }

  /// Synthesises [text] and returns the MP3 bytes. Throws
  /// [EdgeTtsException] on any failure.
  Future<Uint8List> synthesize(
    String text, {
    String voice = defaultVoice,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty) {
      throw const EdgeTtsException('Nothing to speak.');
    }
    final requestId = edgeTtsRequestId();
    final timestamp = HttpDate.format(DateTime.now().toUtc());
    late final WebSocket socket;
    try {
      socket = await WebSocket.connect(
        '$_endpoint?TrustedClientToken=$edgeTtsTrustedClientToken',
        headers: <String, String>{
          'Origin': 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
          'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 '
              'Edg/130.0.0.0',
          'Sec-MS-GEC': edgeTtsAuthToken(DateTime.now().toUtc()),
          'Sec-MS-GEC-Version': '1-130.0.0.0',
        },
      ).timeout(const Duration(seconds: 10));
    } on TimeoutException {
      throw const EdgeTtsException('Edge TTS timed out while connecting.');
    } catch (e) {
      throw EdgeTtsException('Edge TTS could not connect: $e');
    }
    _socket = socket;
    final audio = BytesBuilder();
    final done = Completer<void>();
    late final StreamSubscription<dynamic> sub;
    sub = socket.listen(
      (dynamic message) {
        if (message is List<int>) {
          final bytes = edgeTtsExtractAudio(message);
          if (bytes != null) audio.add(bytes);
        } else if (message is String) {
          if (message.contains('Path:turn.end')) {
            if (!done.isCompleted) done.complete();
          }
        }
      },
      onError: (Object e) {
        if (!done.isCompleted) done.completeError(e);
      },
      onDone: () {
        if (!done.isCompleted) done.complete();
      },
      cancelOnError: true,
    );
    try {
      socket.add(
        'Path: speech.config\r\n'
        'X-RequestId: $requestId\r\n'
        'X-Timestamp: $timestamp\r\n'
        'Content-Type: application/json\r\n'
        '\r\n'
        '{"context":{"synthesis":{"audio":{"metadataoptions":'
        '{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},'
        '"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}',
      );
      socket.add(
        'Path: ssml\r\n'
        'X-RequestId: $requestId\r\n'
        'X-Timestamp: $timestamp\r\n'
        'Content-Type: application/ssml+xml\r\n'
        '\r\n'
        '${edgeTtsSsml(clean, voice: voice)}',
      );
      await done.future.timeout(const Duration(seconds: 20));
    } on TimeoutException {
      throw const EdgeTtsException('Edge TTS timed out waiting for audio.');
    } finally {
      await sub.cancel();
      try {
        await socket.close();
      } catch (_) {}
      if (identical(_socket, socket)) _socket = null;
    }
    final bytes = audio.toBytes();
    if (bytes.isEmpty) {
      throw const EdgeTtsException('Edge TTS returned no audio.');
    }
    return bytes;
  }

  /// Stops any Edge playback/synthesis in progress (STOP button).
  void stop() {
    _stopped = true;
    try {
      _socket?.close();
    } catch (_) {}
    _socket = null;
    try {
      _player.stop();
    } catch (_) {}
    if (_playCompleter != null && !_playCompleter!.isCompleted) {
      _playCompleter!.complete(false);
    }
  }

  Future<void> dispose() async {
    stop();
    await _completeSub?.cancel();
    await _player.dispose();
  }
}
