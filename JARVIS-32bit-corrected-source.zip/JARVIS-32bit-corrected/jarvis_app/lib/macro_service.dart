// Phase 7 (v1.1.0) — F33 macro recorder.
//
// Record a sequence of voice commands once under a name
// ("morning routine" = weather + reminders + time) and replay it with
// one phrase ("run morning routine"). Macros are stored locally on
// this phone only (SharedPreferences). Replay runs each command
// through the existing processQuery path (via the executor main.dart
// passes in) and reports each step honestly — see
// lib/multi_task_service.dart for the shared step reporting.
//
// Pattern: AbuZar-Ansarii/Jarvis
// lib/services/macro_recorder_service.dart. Fresh implementation —
// no code copied.
//
// Voice commands (parsed by the pure helpers below):
//   "record macro morning routine" / "record macro" -> start recording
//   "stop recording"                 -> finish + save under the name
//   "run morning routine" / "run macro morning routine" -> replay
//   "delete macro morning routine"   -> delete it
//   "show my macros" / "list macros" -> open the Macros screen

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'workflow_service.dart';

/// SharedPreferences key holding the macros, as a JSON list of
/// `{name, steps, createdAt}` objects.
const String kJarvisMacrosKey = 'jarvis_macros_v1';

/// Most macros kept; most steps in one macro. A phone should never
/// grow an unbounded macro list.
const int kJarvisMaxMacros = 50;
const int kJarvisMaxMacroSteps = 20;

/// One recorded macro.
class Macro {
  const Macro({
    required this.name,
    required this.steps,
    required this.createdAt,
    this.autonomy = WorkflowAutonomy.askFirst,
  });

  factory Macro.fromJson(Map<String, dynamic> json) {
    final steps = <String>[];
    final raw = json['steps'];
    if (raw is List) {
      for (final step in raw) {
        final text = step?.toString().trim() ?? '';
        if (text.isNotEmpty) steps.add(text);
      }
    }
    return Macro(
      name: json['name']?.toString() ?? '',
      steps: steps,
      createdAt:
          DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
      // Old stored macros have no 'autonomy' key — they load as
      // askFirst (see workflowAutonomyFromString), so replaying them
      // still shows the plan and waits for "yes".
      autonomy: workflowAutonomyFromString(json['autonomy']?.toString()),
    );
  }

  final String name;

  /// The recorded commands, in order, as the user spoke them.
  final List<String> steps;
  final DateTime createdAt;

  /// Whether replaying this macro asks first or runs straight away
  /// (G12). Either way the F42 confirmation gate still applies to
  /// any send/call step inside — autonomy never bypasses it.
  final WorkflowAutonomy autonomy;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'name': name,
    'steps': steps,
    'createdAt': createdAt.toIso8601String(),
    'autonomy': workflowAutonomyToString(autonomy),
  };
}

/// Parses a stored macro list from [raw] JSON; drops malformed entries
/// and macros with no name or no steps.
List<Macro> parseStoredMacros(String? raw) {
  if (raw == null || raw.isEmpty) return [];
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map((e) => Macro.fromJson(Map<String, dynamic>.from(e)))
        .where((m) => m.name.trim().isNotEmpty && m.steps.isNotEmpty)
        .toList();
  } catch (_) {
    return [];
  }
}

String encodeMacros(List<Macro> macros) =>
    jsonEncode(macros.map((m) => m.toJson()).toList());

/// Normalises a macro name for matching: lower-cased, trimmed,
/// collapsed spaces. The stored display name keeps the user's casing.
String normalizeMacroName(String name) =>
    name.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

/// Finds a macro by name (case-insensitive), or null.
Macro? findMacro(List<Macro> macros, String name) {
  final wanted = normalizeMacroName(name);
  for (final macro in macros) {
    if (normalizeMacroName(macro.name) == wanted) return macro;
  }
  return null;
}

/// Extracts the macro name from "record macro <name>" /
/// "start recording macro <name>", or '' when the command starts a
/// recording without a name (main.dart then asks for the name).
/// Returns null when this is not a record command at all.
String? parseMacroRecordName(String utterance) {
  final lower = utterance.trim().toLowerCase();
  for (final prefix in <String>[
    'start recording macro ',
    'record macro ',
    'record a macro ',
    'start recording ',
  ]) {
    if (lower.startsWith(prefix)) {
      return utterance.trim().substring(prefix.length).trim();
    }
  }
  return null;
}

/// Extracts the macro name from `run <name>` / `run macro <name>`.
/// Returns null when this is not a run command. A bare "run" with no
/// name is not a macro command.
String? parseMacroRunName(String utterance) {
  final lower = utterance.trim().toLowerCase();
  for (final prefix in <String>['run macro ', 'run my macro ', 'run ']) {
    if (lower.startsWith(prefix)) {
      final name = utterance.trim().substring(prefix.length).trim();
      if (name.isEmpty) return null;
      // "run the morning routine" — drop a leading article.
      return name.replaceFirst(RegExp(r'^(the|my)\s+', caseSensitive: false), '');
    }
  }
  return null;
}

/// Extracts the macro name from `delete macro <name>` /
/// `remove macro <name>`. Returns null when not a delete command.
String? parseMacroDeleteName(String utterance) {
  final lower = utterance.trim().toLowerCase();
  for (final prefix in <String>['delete macro ', 'remove macro ']) {
    if (lower.startsWith(prefix)) {
      final name = utterance.trim().substring(prefix.length).trim();
      return name.isEmpty ? null : name;
    }
  }
  return null;
}

/// Local macro store. Recording state (which commands have been
/// captured so far) lives in main.dart, next to the other
/// pending-command state — the store only persists finished macros.
class MacroService {
  const MacroService();

  Future<List<Macro>> loadMacros() async {
    final prefs = await SharedPreferences.getInstance();
    final macros = parseStoredMacros(prefs.getString(kJarvisMacrosKey));
    macros.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return macros;
  }

  Future<void> saveMacro(Macro macro) async {
    if (macro.name.trim().isEmpty || macro.steps.isEmpty) return;
    final macros = await loadMacros();
    macros.removeWhere(
      (m) => normalizeMacroName(m.name) == normalizeMacroName(macro.name),
    );
    macros.add(macro);
    while (macros.length > kJarvisMaxMacros) {
      macros.removeAt(0);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(kJarvisMacrosKey, encodeMacros(macros));
  }

  Future<bool> deleteMacro(String name) async {
    final macros = await loadMacros();
    final before = macros.length;
    macros.removeWhere(
      (m) => normalizeMacroName(m.name) == normalizeMacroName(name),
    );
    if (macros.length == before) return false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(kJarvisMacrosKey, encodeMacros(macros));
    return true;
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(kJarvisMacrosKey);
  }
}
