// Phase 6 (v1.1.0) — F20 NVIDIA NIM free-model fallback.
//
// Second [ChatProvider], behind the F18 interface. It speaks NVIDIA's
// hosted NIM API, which is OpenAI-compatible chat completions:
// POST https://integrate.api.nvidia.com/v1/chat/completions with a
// Bearer key from a free NVIDIA account (build.nvidia.com).
//
// Model verified 22 Nov 2026 against NVIDIA's public docs:
// build.nvidia.com/nvidia/nemotron-3-ultra-550b-a55b (free API, "point
// the OpenAI SDK at https://integrate.api.nvidia.com/v1 and call
// nvidia/nemotron-3-ultra-550b-a55b") and docs.api.nvidia.com (same
// endpoint). Defaults follow projecthellhound/JARVIS-Mobile's
// nvidia_api_service.dart (temp 0.5, top_p 0.9, max_tokens 4096) —
// pattern only, fresh implementation, no code copied.
//
// It triggers ONLY when Gemini fails with a transient error (429 /
// overload / timeout) after the existing retries, and ONLY when a free
// NVIDIA key has been entered in the connector hub (F19). Without a
// key it is never constructed, so nothing changes. No key in code/repo
// ever — the key is entered in-app and stored encrypted (F19).

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'chat_provider.dart';

/// The NVIDIA NIM hosted chat-completions endpoint (OpenAI-compatible).
const String kNvidiaNimEndpoint =
    'https://integrate.api.nvidia.com/v1/chat/completions';

/// The free hosted Nemotron model used as the fallback. Verified against
/// build.nvidia.com (see file header).
const String kNvidiaNimModel = 'nvidia/nemotron-3-ultra-550b-a55b';

/// Text deltas from one chunk of a NIM SSE response. Each `data: {...}`
/// line contributes `choices[0].delta.content`; `data: [DONE]`, empty
/// lines and malformed lines are skipped. A bare JSON object line
/// (non-SSE) is accepted too.
List<String> parseNimSseTextDeltas(String chunk) {
  final deltas = <String>[];
  for (final line in chunk.split('\n')) {
    final trimmed = line.trim();
    if (trimmed.isEmpty) continue;
    String? jsonText;
    if (trimmed.startsWith('data:')) {
      jsonText = trimmed.substring(5).trim();
      if (jsonText == '[DONE]') continue;
    } else if (trimmed.startsWith('{')) {
      jsonText = trimmed;
    } else {
      continue;
    }
    try {
      final decoded = jsonDecode(jsonText);
      final delta = nimChoiceText(decoded, streaming: true);
      if (delta.isNotEmpty) deltas.add(delta);
    } catch (_) {
      // Skip a malformed chunk; later chunks may still parse.
    }
  }
  return deltas;
}

/// The assistant text of a decoded NIM chat-completion body (or one SSE
/// event when [streaming] is true), or '' when there is none.
String nimChoiceText(Object? decoded, {bool streaming = false}) {
  if (decoded is! Map) return '';
  final choices = decoded['choices'];
  if (choices is! List || choices.isEmpty || choices.first is! Map) {
    return '';
  }
  final choice = choices.first as Map;
  final message = streaming ? choice['delta'] : choice['message'];
  if (message is! Map) return '';
  final content = message['content'];
  return content is String ? content : '';
}

class NvidiaNimChatProvider extends ChatProvider {
  NvidiaNimChatProvider({
    required this.apiKey,
    this.modelName = kNvidiaNimModel,
    String? systemInstruction,
    http.Client? httpClient,
  })  : systemInstruction = systemInstruction ?? '',
        _httpClient = httpClient ?? http.Client(),
        _ownsClient = httpClient == null;

  final String apiKey;
  final String modelName;

  /// System instruction sent as the first message. '' means none.
  final String systemInstruction;

  http.Client _httpClient;
  final bool _ownsClient;
  bool _disposed = false;

  @override
  String get name => 'NVIDIA NIM';

  @override
  bool get isFallback => true;

  /// Aborts any in-flight request (used by STOP). Only a client this
  /// object owns is closed — an injected test client is left alone.
  /// A fresh client is created so later requests still work.
  @override
  void cancel() {
    if (_disposed || !_ownsClient) return;
    try {
      _httpClient.close();
    } catch (_) {}
    _httpClient = http.Client();
  }

  List<Map<String, String>> _messages({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  }) {
    final system = mergeSystemInstruction(
      systemInstruction,
      extraSystemContext,
    ).trim();
    final messages = <Map<String, String>>[
      if (system.isNotEmpty) {'role': 'system', 'content': system},
      for (final turn in history)
        {
          'role': turn.role == 'model' ? 'assistant' : 'user',
          'content': turn.text,
        },
      {'role': 'user', 'content': message},
    ];
    return messages;
  }

  Map<String, Object> _requestBody({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
    required bool stream,
  }) =>
      <String, Object>{
        'model': modelName,
        'messages': _messages(
          message: message,
          history: history,
          extraSystemContext: extraSystemContext,
        ),
        'temperature': 0.5,
        'top_p': 0.9,
        'max_tokens': 4096,
        'stream': stream,
      };

  void _validateRequest(String message) {
    if (_disposed) {
      throw const ChatProviderException('NVIDIA NIM client is closed.');
    }
    if (apiKey.trim().isEmpty) {
      throw const ChatProviderException(
        'Add your free NVIDIA NIM API key in Connected apps & providers.',
      );
    }
    if (message.trim().isEmpty) {
      throw const ChatProviderException('Your message is empty.');
    }
  }

  Map<String, String> get _headers => <String, String>{
        'Content-Type': 'application/json; charset=utf-8',
        'Authorization': 'Bearer $apiKey',
      };

  ChatProviderException _errorFromBody(String body, int statusCode) {
    final decoded = _decodeJson(body);
    final error = decoded is Map ? decoded['error'] : null;
    final errorMessage = error is Map ? error['message'] : null;
    final text = errorMessage is String && errorMessage.trim().isNotEmpty
        ? errorMessage
        : 'NVIDIA NIM returned HTTP $statusCode.';
    return ChatProviderException(text, statusCode: statusCode);
  }

  @override
  Future<String> sendMessage({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  }) async {
    _validateRequest(message);

    late final http.Response response;
    try {
      response = await _httpClient
          .post(
            Uri.parse(kNvidiaNimEndpoint),
            headers: _headers,
            body: jsonEncode(_requestBody(
              message: message,
              history: history,
              extraSystemContext: extraSystemContext,
              stream: false,
            )),
          )
          .timeout(const Duration(seconds: 45));
    } on TimeoutException {
      throw const ChatProviderException(
        'NVIDIA NIM timed out. Check your connection and try again.',
      );
    } on http.ClientException {
      throw const ChatProviderException(
        'Could not connect to NVIDIA NIM. Check your internet connection.',
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw _errorFromBody(response.body, response.statusCode);
    }

    final answer = nimChoiceText(_decodeJson(response.body)).trim();
    if (answer.isEmpty) {
      throw const ChatProviderException(
        'NVIDIA NIM returned no readable text.',
      );
    }
    return answer;
  }

  @override
  Stream<String> sendMessageStream({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  }) async* {
    _validateRequest(message);

    late final http.StreamedResponse streamed;
    try {
      final request = http.Request('POST', Uri.parse(kNvidiaNimEndpoint))
        ..headers.addAll(_headers)
        ..body = jsonEncode(_requestBody(
          message: message,
          history: history,
          extraSystemContext: extraSystemContext,
          stream: true,
        ));
      streamed =
          await _httpClient.send(request).timeout(const Duration(seconds: 45));
    } on TimeoutException {
      throw const ChatProviderException(
        'NVIDIA NIM timed out. Check your connection and try again.',
      );
    } on http.ClientException {
      throw const ChatProviderException(
        'Could not connect to NVIDIA NIM. Check your internet connection.',
      );
    }

    if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
      final body = await streamed.stream.bytesToString();
      throw _errorFromBody(body, streamed.statusCode);
    }

    // Lines may split across network chunks, so carry the last partial
    // line into the next chunk before parsing.
    var carry = '';
    await for (final chunk in streamed.stream.transform(utf8.decoder)) {
      carry += chunk;
      final lines = carry.split('\n');
      carry = lines.removeLast();
      for (final delta in parseNimSseTextDeltas(lines.join('\n'))) {
        yield delta;
      }
    }
    if (carry.trim().isNotEmpty) {
      for (final delta in parseNimSseTextDeltas(carry)) {
        yield delta;
      }
    }
  }

  Object? _decodeJson(String body) {
    try {
      return jsonDecode(body);
    } on FormatException {
      return null;
    }
  }

  @override
  void dispose() {
    if (_disposed) return;
    _disposed = true;
    if (_ownsClient) _httpClient.close();
  }
}
