/// Pure parsers for the small set of local voice commands supported by Jarvis.

/// Returns a duration in seconds, or zero when the utterance contains no
/// recognized positive hour/minute/second component.
int parseTimerDurationSeconds(String utterance) {
  int readUnit(String pattern) {
    final match = RegExp(pattern, caseSensitive: false).firstMatch(utterance);
    return int.tryParse(match?.group(1) ?? '') ?? 0;
  }

  final hours = readUnit(r'(\d+)\s*(?:hours?|hrs?|h)\b');
  final minutes = readUnit(r'(\d+)\s*(?:minutes?|mins?|m)\b');
  final seconds = readUnit(r'(\d+)\s*(?:seconds?|secs?|s)\b');
  return hours * 3600 + minutes * 60 + seconds;
}

class AlarmTime {
  const AlarmTime({
    required this.hour12,
    required this.minute,
    required this.meridiem,
    required this.hour24,
  });

  final int hour12;
  final int minute;
  final String meridiem;
  final int hour24;
}

/// Parses 12-hour clock times such as "7 AM", "7:30 pm" or "12:05 a.m.".
/// Returns null for missing or invalid times.
AlarmTime? parseAlarmTime(String utterance) {
  final match = RegExp(
    r'\b(\d{1,2})(?::(\d{1,2}))?\s*(a\.?m\.?|p\.?m\.?)(?![a-z])',
    caseSensitive: false,
  ).firstMatch(utterance);
  if (match == null) return null;

  final hour12 = int.tryParse(match.group(1) ?? '');
  final minute = int.tryParse(match.group(2) ?? '0');
  final meridiem = (match.group(3) ?? '').toLowerCase().replaceAll('.', '');
  if (hour12 == null || minute == null || hour12 < 1 || hour12 > 12 || minute < 0 || minute > 59) {
    return null;
  }

  final hour24 = (hour12 % 12) + (meridiem == 'pm' ? 12 : 0);
  return AlarmTime(
    hour12: hour12,
    minute: minute,
    meridiem: meridiem,
    hour24: hour24,
  );
}
