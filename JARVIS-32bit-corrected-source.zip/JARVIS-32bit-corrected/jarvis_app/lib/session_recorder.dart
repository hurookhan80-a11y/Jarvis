import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

/// Session recording, debug only (F13, v1.1.0).
///
/// Off by default; the user turns it on in Settings (Debug section).
/// When on, one conversation session records the microphone to a WAV
/// file plus a text transcript, both in the app-private
/// `jarvis_sessions` folder. Files stay on the phone only — they are
/// never uploaded or sent anywhere.
///
/// The `record` package (v6.2.1, verified: minSdk 23, pure Kotlin
/// MediaRecorder, no native `.so`) does the audio. If audio recording
/// fails for any reason (permission denied, recorder error), the
/// session still records its transcript to a text file instead — the
/// debug value (what was said) is kept even when the audio is not.

/// One transcript line: `[HH:MM:SS] ROLE: text`.
String formatTranscriptLine(DateTime time, String role, String text) {
  final stamp =
      '${time.hour.toString().padLeft(2, '0')}:'
      '${time.minute.toString().padLeft(2, '0')}:'
      '${time.second.toString().padLeft(2, '0')}';
  return '[$stamp] ${role.toUpperCase()}: $text';
}

/// Thin seam over the audio recorder so tests can inject a fake.
abstract class SessionAudioRecorder {
  Future<bool> hasPermission();
  Future<void> start(String path);
  Future<String?> stop();
  Future<void> dispose();
}

/// The real recorder: `record` package, 16 kHz mono WAV.
class RecordSessionAudioRecorder implements SessionAudioRecorder {
  final AudioRecorder _recorder = AudioRecorder();

  @override
  Future<bool> hasPermission() => _recorder.hasPermission();

  @override
  Future<void> start(String path) => _recorder.start(
    const RecordConfig(
      encoder: AudioEncoder.wav,
      sampleRate: 16000,
      numChannels: 1,
    ),
    path: path,
  );

  @override
  Future<String?> stop() => _recorder.stop();

  @override
  Future<void> dispose() => _recorder.dispose();
}

/// Records one session: microphone audio (WAV) + transcript (text).
class SessionRecorder {
  SessionRecorder({
    SessionAudioRecorder? audioRecorder,
    this._directoryOverride,
  }) : _audioRecorder = audioRecorder ?? RecordSessionAudioRecorder();

  final SessionAudioRecorder _audioRecorder;
  final Directory? _directoryOverride;

  bool _active = false;
  bool _audioFailed = false;
  DateTime? _startedAt;
  String? _audioPath;
  String? _transcriptPath;
  String? _lastAudioPath;
  String? _lastTranscriptPath;
  final List<String> _transcript = <String>[];

  /// True while a session is being recorded (audio or transcript-only).
  bool get isRecording => _active;

  /// True when audio recording failed and this session is transcript-only.
  bool get audioFailed => _audioFailed;

  /// WAV file of the last finished session, or null.
  String? get lastAudioPath => _lastAudioPath;

  /// Transcript file of the last finished session, or null.
  String? get lastTranscriptPath => _lastTranscriptPath;

  /// Starts a session. Returns true when recording (audio or, on audio
  /// failure, transcript-only). Never throws.
  Future<bool> startSession() async {
    if (_active) return true;
    _startedAt = DateTime.now();
    _transcript.clear();
    _audioFailed = false;
    _lastAudioPath = null;
    _lastTranscriptPath = null;
    _audioPath = null;
    _transcriptPath = null;
    try {
      final dir = await _sessionsDir();
      final stamp = _fileStamp(_startedAt!);
      _audioPath = '${dir.path}/session_$stamp.wav';
      _transcriptPath = '${dir.path}/session_$stamp.txt';
    } catch (_) {
      // No usable folder: keep the transcript in memory only.
    }
    if (_audioPath != null) {
      try {
        final allowed = await _audioRecorder.hasPermission();
        if (!allowed) throw StateError('Microphone permission not granted.');
        await _audioRecorder.start(_audioPath!);
      } catch (_) {
        // Transcript-only fallback: the debug value survives.
        _audioFailed = true;
      }
    } else {
      _audioFailed = true;
    }
    _active = true;
    return true;
  }

  /// Adds one line to the running session's transcript. No-op when no
  /// session is recording.
  void addTranscript(String role, String text) {
    if (!_active || text.trim().isEmpty) return;
    _transcript.add(formatTranscriptLine(DateTime.now(), role, text));
  }

  /// Stops the session and writes the transcript file. Never throws.
  Future<void> stopSession() async {
    if (!_active) return;
    _active = false;
    String? audioPath;
    try {
      audioPath = await _audioRecorder.stop();
    } catch (_) {
      audioPath = null;
    }
    _lastAudioPath = audioPath ?? (_audioFailed ? null : _audioPath);
    if (_transcriptPath != null) {
      try {
        final file = File(_transcriptPath!);
        await file.writeAsString(
          _transcript.isEmpty ? '' : '${_transcript.join('\n')}\n',
        );
        _lastTranscriptPath = _transcriptPath;
      } catch (_) {
        _lastTranscriptPath = null;
      }
    }
    _transcript.clear();
  }

  Future<void> dispose() async {
    if (_active) await stopSession();
    try {
      await _audioRecorder.dispose();
    } catch (_) {}
  }

  String _fileStamp(DateTime time) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${time.year}${two(time.month)}${two(time.day)}_'
        '${two(time.hour)}${two(time.minute)}${two(time.second)}';
  }

  Future<Directory> _sessionsDir() async {
    if (_directoryOverride != null) return _directoryOverride;
    try {
      final docs = await getApplicationDocumentsDirectory();
      final dir = Directory('${docs.path}/jarvis_sessions');
      if (!await dir.exists()) await dir.create(recursive: true);
      return dir;
    } catch (_) {
      final dir = Directory('${Directory.systemTemp.path}/jarvis_sessions');
      if (!await dir.exists()) await dir.create(recursive: true);
      return dir;
    }
  }
}
