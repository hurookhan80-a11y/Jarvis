import 'dart:async';

import 'package:wake_word_flutter/wake_word_flutter.dart';

/// Phase 5 (v1.1.0): offline "Hey Jarvis" wake word (F14) + barge-in and
/// follow-up listening (F16).
///
/// F14 — the wake word is detected fully on-device by openWakeWord
/// (Apache-2.0 code; see below) through the `wake_word_flutter` plugin:
/// a shared melspectrogram + speech-embedding feature extractor (bundled
/// with the plugin) plus one small classifier model for "Hey Jarvis".
/// No network, no account, no key. The classifier is openWakeWord's own
/// pre-trained `hey_jarvis_v0.1.tflite` (release v0.5.1, 1,278,912 bytes),
/// licensed CC BY-NC-SA 4.0 (non-commercial) — fine for this personal,
/// non-commercial app. Its input tensor is [1, 16, 96] (verified by
/// parsing the model file at build time), which is exactly the shape the
/// plugin's feature extractor produces.
///
/// Build-time verification (22 Nov 2026, see the release notes): both
/// native engines the plugin pulls in ship armeabi-v7a `.so` files —
/// `onnxruntime-android:1.28.0` (`jni/armeabi-v7a/libonnxruntime.so`,
/// 20,388,560 bytes) and LiteRT `1.4.0`
/// (`jni/armeabi-v7a/libtensorflowlite_jni.so`, 2,867,532 bytes).
/// That is what makes this shippable on the 32-bit phone. Size cost:
/// ~24 MB of native libs in the APK (ONNX Runtime dominates).
///
/// F15 — Porcupine is NOT built (F14 passed verification). The
/// [WakeWordEngine] interface below is the seam a Porcupine engine would
/// plug into later: same wake interface, so the rest of the app would
/// not care which engine is underneath. No Porcupine code, key, or
/// dependency ships in this release.
///
/// The speech_to_text wake-word path stays as the fallback: when the
/// offline engine is unavailable (model failed to load, mic denied) the
/// app listens for "Hey Jarvis" through the system recogniser exactly
/// as before. The two listeners are never run at the same time — the
/// offline engine owns the mic while idle/speaking, the system
/// recogniser owns it while a conversation is being listened to.

/// Asset key of the bundled "Hey Jarvis" classifier model.
const String kWakeWordModelAsset =
    'assets/models/hey_jarvis_v0.1.tflite';

/// Classifier score (0-1) above which a frame counts as "Hey Jarvis".
/// The plugin default (0.5). Jarvis's own spoken answers essentially
/// never contain the phrase, so no higher threshold is used while
/// speaking — barge-in must stay easy to trigger.
const double kWakeWordThreshold = 0.5;

/// How long after an answer finishes Jarvis keeps listening for a
/// follow-up before going idle (F16).
const Duration kFollowUpWindow = Duration(seconds: 8);

/// Phases of the wake-word / conversation flow, as seen by the wake-word
/// state machine. This is the single source of truth for "what should a
/// wake-word detection do right now" — the UI code asks the machine
/// instead of re-deriving it from scattered flags.
enum WakeWordPhase {
  /// Waiting for "Hey Jarvis" (offline engine or system recogniser).
  idle,

  /// In a conversation, listening for a command (system recogniser).
  listening,

  /// Speaking an answer (or the greeting).
  speaking,

  /// An answer just finished; listening for a follow-up until the
  /// [kFollowUpWindow] timer expires.
  followUp,
}

/// What the app should do in response to a wake-word event.
enum WakeWordAction {
  /// Ignore the event.
  none,

  /// Enter conversation mode (fresh wake-up).
  enterConversation,

  /// Stop the speech in flight and listen for the new command (barge-in).
  bargeIn,

  /// The follow-up window expired with no command: end the conversation.
  endConversation,
}

/// Pure-Dart state machine for the wake-word flow (F14/F16). No Flutter
/// or plugin calls, so it is fully unit-testable.
///
/// The one subtle rule: a greeting is speech, but it is not an answer —
/// [onSpeechStarted] from [WakeWordPhase.idle] (a one-off message, or a
/// greeting spoken before the machine heard about the wake-up) leaves
/// the phase at idle, so a wake word during it still wakes normally
/// instead of being swallowed as a barge-in.
class WakeWordStateMachine {
  WakeWordStateMachine({this.bargeInEnabled = true});

  /// Whether saying the wake word while Jarvis speaks interrupts it.
  /// Wired to the "Barge-in" Settings toggle.
  bool bargeInEnabled;

  WakeWordPhase _phase = WakeWordPhase.idle;

  WakeWordPhase get phase => _phase;

  /// A wake word was detected. Returns what the app should do.
  WakeWordAction onWakeWord() {
    switch (_phase) {
      case WakeWordPhase.idle:
        _phase = WakeWordPhase.listening;
        return WakeWordAction.enterConversation;
      case WakeWordPhase.speaking:
        if (!bargeInEnabled) return WakeWordAction.none;
        _phase = WakeWordPhase.listening;
        return WakeWordAction.bargeIn;
      case WakeWordPhase.listening:
      case WakeWordPhase.followUp:
        // Already listening for a command; the system recogniser hears
        // it directly, so the wake word itself needs no action.
        return WakeWordAction.none;
    }
  }

  /// Jarvis started speaking an answer (or the greeting).
  void onSpeechStarted() {
    switch (_phase) {
      case WakeWordPhase.listening:
      case WakeWordPhase.followUp:
        _phase = WakeWordPhase.speaking;
      case WakeWordPhase.idle:
      case WakeWordPhase.speaking:
        break;
    }
  }

  /// Jarvis finished speaking.
  void onSpeechEnded() {
    if (_phase == WakeWordPhase.speaking) {
      _phase = WakeWordPhase.followUp;
    }
  }

  /// The user spoke a command (system recogniser final result).
  void onCommandHeard() {
    if (_phase == WakeWordPhase.followUp) {
      _phase = WakeWordPhase.listening;
    }
  }

  /// The follow-up window expired. Returns what the app should do.
  WakeWordAction onFollowUpExpired() {
    if (_phase == WakeWordPhase.followUp) {
      _phase = WakeWordPhase.idle;
      return WakeWordAction.endConversation;
    }
    return WakeWordAction.none;
  }

  /// STOP was pressed (button, orb tap, or voice "stop").
  void onStopPressed() {
    switch (_phase) {
      case WakeWordPhase.speaking:
      case WakeWordPhase.listening:
        // After STOP the user usually wants to say something else: stay
        // in the follow-up window instead of going idle at once.
        _phase = WakeWordPhase.followUp;
      case WakeWordPhase.idle:
      case WakeWordPhase.followUp:
        break;
    }
  }

  /// A conversation started (wake word, orb, or home-screen widget).
  void onConversationStarted() {
    _phase = WakeWordPhase.listening;
  }

  /// Back to idle (conversation ended).
  void reset() {
    _phase = WakeWordPhase.idle;
  }
}

/// One wake-word engine behind a common interface, so the app does not
/// care whether "Hey Jarvis" is heard by openWakeWord (F14), Porcupine
/// (F15, not built), or anything else that implements this contract.
abstract class WakeWordEngine {
  /// Loads the engine's models. True when the engine can listen.
  /// Safe to call repeatedly; a failed load may be retried.
  Future<bool> ensureReady();

  /// Starts microphone capture. False when the mic is unavailable
  /// (permission denied) — the caller then falls back to the system
  /// recogniser.
  Future<bool> start();

  /// Stops microphone capture, keeping the models loaded.
  Future<void> stop();

  /// Releases the microphone, models, and detection stream.
  Future<void> dispose();

  /// True when the models loaded and the engine can listen.
  bool get isAvailable;

  /// True while microphone capture is running.
  bool get isRunning;

  /// Fires once per detected wake word.
  Stream<void> get detections;
}

/// openWakeWord engine (F14) via the `wake_word_flutter` plugin.
class OpenWakeWordEngine implements WakeWordEngine {
  WakeWordDetector? _detector;
  StreamSubscription<WakeWordDetection>? _subscription;
  final StreamController<void> _detections =
      StreamController<void>.broadcast();
  bool _available = false;

  @override
  bool get isAvailable => _available;

  @override
  bool get isRunning => _detector?.isRunning ?? false;

  @override
  Stream<void> get detections => _detections.stream;

  @override
  Future<bool> ensureReady() async {
    if (_detector != null) return true;
    try {
      _detector = await WakeWordDetector.loadFromAsset(
        kWakeWordModelAsset,
        threshold: kWakeWordThreshold,
      );
      _subscription =
          _detector!.detections.listen((_) => _detections.add(null));
      _available = true;
      return true;
    } catch (_) {
      // Model missing, ONNX/TFLite native lib failed to load, or the
      // asset bundle has no model: the app falls back to the system
      // recogniser and never errors on the user.
      _available = false;
      return false;
    }
  }

  @override
  Future<bool> start() async {
    if (!await ensureReady()) return false;
    try {
      return await _detector!.start();
    } catch (_) {
      return false;
    }
  }

  @override
  Future<void> stop() async {
    try {
      await _detector?.stop();
    } catch (_) {}
  }

  @override
  Future<void> dispose() async {
    await _subscription?.cancel();
    try {
      await _detector?.dispose();
    } catch (_) {}
    await _detections.close();
  }
}

/// Owns the active wake-word engine. The engine is created lazily by
/// [ensureReady] so a phone that never uses the wake word never pays
/// the model-load cost; the factory is injectable so tests can supply
/// a fake engine.
class WakeWordService {
  WakeWordService({WakeWordEngine Function()? engineFactory})
      : _engineFactory = engineFactory ?? OpenWakeWordEngine.new;

  final WakeWordEngine Function() _engineFactory;
  WakeWordEngine? _engine;

  /// True when the engine's models loaded and it can listen.
  bool get isAvailable => _engine?.isAvailable ?? false;

  /// True while microphone capture is running.
  bool get isRunning => _engine?.isRunning ?? false;

  /// Fires once per detected wake word.
  Stream<void> get detections =>
      _engine?.detections ?? const Stream<void>.empty();

  /// Loads the engine. True when it can listen; false leaves the app
  /// on the system-recogniser fallback.
  Future<bool> ensureReady() async {
    _engine ??= _engineFactory();
    return _engine!.ensureReady();
  }

  /// Starts listening. False when the mic is unavailable.
  Future<bool> start() async {
    if (!await ensureReady()) return false;
    return _engine!.start();
  }

  /// Stops listening, keeping the models loaded for a fast restart.
  Future<void> stop() async {
    await _engine?.stop();
  }

  /// Releases everything. The service cannot be used after this.
  Future<void> dispose() async {
    await _engine?.dispose();
    _engine = null;
  }
}
