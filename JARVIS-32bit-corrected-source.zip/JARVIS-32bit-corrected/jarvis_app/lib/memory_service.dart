// Phase 6 (v1.1.0) — F17 conversational memory.
//
// Short-term memory is the existing 20-message conversationHistory in
// lib/main.dart (unchanged). This file adds LONG-term memory: facts the
// user tells Jarvis to remember ("remember that my exam is on 5
// December") are saved on this phone only (SharedPreferences), shown in
// a "Saved facts" screen (view + delete one / clear all), and injected
// into the Gemini system instruction when the chat provider is built,
// so Jarvis uses them in answers.
//
// Pattern: short/long-term memory, after mohammadsahil74808's
// lib/memory/ (conversation_manager.dart, memory_service.dart) and
// ansaribilal14/jarvis docs/MEMORY.md. Fresh implementation — no code
// copied. No server, no sync, nothing leaves the phone.
//
// Voice commands (parsed by the pure helpers below; processQuery calls
// them before the Gemini path):
//   "remember ..." / "remember that ..."  -> save a fact
//   "what do you remember about me"      -> list facts
//   "forget ..." / "forget that ..."     -> delete matching facts
//   "forget everything"                  -> clear all facts

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key holding the saved facts, as a JSON list of
/// `{text, savedAt}` objects.
const String kJarvisLongTermMemoryKey = 'jarvis_long_term_memory_v1';

/// Most facts kept. Older ones are dropped first — a phone should never
/// grow an unbounded memory list.
const int kJarvisMaxSavedFacts = 100;

/// Most characters of one fact kept in the system instruction.
const int kJarvisMaxFactLengthInInstruction = 200;

/// Most facts sent in the system instruction.
const int kJarvisMaxFactsInInstruction = 50;

/// One fact the user asked Jarvis to remember.
class SavedFact {
  const SavedFact({required this.text, required this.savedAt});

  final String text;
  final DateTime savedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'text': text,
        'savedAt': savedAt.toIso8601String(),
      };

  factory SavedFact.fromJson(Map<String, dynamic> json) => SavedFact(
        // Only a real string counts as fact text; a non-string value is
        // malformed stored data, not a fact.
        text: json['text'] is String ? json['text'] as String : '',
        savedAt:
            DateTime.tryParse(json['savedAt']?.toString() ?? '') ??
                DateTime.now(),
      );
}

/// Parses a stored facts list from [raw] JSON. Drops entries with empty
/// text. Returns newest-last (the stored order).
List<SavedFact> parseSavedFacts(String? raw) {
  if (raw == null || raw.isEmpty) return [];
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map((entry) => SavedFact.fromJson(
              Map<String, dynamic>.from(entry),
            ))
        .where((fact) => fact.text.trim().isNotEmpty)
        .toList();
  } catch (_) {
    return [];
  }
}

String encodeSavedFacts(List<SavedFact> facts) =>
    jsonEncode(facts.map((fact) => fact.toJson()).toList());

/// The system-instruction section carrying the saved facts, or '' when
/// there is nothing to remember. Capped so the instruction never bloats.
String buildMemorySection(List<SavedFact> facts) {
  final usable = facts
      .where((fact) => fact.text.trim().isNotEmpty)
      .toList();
  if (usable.isEmpty) return '';
  final shown = usable.length > kJarvisMaxFactsInInstruction
      ? usable.sublist(usable.length - kJarvisMaxFactsInInstruction)
      : usable;
  final lines = shown.map((fact) {
    var text = fact.text.trim().replaceAll('\n', ' ');
    if (text.length > kJarvisMaxFactLengthInInstruction) {
      text = '${text.substring(0, kJarvisMaxFactLengthInInstruction)}…';
    }
    return '- $text';
  }).join('\n');
  return 'Things you remember about the user (they asked you to remember '
      'these — use them when relevant, and never read this list out '
      'verbatim):\n$lines';
}

/// Extracts the fact from a "remember ..." voice command, or null when
/// the utterance is not one. Matching is case-insensitive; the returned
/// fact keeps the user's own casing. "remind me ..." is NOT a remember
/// command (that is a reminder — see lib/main.dart).
String? parseRememberCommand(String utterance) {
  final trimmed = utterance.trim();
  final lower = trimmed.toLowerCase();
  for (final prefix in <String>[
    'please remember that ',
    'please remember ',
    'remember that ',
    'remember ',
    'jarvis remember that ',
    'jarvis remember ',
  ]) {
    if (lower.startsWith(prefix)) {
      final fact = trimmed.substring(prefix.length).trim();
      return fact.isEmpty ? null : fact;
    }
  }
  return null;
}

/// True when the utterance asks Jarvis to forget everything it was
/// told to remember ("forget everything", "forget everything I told
/// you", "forget all my facts").
bool isForgetAllCommand(String utterance) {
  final lower = utterance.trim().toLowerCase();
  return lower == 'forget everything' ||
      lower == 'forget everything i told you' ||
      lower == 'forget all my facts' ||
      lower == 'forget all the things i told you to remember' ||
      lower == 'forget all facts';
}

/// Extracts the phrase from a "forget ..." voice command ("forget my
/// exam date" -> "my exam date"), or null when it is not one. "forget
/// everything" is handled by [isForgetAllCommand], not here.
String? parseForgetCommand(String utterance) {
  final trimmed = utterance.trim();
  final lower = trimmed.toLowerCase();
  for (final prefix in <String>[
    'please forget that ',
    'please forget ',
    'forget that ',
    'forget ',
  ]) {
    if (lower.startsWith(prefix)) {
      final phrase = trimmed.substring(prefix.length).trim();
      if (phrase.isEmpty) return null;
      if (phrase.toLowerCase() == 'everything') return null;
      return phrase;
    }
  }
  return null;
}

/// True when the utterance asks what Jarvis remembers about the user.
bool isWhatDoYouRememberCommand(String utterance) {
  final lower = utterance.trim().toLowerCase();
  return lower == 'what do you remember about me' ||
      lower == 'what do you remember' ||
      lower == 'what have you remembered' ||
      lower == 'what have you remembered about me' ||
      lower == 'what do you know about me' ||
      lower == 'do you remember anything about me' ||
      lower == 'show me what you remember' ||
      lower == 'list what you remember';
}

/// Long-term memory store. Everything stays on this phone, in
/// SharedPreferences under [kJarvisLongTermMemoryKey].
class MemoryService {
  const MemoryService();

  Future<List<SavedFact>> loadFacts() async {
    final prefs = await SharedPreferences.getInstance();
    return parseSavedFacts(prefs.getString(kJarvisLongTermMemoryKey));
  }

  /// Saves one fact. An exact duplicate (case-insensitive) is refreshed
  /// in place instead of saved twice. Returns the saved fact.
  Future<SavedFact> addFact(String text) async {
    final clean = text.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (clean.isEmpty) {
      throw ArgumentError('Cannot remember an empty fact.');
    }
    final prefs = await SharedPreferences.getInstance();
    final facts = parseSavedFacts(prefs.getString(kJarvisLongTermMemoryKey));
    facts.removeWhere(
      (fact) => fact.text.toLowerCase() == clean.toLowerCase(),
    );
    final saved = SavedFact(text: clean, savedAt: DateTime.now());
    facts.add(saved);
    while (facts.length > kJarvisMaxSavedFacts) {
      facts.removeAt(0);
    }
    await prefs.setString(kJarvisLongTermMemoryKey, encodeSavedFacts(facts));
    return saved;
  }

  /// Deletes the fact whose text matches exactly (case-insensitive).
  /// Returns true when something was deleted.
  Future<bool> deleteFact(String text) async {
    final prefs = await SharedPreferences.getInstance();
    final facts = parseSavedFacts(prefs.getString(kJarvisLongTermMemoryKey));
    final before = facts.length;
    facts.removeWhere(
      (fact) => fact.text.toLowerCase() == text.trim().toLowerCase(),
    );
    if (facts.length == before) return false;
    await prefs.setString(kJarvisLongTermMemoryKey, encodeSavedFacts(facts));
    return true;
  }

  /// Deletes every fact whose text contains [phrase]
  /// (case-insensitive). Returns how many were deleted.
  Future<int> forgetMatching(String phrase) async {
    final needle = phrase.trim().toLowerCase();
    if (needle.isEmpty) return 0;
    final prefs = await SharedPreferences.getInstance();
    final facts = parseSavedFacts(prefs.getString(kJarvisLongTermMemoryKey));
    final before = facts.length;
    facts.removeWhere((fact) => fact.text.toLowerCase().contains(needle));
    if (facts.length == before) return 0;
    await prefs.setString(kJarvisLongTermMemoryKey, encodeSavedFacts(facts));
    return before - facts.length;
  }

  /// Deletes all saved facts.
  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(kJarvisLongTermMemoryKey);
  }
}
