// Phase 7 (v1.1.0) — F38 local worker: Dart-side tool routing.
//
// A small router in front of processQuery (lib/main.dart). Simple,
// tool-like requests are matched here and handled by the existing
// local handlers WITHOUT calling Gemini first (saves a round trip —
// and for time/date it needs no network at all). Anything this router
// does not recognise falls through to Gemini.
//
// Pattern: the DIRECT fast path idea from ansaribilal14/jarvis
// docs/AGENT_ENGINE.md and mokshith7777/Jarvis-android-
// lib/services/local_worker_service.dart (Dart-side part only; the
// Termux companion is SKIP — see S1). Fresh implementation — no code
// copied. No new dependency, no server.
//
// The router only CLASSIFIES; the handlers live in lib/main.dart
// (and the F33–F37 services), so the matching here must stay in step
// with the branches in processQuery. The pure classifier is
// unit-tested directly (test/phase7b_test.dart).

import 'commute_service.dart';
import 'form_draft_service.dart';
import 'macro_service.dart';
import 'message_draft_service.dart';
import 'multi_task_service.dart';
import 'shizuku_service.dart';

/// Where one utterance goes.
enum LocalRoute {
  /// "what time is it" — answered instantly, no network.
  time,

  /// "what is the date today" — answered instantly, no network.
  date,

  /// "weather" — opens the browser weather search (existing path).
  weather,

  /// Timer / alarm commands.
  timer,
  alarm,

  /// "call Ami".
  call,

  /// "remind me ...".
  reminder,

  /// "open WhatsApp".
  openApp,

  /// "spent 500 on groceries" / "show my expenses".
  finance,

  /// "what is on my calendar today".
  calendar,

  /// "any important mail?"
  mail,

  /// Remember / forget / "what do you remember".
  memory,

  /// Lock, flashlight, volume, Wi-Fi/Bluetooth/display settings,
  /// "code black".
  deviceControl,

  /// F33 macro commands ("record macro ...", "run ... routine").
  macro,

  /// F34 message drafting ("message Ami that ...").
  messageDraft,

  /// F35 voice-guided form drafting ("help me fill a leave application").
  formDraft,

  /// F36 multi-task queue ("do these three things: ...", "open
  /// WhatsApp and remind me at 7").
  multiTask,

  /// F37 commute ("how long to Faisalabad Medical University?").
  commute,

  /// F39 Shizuku controls ("force stop WhatsApp").
  shizuku,

  /// A local command the router recognises as local but whose handler
  /// lives further down processQuery's branch chain (e.g. Roman Urdu
  /// commands). The router says "local", the chain handles it.
  localOther,

  /// Nothing local matches — send it to Gemini.
  gemini,
}

/// Classifies a lower-cased, trimmed utterance. Pure — no I/O, so it
/// is cheap to call on every query and easy to unit-test.
LocalRoute classifyCommand(String normalized) {
  final text = normalized.trim().toLowerCase();
  if (text.isEmpty) return LocalRoute.gemini;

  // F36 first: a compound command must be split before any single
  // branch sees its first half.
  if (splitCompoundSteps(text) != null) return LocalRoute.multiTask;
  // F33 macro commands.
  if (parseMacroRunName(text) != null ||
      parseMacroRecordName(text) != null ||
      text == 'record macro' ||
      text == 'start recording macro' ||
      text == 'stop recording macro' ||
      text == 'stop recording' ||
      text == 'cancel recording' ||
      text == 'show my macros' ||
      text == 'list macros' ||
      parseMacroDeleteName(text) != null) {
    return LocalRoute.macro;
  }
  // F34 message drafting.
  if (parseMessageDraft(text) != null) return LocalRoute.messageDraft;
  // F35 form drafting.
  if (parseFormStart(text) != null) return LocalRoute.formDraft;
  // F37 commute.
  if (parseCommuteDestination(text) != null) return LocalRoute.commute;
  // F39 Shizuku controls.
  if (parseShizukuCommand(text) != null) return LocalRoute.shizuku;

  // Instant answers — no network, no Gemini.
  if (RegExp(r'\b(time|what time|current time|tell me the time|time now)\b')
      .hasMatch(text)) {
    return LocalRoute.time;
  }
  if (RegExp(r'\b(what.*date|today.*date|date today|what day is it)\b')
      .hasMatch(text)) {
    return LocalRoute.date;
  }
  if (RegExp(r'\b(weather|forecast)\b').hasMatch(text)) {
    return LocalRoute.weather;
  }
  if (text.contains('set timer') ||
      text.contains('start timer') ||
      text.contains('timer for') ||
      text.contains('cancel timer') ||
      text.contains('stop timer')) {
    return LocalRoute.timer;
  }
  if (text.contains('set alarm') || text.contains('alarm for')) {
    return LocalRoute.alarm;
  }
  if (text.contains('flashlight') ||
      text.contains('torch') ||
      text.contains('volume') ||
      text == 'mute' ||
      text == 'lock phone' ||
      text == 'lock my phone' ||
      text == 'lock the phone' ||
      text == 'unlock phone' ||
      text == 'unlock my phone' ||
      text == 'code black' ||
      text.contains('wifi settings') ||
      text.contains('wi-fi settings') ||
      text.contains('bluetooth settings') ||
      text.contains('display settings') ||
      text.contains('brightness settings')) {
    return LocalRoute.deviceControl;
  }
  if (text.contains('remind') ||
      text.contains('reminder') ||
      text.contains('yaad dilao') ||
      text.contains('yaad dila do') ||
      text == 'cancel reminder' ||
      text == 'cancel all reminders') {
    return LocalRoute.reminder;
  }
  if (isCallCommandText(text)) return LocalRoute.call;
  if (parseExpenseText(text) != null ||
      text.contains('my expenses') ||
      text.contains('show expenses') ||
      text == 'finance' ||
      text.contains('how much did i spend')) {
    return LocalRoute.finance;
  }
  if (text.contains('calendar') ||
      text.contains('my events today') ||
      text.contains('what is on today')) {
    return LocalRoute.calendar;
  }
  if (text.contains('important mail') ||
      text.contains('any mail') ||
      text.contains('check my email') ||
      text.contains('check my mail')) {
    return LocalRoute.mail;
  }
  if (parseRememberText(text) != null ||
      isForgetAllText(text) ||
      parseForgetText(text) != null ||
      isWhatDoYouRememberText(text)) {
    return LocalRoute.memory;
  }
  if (text.startsWith('open ')) return LocalRoute.openApp;
  // Roman Urdu open/call/lock phrases are handled by _tryUrduCommand
  // in main.dart — local, but not classified further here.
  if (text.contains('kholo') ||
      text.contains('khol do') ||
      text.contains('lock karo') ||
      text.contains('call karo')) {
    return LocalRoute.localOther;
  }
  return LocalRoute.gemini;
}

/// True when the utterance is handled locally (anything but Gemini).
bool isLocalCommand(String normalized) =>
    classifyCommand(normalized) != LocalRoute.gemini;

// ---- Lightweight local mirrors of the parsers in the other Phase 7b
// files, so this file stays dependency-free and the router can be
// tested on its own. The real parsers live in their own files and
// are the ones processQuery calls; these mirrors only answer
// "does this look like that kind of command?" and must use the same
// trigger words.

bool isCallCommandText(String text) {
  return text.startsWith('call ') ||
      text.contains('call karo') ||
      text.contains('call kar do') ||
      text.contains('call karna');
}

/// "spent 500 on groceries" — amount check only; the real parse is in
/// lib/finance_service.dart (parseExpenseCommand).
String? parseExpenseText(String text) {
  final match = RegExp(
    r'\b(?:spent|spend|paid|pay|bought|buy|kharcha)\b[^0-9]*?(?:rs\.?|pkr|rupees?)?\s*([\d,]+(?:\.\d{1,2})?)',
  ).firstMatch(text);
  if (match == null) return null;
  final amount =
      double.tryParse((match.group(1) ?? '').replaceAll(',', ''));
  if (amount == null || amount <= 0) return null;
  return match.group(0);
}

String? parseRememberText(String text) {
  for (final prefix in <String>[
    'please remember that ',
    'please remember ',
    'remember that ',
    'remember ',
  ]) {
    if (text.startsWith(prefix) && text.substring(prefix.length).trim().isNotEmpty) {
      return text.substring(prefix.length).trim();
    }
  }
  return null;
}

bool isForgetAllText(String text) =>
    text.startsWith('forget everything') || text == 'forget all';

String? parseForgetText(String text) {
  for (final prefix in <String>['please forget ', 'forget that ', 'forget ']) {
    if (text.startsWith(prefix) && text.substring(prefix.length).trim().isNotEmpty) {
      final rest = text.substring(prefix.length).trim();
      if (rest == 'everything' || rest == 'all') return null;
      return rest;
    }
  }
  return null;
}

bool isWhatDoYouRememberText(String text) =>
    text.contains('what do you remember') ||
    text.contains('what have you remembered');
