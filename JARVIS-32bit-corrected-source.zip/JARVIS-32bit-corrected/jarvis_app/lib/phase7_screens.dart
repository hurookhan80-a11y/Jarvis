// Phase 7 (v1.1.0) — screens for F26/F27/F28/F29/F30/F31.
//
//   CodeBlackScreen  — F26: one tap locks the phone (device admin).
//   CalendarScreen   — F27: today's events + announce switch.
//   GmailTriageScreen — F28: unread mail, read-only; disabled state
//                      until a Gmail access token is pasted.
//   FinanceScreen    — F29: expenses, totals, optional SMS import.
//   NetworkScreen    — F30: own Wi-Fi + devices on the network.
//   TelemetryScreen  — F31: battery + today's most-used apps.
//
// All data stays on this phone. The screens take their services as
// constructor arguments so the home screen stays the only place that
// wires them together.

import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';

import 'calendar_service.dart';
import 'finance_service.dart';
import 'gmail_service.dart';
import 'network_audit.dart';
import 'telemetry_service.dart';

const _screenBackground = Colors.black;
const _screenAccent = Colors.cyan;

Future<bool> _confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'Clear all',
}) async {
  final confirm = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      backgroundColor: Colors.grey[900],
      title: Text(title, style: const TextStyle(color: Colors.white)),
      content:
          Text(message, style: const TextStyle(color: Colors.white70)),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('Cancel',
              style: TextStyle(color: Colors.white70)),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(true),
          child: Text(confirmLabel,
              style: const TextStyle(color: Colors.redAccent)),
        ),
      ],
    ),
  );
  return confirm == true;
}

Widget _emptyNote(String text) => Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.grey),
        ),
      ),
    );

/// F26: Code Black. One tap locks the phone (the existing device-admin
/// force-lock path). Nothing else happens — no wipe, no silent action.
/// The screen stays visible when locking is not possible yet (device
/// admin not active), so the user can enable it and try again.
class CodeBlackScreen extends StatefulWidget {
  const CodeBlackScreen({super.key, required this.onLock});

  /// Locks the phone (the home screen's _lockPhone, which also handles
  /// the device-admin setup flow).
  final Future<void> Function() onLock;

  @override
  State<CodeBlackScreen> createState() => _CodeBlackScreenState();
}

class _CodeBlackScreenState extends State<CodeBlackScreen> {
  bool _locking = false;
  String? _note;

  Future<void> _lock() async {
    setState(() {
      _locking = true;
      _note = null;
    });
    try {
      await widget.onLock();
      if (mounted) {
        setState(() {
          _note = 'Lock requested. If the screen is still on, device '
              'admin is not active yet — the setup will open.';
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => _note = 'Could not lock the phone.');
      }
    } finally {
      if (mounted) setState(() => _locking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Code Black'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.redAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.security, color: Colors.redAccent, size: 72),
            const SizedBox(height: 24),
            const Text(
              'Code Black locks this phone immediately.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
            const SizedBox(height: 8),
            const Text(
              'Nothing else happens — no data is wiped, nothing is '
              'sent anywhere. Unlock it yourself with your PIN, '
              'pattern or fingerprint.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _locking ? null : _lock,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 18),
              ),
              child: Text(
                _locking ? 'Locking…' : 'LOCK PHONE NOW',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            if (_note != null) ...[
              const SizedBox(height: 16),
              Text(
                _note!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// F27: today's calendar events, read-only, plus the announce switch
/// (default OFF): when on, each upcoming event gets a reminder 15
/// minutes before it starts, through the durable reminder system.
class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key, required this.calendarService});

  final CalendarService calendarService;

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  List<CalendarEvent> _events = [];
  bool _loading = true;
  bool _announce = false;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final announce = await widget.calendarService.isAnnounceEnabled();
    final events = await widget.calendarService.getTodayEvents();
    if (!mounted) return;
    setState(() {
      _events = events;
      _announce = announce;
      _loading = false;
    });
    if (announce) {
      await widget.calendarService.scheduleAnnouncements(events);
    }
  }

  Future<void> _grantCalendar() async {
    await Permission.calendarFullAccess.request();
    _reload();
  }

  Future<void> _toggleAnnounce(bool value) async {
    await widget.calendarService.setAnnounceEnabled(value);
    if (value) {
      await widget.calendarService.scheduleAnnouncements(_events);
    }
    if (mounted) setState(() => _announce = value);
  }

  @override
  Widget build(BuildContext context) {
    final today = DateFormat.yMMMMd().format(DateTime.now());
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Calendar — today'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : Column(
              children: [
                SwitchListTile(
                  value: _announce,
                  activeThumbColor: _screenAccent,
                  title: const Text(
                    'Announce events as reminders',
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),
                  subtitle: const Text(
                    'A reminder 15 minutes before each event, even if the app is closed. Off by default.',
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                  onChanged: _toggleAnnounce,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      today,
                      style: const TextStyle(
                        color: _screenAccent,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: _events.isEmpty
                      ? _emptyNote(
                          'No events today — or Jarvis cannot read the calendar yet.\n\n'
                          'If no events show, tap below to grant the calendar permission. '
                          'Jarvis only reads the calendar; it never writes to it.',
                        )
                      : ListView.builder(
                          itemCount: _events.length,
                          itemBuilder: (context, index) {
                            final event = _events[index];
                            return ListTile(
                              leading: const Icon(
                                Icons.event,
                                color: Colors.cyan,
                              ),
                              title: Text(
                                event.title,
                                style:
                                    const TextStyle(color: Colors.white),
                              ),
                              subtitle: Text(
                                formatEventLine(event) +
                                    (event.calendarName.isEmpty
                                        ? ''
                                        : ' · ${event.calendarName}'),
                                style:
                                    const TextStyle(color: Colors.grey),
                              ),
                            );
                          },
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: _grantCalendar,
                          child: const Text(
                            'Grant calendar permission',
                            style: TextStyle(color: Colors.cyan),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: _reload,
                          child: const Text(
                            'Refresh',
                            style: TextStyle(color: Colors.cyan),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

/// F28: email triage (Gmail REST, read-only). Disabled until a Gmail
/// access token is pasted — the screen explains how to get one. When
/// connected it lists recent unread messages (subject, sender,
/// snippet). It never sends, deletes or marks anything read.
class GmailTriageScreen extends StatefulWidget {
  const GmailTriageScreen({super.key, required this.gmailService});

  final GmailService gmailService;

  @override
  State<GmailTriageScreen> createState() => _GmailTriageScreenState();
}

class _GmailTriageScreenState extends State<GmailTriageScreen> {
  List<GmailMessage> _messages = [];
  bool _loading = true;
  bool _connected = false;
  bool _enabled = false;
  String? _error;
  final TextEditingController _tokenController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _tokenController.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    setState(() => _loading = true);
    final connected = await widget.gmailService.hasToken();
    final enabled = await widget.gmailService.isEnabled();
    List<GmailMessage> messages = [];
    String? error;
    if (connected && enabled) {
      try {
        messages = await widget.gmailService.listUnread();
      } on GmailException catch (e) {
        error = e.message;
      }
    }
    if (!mounted) return;
    setState(() {
      _messages = messages;
      _connected = connected;
      _enabled = enabled;
      _error = error;
      _loading = false;
    });
  }

  Future<void> _saveToken() async {
    final token = _tokenController.text.trim();
    if (token.isEmpty) return;
    await widget.gmailService.saveToken(token);
    _tokenController.clear();
    await widget.gmailService.setEnabled(true);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Gmail token saved (encrypted on this phone). Tokens expire after about an hour — paste a fresh one when triage stops working.',
          ),
        ),
      );
    }
    _reload();
  }

  Future<void> _disconnect() async {
    final confirm = await _confirmDialog(
      context,
      title: 'Disconnect Gmail?',
      message: 'Jarvis will forget the Gmail access token.',
      confirmLabel: 'Disconnect',
    );
    if (!confirm) return;
    await widget.gmailService.clearToken();
    _reload();
  }

  Future<void> _toggleEnabled(bool value) async {
    await widget.gmailService.setEnabled(value);
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Email triage'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.cyan),
            tooltip: 'Refresh',
            onPressed: _reload,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : !_connected
              ? _buildDisabled()
              : ListView(
                  padding: const EdgeInsets.all(16.0),
                  children: [
                    SwitchListTile(
                      value: _enabled,
                      activeThumbColor: _screenAccent,
                      title: const Text(
                        'Email triage',
                        style: TextStyle(color: Colors.white),
                      ),
                      subtitle: const Text(
                        'Read-only: Jarvis lists unread mail, never sends, deletes or marks anything read.',
                        style: TextStyle(color: Colors.grey, fontSize: 12),
                      ),
                      contentPadding: EdgeInsets.zero,
                      onChanged: _toggleEnabled,
                    ),
                    TextButton(
                      onPressed: _disconnect,
                      child: const Text(
                        'Disconnect Gmail (forget the token)',
                        style: TextStyle(color: Colors.redAccent),
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (_error != null)
                      Text(
                        _error!,
                        style: const TextStyle(
                          color: Colors.orangeAccent,
                          fontSize: 13,
                        ),
                      )
                    else if (!_enabled)
                      const Text(
                        'Triage is switched off. Switch it on above to list unread mail.',
                        style: TextStyle(color: Colors.grey),
                      )
                    else if (_messages.isEmpty)
                      const Text(
                        'No unread messages.',
                        style: TextStyle(color: Colors.grey),
                      )
                    else
                      for (final message in _messages)
                        Card(
                          color: Colors.grey[900],
                          child: ListTile(
                            title: Text(
                              message.subject,
                              style: const TextStyle(color: Colors.white),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  message.sender,
                                  style: const TextStyle(
                                    color: _screenAccent,
                                    fontSize: 12,
                                  ),
                                ),
                                if (message.snippet.isNotEmpty)
                                  Text(
                                    message.snippet,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 13,
                                    ),
                                  ),
                                if (message.date.isNotEmpty)
                                  Text(
                                    message.date,
                                    style: const TextStyle(
                                      color: Colors.grey,
                                      fontSize: 11,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                  ],
                ),
    );
  }

  Widget _buildDisabled() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Gmail is not connected yet.',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Jarvis reads your inbox through the Gmail API, but it needs '
            'an access token from your own Google account. There is no '
            'built-in sign-in — Google will not let an app invent one.\n\n'
            'How to get a token (free, no card):\n'
            '1. Open the Google OAuth 2.0 Playground:\n'
            '   developers.google.com/oauthplayground\n'
            '2. In step 1, find "Gmail API v1" and tick\n'
            '   https://www.googleapis.com/auth/gmail.readonly\n'
            '3. Click "Authorize APIs", sign in with your Google account,\n'
            '   then "Exchange authorization code for tokens".\n'
            '4. Copy the "Access token" and paste it below.\n\n'
            'The token is stored encrypted on this phone and expires '
            'after about an hour — paste a fresh one when triage stops '
            'working. Your password is never asked for and never stored.',
            style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.5),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _tokenController,
            obscureText: true,
            enableSuggestions: false,
            autocorrect: false,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              labelText: 'Gmail access token',
              labelStyle: TextStyle(color: Colors.cyan),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: _saveToken,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.cyan,
              foregroundColor: Colors.black,
            ),
            child: const Text('Connect Gmail'),
          ),
        ],
      ),
    );
  }
}

/// F29: expenses logged by voice, with totals by category and a
/// weekly total. Optional SMS import reads bank SMS on-device (only
/// when the SMS toggle in Settings is on) and logs the debits it
/// finds. Nothing is ever uploaded.
class FinanceScreen extends StatefulWidget {
  const FinanceScreen({super.key, required this.financeService});

  final FinanceService financeService;

  @override
  State<FinanceScreen> createState() => _FinanceScreenState();
}

class _FinanceScreenState extends State<FinanceScreen> {
  List<ExpenseEntry> _expenses = [];
  bool _loading = true;
  bool _smsOn = false;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final expenses = await widget.financeService.loadExpenses();
    final smsOn = await widget.financeService.isSmsParsingEnabled();
    if (mounted) {
      setState(() {
        _expenses = expenses;
        _smsOn = smsOn;
        _loading = false;
      });
    }
  }

  Future<void> _clearAll() async {
    final confirm = await _confirmDialog(
      context,
      title: 'Clear all expenses?',
      message: 'Every logged expense will be deleted from this phone.',
    );
    if (!confirm) return;
    await widget.financeService.clearAll();
    _reload();
  }

  Future<void> _addManual() async {
    final amountController = TextEditingController();
    final noteController = TextEditingController();
    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('Add expense',
            style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: amountController,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Amount (Rs)',
                labelStyle: TextStyle(color: Colors.cyan),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: noteController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'What for? (e.g. groceries)',
                labelStyle: TextStyle(color: Colors.cyan),
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel',
                style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () {
              final amount =
                  double.tryParse(amountController.text.trim());
              if (amount == null || amount <= 0) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Enter a valid amount.'),
                  ),
                );
                return;
              }
              widget.financeService.addExpense(
                ParsedExpense(
                  amount: amount,
                  category: guessExpenseCategory(noteController.text),
                  note: noteController.text.trim().isEmpty
                      ? 'Expense'
                      : noteController.text.trim(),
                ),
              );
              Navigator.of(context).pop(true);
            },
            child:
                const Text('Save', style: TextStyle(color: Colors.cyan)),
          ),
        ],
      ),
    );
    amountController.dispose();
    noteController.dispose();
    if (saved == true) _reload();
  }

  Future<void> _importSms() async {
    final found = await widget.financeService.readBankSmsExpenses();
    var added = 0;
    for (final parsed in found) {
      await widget.financeService.addExpense(parsed);
      added++;
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            added == 0
                ? 'No bank debits found in recent SMS.'
                : 'Imported $added bank expense${added == 1 ? '' : 's'} from SMS.',
          ),
        ),
      );
    }
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    final totals = totalsByCategory(_expenses);
    final weekTotal = totalInLastDays(_expenses);
    final allTotal =
        _expenses.fold<double>(0, (sum, e) => sum + e.amount);
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Finance'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: Colors.cyan),
            tooltip: 'Add an expense',
            onPressed: _addManual,
          ),
          IconButton(
            icon: const Icon(Icons.delete_sweep, color: Colors.redAccent),
            tooltip: 'Clear all expenses',
            onPressed: _expenses.isEmpty ? null : _clearAll,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Last 7 days: Rs ${weekTotal.toStringAsFixed(0)}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'All time: Rs ${allTotal.toStringAsFixed(0)} · ${_expenses.length} entries',
                        style: const TextStyle(color: Colors.grey),
                      ),
                      if (totals.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        for (final entry in totals.entries)
                          Text(
                            '${entry.key}: Rs ${entry.value.toStringAsFixed(0)}',
                            style: const TextStyle(color: Colors.white70),
                          ),
                      ],
                      const SizedBox(height: 8),
                      Text(
                        _smsOn
                            ? 'SMS parsing is ON (Settings): bank SMS can be imported below.'
                            : 'SMS parsing is OFF. Say "spent 500 on groceries" to log by voice, or switch SMS parsing on in Settings.',
                        style: const TextStyle(
                            color: Colors.grey, fontSize: 12),
                      ),
                      if (_smsOn) ...[
                        const SizedBox(height: 8),
                        OutlinedButton(
                          onPressed: _importSms,
                          child: const Text(
                            'Import bank expenses from SMS',
                            style: TextStyle(color: Colors.cyan),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                Expanded(
                  child: _expenses.isEmpty
                      ? _emptyNote(
                          'No expenses yet.\n\nSay "spent 500 on groceries" and it will appear here.',
                        )
                      : ListView.builder(
                          itemCount: _expenses.length,
                          itemBuilder: (context, index) {
                            final expense = _expenses[index];
                            return ListTile(
                              leading: const Icon(
                                Icons.receipt,
                                color: Colors.cyan,
                              ),
                              title: Text(
                                'Rs ${expense.amount.toStringAsFixed(0)} · ${expense.category}',
                                style:
                                    const TextStyle(color: Colors.white),
                              ),
                              subtitle: Text(
                                '${expense.note} · ${DateFormat.yMMMd().add_jm().format(expense.loggedAt)}',
                                style:
                                    const TextStyle(color: Colors.grey),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

/// F30: the phone's own network — Wi-Fi name, IP, signal — and the
/// devices on the same network from the ARP table. Display only: no
/// port-scanning, no probing of other devices.
class NetworkScreen extends StatefulWidget {
  const NetworkScreen({super.key, required this.networkService});

  final NetworkAuditService networkService;

  @override
  State<NetworkScreen> createState() => _NetworkScreenState();
}

class _NetworkScreenState extends State<NetworkScreen> {
  WifiInfo? _wifi;
  List<ArpDevice> _devices = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    setState(() => _loading = true);
    final wifi = await widget.networkService.getWifiInfo();
    final devices = await widget.networkService.getArpDevices();
    if (!mounted) return;
    setState(() {
      _wifi = wifi;
      _devices = devices;
      _loading = false;
      _error = wifi == null
          ? 'Not connected to Wi-Fi, or the Wi-Fi info could not be read.'
          : null;
    });
  }

  Future<void> _grantLocation() async {
    await Permission.location.request();
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Network'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.cyan),
            tooltip: 'Refresh',
            onPressed: _reload,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : ListView(
              padding: const EdgeInsets.all(16.0),
              children: [
                const Text(
                  'This phone',
                  style: TextStyle(
                    color: _screenAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                if (_error != null)
                  Text(_error!, style: const TextStyle(color: Colors.grey))
                else if (_wifi != null) ...[
                  Text('Wi-Fi: ${_wifi!.ssidKnown ? _wifi!.ssid : 'Name hidden — grant the location permission to show it'}',
                      style: const TextStyle(color: Colors.white)),
                  Text('IP address: ${_wifi!.ipAddress}',
                      style: const TextStyle(color: Colors.white)),
                  Text(
                    'Signal: ${_wifi!.rssi} dBm (${signalStrengthLabel(_wifi!.rssi)})',
                    style: const TextStyle(color: Colors.white),
                  ),
                  if (!_wifi!.ssidKnown) ...[
                    const SizedBox(height: 8),
                    OutlinedButton(
                      onPressed: _grantLocation,
                      child: const Text(
                        'Grant location permission (shows Wi-Fi name)',
                        style: TextStyle(color: Colors.cyan),
                      ),
                    ),
                  ],
                ],
                const SizedBox(height: 24),
                const Text(
                  'Devices on this network',
                  style: TextStyle(
                    color: _screenAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'From the on-device ARP table. Display only — Jarvis does not scan or probe other devices.',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
                const SizedBox(height: 8),
                if (_devices.isEmpty)
                  const Text(
                    'No other devices seen. Connect to Wi-Fi and refresh.',
                    style: TextStyle(color: Colors.grey),
                  )
                else
                  for (final device in _devices)
                    ListTile(
                      leading: const Icon(Icons.devices, color: Colors.cyan),
                      title: Text(
                        device.ip,
                        style: const TextStyle(color: Colors.white),
                      ),
                      subtitle: Text(
                        '${device.mac} · ${device.device}',
                        style: const TextStyle(color: Colors.grey),
                      ),
                    ),
              ],
            ),
    );
  }
}

/// F31: battery/charging state and today's most-used apps. Read-only;
/// nothing is uploaded. Usage stats need the Usage access permission,
/// granted in Android Settings.
class TelemetryScreen extends StatefulWidget {
  const TelemetryScreen({super.key, required this.telemetryService});

  final TelemetryService telemetryService;

  @override
  State<TelemetryScreen> createState() => _TelemetryScreenState();
}

class _TelemetryScreenState extends State<TelemetryScreen> {
  BatteryInfo? _battery;
  List<AppUsageEntry> _usage = [];
  bool _usageAllowed = false;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    setState(() => _loading = true);
    final battery = await widget.telemetryService.getBatteryInfo();
    final allowed =
        await widget.telemetryService.hasUsageStatsPermission();
    final usage = allowed
        ? await widget.telemetryService.getUsageStats()
        : <AppUsageEntry>[];
    if (!mounted) return;
    setState(() {
      _battery = battery;
      _usageAllowed = allowed;
      _usage = usage;
      _loading = false;
    });
  }

  Future<void> _openUsageAccess() async {
    try {
      await AndroidIntent(
        action: 'android.settings.USAGE_ACCESS_SETTINGS',
        flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
      ).launch();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Telemetry'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.cyan),
            tooltip: 'Refresh',
            onPressed: _reload,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : ListView(
              padding: const EdgeInsets.all(16.0),
              children: [
                const Text(
                  'Battery',
                  style: TextStyle(
                    color: _screenAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  _battery == null
                      ? 'Battery info could not be read.'
                      : formatBatterySummary(_battery!),
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
                const SizedBox(height: 24),
                const Text(
                  'Most-used apps today',
                  style: TextStyle(
                    color: _screenAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                if (!_usageAllowed) ...[
                  const Text(
                    'Usage access is not granted. Android only grants it in Settings — open the Usage access page and switch Jarvis on.',
                    style: TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton(
                    onPressed: _openUsageAccess,
                    child: const Text(
                      'Open usage access settings',
                      style: TextStyle(color: Colors.cyan),
                    ),
                  ),
                ] else if (_usage.isEmpty)
                  const Text(
                    'No app usage recorded today yet.',
                    style: TextStyle(color: Colors.grey),
                  )
                else
                  for (final entry in _usage)
                    ListTile(
                      leading: const Icon(Icons.apps, color: Colors.cyan),
                      title: Text(
                        entry.label.isEmpty
                            ? entry.packageName
                            : entry.label,
                        style: const TextStyle(color: Colors.white),
                      ),
                      subtitle: Text(
                        entry.packageName,
                        style: const TextStyle(color: Colors.grey),
                      ),
                      trailing: Text(
                        formatUsageDuration(entry.minutes),
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
              ],
            ),
    );
  }
}
