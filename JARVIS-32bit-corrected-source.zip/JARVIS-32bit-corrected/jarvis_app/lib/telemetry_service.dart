// Phase 7 (v1.1.0) — F31 charging & app-usage telemetry.
//
// Read-only display: battery/charging state and today's most-used
// apps. No upload anywhere. App-usage stats need the
// PACKAGE_USAGE_STATS permission, granted by the user in Android
// Settings (Usage access) — requested from onboarding (F25) and from
// the Telemetry screen. The native side is a small platform channel in
// MainActivity.kt (BatteryManager + UsageStatsManager), following the
// existing channel pattern. The pure formatting helpers are
// unit-tested directly.

import 'package:flutter/services.dart';

/// Battery state from the platform channel.
class BatteryInfo {
  const BatteryInfo({
    required this.level,
    required this.charging,
    required this.plugged,
  });

  factory BatteryInfo.fromMap(Map<String, dynamic> map) {
    return BatteryInfo(
      level: map['level'] is int
          ? map['level'] as int
          : int.tryParse(map['level']?.toString() ?? '') ?? -1,
      charging: map['charging'] == true,
      plugged: map['plugged']?.toString() ?? '',
    );
  }

  /// 0–100, or -1 when unknown.
  final int level;

  final bool charging;

  /// "AC charger", "USB", "Wireless", or "Not plugged in".
  final String plugged;
}

/// One app's foreground time today.
class AppUsageEntry {
  const AppUsageEntry({
    required this.packageName,
    required this.label,
    required this.minutes,
  });

  factory AppUsageEntry.fromMap(Map<String, dynamic> map) {
    return AppUsageEntry(
      packageName: map['package']?.toString() ?? '',
      label: map['label']?.toString() ?? '',
      minutes: map['minutes'] is int
          ? map['minutes'] as int
          : int.tryParse(map['minutes']?.toString() ?? '') ?? 0,
    );
  }

  final String packageName;

  /// Human label from the package manager; falls back to the package
  /// name when the label cannot be resolved.
  final String label;

  /// Foreground minutes today.
  final int minutes;
}

/// "2h 15m", "45m", "0m".
String formatUsageDuration(int minutes) {
  if (minutes <= 0) return '0m';
  final hours = minutes ~/ 60;
  final rest = minutes % 60;
  if (hours == 0) return '${rest}m';
  if (rest == 0) return '${hours}h';
  return '${hours}h ${rest}m';
}

/// One-line battery summary: "78% · Charging (USB)".
String formatBatterySummary(BatteryInfo info) {
  final level = info.level < 0 ? '?' : '${info.level}%';
  final state = info.charging ? 'Charging' : 'Not charging';
  final plugged = info.plugged.isEmpty ? '' : ' (${info.plugged})';
  return '$level · $state$plugged';
}

class TelemetryService {
  const TelemetryService();

  static const MethodChannel _channel =
      MethodChannel('com.jarvis.jarvis_app/telemetry');

  Future<BatteryInfo?> getBatteryInfo() async {
    try {
      final raw = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getBatteryInfo',
      );
      if (raw == null) return null;
      return BatteryInfo.fromMap(Map<String, dynamic>.from(raw));
    } catch (_) {
      return null;
    }
  }

  /// True when the user has granted Usage access in Android Settings.
  Future<bool> hasUsageStatsPermission() async {
    try {
      return await _channel.invokeMethod<bool>(
            'hasUsageStatsPermission',
          ) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Today's most-used apps, most-used first. Returns [] when the
  /// permission is missing or the channel fails.
  Future<List<AppUsageEntry>> getUsageStats({int limit = 10}) async {
    try {
      final raw = await _channel.invokeMethod<List<dynamic>>(
        'getUsageStats',
        <String, dynamic>{'limit': limit},
      );
      final entries = <AppUsageEntry>[];
      for (final item in raw ?? <dynamic>[]) {
        if (item is Map) {
          entries.add(
            AppUsageEntry.fromMap(Map<String, dynamic>.from(item)),
          );
        }
      }
      entries.sort((a, b) => b.minutes.compareTo(a.minutes));
      return entries;
    } catch (_) {
      return [];
    }
  }
}
