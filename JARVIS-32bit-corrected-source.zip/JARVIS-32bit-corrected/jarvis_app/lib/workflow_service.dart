// Phase 9 (v1.2.0) — G4 workflow templates, G5 scheduled workflows
// (the schedule itself lives in lib/scheduled_workflow_service.dart),
// G12 per-workflow autonomy.
//
// A workflow template is a named, saved list of plain command strings
// ("morning briefing" = what's on my calendar today + any important
// mail + what time is it). Running one replays each step through the
// existing processQuery path (main.dart does the running, via the same
// step runner as F33 macros — see lib/multi_task_service.dart).
// This service NEVER executes anything itself: it only stores
// templates, parses voice commands, and reports each step honestly.
//
// AUTONOMY SEMANTICS (G12):
//   askFirst   — before running a template/macro, show the step plan
//                and wait for the user's "yes" (main.dart does this
//                via the existing confirmation flow). This is the
//                default: nothing ever runs unannounced unless the
//                user said so for that workflow.
//   autonomous — run all steps straight away, no plan confirmation.
// EITHER WAY the F42 confirmation gate (lib/confirmation_gate.dart)
// still applies to any send/call step inside the workflow — autonomy
// NEVER bypasses it. A workflow that messages someone or places a
// call still stops and asks first, step by step.
//
// Built-in templates ship with the app; the user can save their own
// (and override a built-in by saving a template with the same name).
// Templates are stored locally on this phone only
// (SharedPreferences). Fresh implementation — ideas only, no code
// copied from any other Jarvis repo.

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key holding the user's workflow templates, as a
/// JSON list of `{id, name, description, steps, autonomy, createdAt}`
/// objects.
const String kJarvisWorkflowsKey = 'jarvis_workflows_v1';

/// Most templates kept; most steps in one template. A phone should
/// never grow an unbounded template list.
const int kJarvisMaxWorkflows = 50;
const int kJarvisMaxWorkflowSteps = 20;

/// How a workflow runs (G12). See the header for the semantics — in
/// short: askFirst shows the plan and waits for "yes"; autonomous runs
/// straight away. Neither bypasses the F42 gate.
enum WorkflowAutonomy { askFirst, autonomous }

/// Stored value for [WorkflowAutonomy.askFirst].
const String kWorkflowAutonomyAsk = 'ask';

/// Stored value for [WorkflowAutonomy.autonomous].
const String kWorkflowAutonomyAuto = 'auto';

/// Parses a stored autonomy value. Unknown or absent values default
/// to [WorkflowAutonomy.askFirst], so old stored templates/macros
/// (which have no autonomy key) still load as ask-first.
WorkflowAutonomy workflowAutonomyFromString(String? raw) {
  switch (raw?.trim().toLowerCase()) {
    case kWorkflowAutonomyAuto:
    case 'autonomous':
      return WorkflowAutonomy.autonomous;
    case kWorkflowAutonomyAsk:
    case 'askfirst':
    case 'ask first':
    default:
      return WorkflowAutonomy.askFirst;
  }
}

/// Serialises an autonomy value for storage.
String workflowAutonomyToString(WorkflowAutonomy autonomy) =>
    switch (autonomy) {
      WorkflowAutonomy.askFirst => kWorkflowAutonomyAsk,
      WorkflowAutonomy.autonomous => kWorkflowAutonomyAuto,
    };

/// One workflow template.
class WorkflowTemplate {
  const WorkflowTemplate({
    required this.id,
    required this.name,
    required this.description,
    required this.steps,
    this.autonomy = WorkflowAutonomy.askFirst,
    required this.createdAt,
  });

  factory WorkflowTemplate.fromJson(Map<String, dynamic> json) {
    final steps = <String>[];
    final raw = json['steps'];
    if (raw is List) {
      for (final step in raw) {
        final text = step?.toString().trim() ?? '';
        if (text.isNotEmpty) steps.add(text);
      }
    }
    return WorkflowTemplate(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      steps: steps,
      autonomy: workflowAutonomyFromString(json['autonomy']?.toString()),
      createdAt:
          DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  /// Stable id. Built-ins use fixed ids (`builtin-…`); user templates
  /// get an epoch-millis id when saved (see [WorkflowService]).
  final String id;

  final String name;

  /// One line saying what the workflow does, shown on screen.
  final String description;

  /// The commands, in order, as plain strings for the processQuery
  /// path. `{topic}` in a step is a placeholder the caller fills in
  /// before running (see the 'research and save' built-in).
  final List<String> steps;

  /// Whether running this template asks first or runs straight away.
  final WorkflowAutonomy autonomy;

  final DateTime createdAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'id': id,
    'name': name,
    'description': description,
    'steps': steps,
    'autonomy': workflowAutonomyToString(autonomy),
    'createdAt': createdAt.toIso8601String(),
  };
}

/// Parses a stored template list from [raw] JSON; drops malformed
/// entries and templates with no name or no steps.
List<WorkflowTemplate> parseStoredTemplates(String? raw) {
  if (raw == null || raw.isEmpty) return [];
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map((e) => WorkflowTemplate.fromJson(Map<String, dynamic>.from(e)))
        .where((t) => t.name.trim().isNotEmpty && t.steps.isNotEmpty)
        .toList();
  } catch (_) {
    return [];
  }
}

String encodeTemplates(List<WorkflowTemplate> templates) =>
    jsonEncode(templates.map((t) => t.toJson()).toList());

/// Normalises a template name for matching: lower-cased, trimmed,
/// collapsed spaces. The stored display name keeps the user's casing.
String normalizeWorkflowName(String name) =>
    name.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

/// Finds a template by name (case-insensitive), or null.
WorkflowTemplate? findWorkflow(
  List<WorkflowTemplate> templates,
  String name,
) {
  final wanted = normalizeWorkflowName(name);
  for (final template in templates) {
    if (normalizeWorkflowName(template.name) == wanted) return template;
  }
  return null;
}

/// Finds a template by id, or null.
WorkflowTemplate? findWorkflowById(
  List<WorkflowTemplate> templates,
  String id,
) {
  for (final template in templates) {
    if (template.id == id) return template;
  }
  return null;
}

/// Extracts the workflow name from `run workflow <name>` or
/// `run <name> workflow`. Returns null when this is not a workflow
/// run command. A bare `run <name>` is a macro command, not a
/// workflow one, so it does not match here.
String? parseRunWorkflowName(String utterance) {
  final text = utterance.trim();
  final lower = text.toLowerCase();
  for (final prefix in <String>['run my workflow ', 'run workflow ']) {
    if (lower.startsWith(prefix)) {
      final name = text.substring(prefix.length).trim();
      if (name.isEmpty) return null;
      return name.replaceFirst(
        RegExp(r'^(the|my)\s+', caseSensitive: false),
        '',
      );
    }
  }
  // "run the morning briefing workflow" — trailing "workflow".
  const runPrefix = 'run ';
  if (lower.startsWith(runPrefix)) {
    final rest = text.substring(runPrefix.length).trim();
    const suffix = ' workflow';
    if (rest.toLowerCase().endsWith(suffix)) {
      final name = rest
          .substring(0, rest.length - suffix.length)
          .trim()
          .replaceFirst(RegExp(r'^(the|my)\s+', caseSensitive: false), '');
      return name.isEmpty ? null : name;
    }
  }
  return null;
}

/// Extracts the workflow name from `delete workflow <name>` /
/// `remove workflow <name>`. Returns null when not a delete command.
String? parseWorkflowDeleteName(String utterance) {
  final text = utterance.trim();
  final lower = text.toLowerCase();
  for (final prefix in <String>['delete workflow ', 'remove workflow ']) {
    if (lower.startsWith(prefix)) {
      final name = text.substring(prefix.length).trim();
      return name.isEmpty ? null : name;
    }
  }
  return null;
}

/// Extracts the (name, autonomy) pair from `make workflow <name>`
/// followed by `autonomous` or `ask first`. Returns null when this
/// is not an autonomy command.
({String name, WorkflowAutonomy autonomy})? parseWorkflowAutonomyCommand(
  String utterance,
) {
  final text = utterance.trim();
  final lower = text.toLowerCase();
  const prefix = 'make workflow ';
  if (!lower.startsWith(prefix)) return null;
  final rest = text.substring(prefix.length).trim();
  const askSuffix = ' ask first';
  const autoSuffix = ' autonomous';
  if (rest.toLowerCase().endsWith(askSuffix)) {
    final name = rest.substring(0, rest.length - askSuffix.length).trim();
    if (name.isEmpty) return null;
    return (name: name, autonomy: WorkflowAutonomy.askFirst);
  }
  if (rest.toLowerCase().endsWith(autoSuffix)) {
    final name = rest.substring(0, rest.length - autoSuffix.length).trim();
    if (name.isEmpty) return null;
    return (name: name, autonomy: WorkflowAutonomy.autonomous);
  }
  return null;
}

/// Local workflow-template store. The service only persists finished
/// templates; running them (and the ask-first plan confirmation)
/// lives in main.dart, next to the macro replay code.
class WorkflowService {
  const WorkflowService();

  /// The four built-in templates. Fresh objects on every call, so a
  /// caller can never mutate the shared list.
  List<WorkflowTemplate> builtInTemplates() => <WorkflowTemplate>[
    WorkflowTemplate(
      id: 'builtin-morning-briefing',
      name: 'morning briefing',
      description: 'Calendar, important mail, and the time — to start the day.',
      steps: <String>[
        'what is on my calendar today',
        'any important mail',
        'what time is it',
      ],
      autonomy: WorkflowAutonomy.askFirst,
      createdAt: DateTime.fromMillisecondsSinceEpoch(0),
    ),
    WorkflowTemplate(
      id: 'builtin-research-and-save',
      name: 'research and save',
      description:
          'Search the web for a topic and save what it finds. '
          'Say the topic when you run it — {topic} is filled in by the caller.',
      steps: <String>['search the web for {topic}'],
      autonomy: WorkflowAutonomy.askFirst,
      createdAt: DateTime.fromMillisecondsSinceEpoch(0),
    ),
    WorkflowTemplate(
      id: 'builtin-email-production',
      name: 'email production',
      description: 'Summarise unread mail into a document.',
      steps: <String>[
        'draft an email summary of my unread mail',
        'save it to a doc',
      ],
      autonomy: WorkflowAutonomy.askFirst,
      createdAt: DateTime.fromMillisecondsSinceEpoch(0),
    ),
    WorkflowTemplate(
      id: 'builtin-make-a-post',
      name: 'make a post from this file',
      description: 'Draft a social post from an attached file.',
      steps: <String>[
        'use the attached file',
        'draft a social post',
      ],
      autonomy: WorkflowAutonomy.askFirst,
      createdAt: DateTime.fromMillisecondsSinceEpoch(0),
    ),
  ];

  /// User-saved templates, newest first by name (same ordering as
  /// macros). Built-ins are NOT in this list — callers merge them in
  /// with [builtInTemplates] when showing "all workflows".
  Future<List<WorkflowTemplate>> loadTemplates() async {
    final prefs = await SharedPreferences.getInstance();
    final templates = parseStoredTemplates(prefs.getString(kJarvisWorkflowsKey));
    templates.sort(
      (a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()),
    );
    return templates;
  }

  /// Saves a template (replacing any saved template with the same
  /// name, or the same built-in id). A template with no name or no
  /// steps is ignored. An empty id is filled in with an epoch-millis
  /// id so every saved template can be scheduled by id.
  Future<WorkflowTemplate?> saveTemplate(WorkflowTemplate template) async {
    if (template.name.trim().isEmpty || template.steps.isEmpty) return null;
    final templates = await loadTemplates();
    final saved = template.id.trim().isEmpty
        ? WorkflowTemplate(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            name: template.name,
            description: template.description,
            steps: template.steps,
            autonomy: template.autonomy,
            createdAt: template.createdAt,
          )
        : template;
    templates.removeWhere(
      (t) =>
          normalizeWorkflowName(t.name) ==
              normalizeWorkflowName(saved.name) ||
          (saved.id.isNotEmpty && t.id == saved.id),
    );
    templates.add(saved);
    while (templates.length > kJarvisMaxWorkflows) {
      templates.removeAt(0);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(kJarvisWorkflowsKey, encodeTemplates(templates));
    return saved;
  }

  /// Deletes a saved template by name (case-insensitive) or by id.
  /// Returns false when nothing matched. Built-ins are not stored,
  /// so they cannot be deleted here.
  Future<bool> deleteTemplate(String nameOrId) async {
    final templates = await loadTemplates();
    final before = templates.length;
    templates.removeWhere(
      (t) =>
          normalizeWorkflowName(t.name) ==
              normalizeWorkflowName(nameOrId) ||
          t.id == nameOrId,
    );
    if (templates.length == before) return false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(kJarvisWorkflowsKey, encodeTemplates(templates));
    return true;
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(kJarvisWorkflowsKey);
  }
}
