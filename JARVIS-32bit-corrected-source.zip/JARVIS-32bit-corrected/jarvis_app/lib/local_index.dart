// Phase 6 (v1.1.0) — F21 on-device index.
//
// Fast on-device search across chat history (stored sessions),
// reminders, saved facts (F17) and knowledge files (F22). Plain Dart
// string matching (case-insensitive, substring) — no new database
// dependency, no server, nothing leaves the phone.
//
// Pattern: local index, after mokshith7777/Jarvis-android-
// lib/services/local_index_service.dart. Fresh implementation — no code
// copied. Results are grouped by type; the Search screen turns a tap
// into "open the history session / show the reminder / show the fact
// or file".

import 'package:intl/intl.dart';

import 'knowledge_service.dart';
import 'memory_service.dart';

/// What kind of thing a search result is.
enum LocalSearchResultType { chat, reminder, fact, knowledge }

extension LocalSearchResultTypeLabel on LocalSearchResultType {
  String get label {
    switch (this) {
      case LocalSearchResultType.chat:
        return 'Chat';
      case LocalSearchResultType.reminder:
        return 'Reminder';
      case LocalSearchResultType.fact:
        return 'Saved fact';
      case LocalSearchResultType.knowledge:
        return 'Knowledge file';
    }
  }
}

/// One search hit. The screen uses [session] to open a chat,
/// [reminderId] to show a reminder, [factText] to show a fact, and
/// [fileName]/[fileContent] to show a knowledge file.
class LocalSearchResult {
  const LocalSearchResult({
    required this.type,
    required this.title,
    required this.subtitle,
    this.session,
    this.reminderId,
    this.factText,
    this.fileName,
    this.fileContent,
  });

  final LocalSearchResultType type;
  final String title;
  final String subtitle;
  final Map<String, dynamic>? session;
  final int? reminderId;
  final String? factText;
  final String? fileName;
  final String? fileContent;
}

/// Most results kept per type, so one noisy type cannot bury the rest.
const int kLocalSearchMaxPerType = 20;

/// A short snippet of [text] around the first occurrence of [needle]
/// (case-insensitive), at most [maxChars] long, with '…' where text was
/// cut. Falls back to the start of the text when there is no match.
String searchSnippet(String text, String needle, {int maxChars = 90}) {
  final lower = text.toLowerCase();
  final at = lower.indexOf(needle.toLowerCase());
  if (at < 0) {
    final head = text.length > maxChars
        ? '${text.substring(0, maxChars)}…'
        : text;
    return head;
  }
  var start = at - 30;
  if (start < 0) start = 0;
  var end = start + maxChars;
  if (end > text.length) end = text.length;
  var snippet = text.substring(start, end).replaceAll('\n', ' ').trim();
  if (start > 0) snippet = '…$snippet';
  if (end < text.length) snippet = '$snippet…';
  return snippet;
}

/// Searches every on-device source for [query] (case-insensitive
/// substring). Results are grouped by type in the order chat, reminder,
/// saved fact, knowledge file. Returns [] for an empty query.
List<LocalSearchResult> searchLocalIndex({
  required String query,
  required List<Map<String, dynamic>> sessions,
  required List<Map<String, dynamic>> reminders,
  required List<SavedFact> facts,
  required List<KnowledgeFile> files,
}) {
  final needle = query.trim().toLowerCase();
  if (needle.isEmpty) return [];
  final results = <LocalSearchResult>[];

  // Chat history: a session matches on its title or any message.
  var chatCount = 0;
  for (final session in sessions) {
    if (chatCount >= kLocalSearchMaxPerType) break;
    final title = session['title']?.toString() ?? 'Chat';
    final messages = (session['messages'] as List<dynamic>?) ?? [];
    String? hit;
    for (final message in messages) {
      if (message is! Map) continue;
      final text = message['text']?.toString() ?? '';
      if (text.toLowerCase().contains(needle)) {
        hit = text;
        break;
      }
    }
    if (hit == null && !title.toLowerCase().contains(needle)) continue;
    results.add(LocalSearchResult(
      type: LocalSearchResultType.chat,
      title: title,
      subtitle: hit == null
          ? 'Title matches'
          : searchSnippet(hit, needle),
      session: session,
    ));
    chatCount++;
  }

  // Reminders: match on the reminder text.
  var reminderCount = 0;
  for (final reminder in reminders) {
    if (reminderCount >= kLocalSearchMaxPerType) break;
    final text = reminder['text']?.toString() ?? '';
    if (!text.toLowerCase().contains(needle)) continue;
    final fireAt =
        DateTime.tryParse(reminder['fireAt']?.toString() ?? '');
    results.add(LocalSearchResult(
      type: LocalSearchResultType.reminder,
      title: text,
      subtitle: fireAt == null
          ? 'Reminder'
          : 'Reminder · ${DateFormat.yMMMd().add_jm().format(fireAt)}',
      reminderId: reminder['id'] is int ? reminder['id'] as int : null,
    ));
    reminderCount++;
  }

  // Saved facts: match on the fact text.
  var factCount = 0;
  for (final fact in facts) {
    if (factCount >= kLocalSearchMaxPerType) break;
    if (!fact.text.toLowerCase().contains(needle)) continue;
    results.add(LocalSearchResult(
      type: LocalSearchResultType.fact,
      title: fact.text,
      subtitle:
          'Saved ${DateFormat.yMMMd().add_jm().format(fact.savedAt)}',
      factText: fact.text,
    ));
    factCount++;
  }

  // Knowledge files: match on the file name or its content.
  var fileCount = 0;
  for (final file in files) {
    if (fileCount >= kLocalSearchMaxPerType) break;
    final inName = file.name.toLowerCase().contains(needle);
    final inContent = file.content.toLowerCase().contains(needle);
    if (!inName && !inContent) continue;
    results.add(LocalSearchResult(
      type: LocalSearchResultType.knowledge,
      title: file.name,
      subtitle: inContent
          ? searchSnippet(file.content, needle)
          : 'File name matches',
      fileName: file.name,
      fileContent: file.content,
    ));
    fileCount++;
  }

  return results;
}
