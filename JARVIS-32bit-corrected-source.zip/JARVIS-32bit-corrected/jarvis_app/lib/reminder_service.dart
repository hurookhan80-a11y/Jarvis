// Durable reminders (F7, v1.1.0).
//
// Reminders used to live only as in-memory Dart Timers in lib/main.dart,
// so they died when the app was swiped away and never survived a phone
// restart. The in-app Timer path stays as it is — it is the live path
// (it speaks the reminder and adds it to the chat). This file adds the
// durable backstop: one Workmanager one-off task per reminder, which
// fires even after the app is killed or the phone restarts and shows a
// local notification. Either path removes the reminder from storage
// first, so a reminder can never fire twice.
//
// Pattern: Workmanager reminders, after trivedidhruv-dev/jarvis_assistant
// (Workmanager().initialize + executeTask). Fresh implementation — no code
// copied, and their Supabase backend is not used. Reminders stay
// on-device only (SharedPreferences, same key the app already uses).
//
// Cost: none. No key, no server, no new permission beyond the
// notification permission the manifest already declares (Android 13+
// asks it at runtime; see [ReminderService.requestNotificationPermission]).

import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';

/// SharedPreferences key holding the pending reminders. Same key the
/// in-app reminder code in lib/main.dart already uses — both paths read
/// and write the same list, so they agree about what is still pending.
const String kJarvisRemindersKey = 'jarvis_reminders_v1';

/// Workmanager task name shared by every reminder task.
const String kJarvisReminderTask = 'jarvis_reminder_fire';

/// Tag shared by every reminder task, so "cancel all reminders" can drop
/// them all with one call.
const String kJarvisReminderTag = 'jarvis_reminders';

/// Notification channel used for fired reminders.
const String _notificationChannelId = 'jarvis_reminders';
const String _notificationChannelName = 'Jarvis reminders';

/// Unique Workmanager name for one reminder. The id is carried in the
/// name so a task can always be found and cancelled by id.
String reminderWorkName(int id) => 'jarvis_reminder_$id';

/// Android notification ids are 31-bit ints; reminder ids are epoch
/// millis, so fold them into range. Deterministic per reminder.
int reminderNotificationId(int id) => id % 2147483647;

/// Parses and validates the stored reminder list from [raw] JSON.
/// Drops entries with a missing/zero id, empty text, an unparsable fire
/// time, or a fire time already in the past (relative to [now]).
/// Returns clean entries shaped like the ones lib/main.dart stores:
/// `{'id': int, 'text': String, 'fireAt': ISO-8601 String}`.
List<Map<String, dynamic>> parseStoredReminders(String? raw,
    {DateTime? now}) {
  final at = now ?? DateTime.now();
  if (raw == null || raw.isEmpty) return [];
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    final clean = <Map<String, dynamic>>[];
    for (final entry in decoded.whereType<Map>()) {
      final id = entry['id'];
      final text = entry['text']?.toString() ?? '';
      final fireAt =
          DateTime.tryParse(entry['fireAt']?.toString() ?? '');
      if (id is! int || id == 0) continue;
      if (text.isEmpty) continue;
      if (fireAt == null || fireAt.isBefore(at)) continue;
      clean.add({
        'id': id,
        'text': text,
        'fireAt': fireAt.toIso8601String(),
      });
    }
    return clean;
  } catch (_) {
    return [];
  }
}

/// Serialises a reminder list back to the stored JSON shape.
String encodeReminders(List<Map<String, dynamic>> reminders) =>
    jsonEncode(reminders);

class ReminderService {
  ReminderService._();

  static final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  static bool _initialized = false;

  /// Initialises the local-notifications plugin and Workmanager. Safe to
  /// call once from main() before runApp; never throws — if Workmanager
  /// cannot start, reminders simply fall back to the in-app Timer path.
  static Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
    try {
      await _notifications.initialize(
        settings: const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        ),
      );
      await _createChannel(_notifications);
    } catch (_) {}
    try {
      await Workmanager().initialize(reminderCallbackDispatcher);
    } catch (_) {}
  }

  /// Asks Android 13+ for the notification permission, so a reminder
  /// fired while the app is dead can actually be seen. No-op on older
  /// Android and when the permission is already granted. Call once from
  /// the home screen's initState; the system only prompts the first time.
  static Future<void> requestNotificationPermission() async {
    try {
      final android = _notifications.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();
    } catch (_) {}
  }

  /// Schedules the durable backstop for one reminder. No-op when the fire
  /// time is already past. The task's delay is a minimum: Android may
  /// deliver it a little late under Doze, which is fine — this is the
  /// backstop, the in-app Timer handles the on-time case while alive.
  static Future<void> schedule(int id, String text, DateTime fireAt) async {
    final delay = fireAt.difference(DateTime.now());
    if (delay.isNegative) return;
    try {
      await Workmanager().registerOneOffTask(
        reminderWorkName(id),
        kJarvisReminderTask,
        initialDelay: delay,
        inputData: <String, dynamic>{'reminderId': id},
        tag: kJarvisReminderTag,
        existingWorkPolicy: ExistingWorkPolicy.replace,
      );
    } catch (_) {}
  }

  /// Drops the durable backstop for one reminder (fired or cancelled).
  static Future<void> cancel(int id) async {
    try {
      await Workmanager().cancelByUniqueName(reminderWorkName(id));
    } catch (_) {}
  }

  /// Drops the durable backstop for every reminder.
  static Future<void> cancelAll() async {
    try {
      await Workmanager().cancelByTag(kJarvisReminderTag);
    } catch (_) {}
  }

  static Future<void> _createChannel(
      FlutterLocalNotificationsPlugin plugin) async {
    try {
      final android = plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await android?.createNotificationChannel(
        const AndroidNotificationChannel(
          _notificationChannelId,
          _notificationChannelName,
          description: 'Reminders set with Jarvis',
          importance: Importance.high,
        ),
      );
    } catch (_) {}
  }
}

/// Background entry point for Workmanager. Runs in a separate isolate
/// after the app is swiped away or the phone restarts, so it touches
/// only on-device storage and the notifications plugin — never the UI.
@pragma('vm:entry-point')
void reminderCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task != kJarvisReminderTask) return true;
    try {
      WidgetsFlutterBinding.ensureInitialized();
      final rawId = inputData?['reminderId'];
      final id = rawId is int ? rawId : 0;
      if (id == 0) return true;
      final prefs = await SharedPreferences.getInstance();
      final reminders =
          parseStoredReminders(prefs.getString(kJarvisRemindersKey));
      final match = reminders.where((r) => r['id'] == id).toList();
      // Already fired by the in-app Timer, or cancelled: do nothing.
      if (match.isEmpty) return true;
      final text = match.first['text'] as String;
      // Remove from storage FIRST, so the in-app path can never fire the
      // same reminder a second time.
      final remaining = reminders.where((r) => r['id'] != id).toList();
      await prefs.setString(
          kJarvisRemindersKey, encodeReminders(remaining));
      await _showReminderNotification(id, text);
      return true;
    } catch (_) {
      // A failed backstop must not retry forever; the reminder is lost
      // rather than looping. Returning true marks the work finished.
      return true;
    }
  });
}

/// Shows the fired-reminder notification from the background isolate,
/// with its own plugin instance (the main isolate's instance is not
/// reachable here).
Future<void> _showReminderNotification(int id, String text) async {
  final plugin = FlutterLocalNotificationsPlugin();
  await plugin.initialize(
    settings: const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ),
  );
  await ReminderService._createChannel(plugin);
  await plugin.show(
    id: reminderNotificationId(id),
    title: 'Jarvis reminder',
    body: text,
    notificationDetails: const NotificationDetails(
      android: AndroidNotificationDetails(
        _notificationChannelId,
        _notificationChannelName,
        channelDescription: 'Reminders set with Jarvis',
        importance: Importance.high,
        priority: Priority.high,
      ),
    ),
  );
}
