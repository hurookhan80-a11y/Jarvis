// Phase 7 (v1.1.0) — F32 air gestures.
//
// Wave a hand over the proximity sensor to silence Jarvis (wave
// while it is speaking) or to start a conversation (wave while it is
// idle and wake-word listening is on). Off by default; the toggle
// lives in Settings.
//
// Implementation note: sensors_plus does NOT expose the proximity
// sensor (accelerometer / gyroscope / magnetometer / barometer
// only — verified against pub.dev, 22 Nov 2026), so there is no
// maintained plugin route for this. The sensor is read through a
// small Kotlin EventChannel in MainActivity.kt instead
// (SensorManager + TYPE_PROXIMITY, same channel pattern as the
// network/telemetry channels — no new dependency, no native .so).
// A wave is a near -> far transition within 1.5 s; the detector is
// pure Dart and unit-tested. If the phone has no proximity sensor,
// or the channel fails, the service reports unavailable and the
// toggle does nothing — the feature is dropped silently on that
// phone, never claimed to work without a phone test.
//
// Pattern: AbuZar-Ansarii/Jarvis
// lib/services/air_gesture_service.dart. Fresh implementation —
// no code copied.

import 'dart:async';

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key: is the air gesture switched on?
/// Default OFF; the toggle lives in Settings (F32).
const String kJarvisAirGestureKey = 'jarvis_air_gesture_enabled';

/// Detects a wave from proximity events. A wave is the hand coming
/// close (near) and then moving away (far) within [waveWindow].
/// Pure — unit-tested directly.
class WaveDetector {
  WaveDetector({Duration? waveWindow, Duration? cooldown})
    : _waveWindow = waveWindow ?? const Duration(milliseconds: 1500),
      _cooldown = cooldown ?? const Duration(seconds: 2);

  final Duration _waveWindow;
  final Duration _cooldown;
  DateTime? _nearAt;
  DateTime? _lastWaveAt;

  /// Feeds one proximity reading ([near] = hand close to the sensor).
  /// Returns true exactly when this reading completes a wave.
  bool onEvent(bool near, DateTime now) {
    if (near) {
      _nearAt ??= now;
      return false;
    }
    final nearAt = _nearAt;
    _nearAt = null;
    if (nearAt == null) return false;
    if (now.difference(nearAt) > _waveWindow) return false;
    if (_lastWaveAt != null &&
        now.difference(_lastWaveAt!) < _cooldown) {
      return false;
    }
    _lastWaveAt = now;
    return true;
  }

  void reset() {
    _nearAt = null;
    _lastWaveAt = null;
  }
}

/// Proximity-sensor stream from the Kotlin side, plus the on/off
/// toggle. The stream only runs while listening is started.
class AirGestureService {
  AirGestureService({WaveDetector? detector})
    : _detector = detector ?? WaveDetector();

  static const MethodChannel _sensorChannel =
      MethodChannel('com.jarvis.jarvis_app/sensors');
  static const EventChannel _proximityChannel =
      EventChannel('com.jarvis.jarvis_app/proximity');

  final WaveDetector _detector;
  StreamSubscription<dynamic>? _subscription;
  bool _listening = false;

  /// True when this phone has a proximity sensor at all. False when
  /// the sensor is missing or the channel fails.
  Future<bool> isSensorAvailable() async {
    try {
      final available = await _sensorChannel.invokeMethod<bool>(
        'hasProximitySensor',
      );
      return available == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisAirGestureKey) ?? false;
  }

  Future<void> setEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisAirGestureKey, enabled);
  }

  /// Starts listening for waves. Calls [onWave] once per detected
  /// wave. No-op when already listening, or when the phone has no
  /// proximity sensor.
  Future<void> startListening(FutureOr<void> Function() onWave) async {
    if (_listening) return;
    if (!await isSensorAvailable()) return;
    _listening = true;
    _detector.reset();
    _subscription = _proximityChannel.receiveBroadcastStream().listen(
      (event) {
        final near = event == true || event == 1 || event == 'near';
        if (_detector.onEvent(near, DateTime.now())) {
          onWave();
        }
      },
      onError: (_) {
        _listening = false;
      },
      cancelOnError: true,
    );
  }

  Future<void> stopListening() async {
    await _subscription?.cancel();
    _subscription = null;
    _listening = false;
  }

  bool get isListening => _listening;
}
