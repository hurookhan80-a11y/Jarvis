// Phase 8 (v1.1.0) — F41 Accessibility service (Dart side).
//
// A native Android AccessibilityService (Kotlin,
// JarvisAccessibilityService.kt) that can tap by text, type text,
// go back, and scroll — driven ONLY by voice commands, and ONLY when
// the user has enabled it (toggle in Settings, default OFF). The
// service never acts on its own: every action comes from an explicit
// voice command in the current session, and every action the service
// takes is logged on screen (the "Accessibility actions" log, in the
// ⋮ menu → Accessibility).
//
// The Dart side talks to the service through a MethodChannel
// (com.jarvis.jarvis_app/accessibility), following the existing
// channel pattern in MainActivity.kt (sensors / network / telemetry).
// The service itself is registered in AndroidManifest.xml with
// res/xml/accessibilityservice.xml. Native code cannot be
// compile-verified in this sandbox — CI must confirm it.
//
// Pattern: ansaribilal14/jarvis (Accessibility-driven phone
// automation) and tokenarc/open-jarvis (Accessibility Service +
// App Launcher). Fresh implementation — no code copied.

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key: is the Accessibility service switched on
/// in Jarvis? Default OFF; the toggle lives in Settings (F41).
const String kJarvisAccessibilityKey = 'jarvis_accessibility_enabled';

/// The four safe actions the service exposes. Nothing else — no
/// reading passwords, no clicking ads, no background automation.
enum AccessibilityAction { tapByText, typeText, goBack, scrollDown, scrollUp }

extension AccessibilityActionLabel on AccessibilityAction {
  String get label => switch (this) {
    AccessibilityAction.tapByText => 'Tap',
    AccessibilityAction.typeText => 'Type',
    AccessibilityAction.goBack => 'Go back',
    AccessibilityAction.scrollDown => 'Scroll down',
    AccessibilityAction.scrollUp => 'Scroll up',
  };
}

/// One voice command for the service, parsed from the utterance.
class AccessibilityCommand {
  const AccessibilityCommand({required this.action, this.text});

  final AccessibilityAction action;

  /// The text to tap / type; null for go-back and scroll.
  final String? text;
}

/// Parses "tap Send", "click OK", "type hello", "go back",
/// "scroll down", "scroll up". Returns null when the utterance is
/// not an accessibility command. Tap/type text is capped at 200
/// characters (a longer "type" is almost certainly a misheard
/// sentence, not a field entry).
AccessibilityCommand? parseAccessibilityCommand(String normalized) {
  final text = normalized.trim().toLowerCase();
  for (final prefix in <String>['tap on ', 'tap ', 'click on ', 'click ']) {
    if (text.startsWith(prefix)) {
      final target = normalized.trim().substring(prefix.length).trim();
      if (target.isEmpty || target.length > 200) return null;
      return AccessibilityCommand(
        action: AccessibilityAction.tapByText,
        text: target,
      );
    }
  }
  if (text.startsWith('type ')) {
    final typed = normalized.trim().substring('type '.length).trim();
    if (typed.isEmpty || typed.length > 200) return null;
    return AccessibilityCommand(
      action: AccessibilityAction.typeText,
      text: typed,
    );
  }
  if (text == 'go back' || text == 'press back' || text == 'back') {
    return const AccessibilityCommand(action: AccessibilityAction.goBack);
  }
  if (text == 'scroll down' || text == 'scroll forward') {
    return const AccessibilityCommand(action: AccessibilityAction.scrollDown);
  }
  if (text == 'scroll up' || text == 'scroll back') {
    return const AccessibilityCommand(action: AccessibilityAction.scrollUp);
  }
  return null;
}

/// One entry in the on-screen "Accessibility actions" log: what the
/// service was asked to do, whether it worked, and why not. The log
/// is the audit trail — the service never acts without a line here.
class AccessibilityActionLogEntry {
  const AccessibilityActionLogEntry({
    required this.action,
    required this.detail,
    required this.succeeded,
    required this.reason,
    required this.at,
  });

  final AccessibilityAction action;

  /// What was tapped / typed, or '' for go-back / scroll.
  final String detail;

  /// Whether the native service reported the action done.
  final bool succeeded;

  /// Why it failed ('' when it succeeded).
  final String reason;
  final DateTime at;

  String get line =>
      '${action.label}${detail.isEmpty ? '' : ' "$detail"'} — '
      '${succeeded ? 'done' : 'failed: $reason'}';
}

/// Dart side of the Accessibility service: the on/off toggle, the
/// MethodChannel to the Kotlin service, and the in-memory action log.
/// The channel call itself refuses to run when the toggle is off, so
/// a stray call can never drive the service while it is disabled.
class AccessibilityService {
  AccessibilityService();

  static const MethodChannel _channel = MethodChannel(
    'com.jarvis.jarvis_app/accessibility',
  );

  final List<AccessibilityActionLogEntry> _log = [];

  /// The on-screen log, newest last. Read-only view.
  List<AccessibilityActionLogEntry> get log => List.unmodifiable(_log);

  Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisAccessibilityKey) ?? false;
  }

  Future<void> setEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisAccessibilityKey, enabled);
  }

  /// True when Android reports the Jarvis AccessibilityService as
  /// enabled (the user switched it on in Android Settings →
  /// Accessibility). False when the service is off, or the channel
  /// fails — the Dart side then reports "not enabled" instead of
  /// pretending an action worked.
  Future<bool> isServiceEnabled() async {
    try {
      final enabled = await _channel.invokeMethod<bool>(
        'isServiceEnabled',
      );
      return enabled == true;
    } catch (_) {
      return false;
    }
  }

  /// Opens Android Settings → Accessibility, where the user switches
  /// Jarvis on or off. Used from the Settings toggle and the
  /// Accessibility screen.
  Future<void> openAccessibilitySettings() async {
    try {
      await _channel.invokeMethod<void>('openAccessibilitySettings');
    } catch (_) {}
  }

  /// Runs one action through the native service. Returns true only
  /// when the service reported it done. Every attempt — success or
  /// failure — is appended to [log] first, so the screen always
  /// shows what happened. No-op (false) when the Jarvis toggle is
  /// off, or when Android has the service switched off.
  Future<bool> performAction(
    AccessibilityAction action, {
    String? text,
  }) async {
    if (!await isEnabled()) {
      _append(action, text ?? '', false,
          'Accessibility is switched off in Settings.');
      return false;
    }
    if (!await isServiceEnabled()) {
      _append(action, text ?? '', false,
          'Jarvis is not enabled in Android Settings → Accessibility.');
      return false;
    }
    try {
      final done = await _channel.invokeMethod<bool>(
        'performAction',
        <String, dynamic>{
          'action': action.name,
          'text': text ?? '',
        },
      );
      final succeeded = done == true;
      _append(
        action,
        text ?? '',
        succeeded,
        succeeded ? '' : 'The service could not do it on this screen.',
      );
      return succeeded;
    } catch (_) {
      _append(action, text ?? '', false, 'The service did not respond.');
      return false;
    }
  }

  void _append(
    AccessibilityAction action,
    String detail,
    bool succeeded,
    String reason,
  ) {
    _log.add(AccessibilityActionLogEntry(
      action: action,
      detail: detail,
      succeeded: succeeded,
      reason: reason,
      at: DateTime.now(),
    ));
    // The log is an audit trail, not a history store: keep the last
    // 50 entries so it never grows without bound.
    if (_log.length > 50) _log.removeAt(0);
  }

  void clearLog() => _log.clear();
}
