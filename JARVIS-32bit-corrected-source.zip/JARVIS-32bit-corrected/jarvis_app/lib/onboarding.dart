// Phase 7 (v1.1.0) — F25 onboarding + permissions screens.
//
// A first-run walkthrough shown once (flag in SharedPreferences):
// welcome, what Jarvis can do, the Gemini key, then one permission
// per step — microphone, notifications, overlay (F23), usage stats
// (F31), Accessibility (only for do-the-task actions), calendar
// (F27), SMS (optional, F29). Every step has Allow / Skip, and
// skipping never blocks the app: Jarvis works with whatever was
// granted, and each permission can be granted later from Settings.
// The existing Settings dialog keeps working alongside this flow.

import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key: has the first-run onboarding been finished?
const String kJarvisOnboardingDoneKey = 'jarvis_onboarding_done_v1';

class OnboardingService {
  const OnboardingService();

  Future<bool> isDone() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisOnboardingDoneKey) ?? false;
  }

  Future<void> markDone() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisOnboardingDoneKey, true);
  }
}

const MethodChannel _onboardingSecureStorageChannel =
    MethodChannel('com.jarvis.jarvis_app/secure_storage');

/// One onboarding step.
class _OnboardingStep {
  const _OnboardingStep({
    required this.icon,
    required this.title,
    required this.body,
    this.optional = false,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String title;
  final String body;

  /// Shown as "(optional)" next to the title.
  final bool optional;

  /// Label of the Allow button; null for plain "Continue" steps.
  final String? actionLabel;

  /// Runs when Allow is tapped; returns a short status line
  /// ("Granted", "Not granted", "Opened settings", ...).
  final Future<String> Function()? onAction;
}

Future<String> _requestPermission(Permission permission) async {
  try {
    final status = await permission.request();
    return status.isGranted ? 'Granted' : 'Not granted';
  } catch (_) {
    return 'Could not ask — grant it later in Settings';
  }
}

Future<String> _openAndroidSettings(String action) async {
  try {
    await AndroidIntent(
      action: action,
      flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
    ).launch();
    return 'Opened Settings — switch it on there, then come back';
  } catch (_) {
    return 'Could not open Settings';
  }
}

List<_OnboardingStep> _onboardingSteps() => <_OnboardingStep>[
  const _OnboardingStep(
    icon: Icons.waving_hand,
    title: 'Welcome to Jarvis',
    body:
        'Your voice assistant on this phone. Ask questions, set reminders, '
        'call people, open apps — and say "Hey Jarvis" to wake it.',
  ),
  const _OnboardingStep(
    icon: Icons.checklist,
    title: 'What Jarvis can do',
    body:
        '• Answer questions (needs your free Gemini key)\n'
        '• Reminders that fire even after a restart\n'
        '• Calls, timers, alarms, flashlight, volume\n'
        '• Calendar, expenses, network and battery screens\n'
        '• A floating bubble to talk from any app\n\n'
        'Everything stays on this phone unless you connect a service.',
  ),
  _OnboardingStep(
    icon: Icons.key,
    title: 'Gemini API key',
    body:
        'AI answers need a free Gemini key from Google AI Studio '
        '(aistudio.google.com). Voice commands like timers and calls '
        'work without a key. You can add it later in Settings.',
    actionLabel: 'Save key',
  ),
  _OnboardingStep(
    icon: Icons.mic,
    title: 'Microphone',
    body:
        'Jarvis needs the microphone to hear your voice commands and '
        'the "Hey Jarvis" wake word.',
    actionLabel: 'Allow microphone',
    onAction: () => _requestPermission(Permission.microphone),
  ),
  _OnboardingStep(
    icon: Icons.notifications,
    title: 'Notifications',
    body:
        'So reminders can reach you even when the app is closed or '
        'the phone has just restarted.',
    actionLabel: 'Allow notifications',
    onAction: () => _requestPermission(Permission.notification),
  ),
  _OnboardingStep(
    icon: Icons.bubble_chart,
    title: 'Floating bubble',
    body:
        'Lets Jarvis show a small bubble over other apps — tap it to '
        'talk without opening the app. This is the "Draw over other '
        'apps" permission. Off by default; you can switch the bubble '
        'on later in Settings.',
    actionLabel: 'Allow overlay',
    onAction: () async {
      try {
        final granted =
            await FlutterOverlayWindow.requestPermission() ?? false;
        return granted ? 'Granted' : 'Not granted';
      } catch (_) {
        return 'Could not ask — grant it later in Settings';
      }
    },
  ),
  _OnboardingStep(
    icon: Icons.bar_chart,
    title: 'Usage stats',
    body:
        'For the Telemetry screen (which apps you used most today). '
        'Android only grants this in Settings — tap below to open the '
        'Usage access page and switch Jarvis on there.',
    actionLabel: 'Open usage access',
    onAction: () =>
        _openAndroidSettings('android.settings.USAGE_ACCESS_SETTINGS'),
  ),
  _OnboardingStep(
    icon: Icons.accessibility,
    title: 'Accessibility',
    body:
        'Only needed if you want Jarvis to tap and type inside other '
        'apps for you (do-the-task actions, a later update). Nothing '
        'uses it today. You can skip this safely.',
    optional: true,
    actionLabel: 'Open accessibility settings',
    onAction: () =>
        _openAndroidSettings('android.settings.ACCESSIBILITY_SETTINGS'),
  ),
  _OnboardingStep(
    icon: Icons.calendar_month,
    title: 'Calendar',
    body:
        'So Jarvis can show today\'s events and remind you before '
        'them. Jarvis only reads your calendar — it never writes to it.',
    actionLabel: 'Allow calendar',
    onAction: () => _requestPermission(Permission.calendarFullAccess),
  ),
  _OnboardingStep(
    icon: Icons.sms,
    title: 'SMS (optional)',
    body:
        'Only for the Finance screen: reading bank SMS on this phone '
        'to log expenses automatically. Off by default, and nothing is '
        'ever uploaded. Skip unless you want it.',
    optional: true,
    actionLabel: 'Allow SMS',
    onAction: () => _requestPermission(Permission.sms),
  ),
  const _OnboardingStep(
    icon: Icons.check_circle,
    title: 'You\'re all set',
    body:
        'Say "Hey Jarvis" or tap the orb to start. Every permission '
        'you skipped can be granted later from Settings.',
  ),
];

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, required this.onFinished});

  /// Called after the final step, once the done flag is saved.
  final VoidCallback onFinished;

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _steps = _onboardingSteps();
  int _index = 0;
  String? _status;
  bool _busy = false;
  final TextEditingController _keyController = TextEditingController();

  @override
  void dispose() {
    _keyController.dispose();
    super.dispose();
  }

  _OnboardingStep get _step => _steps[_index];

  bool get _isKeyStep => _index == 2;

  bool get _isLast => _index == _steps.length - 1;

  void _next() {
    if (_isLast) {
      _finish();
      return;
    }
    setState(() {
      _index++;
      _status = null;
    });
  }

  Future<void> _finish() async {
    await const OnboardingService().markDone();
    widget.onFinished();
  }

  Future<void> _onAllow() async {
    if (_isKeyStep) {
      final key = _keyController.text.trim();
      if (key.isEmpty) {
        setState(() => _status = 'No key entered — skipped');
        return;
      }
      setState(() => _busy = true);
      try {
        await _onboardingSecureStorageChannel.invokeMethod<void>(
          'saveApiKey',
          <String, String>{'apiKey': key},
        );
        if (mounted) setState(() => _status = 'Key saved');
      } catch (_) {
        if (mounted) {
          setState(() => _status = 'Could not save the key — try in Settings');
        }
      } finally {
        if (mounted) setState(() => _busy = false);
      }
      return;
    }
    final action = _step.onAction;
    if (action == null) {
      _next();
      return;
    }
    setState(() => _busy = true);
    final status = await action();
    if (!mounted) return;
    setState(() {
      _status = status;
      _busy = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              LinearProgressIndicator(
                value: (_index + 1) / _steps.length,
                backgroundColor: Colors.grey[800],
                valueColor:
                    const AlwaysStoppedAnimation<Color>(Colors.cyan),
              ),
              const SizedBox(height: 8),
              Text(
                'Step ${_index + 1} of ${_steps.length}',
                style: const TextStyle(color: Colors.grey, fontSize: 12),
              ),
              const SizedBox(height: 32),
              Icon(_step.icon, color: Colors.cyan, size: 56),
              const SizedBox(height: 16),
              Text(
                _step.title + (_step.optional ? ' (optional)' : ''),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _step.body,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 15,
                          height: 1.5,
                        ),
                      ),
                      if (_isKeyStep) ...[
                        const SizedBox(height: 20),
                        TextField(
                          controller: _keyController,
                          obscureText: true,
                          enableSuggestions: false,
                          autocorrect: false,
                          style: const TextStyle(color: Colors.white),
                          decoration: const InputDecoration(
                            labelText: 'Gemini API key',
                            labelStyle: TextStyle(color: Colors.cyan),
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ],
                      if (_status != null) ...[
                        const SizedBox(height: 16),
                        Text(
                          _status!,
                          style: const TextStyle(
                            color: Colors.cyan,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  if (_step.actionLabel != null)
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _busy ? null : _onAllow,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.cyan,
                          foregroundColor: Colors.black,
                          padding:
                              const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: Text(_busy ? 'Working…' : _step.actionLabel!),
                      ),
                    )
                  else
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _next,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.cyan,
                          foregroundColor: Colors.black,
                          padding:
                              const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: Text(_isLast ? 'Finish' : 'Continue'),
                      ),
                    ),
                  const SizedBox(width: 12),
                  if (_step.actionLabel != null)
                    TextButton(
                      onPressed: _next,
                      child: Text(
                        _isLast
                            ? 'Finish'
                            : _status == null
                                ? 'Skip'
                                : 'Continue',
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
