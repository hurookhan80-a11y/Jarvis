// Phase 8 (v1.1.0) — F42 confirmation gate.
//
// NOTHING in this phase sends a message, places a call, or changes
// a setting without the user's explicit confirmation in that moment.
// Before a do-the-task action executes, Jarvis shows exactly what it
// is about to do on screen, speaks it, and waits for the user to say
// "yes" (or tap Confirm). "No" cancels it. No answer within
// [kConfirmationTimeout] (~15 s) cancels it too, and Jarvis says so.
//
// The gate is a pure state machine — no I/O, no timers of its own
// (main.dart owns the 15 s Timer and calls [markTimedOut] when it
// fires) — so it is unit-tested directly. The action itself is never
// stored in the gate: main.dart keeps the pending action and only
// runs it after [confirm] returns true.

/// How long Jarvis waits for a yes before cancelling (~15 s).
const Duration kConfirmationTimeout = Duration(seconds: 15);

/// What kind of do-the-task action is waiting for confirmation.
enum ConfirmationKind { message, call, alarm }

/// The gate's state. `executed` means the confirmed action ran;
/// `failed` means it ran and reported failure (see
/// [ConfirmationGate.markExecuted]).
enum ConfirmationState {
  idle,
  pending,
  confirmed,
  executed,
  failed,
  timedOut,
  cancelled,
}

/// "yes" / "no" / anything else, from one utterance.
enum ConfirmationAnswer { yes, no, other }

/// Parses a yes/no answer. Accepts English and the Roman Urdu yes/no
/// the user actually says ("haan", "ji", "nahi"). Anything else is
/// [ConfirmationAnswer.other] — the gate stays pending and Jarvis
/// re-asks, instead of guessing.
ConfirmationAnswer parseConfirmationAnswer(String utterance) {
  final text = utterance.trim().toLowerCase();
  const yesWords = <String>{
    'yes',
    'yeah',
    'yep',
    'yup',
    'haan',
    'han',
    'ha',
    'ji',
    'ji haan',
    'confirm',
    'confirmed',
    'send it',
    'send',
    'call them',
    'call',
    'do it',
    'go ahead',
    'ok',
    'okay',
    'theek hai',
    'theek',
    'bhej do',
    'kar do',
  };
  const noWords = <String>{
    'no',
    'nope',
    'nah',
    'nahi',
    'na',
    'cancel',
    'don\'t',
    'dont',
    'do not',
    'stop',
    'ruko',
    'mat karo',
    'no, cancel',
  };
  if (yesWords.contains(text)) return ConfirmationAnswer.yes;
  if (noWords.contains(text)) return ConfirmationAnswer.no;
  // "yes, send it" / "no, don't send it" — the first word decides.
  final first = text.split(RegExp(r'[\s,]+')).first;
  if (yesWords.contains(first)) return ConfirmationAnswer.yes;
  if (noWords.contains(first)) return ConfirmationAnswer.no;
  return ConfirmationAnswer.other;
}

/// One action waiting for confirmation: what Jarvis is about to do,
/// in the user's own words, shown on screen and spoken before the
/// gate opens.
class ConfirmationRequest {
  const ConfirmationRequest({
    required this.kind,
    required this.summary,
    required this.detail,
  });

  final ConfirmationKind kind;

  /// One line, e.g. 'Call Ami (03001234567)'.
  final String summary;

  /// The full thing being confirmed, e.g. the message text.
  final String detail;

  /// The prompt Jarvis speaks and shows: the summary, the detail,
  /// and the yes/no + 15 s timeout terms. Nothing is hidden.
  String get prompt {
    final action = switch (kind) {
      ConfirmationKind.message => 'Send this message',
      ConfirmationKind.call => 'Make this call',
      ConfirmationKind.alarm => 'Set this alarm',
    };
    return '$action?\n$summary\n"$detail"\n\n'
        'Say "yes" to confirm, or "no" to cancel. '
        'If you do not answer within 15 seconds I will cancel it '
        'and nothing will be sent or called.';
  }

  /// What Jarvis says when the action is cancelled (timeout or no).
  String get cancelledText {
    final what = switch (kind) {
      ConfirmationKind.message => 'The message was not sent.',
      ConfirmationKind.call => 'The call was not made.',
      ConfirmationKind.alarm => 'The alarm was not set.',
    };
    return 'Cancelled. $what';
  }
}

/// The confirmation state machine: pending → confirmed → executed
/// (or failed), pending → timedOut / cancelled. Only [confirm]
/// opens the way to execution, and only while the request is still
/// pending and inside its 15 s window.
class ConfirmationGate {
  ConfirmationRequest? _request;
  DateTime? _requestedAt;
  ConfirmationState _state = ConfirmationState.idle;

  ConfirmationRequest? get pendingRequest => _request;
  ConfirmationState get state => _state;
  bool get isPending => _state == ConfirmationState.pending;

  /// Opens the gate for [request]. Any earlier pending request is
  /// dropped (only one confirmation can be live at a time).
  void request(ConfirmationRequest request, {DateTime? now}) {
    _request = request;
    _requestedAt = now ?? DateTime.now();
    _state = ConfirmationState.pending;
  }

  /// True when the pending request's 15 s window has passed.
  bool isTimedOut({DateTime? now}) {
    if (_state != ConfirmationState.pending || _requestedAt == null) {
      return false;
    }
    return (now ?? DateTime.now()).difference(_requestedAt!) >=
        kConfirmationTimeout;
  }

  /// The user said yes. Returns true only when a request is pending
  /// and still inside its window; otherwise false and nothing is
  /// confirmed. Callers must not execute on a false return.
  bool confirm({DateTime? now}) {
    if (_state != ConfirmationState.pending) return false;
    if (isTimedOut(now: now)) {
      _state = ConfirmationState.timedOut;
      return false;
    }
    _state = ConfirmationState.confirmed;
    return true;
  }

  /// The user said no. Returns true only when a request was pending.
  bool decline() {
    if (_state != ConfirmationState.pending) return false;
    _state = ConfirmationState.cancelled;
    return true;
  }

  /// The 15 s timer fired with no answer. Returns true only when a
  /// request was pending.
  bool markTimedOut() {
    if (_state != ConfirmationState.pending) return false;
    _state = ConfirmationState.timedOut;
    return true;
  }

  /// The confirmed action ran. [success] is the action's own honest
  /// result (sent / opened / could not …), never assumed.
  void markExecuted(bool success) {
    if (_state != ConfirmationState.confirmed) return;
    _state = success ? ConfirmationState.executed : ConfirmationState.failed;
  }

  /// Drops the pending request (STOP pressed, or a new command
  /// superseded it). Returns true only when a request was pending.
  bool cancel() {
    if (_state != ConfirmationState.pending) return false;
    _state = ConfirmationState.cancelled;
    return true;
  }

  /// Clears the gate back to idle (after the result has been
  /// reported). Safe to call in any state.
  void reset() {
    _request = null;
    _requestedAt = null;
    _state = ConfirmationState.idle;
  }
}
