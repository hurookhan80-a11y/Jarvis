// v1.2.0 (Jarvis 2.0 free ideas) — the screens behind the ⋮ menu
// entries and the voice commands: Usage dashboard (G11), Workflows
// (G4/G5/G12), Google Workspace (G1–G3) and Notion (G9).
//
// These screens are theme-aware on purpose: they use Theme.of(context)
// colours only, so the G15 light mode recolours them with the rest of
// the app. No hard-coded dark colours here.

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'google_workspace_service.dart';
import 'notion_service.dart';
import 'scheduled_workflow_service.dart';
import 'usage_stats_service.dart';
import 'workflow_service.dart';

const _weekdayNames = <String>[
  'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'
];

String _formatWeekdays(Set<int> weekdays) {
  if (weekdays.isEmpty) return 'Every day';
  final sorted = weekdays.toList()..sort();
  return sorted.map((d) => _weekdayNames[d - 1]).join(', ');
}

String _formatTime(int hour, int minute) {
  final h = hour % 12 == 0 ? 12 : hour % 12;
  final amPm = hour < 12 ? 'am' : 'pm';
  return '$h:${minute.toString().padLeft(2, '0')} $amPm';
}

/// G11: on-device usage dashboard — all-time totals plus the last 7
/// days. Nothing leaves the phone.
class UsageDashboardScreen extends StatefulWidget {
  const UsageDashboardScreen({super.key, required this.usageStatsService});

  final UsageStatsService usageStatsService;

  @override
  State<UsageDashboardScreen> createState() => _UsageDashboardScreenState();
}

class _UsageDashboardScreenState extends State<UsageDashboardScreen> {
  Future<UsageDashboardData>? _future;

  @override
  void initState() {
    super.initState();
    _future = widget.usageStatsService.loadDashboard();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Usage dashboard')),
      body: FutureBuilder<UsageDashboardData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snapshot.data;
          if (data == null) {
            return const Center(
                child: Text('Could not load the usage stats.'));
          }
          return ListView(
            children: [
              const ListTile(
                title: Text('All time',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              ListTile(
                  title: const Text('Conversations'),
                  trailing: Text('${data.totalConversations}')),
              ListTile(
                  title: const Text('Messages spoken'),
                  trailing: Text('${data.totalMessagesSpoken}')),
              ListTile(
                  title: const Text('Reminders fired'),
                  trailing: Text('${data.totalRemindersFired}')),
              ListTile(
                  title: const Text('Tasks done'),
                  trailing: Text('${data.totalTasksDone}')),
              ListTile(
                  title: const Text('Tasks failed'),
                  trailing: Text('${data.totalTasksFailed}')),
              const Divider(),
              const ListTile(
                title: Text('Last 7 days',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              ...data.last7Days.map((day) {
                final label = DateFormat('EEE d MMM').format(day.date);
                return ListTile(
                  title: Text(label),
                  subtitle: Text(
                      '${day.conversations} chats • ${day.messagesSpoken} spoken • ${day.remindersFired} reminders • ${day.tasksDone} tasks done • ${day.tasksFailed} failed'),
                );
              }),
              Padding(
                padding: const EdgeInsets.all(16),
                child: OutlinedButton(
                  onPressed: () async {
                    await widget.usageStatsService.clearAll();
                    if (!mounted) return;
                    setState(() {
                      _future = widget.usageStatsService.loadDashboard();
                    });
                  },
                  child: const Text('Clear usage stats'),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// G4/G5/G12: named multi-step workflows (run, delete, autonomy)
/// plus their schedules (add, enable/disable, delete).
class WorkflowsScreen extends StatefulWidget {
  const WorkflowsScreen({
    super.key,
    required this.workflowService,
    required this.scheduledWorkflowService,
    required this.onRunWorkflow,
  });

  final WorkflowService workflowService;
  final ScheduledWorkflowService scheduledWorkflowService;
  final Future<void> Function(WorkflowTemplate template) onRunWorkflow;

  @override
  State<WorkflowsScreen> createState() => _WorkflowsScreenState();
}

class _WorkflowsScreenState extends State<WorkflowsScreen> {
  List<WorkflowTemplate> _templates = [];
  Set<String> _savedIds = {};
  List<ScheduledWorkflow> _scheduled = [];
  bool _loading = true;
  String _status = '';

  final _nameController = TextEditingController();
  final _stepsController = TextEditingController();
  WorkflowAutonomy _newAutonomy = WorkflowAutonomy.askFirst;

  WorkflowTemplate? _scheduleWorkflow;
  TimeOfDay _scheduleTime = const TimeOfDay(hour: 7, minute: 0);
  final Set<int> _scheduleWeekdays = {};

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _stepsController.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    final saved = await widget.workflowService.loadTemplates();
    final scheduled = await widget.scheduledWorkflowService.loadScheduled();
    if (!mounted) return;
    setState(() {
      _templates = <WorkflowTemplate>[
        ...widget.workflowService.builtInTemplates(),
        ...saved,
      ];
      _savedIds = saved.map((t) => t.id).toSet();
      _scheduled = scheduled;
      _loading = false;
    });
  }

  Future<void> _addWorkflow() async {
    final name = _nameController.text.trim();
    final steps = _stepsController.text
        .split('\n')
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();
    if (name.isEmpty || steps.isEmpty) {
      setState(() => _status = 'Give the workflow a name and at least one step.');
      return;
    }
    final template = WorkflowTemplate(
      id: 'user-${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      description: 'Added in the app',
      steps: steps,
      autonomy: _newAutonomy,
      createdAt: DateTime.now(),
    );
    final saved = await widget.workflowService.saveTemplate(template);
    if (!mounted) return;
    if (saved == null) {
      setState(() => _status = 'Could not save — the 50-workflow limit may be reached.');
      return;
    }
    _nameController.clear();
    _stepsController.clear();
    setState(() => _status = 'Saved "$name".');
    await _reload();
  }

  Future<void> _changeAutonomy(
      WorkflowTemplate template, WorkflowAutonomy autonomy) async {
    final updated = WorkflowTemplate(
      id: template.id,
      name: template.name,
      description: template.description,
      steps: template.steps,
      autonomy: autonomy,
      createdAt: template.createdAt,
    );
    await widget.workflowService.saveTemplate(updated);
    await _reload();
  }

  Future<void> _deleteTemplate(WorkflowTemplate template) async {
    await widget.workflowService.deleteTemplate(template.id);
    await _reload();
  }

  Future<void> _addSchedule() async {
    final template = _scheduleWorkflow;
    if (template == null) {
      setState(() => _status = 'Pick a workflow to schedule first.');
      return;
    }
    final entry = ScheduledWorkflow(
      id: '',
      workflowId: template.id,
      hour: _scheduleTime.hour,
      minute: _scheduleTime.minute,
      weekdays: Set<int>.from(_scheduleWeekdays),
    );
    final saved = await widget.scheduledWorkflowService.saveScheduled(entry);
    if (!mounted) return;
    if (saved == null) {
      setState(() => _status =
          'Could not save that schedule — the 20-schedule limit may be reached.');
      return;
    }
    await widget.scheduledWorkflowService
        .scheduleNotification(saved, template.name);
    setState(() => _status =
        'Scheduled "${template.name}" for ${_formatTime(saved.hour, saved.minute)} (${_formatWeekdays(saved.weekdays)}).');
    await _reload();
  }

  Future<void> _deleteSchedule(ScheduledWorkflow entry) async {
    await widget.scheduledWorkflowService.cancelNotification(entry.id);
    await widget.scheduledWorkflowService.deleteScheduled(entry.id);
    await _reload();
  }

  Future<void> _toggleSchedule(ScheduledWorkflow entry, bool enabled) async {
    final updated = ScheduledWorkflow(
      id: entry.id,
      workflowId: entry.workflowId,
      hour: entry.hour,
      minute: entry.minute,
      weekdays: entry.weekdays,
      enabled: enabled,
      lastRun: entry.lastRun,
    );
    final saved = await widget.scheduledWorkflowService.saveScheduled(updated);
    if (saved != null && enabled) {
      final template = _templates
          .where((t) => t.id == entry.workflowId)
          .firstOrNull;
      if (template != null) {
        await widget.scheduledWorkflowService
            .scheduleNotification(saved, template.name);
      }
    }
    await _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Workflows')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (_status.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(_status,
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.primary)),
                  ),
                const Text('Workflows',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ..._templates.map((template) {
                  final isSaved = _savedIds.contains(template.id);
                  return Card(
                    child: ListTile(
                      title: Text(template.name),
                      subtitle: Text(
                          '${template.description}\n${template.steps.length} steps • ${template.autonomy == WorkflowAutonomy.autonomous ? 'runs on its own' : 'asks first'}'),
                      isThreeLine: true,
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.play_arrow),
                            tooltip: 'Run',
                            onPressed: () =>
                                widget.onRunWorkflow(template),
                          ),
                          if (isSaved)
                            IconButton(
                              icon: const Icon(Icons.delete),
                              tooltip: 'Delete',
                              onPressed: () => _deleteTemplate(template),
                            ),
                        ],
                      ),
                      onTap: () {
                        final next = template.autonomy ==
                                WorkflowAutonomy.askFirst
                            ? WorkflowAutonomy.autonomous
                            : WorkflowAutonomy.askFirst;
                        _changeAutonomy(template, next);
                      },
                    ),
                  );
                }),
                const SizedBox(height: 16),
                const Text('Add a workflow',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                      labelText: 'Name', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _stepsController,
                  maxLines: 4,
                  decoration: const InputDecoration(
                      labelText: 'Steps (one per line)',
                      border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                DropdownButton<WorkflowAutonomy>(
                  value: _newAutonomy,
                  items: const [
                    DropdownMenuItem(
                        value: WorkflowAutonomy.askFirst,
                        child: Text('Ask me first')),
                    DropdownMenuItem(
                        value: WorkflowAutonomy.autonomous,
                        child: Text('Run fully on its own')),
                  ],
                  onChanged: (v) {
                    if (v != null) setState(() => _newAutonomy = v);
                  },
                ),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _addWorkflow,
                  child: const Text('Save workflow'),
                ),
                const SizedBox(height: 8),
                const Text(
                    'Tap a workflow to flip ask-first / run-on-its-own.',
                    style: TextStyle(fontSize: 12)),
                const Divider(height: 32),
                const Text('Schedules',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ..._scheduled.map((entry) {
                  final template = _templates
                      .where((t) => t.id == entry.workflowId)
                      .firstOrNull;
                  final name = template?.name ?? entry.workflowId;
                  final next = nextRunAfter(entry, DateTime.now());
                  return Card(
                    child: SwitchListTile(
                      title: Text(name),
                      subtitle: Text(
                          '${_formatTime(entry.hour, entry.minute)} • ${_formatWeekdays(entry.weekdays)}${next == null ? '' : '\nNext: ${DateFormat('EEE d MMM, h:mm a').format(next)}'}'),
                      value: entry.enabled,
                      onChanged: (v) => _toggleSchedule(entry, v),
                      secondary: IconButton(
                        icon: const Icon(Icons.delete),
                        tooltip: 'Delete schedule',
                        onPressed: () => _deleteSchedule(entry),
                      ),
                    ),
                  );
                }),
                const SizedBox(height: 16),
                const Text('Add a schedule',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                DropdownButton<WorkflowTemplate>(
                  value: _scheduleWorkflow,
                  hint: const Text('Pick a workflow'),
                  isExpanded: true,
                  items: _templates
                      .map((t) => DropdownMenuItem(
                          value: t, child: Text(t.name)))
                      .toList(),
                  onChanged: (v) => setState(() => _scheduleWorkflow = v),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    OutlinedButton(
                      onPressed: () async {
                        final picked = await showTimePicker(
                          context: context,
                          initialTime: _scheduleTime,
                        );
                        if (picked != null) {
                          setState(() => _scheduleTime = picked);
                        }
                      },
                      child: Text(
                          'Time: ${_scheduleTime.format(context)}'),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: List.generate(7, (i) {
                    final day = i + 1;
                    final selected = _scheduleWeekdays.contains(day);
                    return ChoiceChip(
                      label: Text(_weekdayNames[i]),
                      selected: selected,
                      onSelected: (v) {
                        setState(() {
                          if (v) {
                            _scheduleWeekdays.add(day);
                          } else {
                            _scheduleWeekdays.remove(day);
                          }
                        });
                      },
                    );
                  }),
                ),
                const Text('No days picked means every day.',
                    style: TextStyle(fontSize: 12)),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _addSchedule,
                  child: const Text('Save schedule'),
                ),
                const SizedBox(height: 8),
                const Text(
                    'When the app is closed, a due workflow only sends a notification — open Jarvis to run it. While Jarvis is open, due workflows run (or ask first) on their own.',
                    style: TextStyle(fontSize: 12)),
              ],
            ),
    );
  }
}

/// G1–G3: Google Workspace — enable switch + token entry, plus quick
/// create-doc / create-sheet / drive-search actions. The token is
/// the user's own OAuth access token, pasted here (never in code);
/// it lasts about an hour.
class GoogleWorkspaceScreen extends StatefulWidget {
  const GoogleWorkspaceScreen({super.key, required this.service});

  final GoogleWorkspaceService service;

  @override
  State<GoogleWorkspaceScreen> createState() => _GoogleWorkspaceScreenState();
}

class _GoogleWorkspaceScreenState extends State<GoogleWorkspaceScreen> {
  bool _enabled = false;
  bool _loading = true;
  String _status = '';
  List<DriveFile> _driveResults = [];

  final _tokenController = TextEditingController();
  final _docTitleController = TextEditingController();
  final _docTextController = TextEditingController();
  final _sheetTitleController = TextEditingController();
  final _driveQueryController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _tokenController.dispose();
    _docTitleController.dispose();
    _docTextController.dispose();
    _sheetTitleController.dispose();
    _driveQueryController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final enabled = await widget.service.isEnabled();
    if (!mounted) return;
    setState(() {
      _enabled = enabled;
      _loading = false;
    });
  }

  void _showError(Object e) {
    final message = e is GoogleWorkspaceException
        ? e.message
        : 'Something went wrong — check your internet connection.';
    setState(() => _status = message);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Google Workspace')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                SwitchListTile(
                  title: const Text('Google Workspace'),
                  subtitle: const Text(
                      'Docs, Sheets, Drive, Calendar and Gmail by voice. Needs your own Google OAuth access token (scopes: documents, spreadsheets, drive.file, calendar.events, gmail.compose). Tokens last about an hour.'),
                  value: _enabled,
                  onChanged: (v) async {
                    await widget.service.setEnabled(v);
                    final now = await widget.service.isEnabled();
                    if (!mounted) return;
                    setState(() {
                      _enabled = now;
                      if (v && !now) {
                        _status =
                            'Could not switch on — paste a token first, then switch on.';
                      } else {
                        _status = '';
                      }
                    });
                  },
                ),
                TextField(
                  controller: _tokenController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Google OAuth access token (paste it here)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    final token = _tokenController.text.trim();
                    if (token.isEmpty) {
                      setState(
                          () => _status = 'Paste a token first.');
                      return;
                    }
                    await widget.service.saveToken(token);
                    _tokenController.clear();
                    if (!mounted) return;
                    setState(() => _status = 'Token saved.');
                  },
                  child: const Text('Save token'),
                ),
                if (_status.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(_status,
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.primary)),
                  ),
                const Divider(height: 32),
                const Text('Create a Google Doc',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  controller: _docTitleController,
                  decoration: const InputDecoration(
                      labelText: 'Title', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _docTextController,
                  maxLines: 4,
                  decoration: const InputDecoration(
                      labelText: 'Text (optional)',
                      border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    final title = _docTitleController.text.trim();
                    if (title.isEmpty) {
                      setState(() => _status = 'Give the document a title.');
                      return;
                    }
                    try {
                      final id = await widget.service.createDoc(
                        title: title,
                        text: _docTextController.text,
                      );
                      if (!mounted) return;
                      setState(() => _status =
                          'Created "$title".\nhttps://docs.google.com/document/d/$id/edit');
                    } catch (e) {
                      if (mounted) _showError(e);
                    }
                  },
                  child: const Text('Create doc'),
                ),
                const Divider(height: 32),
                const Text('Create a Google Sheet',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  controller: _sheetTitleController,
                  decoration: const InputDecoration(
                      labelText: 'Title', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    final title = _sheetTitleController.text.trim();
                    if (title.isEmpty) {
                      setState(() => _status = 'Give the sheet a title.');
                      return;
                    }
                    try {
                      final id = await widget.service
                          .createSheet(title: title);
                      if (!mounted) return;
                      setState(() => _status =
                          'Created "$title".\nhttps://docs.google.com/spreadsheets/d/$id/edit');
                    } catch (e) {
                      if (mounted) _showError(e);
                    }
                  },
                  child: const Text('Create sheet'),
                ),
                const Divider(height: 32),
                const Text('Search Drive',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  controller: _driveQueryController,
                  decoration: const InputDecoration(
                      labelText: 'File name',
                      border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    final query = _driveQueryController.text.trim();
                    if (query.isEmpty) return;
                    try {
                      final files = await widget.service
                          .searchDriveFiles(query);
                      if (!mounted) return;
                      setState(() {
                        _driveResults = files;
                        _status = files.isEmpty
                            ? 'Nothing in Drive matched "$query".'
                            : '';
                      });
                    } catch (e) {
                      if (mounted) _showError(e);
                    }
                  },
                  child: const Text('Search'),
                ),
                ..._driveResults.map((f) => ListTile(
                      title: Text(f.name),
                      subtitle: Text(f.mimeType),
                    )),
              ],
            ),
    );
  }
}

/// G9: Notion — enable switch + token entry, plus search / read /
/// append actions. The token is the user's own free Notion
/// integration token, pasted here (never in code).
class NotionScreen extends StatefulWidget {
  const NotionScreen({super.key, required this.service});

  final NotionService service;

  @override
  State<NotionScreen> createState() => _NotionScreenState();
}

class _NotionScreenState extends State<NotionScreen> {
  bool _enabled = false;
  bool _loading = true;
  String _status = '';
  String _pageText = '';
  List<NotionPage> _searchResults = [];

  final _tokenController = TextEditingController();
  final _searchController = TextEditingController();
  final _readIdController = TextEditingController();
  final _appendIdController = TextEditingController();
  final _appendTextController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _tokenController.dispose();
    _searchController.dispose();
    _readIdController.dispose();
    _appendIdController.dispose();
    _appendTextController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final enabled = await widget.service.isEnabled();
    if (!mounted) return;
    setState(() {
      _enabled = enabled;
      _loading = false;
    });
  }

  void _showError(Object e) {
    final message = e is NotionException
        ? e.message
        : 'Something went wrong — check your internet connection.';
    setState(() => _status = message);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notion')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                SwitchListTile(
                  title: const Text('Notion'),
                  subtitle: const Text(
                      'Search, read and append Notion pages by voice. Needs your own free Notion integration token — create one at notion.so/my-integrations and share the pages with it.'),
                  value: _enabled,
                  onChanged: (v) async {
                    await widget.service.setEnabled(v);
                    final now = await widget.service.isEnabled();
                    if (!mounted) return;
                    setState(() {
                      _enabled = now;
                      if (v && !now) {
                        _status =
                            'Could not switch on — paste a token first, then switch on.';
                      } else {
                        _status = '';
                      }
                    });
                  },
                ),
                TextField(
                  controller: _tokenController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Notion integration token (paste it here)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    final token = _tokenController.text.trim();
                    if (token.isEmpty) {
                      setState(() => _status = 'Paste a token first.');
                      return;
                    }
                    await widget.service.saveToken(token);
                    _tokenController.clear();
                    if (!mounted) return;
                    setState(() => _status = 'Token saved.');
                  },
                  child: const Text('Save token'),
                ),
                if (_status.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(_status,
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.primary)),
                  ),
                const Divider(height: 32),
                const Text('Search pages',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(
                      labelText: 'Search', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    final query = _searchController.text.trim();
                    if (query.isEmpty) return;
                    try {
                      final pages =
                          await widget.service.searchPages(query);
                      if (!mounted) return;
                      setState(() {
                        _searchResults = pages;
                        _status = pages.isEmpty
                            ? 'Nothing in Notion matched "$query".'
                            : '';
                      });
                    } catch (e) {
                      if (mounted) _showError(e);
                    }
                  },
                  child: const Text('Search'),
                ),
                ..._searchResults.map((p) => ListTile(
                      title: Text(p.title),
                      subtitle: Text(p.id),
                    )),
                const Divider(height: 32),
                const Text('Read a page',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  controller: _readIdController,
                  decoration: const InputDecoration(
                      labelText: 'Page id', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    final id = _readIdController.text.trim();
                    if (id.isEmpty) return;
                    try {
                      final text =
                          await widget.service.readPage(pageId: id);
                      if (!mounted) return;
                      setState(() {
                        _pageText = text;
                        _status = '';
                      });
                    } catch (e) {
                      if (mounted) _showError(e);
                    }
                  },
                  child: const Text('Read page'),
                ),
                if (_pageText.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(_pageText),
                  ),
                const Divider(height: 32),
                const Text('Append to a page',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(
                  controller: _appendIdController,
                  decoration: const InputDecoration(
                      labelText: 'Page id', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _appendTextController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                      labelText: 'Text to add',
                      border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    final id = _appendIdController.text.trim();
                    final text = _appendTextController.text.trim();
                    if (id.isEmpty || text.isEmpty) {
                      setState(() =>
                          _status = 'Give both a page id and some text.');
                      return;
                    }
                    try {
                      await widget.service
                          .appendToPage(pageId: id, text: text);
                      if (!mounted) return;
                      setState(() => _status = 'Added to the page.');
                    } catch (e) {
                      if (mounted) _showError(e);
                    }
                  },
                  child: const Text('Append'),
                ),
              ],
            ),
    );
  }
}
