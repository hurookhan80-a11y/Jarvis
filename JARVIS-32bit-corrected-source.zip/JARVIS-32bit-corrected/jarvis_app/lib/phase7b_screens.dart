// Phase 7 (v1.1.0) — screens for F33/F35/F37/F39.
//
//   MacrosScreen   — F33: list macros, run one, delete one.
//   FormsScreen    — F35: saved form drafts, view/copy/delete.
//   CommuteScreen  — F37: saved places + a route lookup (distance,
//                    ETA, mode) over free OSRM/Nominatim.
//   ShizukuScreen  — F39: Shizuku status, authorisation, and the
//                    allowlisted controls (off by default).
//
// All data stays on this phone. The screens take their services as
// constructor arguments so the home screen stays the only place that
// wires them together.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'commute_service.dart';
import 'form_draft_service.dart';
import 'macro_service.dart';
import 'shizuku_service.dart';

const _screenBackground = Colors.black;
const _screenAccent = Colors.cyan;

Widget _emptyNote(String text) => Center(
  child: Padding(
    padding: const EdgeInsets.all(24.0),
    child: Text(
      text,
      textAlign: TextAlign.center,
      style: const TextStyle(color: Colors.grey),
    ),
  ),
);

Future<bool> _confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'Delete',
}) async {
  final confirm = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      backgroundColor: Colors.grey[900],
      title: Text(title, style: const TextStyle(color: Colors.white)),
      content: Text(message, style: const TextStyle(color: Colors.white70)),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(true),
          child: Text(
            confirmLabel,
            style: const TextStyle(color: Colors.redAccent),
          ),
        ),
      ],
    ),
  );
  return confirm == true;
}

/// F33: macros — list, run, delete. Recording itself is by voice
/// ("record macro morning routine" … "stop recording"), because a
/// macro is a sequence of spoken commands; the screen shows what
/// was recorded and runs it on tap.
class MacrosScreen extends StatefulWidget {
  const MacrosScreen({
    super.key,
    required this.macroService,
    required this.onRunMacro,
  });

  final MacroService macroService;

  /// Runs the macro (main.dart: each step through processQuery, with
  /// the per-step report). The screen closes first so the chat shows
  /// the run.
  final Future<void> Function(Macro macro) onRunMacro;

  @override
  State<MacrosScreen> createState() => _MacrosScreenState();
}

class _MacrosScreenState extends State<MacrosScreen> {
  List<Macro> _macros = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final macros = await widget.macroService.loadMacros();
    if (mounted) {
      setState(() {
        _macros = macros;
        _loading = false;
      });
    }
  }

  Future<void> _delete(Macro macro) async {
    final confirm = await _confirmDialog(
      context,
      title: 'Delete macro?',
      message: '"${macro.name}" and its ${macro.steps.length} steps will be deleted.',
    );
    if (!confirm) return;
    await widget.macroService.deleteMacro(macro.name);
    _reload();
  }

  Future<void> _run(Macro macro) async {
    Navigator.of(context).pop();
    await widget.onRunMacro(macro);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Macros'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : _macros.isEmpty
          ? _emptyNote(
              'No macros yet.\n\nSay "record macro morning routine", then say the commands one by one, then say "stop recording". Say "run morning routine" to replay it.',
            )
          : ListView.builder(
              itemCount: _macros.length,
              itemBuilder: (context, index) {
                final macro = _macros[index];
                return Card(
                  color: Colors.grey[900],
                  child: ListTile(
                    leading: const Icon(Icons.playlist_play, color: Colors.cyan),
                    title: Text(
                      macro.name,
                      style: const TextStyle(color: Colors.white),
                    ),
                    subtitle: Text(
                      macro.steps.map((s) => '• $s').join('\n'),
                      style: const TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                    isThreeLine: macro.steps.length > 1,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.play_arrow, color: Colors.cyan),
                          tooltip: 'Run macro',
                          onPressed: () => _run(macro),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.redAccent),
                          tooltip: 'Delete macro',
                          onPressed: () => _delete(macro),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

/// F35: saved form drafts — view the finished text, copy it, or
/// delete it. Drafts are created by voice ("help me fill a leave
/// application"); nothing here submits anything anywhere.
class FormsScreen extends StatefulWidget {
  const FormsScreen({super.key, required this.formDraftService});

  final FormDraftService formDraftService;

  @override
  State<FormsScreen> createState() => _FormsScreenState();
}

class _FormsScreenState extends State<FormsScreen> {
  List<FormDraft> _drafts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final drafts = await widget.formDraftService.loadDrafts();
    if (mounted) {
      setState(() {
        _drafts = drafts;
        _loading = false;
      });
    }
  }

  Future<void> _delete(FormDraft draft) async {
    final confirm = await _confirmDialog(
      context,
      title: 'Delete draft?',
      message: '"${draft.title}" will be deleted from this phone.',
    );
    if (!confirm) return;
    await widget.formDraftService.deleteDraft(draft.id);
    _reload();
  }

  void _view(FormDraft draft) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: Text(draft.title, style: const TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: SelectableText(
            draft.body,
            style: const TextStyle(color: Colors.white70, fontSize: 14),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: draft.body));
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Draft copied.')),
              );
            },
            child: const Text('Copy', style: TextStyle(color: Colors.cyan)),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close', style: TextStyle(color: Colors.white70)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Form drafts'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : _drafts.isEmpty
          ? _emptyNote(
              'No form drafts yet.\n\nSay "help me fill a leave application" and answer each question — the finished draft appears here to copy or share.',
            )
          : ListView.builder(
              itemCount: _drafts.length,
              itemBuilder: (context, index) {
                final draft = _drafts[index];
                return Card(
                  color: Colors.grey[900],
                  child: ListTile(
                    leading: const Icon(Icons.description, color: Colors.cyan),
                    title: Text(
                      draft.title,
                      style: const TextStyle(color: Colors.white),
                    ),
                    subtitle: Text(
                      DateFormat.yMMMd().add_jm().format(draft.createdAt),
                      style: const TextStyle(color: Colors.grey),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.copy, color: Colors.cyan),
                          tooltip: 'Copy draft',
                          onPressed: () {
                            Clipboard.setData(ClipboardData(text: draft.body));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Draft copied.')),
                            );
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.redAccent),
                          tooltip: 'Delete draft',
                          onPressed: () => _delete(draft),
                        ),
                      ],
                    ),
                    onTap: () => _view(draft),
                  ),
                );
              },
            ),
    );
  }
}

/// F37: commute — saved places plus a route lookup. Distance + ETA
/// come from free OSRM/Nominatim (no key, no live traffic). The
/// start point is the phone's last known location, or a place typed
/// here when that is unavailable.
class CommuteScreen extends StatefulWidget {
  const CommuteScreen({super.key, required this.commuteService});

  final CommuteService commuteService;

  @override
  State<CommuteScreen> createState() => _CommuteScreenState();
}

class _CommuteScreenState extends State<CommuteScreen> {
  final TextEditingController _fromController = TextEditingController();
  final TextEditingController _toController = TextEditingController();
  CommuteMode _mode = CommuteMode.driving;
  String? _result;
  String? _error;
  bool _lookingUp = false;
  Map<String, LatLng> _places = {};

  @override
  void initState() {
    super.initState();
    _loadPlaces();
  }

  @override
  void dispose() {
    _fromController.dispose();
    _toController.dispose();
    super.dispose();
  }

  Future<void> _loadPlaces() async {
    final places = await widget.commuteService.loadSavedPlaces();
    if (mounted) setState(() => _places = places);
  }

  Future<void> _lookup() async {
    final fromText = _fromController.text.trim();
    final toText = _toController.text.trim();
    if (toText.isEmpty) {
      setState(() => _error = 'Enter a destination first.');
      return;
    }
    setState(() {
      _lookingUp = true;
      _result = null;
      _error = null;
    });
    LatLng? from;
    if (fromText.isEmpty) {
      from = await widget.commuteService.getLastKnownLocation();
      if (from == null) {
        if (mounted) {
          setState(() {
            _lookingUp = false;
            _error =
                'Could not read this phone\'s location. Type a starting place instead.';
          });
        }
        return;
      }
    } else {
      from = await widget.commuteService.geocode(fromText);
    }
    final to = await widget.commuteService.geocode(toText);
    if (from == null || to == null) {
      if (mounted) {
        setState(() {
          _lookingUp = false;
          _error = from == null
              ? 'Could not find the starting place.'
              : 'Could not find "$toText". Check the spelling and try again.';
        });
      }
      return;
    }
    final route = await widget.commuteService.getRoute(from, to, _mode);
    if (!mounted) return;
    // Copy into locals: `from`/`to` are nullable and promotion does
    // not survive into the setState closure below.
    final start = from;
    final dest = to;
    setState(() {
      _lookingUp = false;
      if (route == null) {
        _error = 'Routing failed. Check the internet connection and try again.';
      } else {
        _result = widget.commuteService.formatRouteSummary(
          fromLabel: start.label.isEmpty ? 'your location' : start.label,
          toLabel: dest.label.isEmpty ? toText : dest.label,
          route: route,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Commute'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text(
            'Free routing (OSRM + Nominatim) — no key, no live traffic. Say "how long to Faisalabad Medical University?" for the same answer by voice.',
            style: TextStyle(color: Colors.grey, fontSize: 12),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _fromController,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              labelText: 'From (leave empty for this phone\'s location)',
              labelStyle: TextStyle(color: Colors.cyan),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _toController,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              labelText: 'To (e.g. Faisalabad Medical University)',
              labelStyle: TextStyle(color: Colors.cyan),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<CommuteMode>(
            value: _mode,
            dropdownColor: Colors.grey[900],
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              labelText: 'Mode',
              labelStyle: TextStyle(color: Colors.cyan),
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: CommuteMode.driving, child: Text('Driving')),
              DropdownMenuItem(value: CommuteMode.walking, child: Text('Walking')),
              DropdownMenuItem(value: CommuteMode.cycling, child: Text('Cycling')),
            ],
            onChanged: (v) {
              if (v != null) setState(() => _mode = v);
            },
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _lookingUp ? null : _lookup,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.cyan,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: Text(_lookingUp ? 'Looking up…' : 'How long?'),
          ),
          if (_result != null) ...[
            const SizedBox(height: 16),
            Text(_result!, style: const TextStyle(color: Colors.white, fontSize: 16)),
          ],
          if (_error != null) ...[
            const SizedBox(height: 16),
            Text(_error!, style: const TextStyle(color: Colors.orangeAccent)),
          ],
          const SizedBox(height: 24),
          const Text(
            'Saved places',
            style: TextStyle(color: _screenAccent, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          if (_places.isEmpty)
            const Text(
              'No saved places yet. Places you look up by voice are saved automatically when Jarvis finds them, so next time "FMU" needs no network lookup.',
              style: TextStyle(color: Colors.grey, fontSize: 13),
            )
          else
            for (final entry in _places.entries)
              ListTile(
                leading: const Icon(Icons.place, color: Colors.cyan),
                title: Text(entry.value.label, style: const TextStyle(color: Colors.white)),
                subtitle: Text(
                  '${entry.value.lat.toStringAsFixed(4)}, ${entry.value.lon.toStringAsFixed(4)}',
                  style: const TextStyle(color: Colors.grey),
                ),
                trailing: TextButton(
                  onPressed: () {
                    _toController.text = entry.value.label;
                  },
                  child: const Text('Use', style: TextStyle(color: Colors.cyan)),
                ),
              ),
        ],
      ),
    );
  }
}

/// F39: Shizuku — status, authorisation, and the allowlisted
/// controls. Everything is off and inert until Shizuku is installed,
/// running, and authorised; the screen says which step is missing.
class ShizukuScreen extends StatefulWidget {
  const ShizukuScreen({
    super.key,
    required this.shizukuService,
    required this.onForceStopApp,
  });

  final ShizukuService shizukuService;

  /// Resolves a spoken app name to a package and force-stops it
  /// (main.dart, which owns the connected-apps map). The screen
  /// closes first so the chat shows the result.
  final Future<void> Function(String appName) onForceStopApp;

  @override
  State<ShizukuScreen> createState() => _ShizukuScreenState();
}

class _ShizukuScreenState extends State<ShizukuScreen> {
  ShizukuStatus _status = ShizukuStatus.unknown;
  bool _enabled = false;
  bool _loading = true;
  bool _working = false;
  final TextEditingController _appController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _appController.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    final enabled = await widget.shizukuService.isEnabled();
    final status = await widget.shizukuService.getStatus();
    if (mounted) {
      setState(() {
        _enabled = enabled;
        _status = status;
        _loading = false;
      });
    }
  }

  String _statusText(ShizukuStatus status) {
    switch (status) {
      case ShizukuStatus.notInstalled:
        return 'Shizuku is not installed. Install the free Shizuku app from the Play Store, then start it with wireless debugging.';
      case ShizukuStatus.notRunning:
        return 'Shizuku is installed but its service is not running. Open the Shizuku app and start it (wireless debugging), then come back here.';
      case ShizukuStatus.notAuthorised:
        return 'Shizuku is running, but Jarvis is not authorised yet. Tap "Authorise Jarvis" below and allow it in the Shizuku dialog.';
      case ShizukuStatus.ready:
        return 'Shizuku is ready. The controls below will run.';
      case ShizukuStatus.unknown:
        return 'Could not check Shizuku right now. Try refreshing.';
    }
  }

  Future<void> _toggleEnabled(bool value) async {
    await widget.shizukuService.setEnabled(value);
    if (mounted) setState(() => _enabled = value);
  }

  Future<void> _authorise() async {
    setState(() => _working = true);
    final granted = await widget.shizukuService.requestAuthorisation();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            granted ? 'Jarvis is authorised in Shizuku.' : 'Not authorised — allow Jarvis in the Shizuku dialog and try again.',
          ),
        ),
      );
    }
    await _reload();
    if (mounted) setState(() => _working = false);
  }

  Future<void> _toggleMobileData(bool enable) async {
    setState(() => _working = true);
    final output = await widget.shizukuService.runControl(
      ShizukuControl.toggleMobileData,
      enable: enable,
    );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            output == null
                ? 'Mobile data could not be changed — Shizuku is not ready.'
                : 'Mobile data ${enable ? 'on' : 'off'}.',
          ),
        ),
      );
      setState(() => _working = false);
    }
  }

  Future<void> _forceStop() async {
    final name = _appController.text.trim();
    if (name.isEmpty) return;
    Navigator.of(context).pop();
    await widget.onForceStopApp(name);
  }

  @override
  Widget build(BuildContext context) {
    final ready = _status == ShizukuStatus.ready && _enabled;
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Shizuku controls'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.cyan),
            tooltip: 'Refresh status',
            onPressed: _reload,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : ListView(
              padding: const EdgeInsets.all(16.0),
              children: [
                SwitchListTile(
                  value: _enabled,
                  activeThumbColor: _screenAccent,
                  title: const Text(
                    'Shizuku controls',
                    style: TextStyle(color: Colors.white),
                  ),
                  subtitle: const Text(
                    'Off by default. Needs the free Shizuku app + wireless debugging. Only the controls below are ever run.',
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                  contentPadding: EdgeInsets.zero,
                  onChanged: _toggleEnabled,
                ),
                const SizedBox(height: 8),
                Text(_statusText(_status), style: const TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 16),
                if (_status == ShizukuStatus.notRunning)
                  OutlinedButton(
                    onPressed: () => widget.shizukuService.openShizukuApp(),
                    child: const Text('Open the Shizuku app', style: TextStyle(color: Colors.cyan)),
                  ),
                if (_status == ShizukuStatus.notAuthorised)
                  ElevatedButton(
                    onPressed: _working ? null : _authorise,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.cyan,
                      foregroundColor: Colors.black,
                    ),
                    child: const Text('Authorise Jarvis in Shizuku'),
                  ),
                if (_enabled) ...[
                  const SizedBox(height: 24),
                  const Text(
                    'Mobile data',
                    style: TextStyle(color: _screenAccent, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: !ready || _working ? null : () => _toggleMobileData(true),
                          child: const Text('Data on', style: TextStyle(color: Colors.cyan)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: !ready || _working ? null : () => _toggleMobileData(false),
                          child: const Text('Data off', style: TextStyle(color: Colors.cyan)),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Force-stop an app',
                    style: TextStyle(color: _screenAccent, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Stops the app at once. Unsaved work in that app is lost. Jarvis itself and the system UI can never be force-stopped from here.',
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _appController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: 'App name (e.g. WhatsApp)',
                      labelStyle: TextStyle(color: Colors.cyan),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: !ready || _working ? null : _forceStop,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.redAccent,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('Force-stop this app'),
                  ),
                ],
                if (!_enabled)
                  const Padding(
                    padding: EdgeInsets.only(top: 16.0),
                    child: Text(
                      'Switch the controls on above to use them. Without Shizuku installed and authorised, nothing here does anything.',
                      style: TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                  ),
              ],
            ),
    );
  }
}
