// Phase 7 (v1.1.0) — F36 multi-task queue.
//
// "Do these three things: open WhatsApp, remind me at 7 to study,
// and tell me the time" — Jarvis splits the compound command, runs
// the steps one by one through the existing command path, and reports
// each step honestly (done / failed + reason) in the chat and by
// voice at the end. If a step fails, the queue continues with the
// next step and says so; it never pretends a failed step succeeded.
// The same runner replays F33 macros.
//
// Pattern: AbuZar-Ansarii/Jarvis
// lib/services/multi_task_service.dart (task models
// lib/models/task_step.dart / task_history_entry.dart). Fresh
// implementation — no code copied. Pure Dart; the per-step
// verification is the executor main.dart passes in (it awaits
// processQuery for the step and checks the chat for a failure
// message — see _executeQueuedStep in lib/main.dart). Phase 8's F40
// agent loop will deepen that verification later.

/// Most steps in one compound command. More than this is almost
/// certainly a misheard sentence, not a task list.
const int kJarvisMaxQueueSteps = 5;

/// One step's honest outcome.
class StepResult {
  const StepResult.done(this.command, {this.retried = false})
    : status = StepStatus.done,
      reason = '';

  const StepResult.failed(this.command, this.reason, {this.retried = false})
    : status = StepStatus.failed;

  final String command;
  final StepStatus status;

  /// Why the step failed; '' when it succeeded.
  final String reason;

  /// True when this result came from a retry of the step (G13
  /// runAgentLoopWithRetry). Defaults to false; existing callers
  /// are unaffected.
  final bool retried;

  bool get succeeded => status == StepStatus.done;
}

enum StepStatus { done, failed }

/// Splits a compound command into its steps, or null when the
/// utterance is not a compound command. Triggers:
///   "do these three things: A, B and C" / "do these things: ..."
///   "A and B" where both halves look like commands (start with a
///   command verb or match a known local pattern).
/// Splitting is on ", " and " and " / " then ". A single command
/// returns null — it is not a queue.
List<String>? splitCompoundSteps(String utterance) {
  final text = utterance.trim();
  final lower = text.toLowerCase();
  String? body;
  for (final prefix in <String>[
    'do these three things: ',
    'do these things: ',
    'do the following things: ',
    'do these three things ',
    'do these things ',
  ]) {
    if (lower.startsWith(prefix)) {
      body = text.substring(prefix.length).trim();
      break;
    }
  }
  body ??= text;
  final isExplicitList = body != text;
  // Implicit "A and B" must not hijack a single command whose own
  // text contains "and" — a message body, a form request, a commute
  // question, or a macro name. The explicit "do these things:" form
  // above is exempt: the user asked for a list.
  if (!isExplicitList) {
    for (final prefix in <String>[
      'message ',
      'text ',
      'draft ',
      'whatsapp ',
      'help me fill',
      'fill a ',
      'how long ',
      'how far ',
      'record macro',
      'run macro',
      'run ',
    ]) {
      if (lower.startsWith(prefix)) return null;
    }
  }
  // Split on ", and " / " and " / ", " / " then ". The ", and"
  // alternative comes first: splitting on the comma alone would
  // leave a leading "and" on the next step.
  final parts = body
      .split(RegExp(r'\s*,?\s+and\s+|\s*,\s*|\s+then\s+', caseSensitive: false))
      .map((p) => p.trim())
      .where((p) => p.isNotEmpty)
      .toList();
  if (parts.length < 2) return null;
  if (parts.length > kJarvisMaxQueueSteps) {
    return parts.sublist(0, kJarvisMaxQueueSteps);
  }
  if (isExplicitList) return parts;
  // Implicit "A and B": every part must look like a command, so
  // "fish and chips" or "what is time and weather" never becomes a
  // queue. A part looks like a command when it starts with a command
  // verb or matches a known local pattern.
  final looksLikeCommand = parts.every(_looksLikeCommand);
  if (!looksLikeCommand) return null;
  return parts;
}

/// Command verbs / patterns that make a fragment look like a command
/// on its own (used only by the implicit "A and B" split).
bool _looksLikeCommand(String part) {
  final lower = part.toLowerCase();
  for (final verb in <String>[
    'open ',
    'call ',
    'remind ',
    'set ',
    'start ',
    'tell me ',
    'show ',
    'message ',
    'text ',
    'run ',
    'play ',
    'lock ',
    'turn ',
    'switch ',
    'check ',
    'what ',
    'how ',
  ]) {
    if (lower.startsWith(verb)) return true;
  }
  return lower.contains('remind me') ||
      lower.contains('weather') ||
      lower.contains('time');
}

/// Runs [steps] one by one with [execute] (main.dart's
/// _executeQueuedStep, which awaits processQuery for one step and
/// returns its honest outcome). A failed step never stops the queue.
/// Returns the results in order.
Future<List<StepResult>> runTaskQueue(
  List<String> steps,
  Future<StepResult> Function(String step) execute,
) async {
  final results = <StepResult>[];
  for (final step in steps) {
    try {
      results.add(await execute(step));
    } catch (e) {
      results.add(StepResult.failed(step, 'Error: $e'));
    }
  }
  return results;
}

/// One-line-per-step report, plus a one-line summary. Shown in the
/// chat and spoken at the end of the queue. Failed steps name the
/// reason; nothing is softened into a success.
String formatQueueReport(List<StepResult> results) {
  final done = results.where((r) => r.succeeded).length;
  final buffer = StringBuffer();
  for (var i = 0; i < results.length; i++) {
    final result = results[i];
    buffer.writeln(
      '${i + 1}. ${result.command} — ${result.succeeded ? 'done' : 'failed: ${result.reason}'}',
    );
  }
  buffer.write(
    done == results.length
        ? 'All ${results.length} steps done.'
        : '$done of ${results.length} steps done, ${results.length - done} failed.',
  );
  return buffer.toString();
}

/// Short spoken version of the report: the summary only, so a long
/// queue is not read aloud step by step (the full report is on
/// screen).
String formatQueueSpokenSummary(List<StepResult> results) {
  final done = results.where((r) => r.succeeded).length;
  if (done == results.length) {
    return 'All ${results.length} steps done.';
  }
  final failed = results.where((r) => !r.succeeded).toList();
  final first = failed.first;
  return '${results.length - done} of ${results.length} steps failed. '
      'First failure: ${first.command} — ${first.reason}';
}
