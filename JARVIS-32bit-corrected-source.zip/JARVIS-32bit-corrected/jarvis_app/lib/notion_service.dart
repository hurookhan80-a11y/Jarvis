// v1.2.0 (G9) — Notion connector (read pages, append notes).
//
// The feature ships DISABLED until Notion is connected. The connect
// path is: the user creates a FREE Notion integration in their own
// Notion account, shares the pages it may see, and pastes the
// integration token here. The token is stored encrypted through the
// SAME AndroidKeyStore secure-storage channel as the Gemini, NVIDIA
// and Gmail secrets (secret name "notion_token"). No token is ever in
// code or in the repo. No password is ever stored.
//
// Mirrors GmailService (lib/gmail_service.dart): the same
// secure-storage channel, the same enabled-flag pattern, the same
// injectable http.Client + pure parsers, unit-tested the same way.

import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Name of the Notion integration token in the secure-storage channel.
/// Only names on the channel's allowlist are accepted on the native
/// side (see MainActivity.kt).
const String kJarvisNotionSecretName = 'notion_token';

/// SharedPreferences key: is the Notion connector switched on? Always
/// false until a token has been pasted (see [NotionService.setEnabled]).
const String kJarvisConnectorNotionEnabledKey =
    'jarvis_connector_notion_enabled';

/// Notion API base + version header (stable since 2022-06-28).
const String kNotionApiBase = 'https://api.notion.com/v1';
const String kNotionVersion = '2022-06-28';

/// Most characters of a page's text returned by [NotionService.readPage].
const int kNotionReadPageMaxChars = 4000;

/// One Notion page from a search result: its id and readable title.
class NotionPage {
  const NotionPage({required this.id, required this.title});

  final String id;
  final String title;
}

/// Plain text of one rich_text array (Notion's [{plain_text, ...}]).
String _notionRichTextPlain(List<dynamic> richText) => richText
    .whereType<Map>()
    .map((run) => run['plain_text']?.toString() ?? '')
    .join();

/// Title of one search-result page: the plain text of its `title`
/// property, or of the first title/rich_text property found, or
/// '(Untitled page)' when the page has no readable title.
String notionPageTitle(Map<String, dynamic> page) {
  final properties = page['properties'];
  if (properties is Map) {
    final titleProp = properties['title'];
    if (titleProp is Map) {
      final title = titleProp['title'];
      if (title is List && title.isNotEmpty) {
        final text = _notionRichTextPlain(title).trim();
        if (text.isNotEmpty) return text;
      }
    }
    for (final prop in properties.values) {
      if (prop is! Map) continue;
      for (final key in <String>['title', 'rich_text']) {
        final runs = prop[key];
        if (runs is List && runs.isNotEmpty) {
          final text = _notionRichTextPlain(runs).trim();
          if (text.isNotEmpty) return text;
        }
      }
    }
  }
  return '(Untitled page)';
}

/// Pages from a POST /search response. Entries without an id are dropped.
List<NotionPage> parseNotionSearch(Map<String, dynamic> json) {
  final results = json['results'];
  if (results is! List) return [];
  return results.whereType<Map>().map((entry) {
    return NotionPage(
      id: entry['id']?.toString() ?? '',
      title: notionPageTitle(Map<String, dynamic>.from(entry)),
    );
  }).where((page) => page.id.isNotEmpty).toList();
}

/// Plain text of one block's rich_text, or '' for block types this app
/// does not read (images, embeds, tables, ...).
String _notionBlockText(Map<String, dynamic> block) {
  final type = block['type']?.toString() ?? '';
  const readable = <String>{
    'paragraph',
    'bulleted_list_item',
    'numbered_list_item',
    'to_do',
    'heading_1',
    'heading_2',
    'heading_3',
    'quote',
  };
  if (!readable.contains(type)) return '';
  final content = block[type];
  if (content is! Map) return '';
  final richText = content['rich_text'];
  if (richText is! List) return '';
  return _notionRichTextPlain(richText).trim();
}

/// The readable text of a GET /blocks/{id}/children response: one line
/// per readable block, in order. Pure — no I/O, so it is unit-testable.
String parseNotionBlocks(Map<String, dynamic> json) {
  final results = json['results'];
  if (results is! List) return '';
  return results
      .whereType<Map>()
      .map(
        (block) => _notionBlockText(Map<String, dynamic>.from(block)),
      )
      .where((line) => line.isNotEmpty)
      .join('\n');
}

/// Thrown when a Notion call fails (bad token, no internet, quota).
/// The message is shown to the user as-is.
class NotionException implements Exception {
  NotionException(this.message);

  final String message;

  @override
  String toString() => 'NotionException: $message';
}

/// Notion REST client + the connect state for the hub.
class NotionService {
  NotionService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  static const MethodChannel _secureStorageChannel =
      MethodChannel('com.jarvis.jarvis_app/secure_storage');

  Future<bool> hasToken() async => (await readToken()).trim().isNotEmpty;

  Future<String> readToken() async {
    try {
      return await _secureStorageChannel.invokeMethod<String>(
            'readSecret',
            <String, String>{'name': kJarvisNotionSecretName},
          ) ??
          '';
    } catch (_) {
      return '';
    }
  }

  Future<void> saveToken(String token) async {
    await _secureStorageChannel.invokeMethod<void>(
      'saveSecret',
      <String, String>{
        'name': kJarvisNotionSecretName,
        'value': token.trim(),
      },
    );
  }

  Future<void> clearToken() async {
    try {
      await _secureStorageChannel.invokeMethod<void>(
        'clearSecret',
        <String, String>{'name': kJarvisNotionSecretName},
      );
    } catch (_) {}
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisConnectorNotionEnabledKey, false);
  }

  Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisConnectorNotionEnabledKey) ?? false;
  }

  /// Notion can only be switched on when an integration token is stored.
  Future<bool> setEnabled(bool enabled) async {
    if (enabled && !await hasToken()) return false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisConnectorNotionEnabledKey, enabled);
    return true;
  }

  /// Pages matching [query] (newest first from Notion), up to 10.
  /// Throws [NotionException] when the token is missing/invalid or
  /// the network fails.
  Future<List<NotionPage>> searchPages(String query) async {
    final token = await _tokenOrThrow();
    final response = await _send(
      'POST',
      Uri.parse('$kNotionApiBase/search'),
      token,
      body: jsonEncode(<String, Object>{
        'query': query,
        'filter': <String, String>{
          'property': 'object',
          'value': 'page',
        },
        'page_size': 10,
      }),
    );
    final decoded = _decode(response);
    if (decoded is! Map<String, dynamic>) {
      throw NotionException('Notion returned an invalid response.');
    }
    return parseNotionSearch(decoded);
  }

  /// Appends [text] as one paragraph block at the end of [pageId].
  /// Throws [NotionException] on empty text / bad page id / API failure.
  Future<void> appendToPage({
    required String pageId,
    required String text,
  }) async {
    if (pageId.trim().isEmpty) {
      throw NotionException('That Notion page id is empty.');
    }
    if (text.trim().isEmpty) {
      throw NotionException('Cannot append empty text to Notion.');
    }
    final token = await _tokenOrThrow();
    await _send(
      'PATCH',
      Uri.parse('$kNotionApiBase/blocks/${pageId.trim()}/children'),
      token,
      body: jsonEncode(<String, Object>{
        'children': <Map<String, Object>>[
          <String, Object>{
            'object': 'block',
            'type': 'paragraph',
            'paragraph': <String, Object>{
              'rich_text': <Map<String, Object>>[
                <String, Object>{
                  'type': 'text',
                  'text': <String, String>{'content': text},
                },
              ],
            },
          },
        ],
      }),
    );
  }

  /// The readable text of [pageId]'s blocks, capped at
  /// [kNotionReadPageMaxChars] characters. Throws [NotionException]
  /// on a bad page id or API failure.
  Future<String> readPage({required String pageId}) async {
    if (pageId.trim().isEmpty) {
      throw NotionException('That Notion page id is empty.');
    }
    final token = await _tokenOrThrow();
    final response = await _send(
      'GET',
      Uri.parse('$kNotionApiBase/blocks/${pageId.trim()}/children'),
      token,
    );
    final decoded = _decode(response);
    if (decoded is! Map<String, dynamic>) {
      throw NotionException('Notion returned an invalid response.');
    }
    var text = parseNotionBlocks(decoded);
    if (text.length > kNotionReadPageMaxChars) {
      text = '${text.substring(0, kNotionReadPageMaxChars)}…';
    }
    return text;
  }

  Future<String> _tokenOrThrow() async {
    final token = (await readToken()).trim();
    if (token.isEmpty) {
      throw NotionException(
        'Notion is not connected yet — paste an integration token first.',
      );
    }
    return token;
  }

  Map<String, String> _headers(String token) => <String, String>{
        'Authorization': 'Bearer $token',
        'Notion-Version': kNotionVersion,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

  Future<http.Response> _send(
    String method,
    Uri uri,
    String token, {
    String? body,
  }) async {
    http.Response response;
    try {
      switch (method) {
        case 'POST':
          response = await _client.post(
            uri,
            headers: _headers(token),
            body: body,
          );
        case 'PATCH':
          response = await _client.patch(
            uri,
            headers: _headers(token),
            body: body,
          );
        default:
          response = await _client.get(uri, headers: _headers(token));
      }
    } catch (e) {
      throw NotionException('Could not reach Notion: $e');
    }
    if (response.statusCode == 401) {
      throw NotionException(
        'Notion refused the token — check the integration token.',
      );
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw NotionException(
        'Notion answered with status ${response.statusCode}.',
      );
    }
    return response;
  }

  Object? _decode(http.Response response) {
    try {
      return jsonDecode(response.body);
    } catch (_) {
      return null;
    }
  }

  void dispose() => _client.close();
}
