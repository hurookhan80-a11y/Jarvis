// Phase 9 (v1.2.0) — G1/G2/G3 Google Workspace (Docs, Sheets, Drive,
// Calendar events, Gmail drafts + send).
//
// Writes to Google Docs and Sheets, searches Drive, creates Google
// Calendar events, and drafts/sends Gmail — all through the Google
// REST APIs with a user-pasted OAuth access token.
//
// The feature ships DISABLED until Google Workspace is connected. A
// full in-app OAuth flow cannot be built without a real Google Cloud
// OAuth client ID, and one cannot be invented or baked in — so the
// connect path is the same as F28 Gmail: the user creates a free
// OAuth client in their own Google Cloud account, takes an access
// token (the hub screen explains exactly how, via the OAuth 2.0
// Playground), and pastes it here. The token is stored encrypted
// through the SAME AndroidKeyStore secure-storage channel as the
// Gemini, NVIDIA and Gmail keys (secret name
// "google_workspace_oauth"). Access tokens expire after about an
// hour; when calls start failing the screen says so and asks for a
// fresh token. No password is ever stored. No key/token in code/repo
// ever.
//
// The token the user pastes needs these OAuth scopes (OAuth
// Playground, same as F28): documents, spreadsheets, drive.file,
// calendar.events, gmail.compose. The token is THEIR OWN — it is
// never in code, and nothing here asks for or stores a password.
//
// Sending email is NOT gated here: [sendEmail] sends when asked.
// The caller (main.dart) puts it behind the F42 confirmation gate,
// exactly like every other do-the-task action.
//
// [openCalendarInsert] is the no-account path: it opens the device
// Calendar app with the event prefilled for the user to save —
// exactly like the F42 alarm pattern. It needs no token at all.
//
// The pure parsers (parseDriveFileList, parseDocCreate,
// parseSheetCreate, parseCalendarEventCreate, buildGmailRawMessage,
// buildRfc3339) and the REST client (injectable http.Client) are
// unit-tested directly.

import 'dart:convert';

import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Name of the Google Workspace OAuth access token in the
/// secure-storage channel. Only names on the channel's allowlist are
/// accepted on the native side (see MainActivity.kt).
const String kJarvisGoogleWorkspaceSecretName = 'google_workspace_oauth';

/// SharedPreferences key: is Google Workspace switched on? Always
/// false until a token has been pasted (see
/// [GoogleWorkspaceService.setEnabled]).
const String kJarvisConnectorGoogleWorkspaceEnabledKey =
    'jarvis_connector_google_workspace_enabled';

/// One Drive file from a files.list search.
class DriveFile {
  const DriveFile({
    required this.id,
    required this.name,
    required this.mimeType,
  });

  final String id;
  final String name;
  final String mimeType;
}

/// Files from a Drive files.list response. Empty when there are none.
List<DriveFile> parseDriveFileList(Map<String, dynamic> json) {
  final files = json['files'];
  if (files is! List) return [];
  return files.whereType<Map>().map((f) {
    return DriveFile(
      id: f['id']?.toString() ?? '',
      name: f['name']?.toString() ?? '(Unnamed file)',
      mimeType: f['mimeType']?.toString() ?? '',
    );
  }).where((f) => f.id.isNotEmpty).toList();
}

/// documentId from a documents.create response.
String parseDocCreate(Map<String, dynamic> json) {
  return json['documentId']?.toString() ?? '';
}

/// The end index of a document body — the position after the last
/// character — so text can be appended at the end. Falls back to 1
/// (empty document) when the body is missing or unreadable.
int parseDocEndIndex(Map<String, dynamic> json) {
  final body = json['body'];
  if (body is! Map) return 1;
  final content = body['content'];
  if (content is! List || content.isEmpty) return 1;
  var endIndex = 1;
  for (final element in content.whereType<Map>()) {
    final end = element['endIndex'];
    if (end is int && end > endIndex) endIndex = end;
    if (end is String) {
      final parsed = int.tryParse(end);
      if (parsed != null && parsed > endIndex) endIndex = parsed;
    }
  }
  return endIndex;
}

/// spreadsheetId from a spreadsheets.create response.
String parseSheetCreate(Map<String, dynamic> json) {
  return json['spreadsheetId']?.toString() ?? '';
}

/// id from a calendar events.insert response.
String parseCalendarEventCreate(Map<String, dynamic> json) {
  return json['id']?.toString() ?? '';
}

/// id from a gmail drafts.create response.
String parseDraftCreate(Map<String, dynamic> json) {
  return json['id']?.toString() ?? '';
}

/// RFC822 message (To / Subject / plain-text body) encoded as
/// base64url, exactly as the Gmail API expects for `raw`. Padding
/// is stripped — Gmail accepts unpadded base64url.
String buildGmailRawMessage({
  required String to,
  required String subject,
  required String body,
}) {
  final message =
      'To: $to\r\nSubject: $subject\r\n'
      'Content-Type: text/plain; charset=utf-8\r\n\r\n$body';
  return base64Url.encode(utf8.encode(message)).replaceAll('=', '');
}

/// RFC3339 timestamp for the Calendar API, e.g.
/// "2026-11-23T14:00:00.000+05:00". The offset comes from the
/// DateTime itself, so local times stay local.
String buildRfc3339(DateTime dateTime) => dateTime.toIso8601String();

/// The ACTION_INSERT intent [GoogleWorkspaceService.openCalendarInsert]
/// launches: the device Calendar app, prefilled with the event. A
/// pure builder so the action, data URI and extras are unit-testable
/// (launch() itself is a no-op off Android).
AndroidIntent buildCalendarInsertIntent({
  required String title,
  required DateTime start,
  required DateTime end,
  String? description,
}) {
  final arguments = <String, dynamic>{
    'title': title,
    'beginTime': start.millisecondsSinceEpoch,
    'endTime': end.millisecondsSinceEpoch,
  };
  final desc = description?.trim();
  if (desc != null && desc.isNotEmpty) arguments['description'] = desc;
  return AndroidIntent(
    action: 'android.intent.action.INSERT',
    data: 'content://com.android.calendar/events',
    arguments: arguments,
    flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
  );
}

/// Thrown when a Google Workspace call fails (bad/expired token, no
/// internet, quota). The message is shown to the user as-is.
class GoogleWorkspaceException implements Exception {
  GoogleWorkspaceException(this.message);

  final String message;

  @override
  String toString() => 'GoogleWorkspaceException: $message';
}

/// Google Workspace REST client (Docs, Sheets, Drive, Calendar,
/// Gmail draft/send) + the connect state for the hub.
class GoogleWorkspaceService {
  GoogleWorkspaceService({http.Client? client})
      : _client = client ?? http.Client();

  final http.Client _client;

  static const MethodChannel _secureStorageChannel =
      MethodChannel('com.jarvis.jarvis_app/secure_storage');

  Future<bool> hasToken() async => (await readToken()).trim().isNotEmpty;

  Future<String> readToken() async {
    try {
      return await _secureStorageChannel.invokeMethod<String>(
            'readSecret',
            <String, String>{'name': kJarvisGoogleWorkspaceSecretName},
          ) ??
          '';
    } catch (_) {
      return '';
    }
  }

  Future<void> saveToken(String token) async {
    await _secureStorageChannel.invokeMethod<void>(
      'saveSecret',
      <String, String>{
        'name': kJarvisGoogleWorkspaceSecretName,
        'value': token.trim(),
      },
    );
  }

  Future<void> clearToken() async {
    try {
      await _secureStorageChannel.invokeMethod<void>(
        'clearSecret',
        <String, String>{'name': kJarvisGoogleWorkspaceSecretName},
      );
    } catch (_) {}
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisConnectorGoogleWorkspaceEnabledKey, false);
  }

  Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisConnectorGoogleWorkspaceEnabledKey) ??
        false;
  }

  /// Google Workspace can only be switched on when an access token
  /// is stored.
  Future<bool> setEnabled(bool enabled) async {
    if (enabled && !await hasToken()) return false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisConnectorGoogleWorkspaceEnabledKey, enabled);
    return true;
  }

  /// Creates a Google Doc titled [title] and writes [text] into it
  /// (at the start of the empty body). Returns the new documentId.
  /// Throws [GoogleWorkspaceException] when the token is
  /// missing/expired or the network fails.
  Future<String> createDoc({
    required String title,
    required String text,
  }) async {
    final token = await _requireToken();
    final response = await _post(
      Uri.https('docs.googleapis.com', '/v1/documents'),
      token,
      jsonEncode(<String, String>{'title': title}),
    );
    final docId = parseDocCreate(
      jsonDecode(response.body) as Map<String, dynamic>,
    );
    if (docId.isEmpty) {
      throw GoogleWorkspaceException(
        'Google Docs created a document but gave no id back.',
      );
    }
    if (text.isNotEmpty) {
      await _insertDocText(token, docId, text, 1);
    }
    return docId;
  }

  /// Appends [text] to the end of the Doc [docId]. Does nothing when
  /// [text] is empty.
  Future<void> appendToDoc({
    required String docId,
    required String text,
  }) async {
    if (text.isEmpty) return;
    final token = await _requireToken();
    final getResponse = await _get(
      Uri.https('docs.googleapis.com', '/v1/documents/$docId'),
      token,
    );
    final endIndex = parseDocEndIndex(
      jsonDecode(getResponse.body) as Map<String, dynamic>,
    );
    // The body's last element ends with a newline, so the insert
    // position is one before the end index.
    await _insertDocText(token, docId, text, endIndex - 1);
  }

  /// Creates a Google Sheet titled [title]. Returns the new
  /// spreadsheetId.
  Future<String> createSheet({required String title}) async {
    final token = await _requireToken();
    final response = await _post(
      Uri.https('sheets.googleapis.com', '/v4/spreadsheets'),
      token,
      jsonEncode(<String, dynamic>{
        'properties': <String, String>{'title': title},
      }),
    );
    final spreadsheetId = parseSheetCreate(
      jsonDecode(response.body) as Map<String, dynamic>,
    );
    if (spreadsheetId.isEmpty) {
      throw GoogleWorkspaceException(
        'Google Sheets created a spreadsheet but gave no id back.',
      );
    }
    return spreadsheetId;
  }

  /// Appends one row to the first sheet of [spreadsheetId].
  Future<void> appendSheetRow({
    required String spreadsheetId,
    required List<String> values,
  }) async {
    final token = await _requireToken();
    await _post(
      Uri.https(
        'sheets.googleapis.com',
        '/v4/spreadsheets/$spreadsheetId/values/A1:append',
        <String, String>{'valueInputOption': 'USER_ENTERED'},
      ),
      token,
      jsonEncode(<String, dynamic>{
        'values': <List<String>>[values],
      }),
    );
  }

  /// Drive files whose name contains [query]. Returns [] when there
  /// are no matches.
  Future<List<DriveFile>> searchDriveFiles(String query) async {
    final token = await _requireToken();
    final escaped = query.replaceAll("'", r"\'");
    final response = await _get(
      Uri.https(
        'drive.googleapis.com',
        '/drive/v3/files',
        <String, String>{
          'q': "name contains '$escaped'",
          'fields': 'files(id,name,mimeType)',
        },
      ),
      token,
    );
    return parseDriveFileList(
      jsonDecode(response.body) as Map<String, dynamic>,
    );
  }

  /// Creates a Google Calendar event. Returns the new event id.
  Future<String> createCalendarEvent({
    required String title,
    required DateTime start,
    required DateTime end,
    String? description,
  }) async {
    final token = await _requireToken();
    final body = <String, dynamic>{
      'summary': title,
      'start': <String, String>{'dateTime': buildRfc3339(start)},
      'end': <String, String>{'dateTime': buildRfc3339(end)},
    };
    final desc = description?.trim();
    if (desc != null && desc.isNotEmpty) body['description'] = desc;
    final response = await _post(
      Uri.https(
        'calendar.googleapis.com',
        '/calendar/v3/calendars/primary/events',
      ),
      token,
      jsonEncode(body),
    );
    final eventId = parseCalendarEventCreate(
      jsonDecode(response.body) as Map<String, dynamic>,
    );
    if (eventId.isEmpty) {
      throw GoogleWorkspaceException(
        'Google Calendar created an event but gave no id back.',
      );
    }
    return eventId;
  }

  /// Saves a Gmail draft. Returns the draft id. The draft is NOT
  /// sent — it waits in the user's Drafts for them to review.
  Future<String> draftEmail({
    required String to,
    required String subject,
    required String body,
  }) async {
    final token = await _requireToken();
    final response = await _post(
      Uri.https('gmail.googleapis.com', '/gmail/v1/users/me/drafts'),
      token,
      jsonEncode(<String, dynamic>{
        'message': <String, String>{
          'raw': buildGmailRawMessage(
            to: to,
            subject: subject,
            body: body,
          ),
        },
      }),
    );
    final draftId = parseDraftCreate(
      jsonDecode(response.body) as Map<String, dynamic>,
    );
    if (draftId.isEmpty) {
      throw GoogleWorkspaceException(
        'Gmail saved a draft but gave no id back.',
      );
    }
    return draftId;
  }

  /// Sends an email through Gmail. NOT gated here — the caller must
  /// put this behind the F42 confirmation gate before calling it.
  Future<void> sendEmail({
    required String to,
    required String subject,
    required String body,
  }) async {
    final token = await _requireToken();
    await _post(
      Uri.https('gmail.googleapis.com', '/gmail/v1/users/me/messages/send'),
      token,
      jsonEncode(<String, String>{
        'raw': buildGmailRawMessage(to: to, subject: subject, body: body),
      }),
    );
  }

  /// Opens the device Calendar app with a new event prefilled
  /// (title, start, end, description) for the user to save. This is
  /// the no-account path — it needs no Google token and writes
  /// nothing itself; the user saves (or discards) the event in the
  /// Calendar app. Throws [GoogleWorkspaceException] when the
  /// Calendar app cannot be opened.
  Future<void> openCalendarInsert({
    required String title,
    required DateTime start,
    required DateTime end,
    String? description,
  }) async {
    try {
      await buildCalendarInsertIntent(
        title: title,
        start: start,
        end: end,
        description: description,
      ).launch();
    } catch (e) {
      throw GoogleWorkspaceException(
        'Could not open the Calendar app: $e',
      );
    }
  }

  Future<String> _requireToken() async {
    final token = (await readToken()).trim();
    if (token.isEmpty) {
      throw GoogleWorkspaceException(
        'Google Workspace is not connected yet — paste an access '
        'token first.',
      );
    }
    return token;
  }

  Future<void> _insertDocText(
    String token,
    String docId,
    String text,
    int index,
  ) async {
    await _post(
      Uri.https('docs.googleapis.com', '/v1/documents/$docId:batchUpdate'),
      token,
      jsonEncode(<String, dynamic>{
        'requests': <Map<String, dynamic>>[
          <String, dynamic>{
            'insertText': <String, dynamic>{
              'location': <String, int>{'index': index},
              'text': text,
            },
          },
        ],
      }),
    );
  }

  Future<http.Response> _get(Uri uri, String token) async {
    http.Response response;
    try {
      response = await _client.get(
        uri,
        headers: <String, String>{
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );
    } catch (e) {
      throw GoogleWorkspaceException('Could not reach Google: $e');
    }
    return _check(response);
  }

  Future<http.Response> _post(
    Uri uri,
    String token,
    String body,
  ) async {
    http.Response response;
    try {
      response = await _client.post(
        uri,
        headers: <String, String>{
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: body,
      );
    } catch (e) {
      throw GoogleWorkspaceException('Could not reach Google: $e');
    }
    return _check(response);
  }

  http.Response _check(http.Response response) {
    if (response.statusCode == 401 || response.statusCode == 403) {
      throw GoogleWorkspaceException(
        'Google refused the token (it may have expired after about '
        'an hour). Paste a fresh access token to reconnect.',
      );
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw GoogleWorkspaceException(
        'Google answered with status ${response.statusCode}.',
      );
    }
    return response;
  }

  void dispose() => _client.close();
}
