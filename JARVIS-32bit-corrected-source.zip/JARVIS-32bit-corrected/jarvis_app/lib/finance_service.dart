// Phase 7 (v1.1.0) — F29 finance tracking.
//
// Voice logging of expenses ("spent 500 on groceries"), stored locally
// on this phone only (SharedPreferences), with totals by category and a
// weekly total. Optional SMS parsing of bank messages is OFF by
// default: it only reads messages on-device, only when the user turns
// it on in Settings, and never uploads anything.
//
// Pure helpers (parseExpenseCommand, parseBankSms, totalsByCategory)
// have no platform dependency, so they are unit-tested directly.

import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key for the stored expense list.
const String kJarvisFinanceExpensesKey = 'jarvis_finance_expenses_v1';

/// SharedPreferences key: is SMS expense parsing switched on?
/// Default OFF; the toggle lives in Settings (F29).
const String kJarvisFinanceSmsParsingKey = 'jarvis_finance_sms_parsing';

/// One logged expense.
class ExpenseEntry {
  const ExpenseEntry({
    required this.amount,
    required this.category,
    required this.note,
    required this.loggedAt,
  });

  factory ExpenseEntry.fromJson(Map<String, dynamic> json) {
    return ExpenseEntry(
      amount: (json['amount'] as num?)?.toDouble() ?? 0,
      category: json['category']?.toString() ?? 'Other',
      note: json['note']?.toString() ?? '',
      loggedAt:
          DateTime.tryParse(json['loggedAt']?.toString() ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  final double amount;
  final String category;
  final String note;
  final DateTime loggedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'amount': amount,
    'category': category,
    'note': note,
    'loggedAt': loggedAt.toIso8601String(),
  };
}

/// A parsed "spent X on Y" utterance.
class ParsedExpense {
  const ParsedExpense({required this.amount, required this.category, required this.note});

  final double amount;
  final String category;

  /// The free-text remainder ("groceries", "books for Ali", ...).
  final String note;
}

/// Keyword → category. Checked against the lower-cased remainder of the
/// utterance (or of a bank SMS) in order; first match wins.
const Map<String, String> kJarvisExpenseCategoryKeywords = <String, String>{
  'grocery': 'Groceries',
  'groceries': 'Groceries',
  'kirana': 'Groceries',
  'sabzi': 'Groceries',
  'book': 'Books',
  'kitab': 'Books',
  'stationery': 'Books',
  'fuel': 'Fuel',
  'petrol': 'Fuel',
  'diesel': 'Fuel',
  'cng': 'Fuel',
  'food': 'Food',
  'khana': 'Food',
  'lunch': 'Food',
  'dinner': 'Food',
  'breakfast': 'Food',
  'restaurant': 'Food',
  'transport': 'Transport',
  'bus': 'Transport',
  'rickshaw': 'Transport',
  'taxi': 'Transport',
  'uber': 'Transport',
  'careem': 'Transport',
  'medicine': 'Medicine',
  'dawai': 'Medicine',
  'pharmacy': 'Medicine',
  'doctor': 'Medicine',
  'hospital': 'Medicine',
  'mobile': 'Mobile',
  'recharge': 'Mobile',
  'load': 'Mobile',
  'cloth': 'Clothing',
  'kapra': 'Clothing',
  'shoes': 'Clothing',
  'fee': 'Fees',
  'fees': 'Fees',
  'bill': 'Bills',
  'electricity': 'Bills',
  'gas bill': 'Bills',
};

/// Guesses a category from free text; 'Other' when nothing matches.
String guessExpenseCategory(String text) {
  final lower = text.toLowerCase();
  for (final entry in kJarvisExpenseCategoryKeywords.entries) {
    if (lower.contains(entry.key)) return entry.value;
  }
  return 'Other';
}

/// Parses "spent 500 on groceries", "spent 500 rupees on books",
/// "I spent 1,200 on fuel", "paid 300 for lunch".
/// Returns null when no positive amount is found.
ParsedExpense? parseExpenseCommand(String utterance) {
  final lower = utterance.toLowerCase();
  final match = RegExp(
    r'\b(?:spent|spend|paid|pay|bought|buy|kharcha)\b[^0-9]*?(?:rs\.?|pkr|rupees?)?\s*([\d,]+(?:\.\d{1,2})?)\s*(?:rs\.?|pkr|rupees?)?\b\s*(?:on|for|ka|ki|ke)?\s*(.*)',
  ).firstMatch(lower);
  if (match == null) return null;
  final amount =
      double.tryParse((match.group(1) ?? '').replaceAll(',', ''));
  if (amount == null || amount <= 0 || amount > 10000000) return null;
  final remainder = (match.group(2) ?? '').trim();
  // Strip trailing filler words the recogniser often adds.
  final note = remainder
      .replaceAll(RegExp(r'\b(today|yesterday|just now|abhi)\b'), '')
      .trim();
  return ParsedExpense(
    amount: amount,
    category: guessExpenseCategory(note),
    note: note.isEmpty ? 'Expense' : note,
  );
}

/// Parses one bank SMS for a debit. Only debit-like messages count:
/// "credited"/"received" messages return null, as do messages with no
/// amount. The amount is the number after Rs/PKR (or after the debit
/// word when no currency marker is present).
ParsedExpense? parseBankSms(String body) {
  final lower = body.toLowerCase();
  final hasDebit = RegExp(
    r'\b(debited|debit|spent|paid|withdrawn|purchase|payment)\b',
  ).hasMatch(lower);
  if (!hasDebit) return null;
  if (RegExp(r'\b(credited|credit|received|deposit)\b').hasMatch(lower) &&
      !RegExp(r'\b(debited|debit|withdrawn)\b').hasMatch(lower)) {
    return null;
  }
  final amountMatch = RegExp(
    r'(?:rs\.?|pkr|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)',
  ).firstMatch(lower);
  final amountText = amountMatch?.group(1) ??
      RegExp(
        r'\b(?:debited|debit|spent|paid|withdrawn)\b[^0-9]{0,20}?([\d,]+(?:\.\d{1,2})?)',
      ).firstMatch(lower)?.group(1);
  if (amountText == null) return null;
  final amount = double.tryParse(amountText.replaceAll(',', ''));
  if (amount == null || amount <= 0 || amount > 10000000) return null;
  return ParsedExpense(
    amount: amount,
    category: guessExpenseCategory(lower),
    note: 'Bank SMS',
  );
}

/// Totals per category, highest first.
Map<String, double> totalsByCategory(List<ExpenseEntry> expenses) {
  final totals = <String, double>{};
  for (final expense in expenses) {
    totals.update(expense.category, (v) => v + expense.amount,
        ifAbsent: () => expense.amount);
  }
  final sorted = totals.entries.toList()
    ..sort((a, b) => b.value.compareTo(a.value));
  return Map<String, double>.fromEntries(sorted);
}

/// Total of expenses logged in the last [days] days (default 7).
double totalInLastDays(List<ExpenseEntry> expenses,
    {int days = 7, DateTime? now}) {
  final at = now ?? DateTime.now();
  final cutoff = at.subtract(Duration(days: days));
  var total = 0.0;
  for (final expense in expenses) {
    if (!expense.loggedAt.isBefore(cutoff)) total += expense.amount;
  }
  return total;
}

/// Parses the stored expense JSON; drops malformed entries.
List<ExpenseEntry> parseStoredExpenses(String? raw) {
  if (raw == null || raw.isEmpty) return [];
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map((e) => ExpenseEntry.fromJson(Map<String, dynamic>.from(e)))
        .where((e) => e.amount > 0)
        .toList();
  } catch (_) {
    return [];
  }
}

/// Local expense store + the optional on-device SMS reader. SMS reading
/// goes through MainActivity (ContentResolver, Telephony.Sms.Inbox) and
/// only runs when the user has switched SMS parsing on in Settings.
class FinanceService {
  const FinanceService();

  static const MethodChannel _smsChannel =
      MethodChannel('com.jarvis.jarvis_app/sms');

  Future<List<ExpenseEntry>> loadExpenses() async {
    final prefs = await SharedPreferences.getInstance();
    final expenses =
        parseStoredExpenses(prefs.getString(kJarvisFinanceExpensesKey));
    expenses.sort((a, b) => b.loggedAt.compareTo(a.loggedAt));
    return expenses;
  }

  Future<ExpenseEntry> addExpense(
    ParsedExpense parsed, {
    DateTime? loggedAt,
  }) async {
    final entry = ExpenseEntry(
      amount: parsed.amount,
      category: parsed.category,
      note: parsed.note,
      loggedAt: loggedAt ?? DateTime.now(),
    );
    final expenses = await loadExpenses();
    expenses.insert(0, entry);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(kJarvisFinanceExpensesKey,
        jsonEncode(expenses.map((e) => e.toJson()).toList()));
    return entry;
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(kJarvisFinanceExpensesKey);
  }

  Future<bool> isSmsParsingEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisFinanceSmsParsingKey) ?? false;
  }

  Future<void> setSmsParsingEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisFinanceSmsParsingKey, enabled);
  }

  /// Reads recent SMS bodies on-device (READ_SMS, granted in
  /// onboarding/Settings) and returns the ones that parse as bank
  /// debits. Returns [] when the permission is missing or SMS parsing
  /// is switched off. Nothing leaves the phone.
  Future<List<ParsedExpense>> readBankSmsExpenses({int limit = 100}) async {
    if (!await isSmsParsingEnabled()) return [];
    try {
      final raw = await _smsChannel.invokeMethod<List<dynamic>>(
        'getRecentSms',
        <String, dynamic>{'limit': limit},
      );
      final found = <ParsedExpense>[];
      for (final item in raw ?? <dynamic>[]) {
        if (item is! Map) continue;
        final parsed = parseBankSms(item['body']?.toString() ?? '');
        if (parsed != null) found.add(parsed);
      }
      return found;
    } catch (_) {
      return [];
    }
  }
}
