// Phase 8 (v1.1.0) — F40 agent loop.
//
// Understand → plan → act → verify → honest report, for multi-step
// requests. Simple Q&A takes the DIRECT fast path straight to Gemini
// (the existing path in lib/main.dart) and never enters the loop.
//
// Understand: classify the request. The F38 local router
// (lib/local_router.dart) already classifies single commands; the
// loop reuses its compound split (F36, lib/multi_task_service.dart)
// to recognise a multi-step request.
// Plan: break the request into steps with splitCompoundSteps.
// Act: run each step through the existing handlers (processQuery /
// local handlers) via the executor main.dart passes in.
// Verify: after each step, check the result honestly with
// verifyAgentStep — did the step's expected effect happen, judged
// from the success/failure signals the step itself produced in the
// chat (a reminder was actually scheduled, a message draft was
// actually shown, an app was actually opened)? Success is NEVER
// assumed: a step with no result, or with a failure message, fails.
// Report: a final honest summary in chat + voice
// ("done: X, Y; could not do: Z because …").
//
// Pattern: ansaribilal14/jarvis docs/AGENT_ENGINE.md (UNDERSTAND →
// PLAN → OBSERVE → DECIDE → ACT → OBSERVE → VERIFY + honest result
// reporting + DIRECT fast path) and trivedidhruv-dev/jarvis_assistant
// lib/agent/ (friday_orchestrator.dart, intent_router.dart,
// result_verifier.dart). Fresh implementation — no code copied.

import 'multi_task_service.dart';

/// One step's live state, shown on screen while the loop runs (each
/// step + its outcome — see lib/main.dart, which posts one chat line
/// per step and keeps the list in [_agentLoopLog]).
enum AgentStepStatus { pending, running, done, failed }

/// One step in the on-screen agent-loop log.
class AgentStepLogEntry {
  const AgentStepLogEntry({
    required this.index,
    required this.command,
    required this.status,
    required this.detail,
    required this.at,
  });

  final int index;

  /// The step's command text, as spoken.
  final String command;
  final AgentStepStatus status;

  /// Short outcome text ("done", "failed: …", "running…").
  final String detail;
  final DateTime at;
}

/// True when the utterance is a multi-step request the loop should
/// handle (an explicit list, or an implicit "A and B" of commands).
bool isMultiStepRequest(String normalized) =>
    splitCompoundSteps(normalized.trim().toLowerCase()) != null;

/// True when the utterance should skip the loop entirely and go
/// straight to Gemini (the DIRECT fast path): a plain question or
/// chat, not a multi-step request and not a do-something command
/// (open / call / message / remind / alarm / timer / tap / type …).
/// Local single commands are handled by their existing handlers in
/// main.dart; they are not loop work either, so this only answers
/// "is this plain Q&A?".
bool isDirectFastPath(String normalized) {
  final text = normalized.trim().toLowerCase();
  if (text.isEmpty) return true;
  if (isMultiStepRequest(text)) return false;
  for (final prefix in <String>[
    'open ',
    'call ',
    'message ',
    'text ',
    'whatsapp ',
    'sms ',
    'remind ',
    'set alarm',
    'alarm for',
    'set timer',
    'start timer',
    'timer for',
    'tap ',
    'click ',
    'type ',
    'go back',
    'scroll ',
    'force stop ',
    'record macro',
    'run ',
    'lock ',
    'draft ',
  ]) {
    if (text.startsWith(prefix)) return false;
  }
  return true;
}

/// Plans a multi-step request into its steps. Returns the split
/// steps, or the single utterance itself when it is not compound
/// (the loop is only entered for multi-step requests, so callers
/// normally pass a compound command).
List<String> planAgentSteps(String utterance) {
  final steps = splitCompoundSteps(utterance.trim().toLowerCase());
  if (steps != null && steps.isNotEmpty) return steps;
  return [utterance.trim()];
}

/// Failure words a step's own handler writes into the chat when the
/// step did not do what was asked. Any of these in a Jarvis message
/// produced by the step means the step failed — the loop never
/// upgrades it to a success.
const List<String> kAgentFailureMarkers = <String>[
  'could not',
  "couldn't",
  'couldnt',
  'i could not',
  'needs a gemini',
  'no internet',
  'not found',
  'failed',
  'did not catch',
  'i did not',
  'cancelled',
  'canceled',
  'timed out',
];

/// The positive evidence a step of a given kind must leave in the
/// chat for the loop to count it done. The evidence is the handler's
/// own success message — e.g. a reminder step only counts when the
/// chat says "Reminder set …", not when the reminder command merely
/// ran. An alarm step counts when the Clock app was opened for the
/// user to confirm and save the alarm there (the alarm itself is
/// only set when the user saves it in the Clock app — the step's
/// report says exactly that, never "alarm set").
String? _requiredEvidence(String command) {
  final text = command.trim().toLowerCase();
  if (text.contains('remind')) return 'reminder set';
  if (text.contains('alarm')) return 'opening your clock app';
  if (text.startsWith('call ') || text.contains('call karo')) {
    return 'calling ';
  }
  if (text.startsWith('message ') ||
      text.startsWith('text ') ||
      text.startsWith('whatsapp ') ||
      text.startsWith('sms ') ||
      text.startsWith('draft ')) {
    return 'draft for';
  }
  if (text.startsWith('open ')) return 'opening ';
  if (text.startsWith('tap ') ||
      text.startsWith('click ') ||
      text.startsWith('type ') ||
      text.startsWith('go back') ||
      text.startsWith('scroll ')) {
    return 'accessibility:';
  }
  return null;
}

/// Verifies one step honestly from the Jarvis messages the step
/// produced ([jarvisMessagesSinceStep], in order, lower-cased by the
/// caller or not — this function lower-cases them itself).
///
/// A step is done only when:
///   1. at least one Jarvis message was produced, AND
///   2. none of them carries a failure marker, AND
///   3. for kinds with required evidence, that evidence is present.
/// Otherwise it failed, with the first failure message (or the
/// missing-evidence reason) as the reason. Never assumes success.
StepResult verifyAgentStep(
  String command,
  List<String> jarvisMessagesSinceStep,
) {
  if (jarvisMessagesSinceStep.isEmpty) {
    return StepResult.failed(command, 'No result was reported.');
  }
  final lowered = jarvisMessagesSinceStep
      .map((m) => m.toLowerCase())
      .toList();
  for (var i = 0; i < lowered.length; i++) {
    if (kAgentFailureMarkers.any(lowered[i].contains)) {
      final reason = jarvisMessagesSinceStep[i].trim();
      return StepResult.failed(
        command,
        reason.length > 120 ? '${reason.substring(0, 120)}…' : reason,
      );
    }
  }
  final required = _requiredEvidence(command);
  if (required != null &&
      !lowered.any((m) => m.contains(required))) {
    return StepResult.failed(
      command,
      'No confirmation that it happened.',
    );
  }
  return StepResult.done(command);
}

/// Runs [steps] one by one with [execute] (main.dart's agent step
/// executor, which awaits processQuery for one step and returns its
/// verified outcome). A failed step never stops the loop. [onLog] is
/// called for every step transition so the screen can show the
/// per-step log live (running → done / failed).
Future<List<StepResult>> runAgentLoop(
  List<String> steps,
  Future<StepResult> Function(String step) execute, {
  void Function(AgentStepLogEntry entry)? onLog,
}) async {
  final results = <StepResult>[];
  for (var i = 0; i < steps.length; i++) {
    final step = steps[i];
    onLog?.call(AgentStepLogEntry(
      index: i,
      command: step,
      status: AgentStepStatus.running,
      detail: 'running…',
      at: DateTime.now(),
    ));
    StepResult result;
    try {
      result = await execute(step);
    } catch (e) {
      result = StepResult.failed(step, 'Error: $e');
    }
    results.add(result);
    onLog?.call(AgentStepLogEntry(
      index: i,
      command: step,
      status: result.succeeded
          ? AgentStepStatus.done
          : AgentStepStatus.failed,
      detail: result.succeeded ? 'done' : 'failed: ${result.reason}',
      at: DateTime.now(),
    ));
  }
  return results;
}

/// Honest final report, in the chat: "done: X, Y; could not do: Z
/// because …". Failed steps always name their reason; nothing is
/// softened into a success.
String formatAgentReport(List<StepResult> results) {
  final done = results.where((r) => r.succeeded).toList();
  final failed = results.where((r) => !r.succeeded).toList();
  final buffer = StringBuffer();
  if (done.isNotEmpty) {
    buffer.write('Done: ${done.map((r) => r.command).join(', ')}.');
  }
  if (failed.isNotEmpty) {
    if (buffer.isNotEmpty) buffer.write(' ');
    buffer.write(
      'Could not do: ${failed.map((r) {
        final reason = r.reason.endsWith('.')
            ? r.reason.substring(0, r.reason.length - 1)
            : r.reason;
        return '${r.command} because $reason';
      }).join('; ')}.',
    );
  }
  if (done.isEmpty && failed.isEmpty) return 'Nothing was done.';
  return buffer.toString();
}

/// Short spoken version of the report: the summary only, so a long
/// loop is not read aloud step by step (the full report is on
/// screen).
String formatAgentSpokenSummary(List<StepResult> results) {
  final done = results.where((r) => r.succeeded).length;
  if (done == results.length) {
    return 'All ${results.length} steps done.';
  }
  if (done == 0) {
    final first = results.first;
    return 'I could not do any of it. First failure: '
        '${first.command} — ${first.reason}';
  }
  final failed = results.where((r) => !r.succeeded).toList();
  return '$done of ${results.length} steps done. '
      'Could not do: ${failed.map((r) => r.command).join(', ')}.';
}

/// Rebuilds a step result marking it as the product of a retry.
/// [StepResult] is immutable, so a retried outcome is re-created
/// with [StepResult.retried] set instead of mutated.
StepResult _markRetried(StepResult result) {
  if (result.succeeded) {
    return StepResult.done(result.command, retried: true);
  }
  return StepResult.failed(result.command, result.reason, retried: true);
}

/// Runs the agent loop with one diagnosis-driven retry per failed
/// step (G13). First pass is exactly [runAgentLoop]: every step
/// runs once, in order, and a failed step never stops the loop.
///
/// For each step that failed, [diagnose] is asked — with the failed
/// step and its reason — for a fixed version of the step (e.g.
/// Gemini rephrasing a step that was misheard, or splitting a step
/// that was too big). When it returns a non-empty fixed step, that
/// step is executed once through the same [execute] and logged with
/// [onLog] (log entry index = the original step's index, detail
/// "retry: …"), and the retry's result becomes the step's final
/// result, marked [StepResult.retried]. At most ONE retry per step.
/// When [diagnose] is null, or returns null/empty, the original
/// failure stands.
///
/// The honest report stays honest: a retried step that still fails
/// reports its latest reason (the retry's, not the first attempt's),
/// and [formatAgentReport] is unchanged.
Future<List<StepResult>> runAgentLoopWithRetry(
  List<String> steps,
  Future<StepResult> Function(String step) execute, {
  void Function(AgentStepLogEntry entry)? onLog,
  Future<String?> Function(String failedStep, String reason)? diagnose,
}) async {
  final results = await runAgentLoop(steps, execute, onLog: onLog);
  if (diagnose == null) return results;
  for (var i = 0; i < results.length; i++) {
    final result = results[i];
    if (result.succeeded) continue;
    String? fixedStep;
    try {
      fixedStep = await diagnose(result.command, result.reason);
    } catch (_) {
      // A failing diagnoser must not break the loop: keep the
      // original failure.
      continue;
    }
    final fixed = fixedStep?.trim() ?? '';
    if (fixed.isEmpty) continue;
    onLog?.call(AgentStepLogEntry(
      index: i,
      command: fixed,
      status: AgentStepStatus.running,
      detail: 'retry: $fixed',
      at: DateTime.now(),
    ));
    StepResult retryResult;
    try {
      retryResult = await execute(fixed);
    } catch (e) {
      retryResult = StepResult.failed(fixed, 'Error: $e');
    }
    retryResult = _markRetried(retryResult);
    results[i] = retryResult;
    onLog?.call(AgentStepLogEntry(
      index: i,
      command: fixed,
      status: retryResult.succeeded
          ? AgentStepStatus.done
          : AgentStepStatus.failed,
      detail: retryResult.succeeded
          ? 'done'
          : 'failed: ${retryResult.reason}',
      at: DateTime.now(),
    ));
  }
  return results;
}
