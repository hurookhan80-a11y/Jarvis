// Phase 7 (v1.1.0) — F35 voice-guided form drafting.
//
// Guided Q&A fills a simple form draft by voice: "help me fill a
// leave application" — Jarvis asks each field one by one (name,
// dates, reason), repeats each answer back, then shows the finished
// draft text that the user can copy or share. Drafts are stored
// locally on this phone only. Jarvis NEVER submits anything anywhere
// — there is no submit step at all.
//
// Pattern: AbuZar-Ansarii/Jarvis
// lib/services/form_filling_service.dart (voice-guided part only;
// the Accessibility cross-app autofill is SKIP S12). Fresh
// implementation — no code copied.
//
// Voice commands (parsed by the pure helpers below):
//   "help me fill a leave application" / "fill a form" -> start flow
//   "show my forms" / "list forms" -> open the Forms screen

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key holding the saved form drafts.
const String kJarvisFormDraftsKey = 'jarvis_form_drafts_v1';

const int kJarvisMaxFormDrafts = 50;

/// One field of a form template.
class FormField {
  const FormField({required this.key, required this.label, required this.prompt});

  /// Stable key used in the answers map.
  final String key;

  /// Human label, shown in the finished draft.
  final String label;

  /// The question Jarvis asks for this field.
  final String prompt;
}

/// A form template: a title, its fields in order, and how the
/// finished draft text is laid out.
class FormTemplate {
  const FormTemplate({
    required this.id,
    required this.title,
    required this.fields,
    required this.header,
    required this.footer,
  });

  final String id;
  final String title;
  final List<FormField> fields;

  /// First line(s) of the draft (e.g. "To,\nThe Principal, ...").
  final String header;

  /// Closing lines of the draft (e.g. "Yours obediently,").
  final String footer;
}

/// The built-in templates. Leave application first — it is the
/// example in the spec and the one Habib asked about.
const List<FormTemplate> kJarvisFormTemplates = <FormTemplate>[
  FormTemplate(
    id: 'leave',
    title: 'Leave application',
    fields: <FormField>[
      FormField(key: 'name', label: 'Name', prompt: 'What is your name?'),
      FormField(
        key: 'dates',
        label: 'Dates',
        prompt: 'Which dates do you need leave for? For example, 24th to 26th November.',
      ),
      FormField(
        key: 'reason',
        label: 'Reason',
        prompt: 'What is the reason for the leave?',
      ),
    ],
    header: 'To,\nThe Principal,\n\nSubject: Application for leave\n\nRespected Sir/Madam,',
    footer: 'Thank you.\n\nYours obediently,',
  ),
  FormTemplate(
    id: 'permission',
    title: 'Permission letter',
    fields: <FormField>[
      FormField(key: 'name', label: 'Name', prompt: 'What is your name?'),
      FormField(
        key: 'dates',
        label: 'Date',
        prompt: 'For which date do you need permission?',
      ),
      FormField(
        key: 'reason',
        label: 'Reason',
        prompt: 'What do you need permission for?',
      ),
    ],
    header: 'To,\nWhom it may concern,\n\nSubject: Request for permission\n\nRespected Sir/Madam,',
    footer: 'Thank you.\n\nYours faithfully,',
  ),
  FormTemplate(
    id: 'general',
    title: 'General application',
    fields: <FormField>[
      FormField(key: 'name', label: 'Name', prompt: 'What is your name?'),
      FormField(
        key: 'dates',
        label: 'Dates',
        prompt: 'Which dates does this application cover?',
      ),
      FormField(
        key: 'reason',
        label: 'Reason',
        prompt: 'What is this application about? Please say it in one or two sentences.',
      ),
    ],
    header: 'To,\nWhom it may concern,\n\nRespected Sir/Madam,',
    footer: 'Thank you.\n\nYours faithfully,',
  ),
];

/// Finds a template by id, or null.
FormTemplate? findFormTemplate(String id) {
  for (final template in kJarvisFormTemplates) {
    if (template.id == id) return template;
  }
  return null;
}

/// Picks a template from a "fill a ..." utterance: "leave" ->
/// leave application, "permission" -> permission letter, anything
/// else -> the general application. Returns null when this is not a
/// form-start command.
FormTemplate? parseFormStart(String utterance) {
  final lower = utterance.trim().toLowerCase();
  final isFormCommand = lower.contains('fill a form') ||
      lower.contains('fill form') ||
      lower.contains('help me fill') ||
      lower.contains('fill an application') ||
      lower.contains('fill a leave') ||
      lower.contains('write a leave application') ||
      lower.contains('leave application');
  if (!isFormCommand) return null;
  if (lower.contains('leave')) return findFormTemplate('leave');
  if (lower.contains('permission')) return findFormTemplate('permission');
  return findFormTemplate('general');
}

/// Renders the finished draft text from a template + answers.
/// Missing answers render as "[not given]" so a gap is visible
/// instead of silently dropped.
String renderFormDraft(FormTemplate template, Map<String, String> answers) {
  final buffer = StringBuffer();
  buffer.writeln(template.header);
  buffer.writeln();
  buffer.writeln(
    'I am writing to request ${template.title.toLowerCase()} for the following:',
  );
  buffer.writeln();
  for (final field in template.fields) {
    final answer = (answers[field.key] ?? '').trim();
    buffer.writeln('${field.label}: ${answer.isEmpty ? '[not given]' : answer}');
  }
  buffer.writeln();
  buffer.writeln(template.footer);
  final name = (answers['name'] ?? '').trim();
  if (name.isNotEmpty) buffer.writeln(name);
  return buffer.toString().trimRight();
}

/// One saved draft.
class FormDraft {
  const FormDraft({
    required this.id,
    required this.title,
    required this.body,
    required this.createdAt,
  });

  factory FormDraft.fromJson(Map<String, dynamic> json) => FormDraft(
    id: json['id'] is int ? json['id'] as int : 0,
    title: json['title']?.toString() ?? 'Form draft',
    body: json['body']?.toString() ?? '',
    createdAt:
        DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
        DateTime.fromMillisecondsSinceEpoch(0),
  );

  final int id;
  final String title;
  final String body;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'id': id,
    'title': title,
    'body': body,
    'createdAt': createdAt.toIso8601String(),
  };
}

/// Parses a stored draft list; drops entries with no body.
List<FormDraft> parseStoredFormDrafts(String? raw) {
  if (raw == null || raw.isEmpty) return [];
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map((e) => FormDraft.fromJson(Map<String, dynamic>.from(e)))
        .where((d) => d.body.trim().isNotEmpty)
        .toList();
  } catch (_) {
    return [];
  }
}

/// Local store for finished form drafts.
class FormDraftService {
  const FormDraftService();

  Future<List<FormDraft>> loadDrafts() async {
    final prefs = await SharedPreferences.getInstance();
    final drafts = parseStoredFormDrafts(prefs.getString(kJarvisFormDraftsKey));
    drafts.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return drafts;
  }

  Future<FormDraft> saveDraft(String title, String body) async {
    final draft = FormDraft(
      id: DateTime.now().millisecondsSinceEpoch,
      title: title,
      body: body,
      createdAt: DateTime.now(),
    );
    final drafts = await loadDrafts();
    drafts.insert(0, draft);
    while (drafts.length > kJarvisMaxFormDrafts) {
      drafts.removeLast();
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      kJarvisFormDraftsKey,
      jsonEncode(drafts.map((d) => d.toJson()).toList()),
    );
    return draft;
  }

  Future<bool> deleteDraft(int id) async {
    final drafts = await loadDrafts();
    final before = drafts.length;
    drafts.removeWhere((d) => d.id == id);
    if (drafts.length == before) return false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      kJarvisFormDraftsKey,
      jsonEncode(drafts.map((d) => d.toJson()).toList()),
    );
    return true;
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(kJarvisFormDraftsKey);
  }
}
