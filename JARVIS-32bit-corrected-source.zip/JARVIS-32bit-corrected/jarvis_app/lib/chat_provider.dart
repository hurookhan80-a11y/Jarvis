// Phase 6 (v1.1.0) — F18 provider abstraction.
//
// One small interface every chat provider plugs into (Gemini, the NVIDIA
// NIM fallback, and any future provider), so processQuery talks to the
// interface and never to a concrete client. The hand-written Gemini REST
// client (lib/gemini_client.dart) is NOT changed by this file —
// [GeminiChatProvider] wraps it.
//
// Pattern: provider interface + fallback router, after
// mohammadsahil74808's lib/ai/ai_provider.dart. Fresh implementation —
// no code copied, and their google_generative_ai usage and model names
// are not used. Default model stays gemini-3.8-flash.

import 'dart:async';

import 'package:http/http.dart' as http;

import 'gemini_client.dart';

/// One turn of chat, in provider-neutral roles: `user` or `model`.
/// Providers translate `model` to their own assistant role.
class ChatMessage {
  const ChatMessage({required this.role, required this.text});

  ChatMessage.fromGemini(GeminiChatMessage message)
      : role = message.role,
        text = message.text;

  final String role;
  final String text;

  GeminiChatMessage toGemini() => GeminiChatMessage(role: role, text: text);
}

/// An error from a chat provider. [fallbackEligible] is true only when
/// the failure looks transient on the provider's side (quota / overload /
/// timeout) — the only failures the NIM fallback is allowed to rescue.
class ChatProviderException implements Exception {
  const ChatProviderException(
    this.message, {
    this.fallbackEligible = false,
    this.statusCode,
  });

  final String message;
  final bool fallbackEligible;
  final int? statusCode;

  @override
  String toString() => message;
}

/// True when a provider error message looks like a transient
/// quota/overload/timeout failure (Gemini 429 / 503 / "overloaded" /
/// "high demand" / timeout). Used to decide both the retry loop and
/// whether the NIM fallback may take over.
bool isTransientProviderError(String message) {
  final lower = message.toLowerCase();
  return lower.contains('429') ||
      lower.contains('503') ||
      lower.contains('overload') ||
      lower.contains('high demand') ||
      lower.contains('timed out') ||
      lower.contains('try again later');
}

/// The interface every chat provider implements.
abstract class ChatProvider {
  /// Short display name, e.g. `Gemini` or `NVIDIA NIM`.
  String get name;

  /// True for the fallback provider (NVIDIA NIM). The primary is false.
  bool get isFallback => false;

  /// One full answer. [extraSystemContext] is extra instruction text for
  /// this one request only (e.g. a knowledge-file excerpt); null means
  /// "use the instruction the provider was built with".
  Future<String> sendMessage({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  });

  /// The answer as a stream of text deltas.
  Stream<String> sendMessageStream({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  });

  /// Aborts any in-flight request (used by STOP).
  void cancel();

  void dispose();
}

/// Merges a provider's built-in system instruction with one request's
/// extra context. Empty extra context leaves the instruction untouched.
String mergeSystemInstruction(String base, String? extraSystemContext) {
  final extra = extraSystemContext?.trim() ?? '';
  if (extra.isEmpty) return base;
  return '$base\n\n$extra';
}

/// Gemini behind the [ChatProvider] interface. Wraps the existing
/// [GeminiRestClient] — the client itself is untouched.
class GeminiChatProvider extends ChatProvider {
  GeminiChatProvider({
    required String apiKey,
    this.modelName = 'gemini-3.8-flash',
    String? systemInstruction,
    http.Client? httpClient,
  }) : _client = GeminiRestClient(
          apiKey: apiKey,
          modelName: modelName,
          systemInstruction: systemInstruction,
          httpClient: httpClient,
        );

  final String modelName;
  final GeminiRestClient _client;

  @override
  String get name => 'Gemini';

  @override
  Future<String> sendMessage({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  }) async {
    try {
      return await _client.sendMessage(
        message: message,
        history: history.map((m) => m.toGemini()).toList(),
        systemInstruction: extraSystemContext == null
            ? null
            : mergeSystemInstruction(
                _client.systemInstruction, extraSystemContext),
      );
    } on GeminiApiException catch (e) {
      throw ChatProviderException(
        e.message,
        fallbackEligible: isTransientProviderError(e.message),
      );
    }
  }

  @override
  Stream<String> sendMessageStream({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  }) async* {
    try {
      yield* _client.sendMessageStream(
        message: message,
        history: history.map((m) => m.toGemini()).toList(),
        systemInstruction: extraSystemContext == null
            ? null
            : mergeSystemInstruction(
                _client.systemInstruction, extraSystemContext),
      );
    } on GeminiApiException catch (e) {
      throw ChatProviderException(
        e.message,
        fallbackEligible: isTransientProviderError(e.message),
      );
    }
  }

  @override
  void cancel() => _client.cancel();

  @override
  void dispose() => _client.dispose();
}

/// Tries the primary provider first; on a transient failure
/// ([ChatProviderException.fallbackEligible]) and only then, answers
/// from the fallback provider instead. [lastAnswerWasFallback] tells
/// the UI whether the answer just returned came from the fallback, so
/// it can be labelled honestly. Streaming is primary-only: a streaming
/// failure with no text falls back to [sendMessage] upstream, which is
/// where the fallback runs.
class FallbackChatProvider extends ChatProvider {
  FallbackChatProvider({required this.primary, this.fallback});

  final ChatProvider primary;
  final ChatProvider? fallback;

  /// True when the most recent [sendMessage] answer came from the
  /// fallback provider. Reset on every call.
  bool lastAnswerWasFallback = false;

  bool get fallbackAvailable => fallback != null;

  @override
  String get name => primary.name;

  @override
  Future<String> sendMessage({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  }) async {
    lastAnswerWasFallback = false;
    try {
      return await primary.sendMessage(
        message: message,
        history: history,
        extraSystemContext: extraSystemContext,
      );
    } on ChatProviderException catch (e) {
      final fallbackProvider = fallback;
      if (fallbackProvider == null || !e.fallbackEligible) rethrow;
      try {
        final answer = await fallbackProvider.sendMessage(
          message: message,
          history: history,
          extraSystemContext: extraSystemContext,
        );
        lastAnswerWasFallback = true;
        return answer;
      } on ChatProviderException catch (fallbackError) {
        throw ChatProviderException(
          'Gemini failed (${e.message}); the fallback model also failed: ${fallbackError.message}',
        );
      }
    }
  }

  @override
  Stream<String> sendMessageStream({
    required String message,
    required List<ChatMessage> history,
    String? extraSystemContext,
  }) =>
      primary.sendMessageStream(
        message: message,
        history: history,
        extraSystemContext: extraSystemContext,
      );

  @override
  void cancel() {
    primary.cancel();
    fallback?.cancel();
  }

  @override
  void dispose() {
    primary.dispose();
    fallback?.dispose();
  }
}
