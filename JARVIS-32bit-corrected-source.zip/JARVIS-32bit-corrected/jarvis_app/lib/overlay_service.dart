// Phase 7 (v1.1.0) — F23 floating overlay bubble.
//
// A small Jarvis bubble over any screen, built on the
// flutter_overlay_window plugin (verified at build time: minSdk 16,
// no native .so, compileSdk 34, AGP 9.x — compatible with this app's
// Flutter 3.50 / minSdk 24 / armeabi-v7a-only build). Needs the
// SYSTEM_ALERT_WINDOW permission, requested from onboarding (F25) and
// from Settings. The bubble is OFF by default.
//
// How it works:
//   - [OverlayService.showBubble] starts the overlay; the overlay
//     engine runs the `overlayMain` entry point in lib/main.dart,
//     which shows [JarvisBubbleWidget].
//   - Tapping the bubble sends 'bubble_tap' to the main isolate
//     (FlutterOverlayWindow.shareData) and closes the overlay; the
//     home screen's overlay listener then opens the app and starts a
//     conversation (reusing the home-screen widget launch path).
//   - The bubble is draggable, and drag-to-dismiss is enabled.
//
// The bubble is not shown during phone calls: there is no call-state
// listener in this release, so the user can drag it away or switch it
// off in Settings; that gap is noted in the release notes.

import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key: is the floating bubble switched on?
/// Default OFF (F23).
const String kJarvisFloatingBubbleKey = 'jarvis_floating_bubble_enabled';

class OverlayService {
  const OverlayService();

  Future<bool> isBubbleEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisFloatingBubbleKey) ?? false;
  }

  Future<void> setBubbleEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisFloatingBubbleKey, enabled);
  }

  Future<bool> isPermissionGranted() async {
    try {
      return await FlutterOverlayWindow.isPermissionGranted();
    } catch (_) {
      return false;
    }
  }

  /// Opens the system "Draw over other apps" page and returns true
  /// once the permission is granted.
  Future<bool> requestPermission() async {
    try {
      return await FlutterOverlayWindow.requestPermission() ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> isActive() async {
    try {
      return await FlutterOverlayWindow.isActive();
    } catch (_) {
      return false;
    }
  }

  /// Shows the bubble (96×96, draggable, right edge). No-op when the
  /// overlay permission is missing.
  Future<void> showBubble() async {
    if (!await isPermissionGranted()) return;
    try {
      await FlutterOverlayWindow.showOverlay(
        height: 96,
        width: 96,
        alignment: OverlayAlignment.centerRight,
        overlayTitle: 'Jarvis is listening',
        overlayContent: 'Tap the bubble to talk to Jarvis',
        enableDrag: true,
        startPosition: const OverlayPosition(0, 400),
      );
    } catch (_) {}
  }

  Future<void> hideBubble() async {
    try {
      await FlutterOverlayWindow.closeOverlay();
    } catch (_) {}
  }
}

/// The bubble itself, drawn by the overlay engine (`overlayMain`).
/// A plain cyan orb with a "J" — no copied assets. Tap to talk.
class JarvisBubbleWidget extends StatelessWidget {
  const JarvisBubbleWidget({super.key});

  Future<void> _onTap() async {
    try {
      await FlutterOverlayWindow.shareData('bubble_tap');
      await Future<void>.delayed(const Duration(milliseconds: 300));
      await FlutterOverlayWindow.closeOverlay();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: GestureDetector(
        onTap: _onTap,
        child: Container(
          width: 96,
          height: 96,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const RadialGradient(
              colors: [Color(0xFF00E5FF), Color(0xFF006064)],
            ),
            border: Border.all(color: Colors.white70, width: 2),
            boxShadow: const [
              BoxShadow(
                color: Colors.black54,
                blurRadius: 10,
                spreadRadius: 2,
              ),
            ],
          ),
          child: const Center(
            child: Text(
              'J',
              style: TextStyle(
                color: Colors.white,
                fontSize: 44,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
