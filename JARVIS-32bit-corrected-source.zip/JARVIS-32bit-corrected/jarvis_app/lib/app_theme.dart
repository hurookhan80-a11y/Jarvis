// v1.2.0 (G15-data) — light / dark theme data.
//
// Only the theme DATA lives here: the two ThemeData objects, the
// stored-mode key, and the mode parsers. Main.dart wires ThemeMode
// (and the Settings toggle) — this file builds no UI itself.
//
// Dark is the app's current look (near-black scaffold, cyan accent,
// white text). Light keeps the same cyan/teal accent on a soft light
// background with dark ink text.
//
// Fresh implementation — no code copied.

import 'package:flutter/material.dart';

/// SharedPreferences key holding the theme mode ('dark' / 'light').
const String kJarvisThemeModeKey = 'jarvis_theme_mode_v1';

/// The two themes the user can pick. Dark is the default.
enum JarvisThemeMode { dark, light }

/// Parses a stored mode string. Unknown, empty or null values fall
/// back to dark — the app's long-standing look.
JarvisThemeMode parseThemeMode(String? raw) {
  if (raw == null) return JarvisThemeMode.dark;
  switch (raw.trim().toLowerCase()) {
    case 'light':
      return JarvisThemeMode.light;
    case 'dark':
    default:
      return JarvisThemeMode.dark;
  }
}

/// The stored string for a mode ('dark' / 'light').
String themeModeName(JarvisThemeMode mode) =>
    mode == JarvisThemeMode.light ? 'light' : 'dark';

/// Shared accent: the cyan/teal the app already uses for buttons,
/// toggles and highlights.
const Color kJarvisAccent = Color(0xFF00BCD4);

/// Dark theme — the app's current look: near-black scaffold, cyan
/// accent, white text.
final ThemeData jarvisDarkTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  scaffoldBackgroundColor: const Color(0xFF121212),
  colorScheme: const ColorScheme.dark(
    primary: kJarvisAccent,
    secondary: kJarvisAccent,
    surface: Color(0xFF1E1E1E),
    onSurface: Colors.white,
    onPrimary: Colors.black,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: Color(0xFF121212),
    foregroundColor: Colors.white,
    elevation: 0,
  ),
  textTheme: const TextTheme(
    bodyMedium: TextStyle(color: Colors.white),
    bodyLarge: TextStyle(color: Colors.white),
    titleLarge: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
    titleMedium: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
  ),
  floatingActionButtonTheme: const FloatingActionButtonThemeData(
    backgroundColor: kJarvisAccent,
    foregroundColor: Colors.black,
  ),
  switchTheme: SwitchThemeData(
    thumbColor: WidgetStateProperty.resolveWith<Color?>(
      (states) => states.contains(WidgetState.selected)
          ? kJarvisAccent
          : Colors.grey,
    ),
    trackColor: WidgetStateProperty.resolveWith<Color?>(
      (states) => states.contains(WidgetState.selected)
          ? kJarvisAccent.withValues(alpha: 0.4)
          : Colors.grey.shade800,
    ),
  ),
);

/// Light theme — same accent, soft light background, dark ink text.
final ThemeData jarvisLightTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.light,
  scaffoldBackgroundColor: const Color(0xFFF4F7F9),
  colorScheme: const ColorScheme.light(
    primary: Color(0xFF0B5A6B),
    secondary: Color(0xFF0B5A6B),
    surface: Colors.white,
    onSurface: Color(0xFF1C2B33),
    onPrimary: Colors.white,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: Color(0xFFF4F7F9),
    foregroundColor: Color(0xFF1C2B33),
    elevation: 0,
  ),
  textTheme: const TextTheme(
    bodyMedium: TextStyle(color: Color(0xFF1C2B33)),
    bodyLarge: TextStyle(color: Color(0xFF1C2B33)),
    titleLarge: TextStyle(
      color: Color(0xFF1C2B33),
      fontWeight: FontWeight.bold,
    ),
    titleMedium: TextStyle(
      color: Color(0xFF1C2B33),
      fontWeight: FontWeight.bold,
    ),
  ),
  floatingActionButtonTheme: const FloatingActionButtonThemeData(
    backgroundColor: Color(0xFF0B5A6B),
    foregroundColor: Colors.white,
  ),
  switchTheme: SwitchThemeData(
    thumbColor: WidgetStateProperty.resolveWith<Color?>(
      (states) => states.contains(WidgetState.selected)
          ? const Color(0xFF0B5A6B)
          : Colors.grey,
    ),
    trackColor: WidgetStateProperty.resolveWith<Color?>(
      (states) => states.contains(WidgetState.selected)
          ? const Color(0xFF0B5A6B).withValues(alpha: 0.4)
          : Colors.grey.shade300,
    ),
  ),
);
