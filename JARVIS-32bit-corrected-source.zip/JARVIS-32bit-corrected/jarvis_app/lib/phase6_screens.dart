// Phase 6 (v1.1.0) — screens for F17/F19/F21/F22.
//
//   SavedFactsScreen     — F17: view / delete one / clear all saved facts.
//   ConnectorHubScreen   — F19: "Connected apps & providers".
//   SearchScreen         — F21: search across chats, reminders, saved
//                          facts and knowledge files.
//   KnowledgeFilesScreen — F22: list / add (paste text) / delete .txt
//                          knowledge files.
//
// All data stays on this phone. The screens are plain Flutter over the
// Phase 6 services; they take their dependencies as constructor
// arguments so the home screen stays the only place that wires them
// together.

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'connector_hub.dart';
import 'knowledge_service.dart';
import 'local_index.dart';
import 'memory_service.dart';

const _screenBackground = Colors.black;
const _screenAccent = Colors.cyan;

Future<bool> _confirmClearAll(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'Clear all',
}) async {
  final confirm = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      backgroundColor: Colors.grey[900],
      title: Text(title, style: const TextStyle(color: Colors.white)),
      content: Text(message,
          style: const TextStyle(color: Colors.white70)),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('Cancel',
              style: TextStyle(color: Colors.white70)),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(true),
          child: Text(confirmLabel,
              style: const TextStyle(color: Colors.redAccent)),
        ),
      ],
    ),
  );
  return confirm == true;
}

void _showTextDialog(
  BuildContext context, {
  required String title,
  required String body,
}) {
  showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      backgroundColor: Colors.grey[900],
      title: Text(title,
          style: const TextStyle(color: Colors.white)),
      content: SingleChildScrollView(
        child: Text(body, style: const TextStyle(color: Colors.white70)),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close',
              style: TextStyle(color: Colors.cyan)),
        ),
      ],
    ),
  );
}

/// F17: the facts Jarvis was told to remember. Delete one, or clear
/// them all. Changes take effect in answers right away (the home screen
/// rebuilds the chat provider when this screen closes).
class SavedFactsScreen extends StatefulWidget {
  const SavedFactsScreen({super.key, required this.memoryService});

  final MemoryService memoryService;

  @override
  State<SavedFactsScreen> createState() => _SavedFactsScreenState();
}

class _SavedFactsScreenState extends State<SavedFactsScreen> {
  List<SavedFact> _facts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final facts = await widget.memoryService.loadFacts();
    if (mounted) {
      setState(() {
        _facts = facts;
        _loading = false;
      });
    }
  }

  Future<void> _delete(SavedFact fact) async {
    await widget.memoryService.deleteFact(fact.text);
    _reload();
  }

  Future<void> _clearAll() async {
    final confirm = await _confirmClearAll(
      context,
      title: 'Forget everything?',
      message: 'Jarvis will forget every fact you asked it to remember.',
      confirmLabel: 'Forget all',
    );
    if (confirm) {
      await widget.memoryService.clearAll();
      _reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Saved facts'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep, color: Colors.redAccent),
            tooltip: 'Forget all facts',
            onPressed: _facts.isEmpty ? null : _clearAll,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : _facts.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24.0),
                    child: Text(
                      'Nothing saved yet.\n\nSay "remember that my exam is on 5 December" and Jarvis will keep it here — and use it when answering.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: _facts.length,
                  itemBuilder: (context, index) {
                    final fact = _facts[index];
                    return ListTile(
                      title: Text(fact.text,
                          style: const TextStyle(color: Colors.white)),
                      subtitle: Text(
                        'Saved ${DateFormat.yMMMd().add_jm().format(fact.savedAt)}',
                        style: const TextStyle(color: Colors.grey),
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete,
                            color: Colors.redAccent),
                        tooltip: 'Forget this fact',
                        onPressed: () => _delete(fact),
                      ),
                    );
                  },
                ),
    );
  }
}

/// F19: the switchboard. Gemini is always on; NVIDIA NIM can be
/// switched on once a free key is entered; Gmail (F28, Phase 7) can be
/// switched on once a Gmail access token is pasted below.
class ConnectorHubScreen extends StatefulWidget {
  const ConnectorHubScreen({
    super.key,
    required this.hub,
    required this.onChanged,
  });

  final ConnectorHubService hub;

  /// Called after a key or toggle changes, so the home screen rebuilds
  /// the chat provider (new fallback / new memory) right away.
  final Future<void> Function() onChanged;

  @override
  State<ConnectorHubScreen> createState() => _ConnectorHubScreenState();
}

class _ConnectorHubScreenState extends State<ConnectorHubScreen> {
  List<ConnectorInfo> _connectors = [];
  bool _loading = true;
  final TextEditingController _nimKeyController = TextEditingController();
  final TextEditingController _gmailTokenController =
      TextEditingController();

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _nimKeyController.dispose();
    _gmailTokenController.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    final connectors = await widget.hub.listConnectors();
    if (mounted) {
      setState(() {
        _connectors = connectors;
        _loading = false;
      });
    }
  }

  ConnectorInfo? _connector(ConnectorId id) {
    for (final connector in _connectors) {
      if (connector.id == id) return connector;
    }
    return null;
  }

  Future<void> _toggleNim(bool value) async {
    if (value) {
      final keySet = await widget.hub.hasNimKey();
      if (!keySet) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                  'Add your free NVIDIA key first — the fallback cannot switch on without one.'),
            ),
          );
        }
        return;
      }
    }
    await widget.hub.setNimEnabled(value);
    await widget.onChanged();
    _reload();
  }

  Future<void> _saveNimKey() async {
    final key = _nimKeyController.text.trim();
    if (key.isEmpty) return;
    await widget.hub.saveNimKey(key);
    _nimKeyController.clear();
    await widget.onChanged();
    _reload();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'NVIDIA key saved (encrypted on this phone). Switch the fallback on to use it.'),
        ),
      );
    }
  }

  Future<void> _clearNimKey() async {
    await widget.hub.clearNimKey();
    await widget.onChanged();
    _reload();
  }

  Future<void> _toggleGmail(bool value) async {
    if (value) {
      final tokenSet = await widget.hub.hasGmailToken();
      if (!tokenSet) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                  'Paste a Gmail access token first — triage cannot switch on without one. See the Email triage screen for how to get it.'),
            ),
          );
        }
        return;
      }
    }
    await widget.hub.setGmailEnabled(value);
    await widget.onChanged();
    _reload();
  }

  Future<void> _saveGmailToken() async {
    final token = _gmailTokenController.text.trim();
    if (token.isEmpty) return;
    await widget.hub.saveGmailToken(token);
    _gmailTokenController.clear();
    await widget.onChanged();
    _reload();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'Gmail token saved (encrypted on this phone). Switch triage on to use it. Tokens expire after about an hour.'),
        ),
      );
    }
  }

  Future<void> _clearGmailToken() async {
    await widget.hub.clearGmailToken();
    await widget.onChanged();
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    final nim = _connector(ConnectorId.nvidiaNim);
    final gmail = _connector(ConnectorId.gmail);
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Connected apps & providers'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : ListView(
              padding: const EdgeInsets.all(16.0),
              children: [
                const Text(
                  'Providers answer your questions. Gemini is the default and always on. The NVIDIA fallback only answers if Gemini fails — and only with a free key you add here.',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
                const SizedBox(height: 16),
                for (final connector in _connectors)
                  Card(
                    color: Colors.grey[900],
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  connector.name,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              if (connector.canToggle)
                                Switch(
                                  value: connector.enabled,
                                  activeThumbColor: _screenAccent,
                                  onChanged: connector.id ==
                                          ConnectorId.nvidiaNim
                                      ? _toggleNim
                                      : connector.id == ConnectorId.gmail
                                          ? _toggleGmail
                                          : null,
                                )
                              else
                                const Icon(Icons.lock,
                                    color: Colors.grey, size: 20),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            connector.description,
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 13),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            connector.status,
                            style: const TextStyle(
                                color: _screenAccent, fontSize: 12),
                          ),
                          if (connector.id == ConnectorId.nvidiaNim) ...[
                            const SizedBox(height: 12),
                            TextField(
                              controller: _nimKeyController,
                              obscureText: true,
                              enableSuggestions: false,
                              autocorrect: false,
                              style: const TextStyle(color: Colors.white),
                              decoration: InputDecoration(
                                labelText: nim?.keySet == true
                                    ? 'NVIDIA API key (saved — paste a new one to replace it)'
                                    : 'NVIDIA API key (free, from build.nvidia.com)',
                                labelStyle:
                                    const TextStyle(color: Colors.cyan),
                                border: const OutlineInputBorder(),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                ElevatedButton(
                                  onPressed: _saveNimKey,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.cyan,
                                    foregroundColor: Colors.black,
                                  ),
                                  child: const Text('Save key'),
                                ),
                                const SizedBox(width: 8),
                                if (nim?.keySet == true)
                                  TextButton(
                                    onPressed: _clearNimKey,
                                    child: const Text('Remove key',
                                        style: TextStyle(
                                            color: Colors.redAccent)),
                                  ),
                              ],
                            ),
                          ],
                          if (connector.id == ConnectorId.gmail) ...[
                            const SizedBox(height: 12),
                            TextField(
                              controller: _gmailTokenController,
                              obscureText: true,
                              enableSuggestions: false,
                              autocorrect: false,
                              style: const TextStyle(color: Colors.white),
                              decoration: InputDecoration(
                                labelText: gmail?.keySet == true
                                    ? 'Gmail access token (saved — paste a new one to replace it)'
                                    : 'Gmail access token (from the OAuth 2.0 Playground — see the Email triage screen)',
                                labelStyle:
                                    const TextStyle(color: Colors.cyan),
                                border: const OutlineInputBorder(),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                ElevatedButton(
                                  onPressed: _saveGmailToken,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.cyan,
                                    foregroundColor: Colors.black,
                                  ),
                                  child: const Text('Save token'),
                                ),
                                const SizedBox(width: 8),
                                if (gmail?.keySet == true)
                                  TextButton(
                                    onPressed: _clearGmailToken,
                                    child: const Text('Remove token',
                                        style: TextStyle(
                                            color: Colors.redAccent)),
                                  ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
              ],
            ),
    );
  }
}

/// F21: search across chats, reminders, saved facts and knowledge
/// files. Tap a chat result to open that conversation; tap any other
/// result to see it.
class SearchScreen extends StatefulWidget {
  const SearchScreen({
    super.key,
    required this.sessions,
    required this.reminders,
    required this.facts,
    required this.files,
    required this.onOpenSession,
  });

  final List<Map<String, dynamic>> sessions;
  final List<Map<String, dynamic>> reminders;
  final List<SavedFact> facts;
  final List<KnowledgeFile> files;

  /// Opens a chat session (the home screen pushes HistoryChatView).
  final void Function(Map<String, dynamic> session) onOpenSession;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _queryController = TextEditingController();
  List<LocalSearchResult> _results = [];
  bool _searched = false;

  @override
  void dispose() {
    _queryController.dispose();
    super.dispose();
  }

  void _runSearch(String query) {
    final results = searchLocalIndex(
      query: query,
      sessions: widget.sessions,
      reminders: widget.reminders,
      facts: widget.facts,
      files: widget.files,
    );
    setState(() {
      _results = results;
      _searched = true;
    });
  }

  void _openResult(LocalSearchResult result) {
    switch (result.type) {
      case LocalSearchResultType.chat:
        if (result.session != null) {
          widget.onOpenSession(result.session!);
        }
      case LocalSearchResultType.reminder:
        _showTextDialog(
          context,
          title: 'Reminder',
          body: '${result.title}\n\n${result.subtitle}',
        );
      case LocalSearchResultType.fact:
        _showTextDialog(
          context,
          title: 'Saved fact',
          body: result.factText ?? result.title,
        );
      case LocalSearchResultType.knowledge:
        _showTextDialog(
          context,
          title: result.fileName ?? 'Knowledge file',
          body: result.fileContent ?? result.title,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final grouped = <LocalSearchResultType, List<LocalSearchResult>>{};
    for (final result in _results) {
      grouped.putIfAbsent(result.type, () => []).add(result);
    }
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Search'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _queryController,
              autofocus: true,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: 'Search chats, reminders, facts, files…',
                hintStyle: TextStyle(color: Colors.white54),
                prefixIcon: Icon(Icons.search, color: Colors.cyan),
                border: OutlineInputBorder(),
              ),
              textInputAction: TextInputAction.search,
              onChanged: _runSearch,
              onSubmitted: _runSearch,
            ),
          ),
          Expanded(
            child: !_searched
                ? const Center(
                    child: Text(
                      'Searches this phone only — chats, reminders, saved facts and knowledge files.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  )
                : _results.isEmpty
                    ? const Center(
                        child: Text(
                          'Nothing found on this phone.',
                          style: TextStyle(color: Colors.grey),
                        ),
                      )
                    : ListView(
                        children: [
                          for (final entry in grouped.entries) ...[
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  16, 12, 16, 4),
                              child: Text(
                                entry.key.label,
                                style: const TextStyle(
                                  color: _screenAccent,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            for (final result in entry.value)
                              ListTile(
                                title: Text(result.title,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        color: Colors.white)),
                                subtitle: Text(result.subtitle,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        color: Colors.grey)),
                                onTap: () => _openResult(result),
                              ),
                          ],
                        ],
                      ),
          ),
        ],
      ),
    );
  }
}

/// F22: the user's .txt knowledge files. Add by pasting text and giving
/// it a name; tap one to read it; delete one to remove it. Files live
/// in an app-private folder on this phone.
class KnowledgeFilesScreen extends StatefulWidget {
  const KnowledgeFilesScreen({super.key, required this.knowledgeService});

  final KnowledgeService knowledgeService;

  @override
  State<KnowledgeFilesScreen> createState() => _KnowledgeFilesScreenState();
}

class _KnowledgeFilesScreenState extends State<KnowledgeFilesScreen> {
  List<KnowledgeFile> _files = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final files = await widget.knowledgeService.listFiles();
    if (mounted) {
      setState(() {
        _files = files;
        _loading = false;
      });
    }
  }

  Future<void> _delete(KnowledgeFile file) async {
    await widget.knowledgeService.deleteFile(file.name);
    _reload();
  }

  Future<void> _addFile() async {
    final nameController = TextEditingController();
    final textController = TextEditingController();
    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('Add knowledge file',
            style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'File name (e.g. anatomy notes)',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: textController,
                maxLines: 8,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Paste the text here',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel',
                style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () async {
              try {
                await widget.knowledgeService.saveFile(
                  nameController.text,
                  textController.text,
                );
                if (context.mounted) Navigator.of(context).pop(true);
              } on ArgumentError catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(e.message)),
                  );
                }
              }
            },
            child:
                const Text('Save', style: TextStyle(color: Colors.cyan)),
          ),
        ],
      ),
    );
    nameController.dispose();
    textController.dispose();
    if (saved == true) _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Knowledge files'),
        backgroundColor: Colors.black,
        foregroundColor: _screenAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: Colors.cyan),
            tooltip: 'Add a knowledge file',
            onPressed: _addFile,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _screenAccent))
          : _files.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24.0),
                    child: Text(
                      'No knowledge files yet.\n\nPaste in a note or a book extract and Jarvis will quote it (naming the file) when it answers a question about it.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: _files.length,
                  itemBuilder: (context, index) {
                    final file = _files[index];
                    return ListTile(
                      leading: const Icon(Icons.description,
                          color: Colors.cyan),
                      title: Text(file.name,
                          style: const TextStyle(color: Colors.white)),
                      subtitle: Text(
                        '${file.content.length} characters',
                        style: const TextStyle(color: Colors.grey),
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete,
                            color: Colors.redAccent),
                        tooltip: 'Delete this file',
                        onPressed: () => _delete(file),
                      ),
                      onTap: () => _showTextDialog(
                        context,
                        title: file.name,
                        body: file.content,
                      ),
                    );
                  },
                ),
    );
  }
}
