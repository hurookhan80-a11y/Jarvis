// Phase 7 (v1.1.0) — F28 email triage (Gmail REST, read-only).
//
// Lists recent unread Gmail messages (subject, sender, snippet).
// READ-ONLY: it never sends, never deletes, never marks anything read.
//
// The feature ships DISABLED until Gmail is connected. A full in-app
// OAuth flow cannot be built without a real Google Cloud OAuth client
// ID, and one cannot be invented or baked in — so the connect path is:
// the user creates a free OAuth client in their own Google Cloud
// account, takes an access token (the hub screen explains exactly how,
// via the OAuth 2.0 Playground), and pastes it here. The token is
// stored encrypted through the SAME AndroidKeyStore secure-storage
// channel as the Gemini and NVIDIA keys (secret name "gmail_oauth").
// Access tokens expire after about an hour; when triage stops working
// the screen says so and asks for a fresh token. No password is ever
// stored. No key/token in code/repo ever.
//
// The pure parsers (parseMessageListResponse, parseMessageDetail) and
// the REST client (injectable http.Client) are unit-tested directly.

import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Name of the Gmail OAuth access token in the secure-storage channel.
/// Only names on the channel's allowlist are accepted on the native
/// side (see MainActivity.kt).
const String kJarvisGmailSecretName = 'gmail_oauth';

/// SharedPreferences key: is Gmail triage switched on? Always false
/// until a token has been pasted (see [GmailService.canBeEnabled]).
const String kJarvisConnectorGmailEnabledKey =
    'jarvis_connector_gmail_enabled';

/// One unread message for the triage screen.
class GmailMessage {
  const GmailMessage({
    required this.id,
    required this.subject,
    required this.sender,
    required this.snippet,
    required this.date,
  });

  final String id;
  final String subject;
  final String sender;
  final String snippet;

  /// Raw Date header as Gmail returns it (shown as-is).
  final String date;
}

/// Ids from a messages.list response. Empty when there are none.
List<String> parseMessageListResponse(Map<String, dynamic> json) {
  final messages = json['messages'];
  if (messages is! List) return [];
  return messages
      .whereType<Map>()
      .map((m) => m['id']?.toString() ?? '')
      .where((id) => id.isNotEmpty)
      .toList();
}

/// Subject / From / Date / snippet from one messages.get response
/// (format=metadata, headers Subject/From/Date).
GmailMessage parseMessageDetail(Map<String, dynamic> json) {
  final headers = <String, String>{};
  final payload = json['payload'];
  if (payload is Map) {
    final list = payload['headers'];
    if (list is List) {
      for (final header in list.whereType<Map>()) {
        final name = header['name']?.toString().toLowerCase() ?? '';
        final value = header['value']?.toString() ?? '';
        if (name.isNotEmpty) headers[name] = value;
      }
    }
  }
  return GmailMessage(
    id: json['id']?.toString() ?? '',
    subject: headers['subject']?.trim().isNotEmpty == true
        ? headers['subject']!.trim()
        : '(No subject)',
    sender: headers['from']?.trim().isNotEmpty == true
        ? headers['from']!.trim()
        : '(Unknown sender)',
    snippet: (json['snippet']?.toString() ?? '').trim(),
    date: headers['date']?.trim() ?? '',
  );
}

/// Thrown when the Gmail call fails (bad/expired token, no internet,
/// quota). The message is shown to the user as-is.
class GmailException implements Exception {
  GmailException(this.message);

  final String message;

  @override
  String toString() => 'GmailException: $message';
}

/// Read-only Gmail REST client + the connect state for the hub.
class GmailService {
  GmailService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  static const MethodChannel _secureStorageChannel =
      MethodChannel('com.jarvis.jarvis_app/secure_storage');

  Future<bool> hasToken() async => (await readToken()).trim().isNotEmpty;

  Future<String> readToken() async {
    try {
      return await _secureStorageChannel.invokeMethod<String>(
            'readSecret',
            <String, String>{'name': kJarvisGmailSecretName},
          ) ??
          '';
    } catch (_) {
      return '';
    }
  }

  Future<void> saveToken(String token) async {
    await _secureStorageChannel.invokeMethod<void>(
      'saveSecret',
      <String, String>{
        'name': kJarvisGmailSecretName,
        'value': token.trim(),
      },
    );
  }

  Future<void> clearToken() async {
    try {
      await _secureStorageChannel.invokeMethod<void>(
        'clearSecret',
        <String, String>{'name': kJarvisGmailSecretName},
      );
    } catch (_) {}
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisConnectorGmailEnabledKey, false);
  }

  Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisConnectorGmailEnabledKey) ?? false;
  }

  /// Gmail can only be switched on when an access token is stored.
  Future<bool> setEnabled(bool enabled) async {
    if (enabled && !await hasToken()) return false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisConnectorGmailEnabledKey, enabled);
    return true;
  }

  /// Recent unread messages, newest first. Throws [GmailException]
  /// when the token is missing/expired or the network fails.
  Future<List<GmailMessage>> listUnread({int maxResults = 10}) async {
    final token = (await readToken()).trim();
    if (token.isEmpty) {
      throw GmailException(
        'Gmail is not connected yet — paste an access token first.',
      );
    }
    final listUri = Uri.https(
      'gmail.googleapis.com',
      '/gmail/v1/users/me/messages',
      <String, String>{
        'q': 'is:unread',
        'maxResults': '$maxResults',
      },
    );
    final listResponse = await _get(listUri, token);
    final ids = parseMessageListResponse(
      jsonDecode(listResponse.body) as Map<String, dynamic>,
    );
    final messages = <GmailMessage>[];
    for (final id in ids) {
      // format=metadata returns the message headers (Subject, From,
      // Date) plus the snippet — one small call per message.
      final detailResponse = await _get(
        Uri.https(
          'gmail.googleapis.com',
          '/gmail/v1/users/me/messages/$id',
          <String, String>{'format': 'metadata'},
        ),
        token,
      );
      messages.add(parseMessageDetail(
        jsonDecode(detailResponse.body) as Map<String, dynamic>,
      ));
    }
    return messages;
  }

  Future<http.Response> _get(Uri uri, String token) async {
    http.Response response;
    try {
      response = await _client.get(
        uri,
        headers: <String, String>{
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );
    } catch (e) {
      throw GmailException('Could not reach Gmail: $e');
    }
    if (response.statusCode == 401 || response.statusCode == 403) {
      throw GmailException(
        'Gmail refused the token (it may have expired after about an '
        'hour). Paste a fresh access token to reconnect.',
      );
    }
    if (response.statusCode != 200) {
      throw GmailException(
        'Gmail answered with status ${response.statusCode}.',
      );
    }
    return response;
  }

  void dispose() => _client.close();
}
