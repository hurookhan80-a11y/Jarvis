import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

const String jarvisSystemInstruction = '''
You are J.A.R.V.I.S., a capable, courteous, concise voice assistant.
Speak naturally and professionally. Keep spoken answers short unless the user asks
for detail. Be honest about uncertainty and never claim to control a device feature
unless the app has actually completed that action. You are a fictional assistant
inspired by the J.A.R.V.I.S. character; do not claim to be a real system made by
Tony Stark.
''';

class GeminiChatMessage {
  const GeminiChatMessage({required this.role, required this.text});

  /// Gemini conversation role: `user` or `model`.
  final String role;
  final String text;
}

class GeminiApiException implements Exception {
  const GeminiApiException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Small REST client for Gemini generateContent.
/// Uses the caller-provided API key and avoids the archived google_generative_ai SDK.
class GeminiRestClient {
  GeminiRestClient({
    required this.apiKey,
    required this.modelName,
    http.Client? httpClient,
  })  : _httpClient = httpClient ?? http.Client(),
        _ownsClient = httpClient == null;

  final String apiKey;
  final String modelName;
  final http.Client _httpClient;
  final bool _ownsClient;
  bool _disposed = false;

  Future<String> sendMessage({
    required String message,
    required List<GeminiChatMessage> history,
  }) async {
    if (_disposed) throw const GeminiApiException('Gemini client is closed.');
    if (apiKey.trim().isEmpty) {
      throw const GeminiApiException('Add your Gemini API key in Settings.');
    }
    if (!RegExp(r'^[A-Za-z0-9._-]+$').hasMatch(modelName)) {
      throw const GeminiApiException('The Gemini model name contains invalid characters.');
    }
    if (message.trim().isEmpty) {
      throw const GeminiApiException('Your message is empty.');
    }

    final contents = <Map<String, Object>>[
      for (final turn in history)
        {
          'role': turn.role,
          'parts': <Map<String, String>>[{'text': turn.text}],
        },
      {
        'role': 'user',
        'parts': <Map<String, String>>[{'text': message}],
      },
    ];

    final uri = Uri.https(
      'generativelanguage.googleapis.com',
      '/v1beta/models/$modelName:generateContent',
    );

    late final http.Response response;
    try {
      response = await _httpClient
          .post(
            uri,
            headers: <String, String>{
              'Content-Type': 'application/json; charset=utf-8',
              'x-goog-api-key': apiKey,
            },
            body: jsonEncode(<String, Object>{
              'systemInstruction': <String, Object>{
                'parts': <Map<String, String>>[
                  {'text': jarvisSystemInstruction},
                ],
              },
              'contents': contents,
              'generationConfig': <String, Object>{
                'temperature': 0.65,
                'maxOutputTokens': 400,
              },
            }),
          )
          .timeout(const Duration(seconds: 45));
    } on TimeoutException {
      throw const GeminiApiException('Gemini timed out. Check your connection and try again.');
    } on http.ClientException {
      throw const GeminiApiException('Could not connect to Gemini. Check your internet connection.');
    }

    final decoded = _decodeJson(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final error = decoded is Map ? decoded['error'] : null;
      final message = error is Map ? error['message'] : null;
      throw GeminiApiException(
        message is String && message.trim().isNotEmpty
            ? message
            : 'Gemini returned HTTP ${response.statusCode}. Check your API key and model name.',
      );
    }

    if (decoded is! Map) {
      throw const GeminiApiException('Gemini returned an invalid response.');
    }
    final candidates = decoded['candidates'];
    if (candidates is! List || candidates.isEmpty || candidates.first is! Map) {
      throw const GeminiApiException('Gemini did not return an answer. The request may have been blocked.');
    }

    final content = (candidates.first as Map)['content'];
    final parts = content is Map ? content['parts'] : null;
    if (parts is! List) {
      throw const GeminiApiException('Gemini returned an empty answer.');
    }

    final answer = parts
        .whereType<Map>()
        .map((part) => part['text'])
        .whereType<String>()
        .join('\n')
        .trim();
    if (answer.isEmpty) {
      throw const GeminiApiException('Gemini returned no readable text.');
    }
    return answer;
  }

  Object? _decodeJson(String body) {
    try {
      return jsonDecode(body);
    } on FormatException {
      return null;
    }
  }

  void dispose() {
    if (_disposed) return;
    _disposed = true;
    if (_ownsClient) _httpClient.close();
  }
}
