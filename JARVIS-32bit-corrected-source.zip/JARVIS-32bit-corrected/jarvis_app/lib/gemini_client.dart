import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

const String jarvisSystemInstruction = '''
You are J.A.R.V.I.S., a capable, courteous, concise voice assistant.
Speak naturally and professionally. Keep spoken answers short unless the user asks
for detail. When the user asks for code, write the complete working code and
explain it briefly. Do not shorten or cut off code. Be honest about uncertainty and never claim to control a device feature
unless the app has actually completed that action. You are a fictional assistant
inspired by the J.A.R.V.I.S. character; do not claim to be a real system made by
Tony Stark.
''';

class GeminiChatMessage {
  const GeminiChatMessage({required this.role, required this.text});

  /// Gemini conversation role: `user` or `model`.
  final String role;
  final String text;
}

class GeminiApiException implements Exception {
  const GeminiApiException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Text deltas from one chunk of a Gemini `streamGenerateContent`
/// (SSE) response. Each `data: {...}` line contributes the text of
/// `candidates[0].content.parts[*].text`; `[DONE]`, empty lines, and
/// malformed lines are skipped. A bare JSON object line (non-SSE) is
/// accepted too, so a plain JSON-chunked response still parses.
List<String> parseSseTextDeltas(String chunk) {
  final deltas = <String>[];
  for (final line in chunk.split('\n')) {
    final trimmed = line.trim();
    if (trimmed.isEmpty) continue;
    String? jsonText;
    if (trimmed.startsWith('data:')) {
      jsonText = trimmed.substring(5).trim();
      if (jsonText == '[DONE]') continue;
    } else if (trimmed.startsWith('{')) {
      jsonText = trimmed;
    } else {
      continue;
    }
    try {
      final delta = geminiCandidateText(jsonDecode(jsonText));
      if (delta.isNotEmpty) deltas.add(delta);
    } catch (_) {
      // Skip a malformed chunk; later chunks may still parse.
    }
  }
  return deltas;
}

/// The readable text of a decoded Gemini response body, or '' when the
/// body has no candidate text.
String geminiCandidateText(Object? decoded) {
  if (decoded is! Map) return '';
  final candidates = decoded['candidates'];
  if (candidates is! List || candidates.isEmpty || candidates.first is! Map) {
    return '';
  }
  final content = (candidates.first as Map)['content'];
  final parts = content is Map ? content['parts'] : null;
  if (parts is! List) return '';
  // No trim: streaming deltas must keep trailing spaces, which are the
  // word separators between chunks.
  return parts
      .whereType<Map>()
      .map((part) => part['text'])
      .whereType<String>()
      .join('\n');
}

/// Splits [text] into complete sentences and the trailing partial
/// sentence. A sentence ends at `.`, `!` or `?` followed by a space,
/// a newline, or the end of the text, so decimals like `3.5` do not
/// split. Used to speak streamed answers sentence by sentence.
({List<String> sentences, String remainder}) splitCompleteSentences(
  String text,
) {
  final sentences = <String>[];
  var start = 0;
  for (var i = 0; i < text.length; i++) {
    final ch = text[i];
    if (ch != '.' && ch != '!' && ch != '?') continue;
    final next = i + 1 < text.length ? text[i + 1] : '';
    if (next == '' || next == ' ' || next == '\n') {
      final sentence = text.substring(start, i + 1).trim();
      if (sentence.isNotEmpty) sentences.add(sentence);
      start = i + 1;
    }
  }
  return (sentences: sentences, remainder: text.substring(start));
}

/// Small REST client for Gemini generateContent.
/// Uses the caller-provided API key and avoids the archived google_generative_ai SDK.
///
/// Phase 6 (F17/F22, v1.1.0): the system instruction can be extended —
/// [systemInstruction] at construction (long-term memory facts, baked in
/// when the client is created) and per request (a knowledge-file excerpt
/// for this one question). Both default to [jarvisSystemInstruction], so
/// existing callers are unaffected.
class GeminiRestClient {
  GeminiRestClient({
    required this.apiKey,
    required this.modelName,
    String? systemInstruction,
    http.Client? httpClient,
  })  : systemInstruction = systemInstruction ?? jarvisSystemInstruction,
        _httpClient = httpClient ?? http.Client(),
        _ownsClient = httpClient == null;

  final String apiKey;
  final String modelName;

  /// The system instruction this client sends, unless a single request
  /// overrides it. Defaults to [jarvisSystemInstruction].
  final String systemInstruction;
  http.Client _httpClient;
  final bool _ownsClient;
  bool _disposed = false;

  /// Aborts any in-flight request (used by STOP). Only a client this
  /// object owns is closed — an injected test client is left alone.
  /// A fresh client is created so later requests still work.
  void cancel() {
    if (_disposed || !_ownsClient) return;
    try {
      _httpClient.close();
    } catch (_) {}
    _httpClient = http.Client();
  }

  /// Request body shared by [sendMessage] and [sendMessageStream].
  Map<String, Object> _requestBody({
    required String message,
    required List<GeminiChatMessage> history,
    required String systemInstruction,
  }) {
    final contents = <Map<String, Object>>[
      for (final turn in history)
        {
          'role': turn.role,
          'parts': <Map<String, String>>[{'text': turn.text}],
        },
      {
        'role': 'user',
        'parts': <Map<String, String>>[{'text': message}],
      },
    ];
    return <String, Object>{
      'systemInstruction': <String, Object>{
        'parts': <Map<String, String>>[
          {'text': systemInstruction},
        ],
      },
      'contents': contents,
      'generationConfig': <String, Object>{
        'temperature': 0.65,
        'maxOutputTokens': 2048,
      },
    };
  }

  void _validateRequest(String message) {
    if (_disposed) throw const GeminiApiException('Gemini client is closed.');
    if (apiKey.trim().isEmpty) {
      throw const GeminiApiException('Add your Gemini API key in Settings.');
    }
    if (!RegExp(r'^[A-Za-z0-9._-]+$').hasMatch(modelName)) {
      throw const GeminiApiException('The Gemini model name contains invalid characters.');
    }
    if (message.trim().isEmpty) {
      throw const GeminiApiException('Your message is empty.');
    }
  }

  Future<String> sendMessage({
    required String message,
    required List<GeminiChatMessage> history,
    String? systemInstruction,
  }) async {
    _validateRequest(message);

    final uri = Uri.https(
      'generativelanguage.googleapis.com',
      '/v1beta/models/$modelName:generateContent',
    );

    late final http.Response response;
    try {
      response = await _httpClient
          .post(
            uri,
            headers: <String, String>{
              'Content-Type': 'application/json; charset=utf-8',
              'x-goog-api-key': apiKey,
            },
            body: jsonEncode(_requestBody(
              message: message,
              history: history,
              systemInstruction: systemInstruction ?? this.systemInstruction,
            )),
          )
          .timeout(const Duration(seconds: 45));
    } on TimeoutException {
      throw const GeminiApiException('Gemini timed out. Check your connection and try again.');
    } on http.ClientException {
      throw const GeminiApiException('Could not connect to Gemini. Check your internet connection.');
    }

    final decoded = _decodeJson(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final error = decoded is Map ? decoded['error'] : null;
      final message = error is Map ? error['message'] : null;
      throw GeminiApiException(
        message is String && message.trim().isNotEmpty
            ? message
            : 'Gemini returned HTTP ${response.statusCode}. Check your API key and model name.',
      );
    }

    if (decoded is! Map) {
      throw const GeminiApiException('Gemini returned an invalid response.');
    }
    final candidates = decoded['candidates'];
    if (candidates is! List || candidates.isEmpty || candidates.first is! Map) {
      throw const GeminiApiException('Gemini did not return an answer. The request may have been blocked.');
    }

    final content = (candidates.first as Map)['content'];
    final parts = content is Map ? content['parts'] : null;
    if (parts is! List) {
      throw const GeminiApiException('Gemini returned an empty answer.');
    }

    final answer = parts
        .whereType<Map>()
        .map((part) => part['text'])
        .whereType<String>()
        .join('\n')
        .trim();
    if (answer.isEmpty) {
      throw const GeminiApiException('Gemini returned no readable text.');
    }
    return answer;
  }

  /// Sends [message] together with one image to Gemini vision, using
  /// the same generateContent endpoint, model and key as [sendMessage].
  /// The image travels as an `inlineData` part (base64) alongside the
  /// text part. Only JPEG, PNG, WebP and GIF are accepted; empty image
  /// bytes are rejected. Throws [GeminiApiException] on bad input,
  /// HTTP errors, or a response with no readable text.
  Future<String> sendMessageWithImage({
    required String message,
    required List<GeminiChatMessage> history,
    required List<int> imageBytes,
    required String mimeType,
    String? systemInstruction,
  }) async {
    _validateRequest(message);
    const supportedMimeTypes = <String>{
      'image/jpeg',
      'image/png',
      'image/webp',
      'image/gif',
    };
    if (!supportedMimeTypes.contains(mimeType)) {
      throw const GeminiApiException(
        'That image type is not supported — use JPEG, PNG, WebP or GIF.',
      );
    }
    if (imageBytes.isEmpty) {
      throw const GeminiApiException('The image is empty.');
    }

    final uri = Uri.https(
      'generativelanguage.googleapis.com',
      '/v1beta/models/$modelName:generateContent',
    );

    final contents = <Map<String, Object>>[
      for (final turn in history)
        {
          'role': turn.role,
          'parts': <Map<String, String>>[{'text': turn.text}],
        },
      {
        'role': 'user',
        'parts': <Object>[
          <String, String>{'text': message},
          <String, Object>{
            'inlineData': <String, String>{
              'mimeType': mimeType,
              'data': base64Encode(imageBytes),
            },
          },
        ],
      },
    ];
    final body = <String, Object>{
      'systemInstruction': <String, Object>{
        'parts': <Map<String, String>>[
          {'text': systemInstruction ?? this.systemInstruction},
        ],
      },
      'contents': contents,
      'generationConfig': <String, Object>{
        'temperature': 0.65,
        'maxOutputTokens': 2048,
      },
    };

    late final http.Response response;
    try {
      response = await _httpClient
          .post(
            uri,
            headers: <String, String>{
              'Content-Type': 'application/json; charset=utf-8',
              'x-goog-api-key': apiKey,
            },
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 45));
    } on TimeoutException {
      throw const GeminiApiException('Gemini timed out. Check your connection and try again.');
    } on http.ClientException {
      throw const GeminiApiException('Could not connect to Gemini. Check your internet connection.');
    }

    final decoded = _decodeJson(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final error = decoded is Map ? decoded['error'] : null;
      final errorMessage = error is Map ? error['message'] : null;
      throw GeminiApiException(
        errorMessage is String && errorMessage.trim().isNotEmpty
            ? errorMessage
            : 'Gemini returned HTTP ${response.statusCode}. Check your API key and model name.',
      );
    }

    if (decoded is! Map) {
      throw const GeminiApiException('Gemini returned an invalid response.');
    }
    final candidates = decoded['candidates'];
    if (candidates is! List || candidates.isEmpty || candidates.first is! Map) {
      throw const GeminiApiException('Gemini did not return an answer. The request may have been blocked.');
    }

    final content = (candidates.first as Map)['content'];
    final parts = content is Map ? content['parts'] : null;
    if (parts is! List) {
      throw const GeminiApiException('Gemini returned an empty answer.');
    }

    final answer = parts
        .whereType<Map>()
        .map((part) => part['text'])
        .whereType<String>()
        .join('\n')
        .trim();
    if (answer.isEmpty) {
      throw const GeminiApiException('Gemini returned no readable text.');
    }
    return answer;
  }

  /// Streams the answer with `streamGenerateContent` (SSE), yielding
  /// each text delta as it arrives. The caller speaks complete
  /// sentences as they arrive and shows the partial text live.
  /// Throws [GeminiApiException] on HTTP errors or when the stream
  /// fails before producing text. Stopping the stream (breaking out of
  /// the `await for`, or [cancel] closing the owned client) ends the
  /// request — this is how STOP works mid-stream.
  Stream<String> sendMessageStream({
    required String message,
    required List<GeminiChatMessage> history,
    String? systemInstruction,
  }) async* {
    _validateRequest(message);

    final uri = Uri.https(
      'generativelanguage.googleapis.com',
      '/v1beta/models/$modelName:streamGenerateContent',
      <String, String>{'alt': 'sse'},
    );

    late final http.StreamedResponse streamed;
    try {
      final request = http.Request('POST', uri)
        ..headers['Content-Type'] = 'application/json; charset=utf-8'
        ..headers['x-goog-api-key'] = apiKey
        ..body = jsonEncode(_requestBody(
          message: message,
          history: history,
          systemInstruction: systemInstruction ?? this.systemInstruction,
        ));
      streamed = await _httpClient
          .send(request)
          .timeout(const Duration(seconds: 45));
    } on TimeoutException {
      throw const GeminiApiException('Gemini timed out. Check your connection and try again.');
    } on http.ClientException {
      throw const GeminiApiException('Could not connect to Gemini. Check your internet connection.');
    }

    if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
      final body = await streamed.stream.bytesToString();
      final decoded = _decodeJson(body);
      final error = decoded is Map ? decoded['error'] : null;
      final errorMessage = error is Map ? error['message'] : null;
      throw GeminiApiException(
        errorMessage is String && errorMessage.trim().isNotEmpty
            ? errorMessage
            : 'Gemini returned HTTP ${streamed.statusCode}. Check your API key and model name.',
      );
    }

    // Lines may split across network chunks, so carry the last partial
    // line into the next chunk before parsing.
    var carry = '';
    await for (final chunk in streamed.stream.transform(utf8.decoder)) {
      carry += chunk;
      final lines = carry.split('\n');
      carry = lines.removeLast();
      for (final delta in parseSseTextDeltas(lines.join('\n'))) {
        yield delta;
      }
    }
    if (carry.trim().isNotEmpty) {
      for (final delta in parseSseTextDeltas(carry)) {
        yield delta;
      }
    }
  }

  Object? _decodeJson(String body) {
    try {
      return jsonDecode(body);
    } on FormatException {
      return null;
    }
  }

  void dispose() {
    if (_disposed) return;
    _disposed = true;
    if (_ownsClient) _httpClient.close();
  }
}
