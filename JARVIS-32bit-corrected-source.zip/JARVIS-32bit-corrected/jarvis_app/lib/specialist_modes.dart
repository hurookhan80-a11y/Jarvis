// v1.2.0 — G6 specialist agent modes.
//
// Jarvis can work in one specialist mode at a time: general (the
// default assistant), research, writer, or publisher. A mode is
// only a short instruction prefix that main.dart merges into the
// provider's system instruction (see mergeSystemInstruction in
// lib/chat_provider.dart) — the mode never changes which provider
// or model answers, and it never changes a command handler. The
// user switches mode by voice or text ("research mode",
// "switch to writer mode", "normal mode"); the mode persists in
// SharedPreferences so it survives a restart.
//
// Fresh implementation — ideas only, no code copied.

import 'package:shared_preferences/shared_preferences.dart';

/// The specialist modes Jarvis can work in.
enum AgentMode { general, research, writer, publisher }

/// SharedPreferences key holding the saved mode name.
const String kAgentModePrefsKey = 'jarvis_agent_mode_v1';

/// Short instruction prefix merged into the provider's system
/// instruction while this mode is active. General mode adds
/// nothing (''), so the default assistant behaviour is untouched.
///
/// Kept short on purpose: the prefix is prepended to every Gemini
/// request while the mode is on, and long boilerplate would waste
/// tokens and drown the base instruction.
String modeSystemPrompt(AgentMode mode) {
  switch (mode) {
    case AgentMode.research:
      return 'Research mode: use web search first for anything '
          'time-sensitive or factual, cite the sources you used, '
          'and say plainly what is still unconfirmed instead of '
          'guessing.';
    case AgentMode.writer:
      return 'Writer mode: draft in the user\'s own voice, in short '
          'paragraphs, and offer to save the draft when it is ready.';
    case AgentMode.publisher:
      return 'Publisher mode: save results to Google Docs, Google '
          'Sheets, or Google Calendar as the task needs, and report '
          'exactly where each result was saved.';
    case AgentMode.general:
      return '';
  }
}

/// Human label for a mode, used in the chat when the mode changes.
String modeDisplayName(AgentMode mode) {
  switch (mode) {
    case AgentMode.general:
      return 'General';
    case AgentMode.research:
      return 'Research';
    case AgentMode.writer:
      return 'Writer';
    case AgentMode.publisher:
      return 'Publisher';
  }
}

/// Parses a mode name ("research", "writer", "publisher",
/// "general" / "normal" / "assistant") into its mode, or null
/// when the word is not a mode name.
AgentMode? agentModeFromName(String name) {
  switch (name.trim().toLowerCase()) {
    case 'research':
      return AgentMode.research;
    case 'writer':
      return AgentMode.writer;
    case 'publisher':
      return AgentMode.publisher;
    case 'general':
    case 'normal':
    case 'assistant':
      return AgentMode.general;
    default:
      return null;
  }
}

/// Parses a mode-switch command from a normalized utterance
/// (lower-cased, trimmed), or null when the utterance is not a
/// mode command. Accepts "research mode", "writer mode",
/// "publisher mode", "normal mode", "assistant mode",
/// "general mode", and the same with a "switch to " / "go to " /
/// "turn on " / "enable " prefix, e.g. "switch to research mode".
/// Anything else — including a sentence that merely mentions a
/// mode word — returns null, so ordinary chat never flips modes.
AgentMode? parseModeCommand(String normalized) {
  final text = normalized.trim().toLowerCase();
  if (text.isEmpty) return null;
  var body = text;
  for (final prefix in <String>[
    'switch to ',
    'switch into ',
    'go to ',
    'go into ',
    'turn on ',
    'enable ',
    'set mode to ',
    'change to ',
  ]) {
    if (body.startsWith(prefix)) {
      body = body.substring(prefix.length).trim();
      break;
    }
  }
  if (!body.endsWith(' mode')) return null;
  final name = body.substring(0, body.length - ' mode'.length).trim();
  return agentModeFromName(name);
}

/// Persists and loads the active specialist mode.
class AgentModeService {
  /// Loads the saved mode; general when nothing is saved or the
  /// saved value is not a known mode name.
  Future<AgentMode> loadMode() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(kAgentModePrefsKey);
    if (saved == null) return AgentMode.general;
    return agentModeFromName(saved) ?? AgentMode.general;
  }

  /// Saves the mode.
  Future<void> saveMode(AgentMode mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(kAgentModePrefsKey, mode.name);
  }
}
