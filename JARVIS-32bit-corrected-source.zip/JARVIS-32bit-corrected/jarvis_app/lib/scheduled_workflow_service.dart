// Phase 9 (v1.2.0) — G5 scheduled workflows.
//
// A scheduled workflow is a template (see lib/workflow_service.dart)
// tied to a time of day and a set of weekdays. When its time comes,
// Jarvis should run it — with one honest limit:
//
//   WHEN THE APP IS DEAD, A SCHEDULED WORKFLOW CANNOT RUN ITSELF.
//   Background isolates cannot run the Gemini-backed agent loop, so
//   a dead app only gets a NOTIFICATION ("Your scheduled workflow
//   '<name>' is due — open Jarvis to run it"), delivered by a
//   Workmanager one-off task (see [ScheduledWorkflowService.
//   scheduleNotification] and the 'jarvis_workflow_notify' branch in
//   lib/reminder_service.dart). The user opens the app and runs it.
//
//   WHEN THE APP IS ALIVE, main.dart polls [dueWorkflows] on a
//   timer and runs whatever is due, then marks it run (see
//   [ScheduledWorkflowService.markRun]) so it is not run twice.
//
// The notification is a one-off Workmanager task, so after it fires
// (or after a live run) the NEXT occurrence must be registered again
// — main.dart re-registers on launch and after each run. Nothing
// here executes a workflow: the service only stores schedules, works
// out what is due, and registers/cancels the notification tasks.
//
// Fresh implementation — ideas only, no code copied from any other
// Jarvis repo.

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';

/// SharedPreferences key holding the scheduled workflows, as a JSON
/// list of `{id, workflowId, hour, minute, weekdays, enabled,
/// lastRun}` objects.
const String kJarvisScheduledWorkflowsKey = 'jarvis_scheduled_workflows_v1';

/// Most scheduled workflows kept. A phone should never grow an
/// unbounded schedule list.
const int kJarvisMaxScheduledWorkflows = 20;

/// Workmanager task name for a due-workflow notification.
const String kJarvisWorkflowNotifyTask = 'jarvis_workflow_notify';

/// Tag shared by every workflow notification task, so "cancel all"
/// can drop them all with one call.
const String kJarvisWorkflowTag = 'jarvis_workflows';

/// Notification channel used for due-workflow notifications.
const String kJarvisWorkflowChannelId = 'jarvis_workflows';
const String kJarvisWorkflowChannelName = 'Jarvis workflows';

/// Unique Workmanager name for one scheduled workflow's notification
/// task. The id is carried in the name so the task can always be
/// found and cancelled by id.
String workflowNotificationWorkName(String id) => 'jarvis_workflow_$id';

/// Deterministic Android notification id for a scheduled workflow.
/// A stable fold over the id's code units (String.hashCode is not
/// stable across runs, so it must not be used here).
int workflowNotificationId(String id) =>
    id.codeUnits.fold(0, (acc, c) => (acc * 31 + c) & 0x7fffffff);

/// One scheduled workflow: a template id plus when it runs.
class ScheduledWorkflow {
  const ScheduledWorkflow({
    required this.id,
    required this.workflowId,
    required this.hour,
    required this.minute,
    required this.weekdays,
    this.enabled = true,
    this.lastRun,
  });

  factory ScheduledWorkflow.fromJson(Map<String, dynamic> json) {
    final weekdays = <int>{};
    final raw = json['weekdays'];
    if (raw is List) {
      for (final day in raw) {
        final value = day is int
            ? day
            : int.tryParse(day?.toString() ?? '');
        if (value != null && value >= 1 && value <= 7) {
          weekdays.add(value);
        }
      }
    }
    final hour = json['hour'] is int
        ? json['hour'] as int
        : int.tryParse(json['hour']?.toString() ?? '') ?? -1;
    final minute = json['minute'] is int
        ? json['minute'] as int
        : int.tryParse(json['minute']?.toString() ?? '') ?? -1;
    return ScheduledWorkflow(
      id: json['id']?.toString() ?? '',
      workflowId: json['workflowId']?.toString() ?? '',
      hour: hour,
      minute: minute,
      weekdays: weekdays,
      enabled: json['enabled'] is bool
          ? json['enabled'] as bool
          : json['enabled']?.toString().toLowerCase() != 'false',
      lastRun: DateTime.tryParse(json['lastRun']?.toString() ?? ''),
    );
  }

  /// Stable id for this schedule (epoch-millis string when created).
  final String id;

  /// Id of the template to run (a built-in `builtin-…` id or a saved
  /// template's id — see lib/workflow_service.dart).
  final String workflowId;

  /// Time of day to run, 24-hour clock.
  final int hour;
  final int minute;

  /// Weekdays to run on, 1 = Monday … 7 = Sunday (DateTime.weekday).
  /// Empty means every day.
  final Set<int> weekdays;

  final bool enabled;

  /// When this schedule last ran (or last fired its notification),
  /// or null when it never has. Used by [dueWorkflows] so a schedule
  /// is never run twice for the same occurrence.
  final DateTime? lastRun;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'id': id,
    'workflowId': workflowId,
    'hour': hour,
    'minute': minute,
    'weekdays': weekdays.toList()..sort(),
    'enabled': enabled,
    'lastRun': lastRun?.toIso8601String(),
  };

  /// The scheduled time on [day]'s date.
  DateTime scheduledTimeOn(DateTime day) =>
      DateTime(day.year, day.month, day.day, hour, minute);
}

/// Parses a stored schedule list from [raw] JSON; drops malformed
/// entries and schedules with no id, no workflow id, or an
/// out-of-range time.
List<ScheduledWorkflow> parseStoredScheduled(String? raw) {
  if (raw == null || raw.isEmpty) return [];
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map(
          (e) => ScheduledWorkflow.fromJson(Map<String, dynamic>.from(e)),
        )
        .where(
          (s) =>
              s.id.trim().isNotEmpty &&
              s.workflowId.trim().isNotEmpty &&
              s.hour >= 0 &&
              s.hour <= 23 &&
              s.minute >= 0 &&
              s.minute <= 59,
        )
        .toList();
  } catch (_) {
    return [];
  }
}

String encodeScheduled(List<ScheduledWorkflow> scheduled) =>
    jsonEncode(scheduled.map((s) => s.toJson()).toList());

/// Finds a schedule by id, or null.
ScheduledWorkflow? findScheduled(
  List<ScheduledWorkflow> scheduled,
  String id,
) {
  for (final entry in scheduled) {
    if (entry.id == id) return entry;
  }
  return null;
}

/// The schedules due right now.
///
/// A schedule is due when ALL of these hold:
///   1. it is enabled,
///   2. today is one of its weekdays (or its weekdays are empty,
///      meaning every day),
///   3. its scheduled time today has passed
///      (scheduled time today <= [now]), and
///   4. it has not already run for today's occurrence — i.e.
///      [ScheduledWorkflow.lastRun] is null, or is before today's
///      scheduled time.
///
/// There is deliberately NO 10-minute window: main.dart polls this
/// on a timer, and rule 4 (updated by [markRun] after every run) is
/// what stops a schedule from firing twice. A schedule whose time
/// passed hours ago while the phone was off is still due when the
/// app next wakes — that is the point: the work was missed, not
/// cancelled.
List<ScheduledWorkflow> dueWorkflows(
  List<ScheduledWorkflow> scheduled,
  DateTime now,
) {
  final due = <ScheduledWorkflow>[];
  for (final entry in scheduled) {
    if (!entry.enabled) continue;
    if (entry.weekdays.isNotEmpty && !entry.weekdays.contains(now.weekday)) {
      continue;
    }
    final today = entry.scheduledTimeOn(now);
    if (today.isAfter(now)) continue;
    if (entry.lastRun != null && !entry.lastRun!.isBefore(today)) continue;
    due.add(entry);
  }
  return due;
}

/// The next time [entry] should fire after [from], or null when it
/// is disabled. Looks up to 7 days ahead (a weekly schedule always
/// lands within a week); a schedule with an empty weekday set fires
/// every day. The returned time is strictly after [from].
DateTime? nextRunAfter(ScheduledWorkflow entry, DateTime from) {
  if (!entry.enabled) return null;
  for (var offset = 0; offset <= 7; offset++) {
    final day = DateTime(from.year, from.month, from.day)
        .add(Duration(days: offset));
    if (entry.weekdays.isNotEmpty && !entry.weekdays.contains(day.weekday)) {
      continue;
    }
    final candidate = entry.scheduledTimeOn(day);
    if (candidate.isAfter(from)) return candidate;
  }
  return null;
}

/// Local schedule store + notification registration. Running the
/// workflow itself lives in main.dart (see the header).
class ScheduledWorkflowService {
  const ScheduledWorkflowService();

  Future<List<ScheduledWorkflow>> loadScheduled() async {
    final prefs = await SharedPreferences.getInstance();
    final scheduled = parseStoredScheduled(
      prefs.getString(kJarvisScheduledWorkflowsKey),
    );
    scheduled.sort((a, b) {
      final byTime = (a.hour * 60 + a.minute) - (b.hour * 60 + b.minute);
      return byTime != 0
          ? byTime
          : a.workflowId.compareTo(b.workflowId);
    });
    return scheduled;
  }

  /// Saves a schedule (replacing any schedule with the same id). A
  /// schedule with no id, no workflow id, or an out-of-range time is
  /// ignored and null is returned. An empty id is filled in with an
  /// epoch-millis id.
  Future<ScheduledWorkflow?> saveScheduled(ScheduledWorkflow entry) async {
    if (entry.workflowId.trim().isEmpty) return null;
    if (entry.hour < 0 ||
        entry.hour > 23 ||
        entry.minute < 0 ||
        entry.minute > 59) {
      return null;
    }
    final scheduled = await loadScheduled();
    final saved = entry.id.trim().isEmpty
        ? ScheduledWorkflow(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            workflowId: entry.workflowId,
            hour: entry.hour,
            minute: entry.minute,
            weekdays: entry.weekdays,
            enabled: entry.enabled,
            lastRun: entry.lastRun,
          )
        : entry;
    scheduled.removeWhere((s) => s.id == saved.id);
    scheduled.add(saved);
    while (scheduled.length > kJarvisMaxScheduledWorkflows) {
      scheduled.removeAt(0);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      kJarvisScheduledWorkflowsKey,
      encodeScheduled(scheduled),
    );
    return saved;
  }

  /// Deletes a schedule by id. Returns false when nothing matched.
  Future<bool> deleteScheduled(String id) async {
    final scheduled = await loadScheduled();
    final before = scheduled.length;
    scheduled.removeWhere((s) => s.id == id);
    if (scheduled.length == before) return false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      kJarvisScheduledWorkflowsKey,
      encodeScheduled(scheduled),
    );
    return true;
  }

  /// Records that [entry] ran (or its notification fired) at [at]
  /// — the guard that stops [dueWorkflows] returning it again for
  /// the same occurrence. Returns false when the id is unknown.
  Future<bool> markRun(String id, {DateTime? at}) async {
    final scheduled = await loadScheduled();
    final index = scheduled.indexWhere((s) => s.id == id);
    if (index < 0) return false;
    final entry = scheduled[index];
    scheduled[index] = ScheduledWorkflow(
      id: entry.id,
      workflowId: entry.workflowId,
      hour: entry.hour,
      minute: entry.minute,
      weekdays: entry.weekdays,
      enabled: entry.enabled,
      lastRun: at ?? DateTime.now(),
    );
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      kJarvisScheduledWorkflowsKey,
      encodeScheduled(scheduled),
    );
    return true;
  }

  /// Registers the Workmanager one-off task that shows the
  /// "workflow due" notification at the schedule's next run (see
  /// [nextRunAfter]). No-op when the schedule is disabled, has no
  /// next run, or its next run is already past. The delay is a
  /// minimum: Android may deliver it a little late under Doze.
  /// The caller passes the template's display name — the background
  /// isolate only knows the id, so the name has to travel in the
  /// task's inputData.
  Future<void> scheduleNotification(
    ScheduledWorkflow entry,
    String templateName,
  ) async {
    final next = nextRunAfter(entry, DateTime.now());
    if (next == null) return;
    final delay = next.difference(DateTime.now());
    if (delay.isNegative) return;
    try {
      await Workmanager().registerOneOffTask(
        workflowNotificationWorkName(entry.id),
        kJarvisWorkflowNotifyTask,
        initialDelay: delay,
        inputData: <String, dynamic>{
          'workflowId': entry.id,
          'workflowName': templateName,
        },
        tag: kJarvisWorkflowTag,
        existingWorkPolicy: ExistingWorkPolicy.replace,
      );
    } catch (_) {}
  }

  /// Drops the notification task for one schedule.
  Future<void> cancelNotification(String id) async {
    try {
      await Workmanager().cancelByUniqueName(
        workflowNotificationWorkName(id),
      );
    } catch (_) {}
  }

  /// Drops the notification task for every schedule.
  Future<void> cancelAllNotifications() async {
    try {
      await Workmanager().cancelByTag(kJarvisWorkflowTag);
    } catch (_) {}
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(kJarvisScheduledWorkflowsKey);
  }
}
