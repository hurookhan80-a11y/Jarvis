// Phase 6 (v1.1.0) — F22 knowledge files.
//
// The user adds plain .txt files as knowledge: a "Knowledge files"
// screen lists the .txt files in an app-private folder
// (jarvis_knowledge/), with add (paste text and save as a named .txt)
// and delete. When answering, if a file's content is relevant to the
// question (simple keyword overlap), a short excerpt — quoted, with the
// file name cited as the source — is included in the prompt context
// sent to Gemini. Never whole files; the excerpt is capped at 2,000
// characters. Files stay on-device.
//
// Pattern: user knowledge files, after alwin123098/jarvis-android
// docs/KNOWLEDGE.md + sample_knowledge/welcome.txt. Fresh
// implementation — no code copied.

import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// App-private folder (under the app documents directory) holding the
/// user's .txt knowledge files.
const String kJarvisKnowledgeFolder = 'jarvis_knowledge';

/// Most characters of one knowledge excerpt sent to Gemini.
const int kJarvisKnowledgeExcerptMaxChars = 2000;

/// Most bytes one knowledge file may hold (keeps the on-device store
/// small and the phone's storage safe).
const int kJarvisKnowledgeMaxFileBytes = 100 * 1024;

/// One knowledge file: its name and full text (kept in memory only
/// while the app runs).
class KnowledgeFile {
  const KnowledgeFile({required this.name, required this.content});

  final String name;
  final String content;
}

/// Keeps a file name safe for the app-private folder: letters, digits,
/// spaces, dots, dashes and underscores only; always ends in `.txt`.
String sanitizeKnowledgeFileName(String name) {
  var clean = name
      .trim()
      .replaceAll(RegExp(r'[^A-Za-z0-9 ._-]'), '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  if (clean.isEmpty) clean = 'note';
  if (clean.toLowerCase().endsWith('.txt')) {
    clean = clean.substring(0, clean.length - 4);
  }
  // A leading dot would hide the file; strip it.
  clean = clean.replaceAll(RegExp(r'^\.+'), '');
  if (clean.isEmpty) clean = 'note';
  return '$clean.txt';
}

/// Words too common to count as a knowledge keyword. Matching on these
/// would make every file "relevant" to every question.
const Set<String> _knowledgeStopwords = <String>{
  'what', 'when', 'where', 'which', 'that', 'this', 'with', 'from',
  'about', 'tell', 'have', 'does', 'your', 'there', 'their', 'been',
  'were', 'would', 'could', 'should', 'into', 'then', 'than', 'them',
  'they', 'and', 'the', 'for', 'are', 'but', 'not', 'you',
  'all', 'any', 'can', 'had', 'her', 'was', 'one', 'our', 'out', 'has',
  'how', 'why', 'who', 'whom', 'whose', 'will', 'just', 'like',
};

/// The question's keywords: lowercase words of 3+ letters, stopwords
/// removed, in first-seen order.
List<String> knowledgeKeywords(String question) {
  final seen = <String>{};
  final keywords = <String>[];
  for (final match in RegExp(r'[a-z0-9]+')
      .allMatches(question.toLowerCase())) {
    final word = match.group(0)!;
    if (word.length < 3) continue;
    if (_knowledgeStopwords.contains(word)) continue;
    if (seen.add(word)) keywords.add(word);
  }
  return keywords;
}

/// Picks the most relevant knowledge file for [question] by keyword
/// overlap, and returns its name plus a short excerpt (at most
/// [kJarvisKnowledgeExcerptMaxChars] characters) centred on the first
/// keyword hit. Returns null when no file shares a keyword with the
/// question, or when there are no files. Pure — no I/O, so it is
/// unit-testable.
({String fileName, String excerpt})? selectKnowledgeExcerpt(
  String question,
  List<KnowledgeFile> files,
) {
  final keywords = knowledgeKeywords(question);
  if (keywords.isEmpty || files.isEmpty) return null;

  KnowledgeFile? bestFile;
  var bestScore = 0;
  var bestFirstHit = -1;
  for (final file in files) {
    final lower = file.content.toLowerCase();
    var score = 0;
    var firstHit = -1;
    for (final keyword in keywords) {
      final at = lower.indexOf(keyword);
      if (at < 0) continue;
      score++;
      if (firstHit < 0 || at < firstHit) firstHit = at;
    }
    if (score > bestScore) {
      bestFile = file;
      bestScore = score;
      bestFirstHit = firstHit;
    }
  }
  if (bestFile == null || bestScore == 0 || bestFirstHit < 0) return null;

  final content = bestFile.content;
  var start = bestFirstHit - 200;
  if (start < 0) start = 0;
  var end = start + kJarvisKnowledgeExcerptMaxChars;
  if (end > content.length) end = content.length;
  var excerpt = content.substring(start, end);
  if (start > 0) excerpt = '…$excerpt';
  if (end < content.length) excerpt = '$excerpt…';
  return (fileName: bestFile.name, excerpt: excerpt);
}

/// The extra prompt context for one question, or '' when no knowledge
/// file is relevant. The file name is cited as the source so Jarvis can
/// say where the answer came from.
String buildKnowledgeContext(
  String question,
  List<KnowledgeFile> files,
) {
  final picked = selectKnowledgeExcerpt(question, files);
  if (picked == null) return '';
  return 'From the user\'s own notes (file "${picked.fileName}") — use '
      'this when it answers the question, quote it briefly, and name '
      'the file as the source:\n"${picked.excerpt}"';
}

/// On-device store for the user's .txt knowledge files.
class KnowledgeService {
  const KnowledgeService();

  Future<Directory> _folder() async {
    final docs = await getApplicationDocumentsDirectory();
    final folder = Directory('${docs.path}/$kJarvisKnowledgeFolder');
    if (!await folder.exists()) {
      await folder.create(recursive: true);
    }
    return folder;
  }

  /// Lists the .txt files in the knowledge folder, newest first.
  Future<List<KnowledgeFile>> listFiles() async {
    try {
      final folder = await _folder();
      final files = <KnowledgeFile>[];
      await for (final entry in folder.list()) {
        if (entry is! File) continue;
        if (!entry.path.toLowerCase().endsWith('.txt')) continue;
        final name = entry.uri.pathSegments.last;
        final content = await entry.readAsString();
        files.add(KnowledgeFile(name: name, content: content));
      }
      files.sort((a, b) => b.name.compareTo(a.name));
      return files;
    } catch (_) {
      return [];
    }
  }

  /// Saves [content] as a named .txt file (name is sanitised; an
  /// existing file with the same name is replaced). Throws
  /// [ArgumentError] when the name is empty after sanitising or the
  /// text is empty or over [kJarvisKnowledgeMaxFileBytes].
  Future<KnowledgeFile> saveFile(String name, String content) async {
    final cleanName = sanitizeKnowledgeFileName(name);
    final cleanContent = content.trim();
    if (cleanContent.isEmpty) {
      throw ArgumentError('Cannot save an empty knowledge file.');
    }
    if (cleanContent.length > kJarvisKnowledgeMaxFileBytes) {
      throw ArgumentError(
        'That text is too long for a knowledge file '
        '(max ${kJarvisKnowledgeMaxFileBytes ~/ 1024} KB).',
      );
    }
    final folder = await _folder();
    final file = File('${folder.path}/$cleanName');
    await file.writeAsString(cleanContent);
    return KnowledgeFile(name: cleanName, content: cleanContent);
  }

  /// Deletes one knowledge file. Returns true when a file was deleted.
  Future<bool> deleteFile(String name) async {
    try {
      final folder = await _folder();
      final file = File('${folder.path}/$name');
      if (!await file.exists()) return false;
      await file.delete();
      return true;
    } catch (_) {
      return false;
    }
  }
}
