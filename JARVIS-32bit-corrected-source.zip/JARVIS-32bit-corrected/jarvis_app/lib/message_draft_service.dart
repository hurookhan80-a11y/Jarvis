// Phase 7 (v1.1.0) — F34 message drafting.
//
// Voice command "message Ami that I'll be late" prepares a draft
// (shown on screen) and opens the messaging app with the draft
// prefilled — the user presses send themselves. Jarvis NEVER sends a
// message by itself: there is no auto-send anywhere in this file or
// in main.dart's draft flow. SMS opens via the Android SMS intent
// (smsto: + body); WhatsApp opens via a wa.me link with prefilled
// text. Contact lookup reuses the existing flutter_contacts path
// (same as voice calling in lib/main.dart). If a contact has no
// number, or several contacts match a name, main.dart asks which one
// instead of guessing.
//
// Pattern: AbuZar-Ansarii/Jarvis
// lib/services/message_drafting_service.dart. Fresh implementation —
// no code copied.

import 'package:flutter_contacts/flutter_contacts.dart';

/// Which app the draft opens in. `unspecified` means the user did not
/// name one — main.dart asks, defaulting to SMS when the contact has
/// no WhatsApp hint.
enum DraftChannel { sms, whatsapp, unspecified }

/// A parsed `message <who> that <text>` voice command.
class MessageDraftRequest {
  const MessageDraftRequest({
    required this.recipientName,
    required this.body,
    required this.channel,
  });

  /// The name as spoken (or the digits, for a bare number).
  final String recipientName;

  /// The message text, as spoken.
  final String body;
  final DraftChannel channel;
}

/// Parses "message Ami that I'll be late", "text Ami I'll be late",
/// "draft a message to Ami saying I'll be late", "whatsapp Ami that
/// I'll be late", "send a message to Ami: I'll be late".
/// Returns null when the utterance is not a message-draft command.
/// The returned body keeps the user's own casing; the recipient is
/// the name (or number) before the message text.
MessageDraftRequest? parseMessageDraft(String utterance) {
  final trimmed = utterance.trim();
  final lower = trimmed.toLowerCase();
  var channel = DraftChannel.unspecified;
  var rest = trimmed;
  // Channel words first.
  if (lower.startsWith('whatsapp ')) {
    channel = DraftChannel.whatsapp;
    rest = trimmed.substring('whatsapp '.length).trim();
  } else if (lower.startsWith('whats app ')) {
    channel = DraftChannel.whatsapp;
    rest = trimmed.substring('whats app '.length).trim();
  } else if (lower.startsWith('sms ')) {
    channel = DraftChannel.sms;
    rest = trimmed.substring('sms '.length).trim();
  }
  final lowerRest = rest.toLowerCase();
  String? afterVerb;
  for (final prefix in <String>[
    'draft a message to ',
    'draft a message for ',
    'send a message to ',
    'send a message ',
    'message to ',
    'message ',
    'text to ',
    'text ',
    'sms to ',
  ]) {
    if (lowerRest.startsWith(prefix)) {
      afterVerb = rest.substring(prefix.length).trim();
      break;
    }
  }
  // "whatsapp Ami that ..." has no message verb after the channel
  // word — the channel word itself implies a message.
  if (afterVerb == null && channel != DraftChannel.unspecified) {
    afterVerb = rest;
  }
  if (afterVerb == null || afterVerb.isEmpty) return null;
  // Split recipient from body at "that", "saying", "say" or ":".
  final split = RegExp(
    r'^(.*?)\s+(?:that|saying|say)\s+(.+)$',
    caseSensitive: false,
    dotAll: true,
  ).firstMatch(afterVerb);
  String recipient;
  String body;
  if (split != null) {
    recipient = (split.group(1) ?? '').trim();
    body = (split.group(2) ?? '').trim();
  } else {
    final colon = afterVerb.indexOf(':');
    if (colon > 0) {
      recipient = afterVerb.substring(0, colon).trim();
      body = afterVerb.substring(colon + 1).trim();
    } else {
      // No separator ("message Ami I'll be late"): the first word is
      // the recipient and the rest is the message. A bare "message
      // Ami" leaves the body empty and main.dart asks what to say.
      // Multi-word names need "that" ("message Muhammad Ali that
      // I'll be late") — the split above handles those.
      final firstSpace = afterVerb.indexOf(' ');
      if (firstSpace < 0) {
        return MessageDraftRequest(
          recipientName: afterVerb,
          body: '',
          channel: channel,
        );
      }
      recipient = afterVerb.substring(0, firstSpace).trim();
      body = afterVerb.substring(firstSpace + 1).trim();
    }
  }
  if (recipient.isEmpty) return null;
  return MessageDraftRequest(
    recipientName: recipient,
    body: body,
    channel: channel,
  );
}

/// A contact match for a draft: display name + one phone number.
/// A contact with several numbers produces one entry per number.
class DraftContact {
  const DraftContact({required this.name, required this.number});

  final String name;
  final String number;
}

/// Matches contacts by name the same way voice calling does
/// (substring either way, case-insensitive). Pure, so it is tested
/// directly; the real contact list comes from [MessageDraftService].
List<DraftContact> matchDraftContacts(
  List<DraftContact> all,
  String query,
) {
  final wanted = query.trim().toLowerCase();
  if (wanted.isEmpty) return [];
  // A bare number matches itself.
  final digits = wanted.replaceAll(RegExp(r'[^0-9+]'), '');
  if (digits.length >= 7 && RegExp(r'^\+?[0-9]{7,15}$').hasMatch(digits)) {
    return [DraftContact(name: wanted, number: digits)];
  }
  return all.where((c) {
    final name = c.name.toLowerCase();
    return name.contains(wanted) || wanted.contains(name);
  }).toList();
}

/// Keeps only the digits (and a leading +) of a phone number, for
/// wa.me links and sms: URIs. Pakistani mobile numbers without a
/// country code get +92 (03xx -> +92 3xx), matching how the dialer
/// path treats them.
String cleanPhoneNumber(String raw) {
  var digits = raw.replaceAll(RegExp(r'[^0-9+]'), '');
  if (digits.startsWith('00')) digits = '+${digits.substring(2)}';
  if (digits.startsWith('0') && digits.length == 11) {
    digits = '+92${digits.substring(1)}';
  }
  return digits;
}

/// Builds the SMS draft URI: `sms:<number>?body=<text>`. Opening it
/// shows the messaging app with the text prefilled; nothing is sent.
Uri buildSmsDraftUri(String number, String body) => Uri(
  scheme: 'sms',
  path: cleanPhoneNumber(number),
  queryParameters: <String, String>{'body': body},
);

/// Builds the WhatsApp draft link: `https://wa.me/<digits>?text=...`.
/// Opening it shows the WhatsApp chat with the text prefilled;
/// nothing is sent.
Uri buildWhatsAppDraftUri(String number, String body) {
  final digits = cleanPhoneNumber(number).replaceAll('+', '');
  return Uri.parse(
    'https://wa.me/$digits?text=${Uri.encodeComponent(body)}',
  );
}

/// Contact lookup for message drafting. Mirrors the voice-calling
/// lookup in lib/main.dart (same permission, same properties).
class MessageDraftService {
  const MessageDraftService();

  /// All contacts with a phone number, as draft candidates.
  Future<List<DraftContact>> loadCandidates() async {
    try {
      final granted = await FlutterContacts.permissions.request(
            PermissionType.read,
          ) ==
          PermissionStatus.granted;
      if (!granted) return [];
      final contacts = await FlutterContacts.getAll(
        properties: {ContactProperty.name, ContactProperty.phone},
      );
      final found = <DraftContact>[];
      for (final contact in contacts) {
        final name = contact.displayName ?? '';
        if (name.isEmpty) continue;
        for (final phone in contact.phones) {
          final number = phone.number.trim();
          if (number.isNotEmpty) {
            found.add(DraftContact(name: name, number: number));
          }
        }
      }
      return found;
    } catch (_) {
      return [];
    }
  }

  /// Contacts matching [query] by name (or the number itself).
  Future<List<DraftContact>> findContacts(String query) async {
    final all = await loadCandidates();
    return matchDraftContacts(all, query);
  }
}
