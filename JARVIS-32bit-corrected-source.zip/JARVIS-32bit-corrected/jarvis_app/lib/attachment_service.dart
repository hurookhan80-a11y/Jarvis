// v1.2.0 (G8) — attach a file or image to a task.
//
// The user picks a file with the system picker (Storage Access
// Framework — no storage permission needed). The attachment is READ,
// not stored: the caller sends its bytes to Gemini vision with
// GeminiRestClient.sendMessageWithImage, or hands text content to a
// task. Nothing is copied into the knowledge store.
//
// Picker API is file_picker 13.x (federated): the static
// FilePicker.pickFile() returns one PlatformFile (null on cancel),
// and PlatformFile.readAsBytes() reads through the picker — including
// Storage Access Framework content:// URIs, where there is no usable
// local path. The old 8.x FilePicker.platform.pickFiles +
// PlatformFile.bytes API no longer exists.
//
// Size guard: files over 10 MB are refused — a phone should never try
// to push a huge file through a chat request.
//
// Fresh implementation — no code copied.

import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';

/// Most bytes one attachment may hold (10 MB).
const int kJarvisMaxAttachmentBytes = 10 * 1024 * 1024;

/// Thrown when a file cannot be picked or is too big. The message is
/// shown to the user as-is.
class AttachmentException implements Exception {
  AttachmentException(this.message);

  final String message;

  @override
  String toString() => 'AttachmentException: $message';
}

/// One picked file, held in memory only while the task runs.
class PickedAttachment {
  const PickedAttachment({
    required this.name,
    required this.path,
    required this.mimeType,
    required this.bytes,
  });

  /// File name as the picker reports it (e.g. "ecg.png").
  final String name;

  /// Device path, when the picker gives one (may be empty on web /
  /// some pickers — [bytes] is the reliable payload).
  final String path;

  /// MIME type guessed from the extension (see
  /// [classifyAttachmentByExtension]).
  final String mimeType;

  /// The file's bytes.
  final Uint8List bytes;

  /// True when the MIME type is an image type.
  bool get isImage => mimeType.startsWith('image/');
}

/// Guesses the MIME type from a file name's extension (case-insensitive).
/// Images map to their image/* type, .txt/.md to text/plain, .pdf to
/// application/pdf, and anything unknown (or extension-less) to
/// application/octet-stream. Pure — no I/O, so it is unit-testable.
String classifyAttachmentByExtension(String name) {
  final dot = name.lastIndexOf('.');
  if (dot < 0 || dot == name.length - 1) return 'application/octet-stream';
  switch (name.substring(dot + 1).toLowerCase()) {
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'png':
      return 'image/png';
    case 'webp':
      return 'image/webp';
    case 'gif':
      return 'image/gif';
    case 'bmp':
      return 'image/bmp';
    case 'txt':
    case 'md':
      return 'text/plain';
    case 'pdf':
      return 'application/pdf';
    default:
      return 'application/octet-stream';
  }
}

/// Throws [AttachmentException] when [byteCount] is over the 10 MB
/// attachment limit. Pure, so the guard is unit-testable without a
/// picker.
void checkAttachmentSize(int byteCount) {
  if (byteCount > kJarvisMaxAttachmentBytes) {
    throw AttachmentException('That file is too big (over 10 MB).');
  }
}

/// Picks one file (or one image when [imagesOnly] is true) with the
/// system file picker. Returns null when the user cancels. Throws
/// [AttachmentException] when the file is over 10 MB or cannot be read.
class AttachmentService {
  const AttachmentService();

  Future<PickedAttachment?> pickAttachment({bool imagesOnly = false}) async {
    // file_picker 13.x: static FilePicker.pickFile() returns one
    // PlatformFile (null when the user cancels); there is no
    // FilePicker.platform / pickFiles / withData / allowMultiple any
    // more. PlatformFile.readAsBytes() reads through the picker,
    // including SAF content:// URIs with no usable local path.
    final file = await FilePicker.pickFile(
      type: imagesOnly ? FileType.image : FileType.any,
    );
    if (file == null) return null;

    Uint8List? bytes;
    try {
      bytes = await file.readAsBytes();
    } catch (_) {
      bytes = null;
    }
    if (bytes == null) {
      throw AttachmentException('Could not read that file.');
    }
    checkAttachmentSize(bytes.length);

    final name = file.name.trim().isNotEmpty
        ? file.name.trim()
        : 'attachment';
    return PickedAttachment(
      name: name,
      path: file.path ?? '',
      mimeType: classifyAttachmentByExtension(name),
      bytes: bytes,
    );
  }
}
