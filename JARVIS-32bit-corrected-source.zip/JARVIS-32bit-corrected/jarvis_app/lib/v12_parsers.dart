// v1.2.0 (Jarvis 2.0 free ideas) — pure parsers for the voice
// commands wired up in main.dart. No I/O, no Flutter, so they are
// unit-testable here (see test/v12_parsers_test.dart). All of them
// work on the lower-cased utterance unless noted.

/// "3 pm" / "3:30 pm" / "15:30" out of an utterance. Null when no
/// usable time is found.
({int hour, int minute})? parseV12TimeOfDay(String text) {
  final withAmPm =
      RegExp(r'(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b').firstMatch(text);
  if (withAmPm != null) {
    var hour = int.parse(withAmPm.group(1)!);
    final minute = int.parse(withAmPm.group(2) ?? '0');
    final amPm = withAmPm.group(3)!;
    if (hour > 12 || minute > 59) return null;
    if (amPm == 'pm' && hour < 12) hour += 12;
    if (amPm == 'am' && hour == 12) hour = 0;
    return (hour: hour, minute: minute);
  }
  final twentyFour = RegExp(r'\b(\d{1,2}):(\d{2})\b').firstMatch(text);
  if (twentyFour != null) {
    final hour = int.parse(twentyFour.group(1)!);
    final minute = int.parse(twentyFour.group(2)!);
    if (hour > 23 || minute > 59) return null;
    return (hour: hour, minute: minute);
  }
  return null;
}

const _v12Weekdays = <String>[
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
  'sunday'
];

/// A day + time out of a calendar-event utterance. Day words: today
/// / tomorrow / a weekday name (with or without "next"). A named
/// weekday whose time already passed rolls to next week; an unnamed
/// past time today rolls to tomorrow. Null when no usable time is
/// found. [now] is a parameter so tests can pin the clock.
DateTime? parseV12EventDateTime(String normalized, DateTime now) {
  final time = parseV12TimeOfDay(normalized);
  if (time == null) return null;
  var day = DateTime(now.year, now.month, now.day);
  var namedWeekday = false;
  if (normalized.contains('tomorrow')) {
    day = day.add(const Duration(days: 1));
  } else {
    for (var i = 0; i < _v12Weekdays.length; i++) {
      if (normalized.contains(_v12Weekdays[i])) {
        namedWeekday = true;
        final target = i + 1;
        var delta = (target - now.weekday) % 7;
        if (normalized.contains('next ${_v12Weekdays[i]}')) delta += 7;
        day = day.add(Duration(days: delta));
        break;
      }
    }
  }
  final start =
      DateTime(day.year, day.month, day.day, time.hour, time.minute);
  if (start.isBefore(now)) {
    // A past time: a named weekday means next week, anything else
    // means tomorrow.
    return start
        .add(Duration(days: namedWeekday ? 7 : 1));
  }
  return start;
}

/// The event title: the utterance with the trigger phrase, day words
/// and time removed, tidied up.
String parseV12EventTitle(String normalized) {
  var text = normalized;
  for (final trigger in <String>[
    'create a calendar event',
    'add a calendar event',
    'create an event',
    'schedule an event',
    'add event',
  ]) {
    text = text.replaceFirst(trigger, '');
  }
  for (final day in [..._v12Weekdays, 'tomorrow', 'today', 'next']) {
    text = text.replaceAll(day, '');
  }
  text = text.replaceAll(RegExp(r'\d{1,2}(?::\d{2})?\s*(?:am|pm)\b'), '');
  text = text.replaceAll(RegExp(r'\b\d{1,2}:\d{2}\b'), '');
  text = text
      .replaceAll(RegExp(r'\s+'), ' ')
      .replaceAll(RegExp(r'^(\s*(at|on))+'), '')
      .replaceAll(RegExp(r'(\s+(at|on))+\s*$'), '')
      .trim();
  return text;
}

/// "Monday, 3:30 pm" style label for a scheduled time.
String formatV12EventTime(DateTime start) {
  final hour = start.hour % 12 == 0 ? 12 : start.hour % 12;
  final amPm = start.hour < 12 ? 'am' : 'pm';
  final minute = start.minute.toString().padLeft(2, '0');
  const weekdays = <String>[
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];
  return '${weekdays[start.weekday - 1]}, $hour:$minute $amPm';
}

/// Parses "to" + address + "subject"/"about" + subject +
/// "body"/"saying" + body out of an email command. Returns null when
/// no email address is found. [query] keeps its original case so the
/// subject and body are not lower-cased.
({String to, String subject, String body})? parseV12EmailCommand(
    String query) {
  final address = RegExp(r'[\w.+-]+@[\w-]+\.[a-z]{2,}',
          caseSensitive: false)
      .firstMatch(query)
      ?.group(0);
  if (address == null) return null;
  var rest = query.substring(
      query.toLowerCase().indexOf(address.toLowerCase()) + address.length);
  var subject = '';
  var body = '';
  final bodyMatch = RegExp(r'\b(?:body|saying)\s+(.+)$',
          caseSensitive: false, dotAll: true)
      .firstMatch(rest);
  if (bodyMatch != null) {
    body = bodyMatch.group(1)!.trim();
    rest = rest.substring(0, bodyMatch.start);
  }
  final subjectMatch = RegExp(r'\b(?:subject|about)\s+(.+)$',
          caseSensitive: false, dotAll: true)
      .firstMatch(rest);
  if (subjectMatch != null) {
    subject = subjectMatch.group(1)!.trim();
  }
  return (to: address, subject: subject, body: body);
}

/// "search the web for X" / "research X" / "look up X on the web".
/// Returns null for anything else. [query] keeps its original case
/// for the search text.
String? parseV12ResearchQuery(String normalized, String query) {
  const prefixes = <String>[
    'search the web for ',
    'search web for ',
    'look up ',
    'research ',
  ];
  final trimmed = query.trim();
  for (final prefix in prefixes) {
    // Match on the trimmed prefix: the raw utterance may end right
    // after the trigger words ("search the web for" with nothing
    // after it), and the trimmed query is then shorter than the
    // prefix with its trailing space.
    final trigger = prefix.trim();
    if (!normalized.startsWith(prefix) &&
        !trimmed.toLowerCase().startsWith(trigger)) {
      continue;
    }
    final rest = trimmed.length > trigger.length
        ? trimmed.substring(trigger.length).trim()
        : '';
    if (rest.isEmpty) return null;
    if (prefix == 'look up ') {
      final cleaned = rest
          .replaceFirst(
              RegExp(r'\s+on the web\s*$', caseSensitive: false), '')
          .trim();
      if (cleaned.isEmpty) return null;
      return cleaned;
    }
    return rest;
  }
  return null;
}

/// The topic of a workflow command: "run X workflow about Y" /
/// "... for Y". Null when the command names no topic.
String? extractV12Topic(String normalized) {
  final about = RegExp(r'\babout\s+(.+)$').firstMatch(normalized);
  if (about != null) return about.group(1)!.trim();
  final forTopic = RegExp(r'\bfor\s+(.+)$').firstMatch(normalized);
  if (forTopic != null) return forTopic.group(1)!.trim();
  return null;
}
