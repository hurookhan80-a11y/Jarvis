// Phase 7 (v1.1.0) — F27 calendar reminders.
//
// Reads the device calendar (READ_CALENDAR, granted in onboarding F25)
// and surfaces today's events. READ-ONLY — Jarvis never writes to the
// calendar. The optional announce switch (default OFF) schedules each
// upcoming event as a reminder 15 minutes before it starts, through
// the existing durable reminder system (F7 / ReminderService), so it
// fires even if the app is swiped away.
//
// The native read is a small platform channel in MainActivity.kt
// (CalendarContract.Instances). The pure helpers (nextEvent,
// formatEventLine, calendarReminderId) are unit-tested directly.

import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'reminder_service.dart';

/// SharedPreferences key: is the "announce next event" switch on?
/// Default OFF (F27).
const String kJarvisCalendarAnnounceKey = 'jarvis_calendar_announce_enabled';

/// SharedPreferences key: the set of event keys already scheduled as
/// reminders, so an event is never announced twice.
const String kJarvisCalendarAnnouncedKey = 'jarvis_calendar_announced_v1';

/// How long before an event the announcement reminder fires.
const Duration kJarvisCalendarAnnounceLead = Duration(minutes: 15);

/// One calendar event, today.
class CalendarEvent {
  const CalendarEvent({
    required this.title,
    required this.start,
    required this.end,
    required this.calendarName,
    required this.allDay,
  });

  factory CalendarEvent.fromMap(Map<String, dynamic> map) {
    return CalendarEvent(
      title: map['title']?.toString() ?? '(No title)',
      start: DateTime.fromMillisecondsSinceEpoch(
        map['start'] is int
            ? map['start'] as int
            : int.tryParse(map['start']?.toString() ?? '') ?? 0,
      ),
      end: DateTime.fromMillisecondsSinceEpoch(
        map['end'] is int
            ? map['end'] as int
            : int.tryParse(map['end']?.toString() ?? '') ?? 0,
      ),
      calendarName: map['calendar']?.toString() ?? '',
      allDay: map['allDay'] == true || map['allDay'] == 1,
    );
  }

  final String title;
  final DateTime start;
  final DateTime end;
  final String calendarName;
  final bool allDay;

  /// Stable key for de-duplication: title + start time.
  String get key => '$title|${start.millisecondsSinceEpoch}';
}

/// The next event that has not started yet (or is in progress), or null.
CalendarEvent? nextEvent(List<CalendarEvent> events, {DateTime? now}) {
  final at = now ?? DateTime.now();
  final upcoming = events
      .where((e) => e.end.isAfter(at))
      .toList()
    ..sort((a, b) => a.start.compareTo(b.start));
  return upcoming.isEmpty ? null : upcoming.first;
}

/// "Class at 9:00 AM – 10:00 AM" (all-day events show "All day").
String formatEventLine(CalendarEvent event) {
  if (event.allDay) return '${event.title} · All day';
  final time = DateFormat.jm();
  return '${event.title} · ${time.format(event.start)} – ${time.format(event.end)}';
}

/// Deterministic reminder id for one event's announcement. Calendar
/// announcement ids live in the 1,000,000,000+ range, which never
/// collides with user reminders (epoch-millis ids, ~1.7e12).
int calendarReminderId(CalendarEvent event) {
  return 1000000000 +
      (event.start.millisecondsSinceEpoch % 1000000000);
}

class CalendarService {
  const CalendarService();

  static const MethodChannel _channel =
      MethodChannel('com.jarvis.jarvis_app/calendar');

  /// Today's events, earliest first. Returns [] when the calendar
  /// permission is missing or the channel fails — the screen then
  /// explains and offers to grant it.
  Future<List<CalendarEvent>> getTodayEvents() async {
    try {
      final raw = await _channel.invokeMethod<List<dynamic>>(
        'getTodayEvents',
      );
      final events = <CalendarEvent>[];
      for (final item in raw ?? <dynamic>[]) {
        if (item is Map) {
          events.add(
            CalendarEvent.fromMap(Map<String, dynamic>.from(item)),
          );
        }
      }
      events.sort((a, b) => a.start.compareTo(b.start));
      return events;
    } catch (_) {
      return [];
    }
  }

  Future<bool> isAnnounceEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(kJarvisCalendarAnnounceKey) ?? false;
  }

  Future<void> setAnnounceEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(kJarvisCalendarAnnounceKey, enabled);
    if (!enabled) await cancelAnnouncements();
  }

  /// Schedules an announcement reminder (15 min before) for each
  /// upcoming event that has not been scheduled yet. Safe to call
  /// repeatedly — already-scheduled events are skipped.
  Future<void> scheduleAnnouncements(List<CalendarEvent> events) async {
    if (!await isAnnounceEnabled()) return;
    final prefs = await SharedPreferences.getInstance();
    final done = prefs.getStringList(kJarvisCalendarAnnouncedKey) ?? [];
    final doneSet = done.toSet();
    final now = DateTime.now();
    for (final event in events) {
      if (doneSet.contains(event.key)) continue;
      final fireAt = event.start.subtract(kJarvisCalendarAnnounceLead);
      if (fireAt.isBefore(now)) continue;
      final id = calendarReminderId(event);
      final text =
          'Calendar: ${event.title} at ${DateFormat.jm().format(event.start)}';
      // The durable backstop (F7) needs the reminder in the same store
      // the in-app list uses, so it can fire after the app is killed.
      final stored = parseStoredReminders(
        prefs.getString(kJarvisRemindersKey),
      );
      if (stored.any((r) => r['id'] == id)) {
        doneSet.add(event.key);
        continue;
      }
      stored.add({
        'id': id,
        'text': text,
        'fireAt': fireAt.toIso8601String(),
      });
      await prefs.setString(
        kJarvisRemindersKey,
        encodeReminders(stored),
      );
      await ReminderService.schedule(id, text, fireAt);
      doneSet.add(event.key);
    }
    await prefs.setStringList(
      kJarvisCalendarAnnouncedKey,
      doneSet.toList(),
    );
  }

  /// Drops every pending calendar announcement (and its stored entry).
  Future<void> cancelAnnouncements() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = parseStoredReminders(
      prefs.getString(kJarvisRemindersKey),
    );
    final kept = <Map<String, dynamic>>[];
    for (final reminder in stored) {
      final id = reminder['id'] as int;
      final isCalendar = id >= 1000000000 && id < 2000000000;
      if (isCalendar) {
        await ReminderService.cancel(id);
      } else {
        kept.add(reminder);
      }
    }
    await prefs.setString(kJarvisRemindersKey, encodeReminders(kept));
    await prefs.remove(kJarvisCalendarAnnouncedKey);
  }
}
