// Phase 7 (v1.1.0) — F24 default-assistant role.
//
// Requests the Android default-assistant role via RoleManager
// (API 29+; guarded — his phone is Android 14, API 34, so it
// applies). The user grants or declines in a system dialog; declining
// changes nothing and breaks nothing. The app must declare an ASSIST
// activity (AssistActivity.kt + manifest) to be eligible for the role.
//
// Jarvis never claims to be the default assistant unless the role is
// actually held (see [isHeld]).

import 'package:flutter/services.dart';

/// Default-assistant role, through the existing device channel in
/// MainActivity.kt (RoleManager, API 29+ guard on the native side).
class AssistantRoleService {
  const AssistantRoleService();

  static const MethodChannel _deviceChannel =
      MethodChannel('com.jarvis.jarvis_app/device');

  /// True only when the system says Jarvis currently holds the
  /// assistant role.
  Future<bool> isHeld() async {
    try {
      return await _deviceChannel.invokeMethod<bool>(
            'isAssistantRoleHeld',
          ) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Opens the system role-request dialog. Returns true when the user
  /// granted the role, false when they declined or the role is not
  /// available on this phone. Never throws.
  Future<bool> request() async {
    try {
      return await _deviceChannel.invokeMethod<bool>(
            'requestAssistantRole',
          ) ??
          false;
    } catch (_) {
      return false;
    }
  }
}
