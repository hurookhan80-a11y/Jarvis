import 'dart:async';
import 'dart:math';

import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:url_launcher/url_launcher.dart';

import 'command_parser.dart';
import 'gemini_client.dart';

const MethodChannel _secureStorageChannel = MethodChannel('com.jarvis.jarvis_app/secure_storage');


void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterForegroundTask.initCommunicationPort();
  runApp(const JarvisApp());
}

/// Background-service callback: keeps the app process alive so wake-word
/// listening can continue while Jarvis is minimised. The service itself does
/// nothing but stay alive; the main isolate's 30-second timer re-arms
/// listening. Stops when the app is swiped away from recents
/// (stopWithTask in the manifest).
@pragma('vm:entry-point')
void jarvisForegroundCallback() {
  FlutterForegroundTask.setTaskHandler(JarvisForegroundTaskHandler());
}

class JarvisForegroundTaskHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {}

  @override
  void onRepeatEvent(DateTime timestamp) {}

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {}

  @override
  void onNotificationPressed() {
    FlutterForegroundTask.launchApp();
  }
}

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  final AudioPlayer _audioPlayer = AudioPlayer();
  Timer? _navigationTimer;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
    );
    _fadeAnimation =
        Tween<double>(begin: 0.0, end: 1.0).animate(_fadeController);
    _fadeController.forward();

    _playStartupSound();

    _navigationTimer = Timer(const Duration(seconds: 5), () {
      if (!mounted) return;
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => JarvisScreen()));
    });
  }

  Future<void> _playStartupSound() async {
    try {
      await _audioPlayer.play(AssetSource('sounds/startup.mp3'));
    } catch (e) {
      debugPrint('Error playing startup sound: $e');
    }
  }

  @override
  void dispose() {
    _navigationTimer?.cancel();
    _fadeController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: CircuitPatternPainter(),
            ),
          ),
          Center(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    colors: [
                      Colors.blue.withValues(alpha: 0.3),
                      Colors.transparent,
                    ],
                    radius: 1.2,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'J.A.R.V.I.S',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 52,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 4,
                        shadows: [
                          Shadow(
                            color: Colors.blue.withValues(alpha: 0.9),
                            blurRadius: 20,
                            offset: Offset(0, 0),
                          ),
                          Shadow(
                            color: Colors.white.withValues(alpha: 0.5),
                            blurRadius: 30,
                            offset: Offset(0, 0),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 25),
                    Container(
                      width: 180,
                      height: 180,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            Colors.blue.withValues(alpha: 0.4),
                            Colors.blue.withValues(alpha: 0.2),
                            Colors.transparent,
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.blue.withValues(alpha: 0.4),
                            blurRadius: 30,
                            spreadRadius: 8,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Icon(
                          Icons.power_settings_new,
                          size: 70,
                          color: Colors.blue.withValues(alpha: 0.9),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CircuitPatternPainter extends CustomPainter {
  final bool isIdleState;

  CircuitPatternPainter({this.isIdleState = true});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue.withValues(alpha: 0.2)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final random = Random();
    final numberOfLines = 120;
    final numberOfNodes = 25;

    final seedRandom = isIdleState ? Random(DateTime.now().millisecondsSinceEpoch ~/ (isIdleState ? 10000 : 1000)) : random;

    final nodes = List.generate(numberOfNodes, (index) {
      return Offset(
        seedRandom.nextDouble() * size.width,
        seedRandom.nextDouble() * size.height,
      );
    });

    for (var i = 0; i < nodes.length; i++) {
      for (var j = i + 1; j < nodes.length; j++) {
        if (seedRandom.nextDouble() < 0.35) {
          final path = Path();
          path.moveTo(nodes[i].dx, nodes[i].dy);
          path.lineTo(nodes[j].dx, nodes[j].dy);
          canvas.drawPath(path, paint);
        }
      }
    }

    for (var i = 0; i < numberOfLines; i++) {
      final startX = seedRandom.nextDouble() * size.width;
      final startY = seedRandom.nextDouble() * size.height;
      final path = Path();
      path.moveTo(startX, startY);

      var currentX = startX;
      var currentY = startY;
      var segments = seedRandom.nextInt(5) + 3; 

      for (var j = 0; j < segments; j++) {
        if (seedRandom.nextBool()) {
          currentX +=
              seedRandom.nextDouble() * 150 - 75; 
        } else {
          currentY += seedRandom.nextDouble() * 150 - 75;
        }
        path.lineTo(currentX, currentY);
      }

      if (seedRandom.nextDouble() < 0.3) {
        final controlPoint = Offset(
          (startX + currentX) / 2 + seedRandom.nextDouble() * 50 - 25,
          (startY + currentY) / 2 + seedRandom.nextDouble() * 50 - 25,
        );
        path.quadraticBezierTo(
          controlPoint.dx,
          controlPoint.dy,
          currentX,
          currentY,
        );
      }

      canvas.drawPath(path, paint);
    }

    final dotPaint = Paint()
      ..color = Colors.blue.withValues(alpha: 0.5)
      ..style = PaintingStyle.fill;

    for (var node in nodes) {
      canvas.drawCircle(node, 3, dotPaint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) =>
      true; 
}

class JarvisScreen extends StatefulWidget {
  @override
  _JarvisScreenState createState() => _JarvisScreenState();
}

class _JarvisScreenState extends State<JarvisScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  // Gemini API key / model are entered by the user in Settings (gear icon)
  // The API key is stored through a native Android Keystore-backed channel.
  String _apiKey = '';
  String _modelName = 'gemini-3.8-flash';
  String _pendingCommand = '';
  bool _isProcessingQuery = false;
  bool _isAppInForeground = true;
  DateTime? _timerEndsAt;
  GeminiRestClient? model;
  late stt.SpeechToText speech;
  late FlutterTts flutterTts;
  late Future<void> _ttsReady;
  bool isListening = false;
  bool isSpeaking = false;
  DateTime? _speakingSince;
  String responseText = "";
  // On-screen chat transcript: what the user said/typed + what Jarvis replied.
  final List<Map<String, String>> _chatMessages = [];
  final TextEditingController _chatInputController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();

  void _addChatMessage(String role, String text) {
    if (!mounted || text.trim().isEmpty) return;
    setState(() {
      _chatMessages.add({'role': role, 'text': text});
      if (_chatMessages.length > 50) _chatMessages.removeAt(0);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_chatScrollController.hasClients) {
        _chatScrollController.animateTo(
          _chatScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendTypedMessage() {
    final text = _chatInputController.text.trim();
    if (text.isEmpty) return;
    if (_isProcessingQuery) {
      _addChatMessage(
          'jarvis', 'Still working on your last question — one moment.');
      return;
    }
    _chatInputController.clear();
    _addChatMessage('user', text);
    processQuery(text);
  }
  final List<GeminiChatMessage> conversationHistory = [];
  late AnimationController _animationController;
  late Animation<double> _bounceAnimation;
  Timer? _timer;
  int? _remainingSeconds;
  bool _isTimerActive = false;
  bool _isWakeWordDetected = false;
  Timer? _wakeWordTimer;
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isBackgroundListening = false;
  bool _isInConversationMode =
      false; 

  late AnimationController _colorAnimationController;
  late Animation<Color?> _colorAnimation;
  int _currentColorIndex = 0;
  final List<Color> _ironManColors = [
    Colors.red,
    Colors.blue,
    Color(0xFF00B8D4), // greenish blue (cyan)
    Color(0xFFE91E63), // reddish blue (pink)
    Color(0xFFFFA000), // amber (gold)
  ];

  Timer? _backgroundAnimationTimer;
  int _backgroundAnimationCounter = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadSettings();
    _initForegroundService();
    _loadConnectedApps();
    speech = stt.SpeechToText();
    flutterTts = FlutterTts();

    _ttsReady = _configureTextToSpeech();

    flutterTts.setCompletionHandler(() {
      if (!mounted) return;
      setState(() {
        isSpeaking = false;
        _speakingSince = null;
      });
      // After Jarvis finishes speaking, listen again right away instead of
      // waiting for the 30-second timer. No foreground check: the background
      // service keeps listening alive when the app is minimised.
      if (_isInConversationMode) {
        _continueConversation();
      } else if (_isBackgroundListening) {
        _startWakeWordDetection();
      }
    });

    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 500),
    )..repeat(reverse: true);
    _bounceAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _colorAnimationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 2000),
    );

    _setupColorAnimation();

    _colorAnimationController.forward();
    _colorAnimationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _currentColorIndex = (_currentColorIndex + 1) % _ironManColors.length;
        _setupColorAnimation();
        _colorAnimationController.reset();
        _colorAnimationController.forward();
      }
    });

    _startWakeWordDetection();

    _wakeWordTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (_isBackgroundListening &&
          !speech.isListening &&
          !_isWakeWordDetected &&
          !isSpeaking &&
          !_isInConversationMode) {
        _startWakeWordDetection();
      }
      // If conversation listening died after a reply, re-arm it so the
      // app does not go silent after the first exchange.
      if (_isInConversationMode &&
          !speech.isListening &&
          !isSpeaking &&
          !_isProcessingQuery) {
        _continueConversation();
      }
      // Safety net: if TTS never reported completion, speaking gets stuck
      // and listening never restarts. Force-stop it after 60 seconds.
      if (isSpeaking &&
          _speakingSince != null &&
          DateTime.now().difference(_speakingSince!).inSeconds > 60) {
        flutterTts.stop();
        if (mounted) {
          setState(() {
            isSpeaking = false;
            _speakingSince = null;
          });
        }
      }
    });

    _startBackgroundAnimationTimer();
  }

  Future<void> _configureTextToSpeech() async {
    try {
      await flutterTts.setLanguage('en-au');
      await flutterTts.setPitch(0.8);
      await flutterTts.setSpeechRate(0.6);
      await flutterTts.awaitSpeakCompletion(true);
    } catch (_) {
      // Keep the device's default TTS configuration if a setting is unsupported.
    }
  }

  GeminiRestClient _buildModel(String apiKey, String modelName) {
    return GeminiRestClient(apiKey: apiKey, modelName: modelName);
  }

  Future<void> _loadSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      var savedKey = '';
      try {
        savedKey = await _secureStorageChannel.invokeMethod<String>('readApiKey') ?? '';
      } catch (_) {
        savedKey = '';
      }
      final savedModel = prefs.getString('gemini_model') ?? 'gemini-3.8-flash';
      if (!mounted) return;
      model?.dispose();
      conversationHistory.clear();
      setState(() {
        _apiKey = savedKey;
        _modelName = savedModel;
        model = _apiKey.isNotEmpty ? _buildModel(_apiKey, _modelName) : null;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _apiKey = '';
        model = null;
      });
    }
  }

  Future<void> _saveSettings(String key, String modelName) async {
    final prefs = await SharedPreferences.getInstance();
    final normalizedModel = modelName.trim().isEmpty ? 'gemini-3.8-flash' : modelName.trim();
    if (key.trim().isEmpty) {
      await _secureStorageChannel.invokeMethod<void>('clearApiKey');
    } else {
      await _secureStorageChannel.invokeMethod<void>('saveApiKey', {'apiKey': key.trim()});
    }
    await prefs.setString('gemini_model', normalizedModel);
    if (!mounted) return;
    model?.dispose();
    conversationHistory.clear();
    setState(() {
      _apiKey = key.trim();
      _modelName = normalizedModel;
      model = _apiKey.isNotEmpty ? _buildModel(_apiKey, _modelName) : null;
    });
  }

  void _showSettingsDialog() {
    final keyController = TextEditingController(text: _apiKey);
    final modelController = TextEditingController(text: _modelName);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('Gemini Settings',
            style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Paste your free Gemini API key from Google AI Studio (aistudio.google.com). Voice commands such as opening apps, telling the time, timers and alarms work without a key.',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: keyController,
                obscureText: true,
                enableSuggestions: false,
                autocorrect: false,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Gemini API key',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: modelController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Model name',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await _saveSettings('', 'gemini-3.8-flash');
              keyController.dispose();
              modelController.dispose();
              if (context.mounted) Navigator.of(context).pop();
            },
            child:
                const Text('Clear key', style: TextStyle(color: Colors.redAccent)),
          ),
          TextButton(
            onPressed: () {
              keyController.dispose();
              modelController.dispose();
              Navigator.of(context).pop();
            },
            child:
                const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _saveSettings(keyController.text.trim(), modelController.text.trim());
                keyController.dispose();
                modelController.dispose();
                if (context.mounted) Navigator.of(context).pop();
                speak('Settings saved, sir.');
              } catch (_) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Could not securely save the API key. Please try again.')),
                  );
                }
              }
            },
            child: const Text('Save', style: TextStyle(color: Colors.cyan)),
          ),
        ],
      ),
    );
  }

  void _startBackgroundAnimationTimer() {
    _backgroundAnimationTimer = Timer.periodic(Duration(seconds: 5), (timer) {
      if (!_isWakeWordDetected && !isSpeaking && !_isInConversationMode) {
        setState(() {
          _backgroundAnimationCounter++;
        });
      }
    });
  }

  void _setupColorAnimation() {
    final nextColorIndex = (_currentColorIndex + 1) % _ironManColors.length;
    _colorAnimation = ColorTween(
      begin: _ironManColors[_currentColorIndex],
      end: _ironManColors[nextColorIndex],
    ).animate(_colorAnimationController);
  }

  Future<void> _startWakeWordDetection() async {
    if (!mounted || _isInConversationMode) return;
    try {
      final available = await speech.initialize();
      if (!mounted) return;
      if (!available) {
        // Speech service hiccup (no network / Google app busy). Keep the
        // toggle ON so the 30-second timer retries — never switch it off
        // by ourselves, or voice dies silently until the user re-toggles.
        debugPrint('Speech recognition unavailable; will retry.');
        return;
      }
      setState(() => _isBackgroundListening = true);
      speech.statusListener = (status) {
        if (status == stt.SpeechToText.doneStatus ||
            status == stt.SpeechToText.notListeningStatus) {
          if (_isBackgroundListening &&
              !_isWakeWordDetected &&
              !_isInConversationMode) {
            Future.delayed(const Duration(milliseconds: 350), () {
              if (mounted &&
                  _isBackgroundListening &&
                  !_isWakeWordDetected &&
                  !_isInConversationMode) {
                _startListeningForWakeWord();
              }
            });
          }
        }
      };
      _startListeningForWakeWord();
    } catch (_) {
      // Same as above: keep the toggle ON; the timer retries.
      debugPrint('Wake-word start failed; will retry.');
    }
  }

  void _startListeningForWakeWord() {
    if (!speech.isListening && mounted && !_isInConversationMode) {
      try {
        speech.listen(
          onResult: (result) {
            if (result.finalResult) {
              if (!mounted) return;
              String userInput = result.recognizedWords.toLowerCase();
              if (userInput.contains('jarvis') ||
                  userInput.contains('hey jarvis')) {
                _addChatMessage('user', userInput);
                setState(() => _isWakeWordDetected = true);
                _playWakeSound();

                _startConversationMode();
              }
            }
          },
          listenFor: Duration(minutes: 10), 
          pauseFor: Duration(seconds: 10), 
          partialResults: true,
          listenMode: stt.ListenMode.deviceDefault,
          cancelOnError: false,
          onSoundLevelChange: (level) {},
        );
      } catch (e) {
        debugPrint("Error starting speech recognition: $e");

        Future.delayed(Duration(seconds: 2), () {
          if (mounted && _isBackgroundListening && !_isInConversationMode) {
            _startListeningForWakeWord();
          }
        });
      }
    }
  }

  void _startConversationMode() {
    speech.stop();

    setState(() {
      _isInConversationMode = true;
      _isWakeWordDetected = true;
    });

    speak("I'm listening, sir. How can I assist you?");
    _addChatMessage('jarvis', "I'm listening, sir. How can I assist you?");
  }

  void _continueConversation() {
    if (!mounted || !_isInConversationMode || _isProcessingQuery) return;

    debugPrint("Continuing conversation...");

    if (!speech.isListening) {
      try {
        speech.listen(
          onResult: (result) async {
            if (result.finalResult) {
              if (!mounted) return;
              String userInput = result.recognizedWords.toLowerCase();
              _addChatMessage('user', userInput);

              if (userInput.contains("end conversation") ||
                  userInput.contains("goodbye") ||
                  userInput.contains("bye") ||
                  userInput.contains("that's all") ||
                  userInput.contains("exit conversation")) {
                _endConversationMode();
                speak(
                    "Ending conversation mode. Just say 'Hey Jarvis' when you need me again.");
                return;
              }

              processQuery(userInput);
            }
          },
          listenFor: Duration(minutes: 10),
          pauseFor: Duration(seconds: 10),
          partialResults: true,
          listenMode: stt.ListenMode.deviceDefault,
          cancelOnError: false,
          onSoundLevelChange: (level) {},
        );

        speech.statusListener = (status) {
          if ((status == stt.SpeechToText.doneStatus ||
                  status == stt.SpeechToText.notListeningStatus) &&
              _isInConversationMode &&
              !isSpeaking &&
              !_isProcessingQuery) {
            Future.delayed(Duration(milliseconds: 300), () {
              if (mounted &&
                  _isInConversationMode &&
                  !isSpeaking &&
                  !_isProcessingQuery &&
                  !speech.isListening) {
                debugPrint("Restarting conversation listening...");
                _continueConversation();
              }
            });
          }
        };
      } catch (e) {
        debugPrint("Error in conversation listening: $e");

        Future.delayed(Duration(seconds: 1), () {
          if (mounted && _isInConversationMode) {
            _continueConversation();
          }
        });
      }
    }
  }

  void _endConversationMode() {
    setState(() {
      _isInConversationMode = false;
      _isWakeWordDetected = false;
    });

    if (_isBackgroundListening) {
      _startWakeWordDetection();
    }
  }


  Future<void> processQuery(String query) async {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty || _isProcessingQuery) return;

    if (normalized.contains('cancel timer') || normalized.contains('stop timer')) {
      _pendingCommand = '';
      _timer?.cancel();
      _timerEndsAt = null;
      if (mounted) setState(() { _isTimerActive = false; _remainingSeconds = null; });
      speak('Timer cancelled.');
      return;
    }
    // "Stop" / "chup" / "khamosh": silence Jarvis immediately. Exact
    // phrases only, so questions like "how do I stop a nosebleed" still
    // get answered instead of silencing the app.
    const stopWords = <String>{
      'stop',
      'stop jarvis',
      'jarvis stop',
      'please stop',
      'stop please',
      'stop speaking',
      'stop talking',
      'chup',
      'chup ho jao',
      'chup kar',
      'khamosh',
      'khamosh ho jao',
      'bas',
      'bas karo',
      'ruk jao',
      'ruk',
      'band karo',
      'quiet',
      'shut up',
    };
    if (stopWords.contains(normalized)) {
      _stopSpeaking();
      _addChatMessage('jarvis', 'Stopped.');
      return;
    }
    if (_pendingCommand == 'alarm' && normalized.contains('cancel')) {
      _pendingCommand = '';
      speak('Alarm request cancelled.');
      return;
    }

    // A follow-up answer is routed to the command that requested it.
    if (_pendingCommand == 'timer') {
      _pendingCommand = '';
      _handleTimerCommand(normalized, allowPrompt: false);
      return;
    }
    if (_pendingCommand == 'alarm') {
      _pendingCommand = '';
      await _handleAlarmCommand(normalized, allowPrompt: false);
      return;
    }

    if (RegExp(r'\b(weather|forecast)\b').hasMatch(normalized)) {
      _searchWeather();
      return;
    }
    if (RegExp(r'\b(time|what time|current time|tell me the time|time now)\b').hasMatch(normalized)) {
      _tellTime();
      return;
    }
    if (normalized.contains('set timer') || normalized.contains('start timer') || normalized.contains('timer for')) {
      _handleTimerCommand(normalized);
      return;
    }
    if (normalized.contains('set alarm') || normalized.contains('alarm for')) {
      await _handleAlarmCommand(normalized);
      return;
    }
    // Device controls (checked before "open ..." so "open wifi settings"
    // does not fall through to the Play Store search).
    if (normalized == 'lock phone' ||
        normalized == 'lock my phone' ||
        normalized == 'lock the phone') {
      _lockPhone();
      return;
    }
    if (normalized == 'unlock phone' || normalized == 'unlock my phone') {
      _addChatMessage('jarvis',
          "I can't unlock the phone — Android does not allow any app to unlock the lock screen. Only you can unlock it with your PIN, pattern or fingerprint.");
      speak("I can't unlock the phone. Only you can unlock it.");
      return;
    }
    if (normalized.contains('flashlight on') ||
        normalized.contains('torch on')) {
      _setTorch(true);
      return;
    }
    if (normalized.contains('flashlight off') ||
        normalized.contains('torch off')) {
      _setTorch(false);
      return;
    }
    if (normalized.contains('volume up')) {
      _setVolume('up');
      return;
    }
    if (normalized.contains('volume down')) {
      _setVolume('down');
      return;
    }
    if (normalized == 'mute' ||
        normalized.contains('volume mute') ||
        normalized.contains('mute volume')) {
      _setVolume('mute');
      return;
    }
    if (normalized.contains('wifi settings') ||
        normalized.contains('wi-fi settings')) {
      _openSettingsPanel('android.settings.WIFI_SETTINGS', 'WiFi settings');
      return;
    }
    if (normalized.contains('bluetooth settings')) {
      _openSettingsPanel(
          'android.settings.BLUETOOTH_SETTINGS', 'Bluetooth settings');
      return;
    }
    if (normalized.contains('display settings') ||
        normalized.contains('brightness settings')) {
      _openSettingsPanel(
          'android.settings.DISPLAY_SETTINGS', 'Display settings');
      return;
    }

    if (normalized.startsWith('open ')) {
      _openApp(normalized);
      return;
    }

    final currentModel = model;
    if (currentModel == null) {
      _addChatMessage('jarvis',
          'AI chat needs a Gemini API key. Open Settings (gear icon) and add your key.');
      speak('AI chat needs a Gemini API key. Open Settings and add your key.');
      return;
    }

    _isProcessingQuery = true;
    try {
      // Retry automatically when Google says the model is busy or the
      // request times out, so a temporary overload does not surface as an
      // error. Up to 3 tries with growing pauses (5s, then 10s).
      String answer = '';
      for (var attempt = 0; attempt < 3; attempt++) {
        try {
          answer = (await currentModel.sendMessage(
            message: query,
            history: conversationHistory,
          ))
              .trim();
          break;
        } on GeminiApiException catch (e) {
          final msg = e.message.toLowerCase();
          final retryable = msg.contains('overload') ||
              msg.contains('high demand') ||
              msg.contains('timed out') ||
              msg.contains('try again later');
          if (retryable && attempt < 2) {
            await Future.delayed(Duration(seconds: 5 * (attempt + 1)));
            continue;
          }
          rethrow;
        }
      }
      if (answer.isEmpty) {
        _addChatMessage('jarvis', "I didn't receive a usable response.");
        speak("I didn't receive a usable response.");
        return;
      }
      conversationHistory
        ..add(GeminiChatMessage(role: 'user', text: query))
        ..add(GeminiChatMessage(role: 'model', text: answer));
      if (conversationHistory.length > 20) {
        conversationHistory.removeRange(0, conversationHistory.length - 20);
      }
      if (mounted) setState(() => responseText = answer);
      _addChatMessage('jarvis', answer);
      speak(_shortSpoken(answer));
    } on GeminiApiException catch (e) {
      _addChatMessage('jarvis', 'Gemini request failed: ${e.message}');
      speak('Gemini request failed: ${e.message}');
    } catch (_) {
      _addChatMessage('jarvis',
          'Sorry, I could not complete that request. Check your internet connection and API settings.');
      speak('Sorry, I could not complete that request. Check your internet connection and API settings.');
    } finally {
      _isProcessingQuery = false;
    }
  }

  void _searchWeather() async {
    final Uri url = Uri.https('www.google.com', '/search', {'q': 'weather near me'});
    try {
      final opened = await launchUrl(url, mode: LaunchMode.externalApplication);
      if (!opened) speak('I could not open the browser.');
    } catch (e) {
      speak(
          "I couldn't open the browser. Please check your internet connection.");
    }
  }

  void _tellTime() {
    String time = DateFormat.jm().format(DateTime.now());
    speak("The current time is $time");
  }

  static const MethodChannel _deviceChannel =
      MethodChannel('com.jarvis.jarvis_app/device');

  /// Locks the screen. Needs the app enabled as a device admin first
  /// (Android only allows device-admin apps to lock the screen).
  Future<void> _lockPhone() async {
    try {
      final active =
          await _deviceChannel.invokeMethod<bool>('isDeviceAdminActive');
      if (active != true) {
        _addChatMessage('jarvis',
            'To lock the phone, Jarvis needs device admin. Opening the setup — tap "Activate", then say "lock phone" again.');
        speak('Please activate device admin first.');
        await _deviceChannel.invokeMethod('requestDeviceAdmin');
        return;
      }
      await _deviceChannel.invokeMethod('lockPhone');
      _addChatMessage('jarvis', 'Phone locked.');
    } catch (e) {
      _addChatMessage('jarvis', 'Could not lock the phone: $e');
      speak('I could not lock the phone.');
    }
  }

  Future<void> _setTorch(bool on) async {
    try {
      final result = await _deviceChannel
          .invokeMethod<String>('setTorch', <String, dynamic>{'on': on});
      if (result == 'NO_PERMISSION') {
        _addChatMessage('jarvis',
            'Flashlight needs the Camera permission. Opening app settings — allow Camera, then try again.');
        speak('Flashlight needs the Camera permission.');
        _openAppSettings();
        return;
      }
      _addChatMessage('jarvis', on ? 'Flashlight on.' : 'Flashlight off.');
      speak(on ? 'Flashlight on.' : 'Flashlight off.');
    } catch (e) {
      _addChatMessage('jarvis', 'Could not change the flashlight: $e');
    }
  }

  Future<void> _setVolume(String direction) async {
    try {
      await _deviceChannel.invokeMethod(
          'setVolume', <String, dynamic>{'direction': direction});
      _addChatMessage('jarvis', 'Volume $direction.');
    } catch (e) {
      _addChatMessage('jarvis', 'Could not change the volume: $e');
    }
  }

  Future<void> _openSettingsPanel(String action, String label) async {
    try {
      final intent = AndroidIntent(
        action: action,
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      _addChatMessage('jarvis', 'Opening $label.');
    } catch (e) {
      _addChatMessage('jarvis', "I couldn't open $label.");
    }
  }

  Future<void> _openAppSettings() async {
    try {
      final intent = AndroidIntent(
        action: 'android.settings.APPLICATION_DETAILS_SETTINGS',
        data: 'package:com.jarvis.jarvis_app',
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
    } catch (_) {}
  }

  void _openApp(String query) async {
    String cleanedQuery = query.toLowerCase().replaceAll("open", "").trim();
    // 1. Apps the user connected (any app on the phone).
    String? connectedPackage;
    for (final entry in _connectedApps.entries) {
      final label = entry.value.toLowerCase();
      if (label == cleanedQuery || cleanedQuery.contains(label)) {
        connectedPackage = entry.key;
        break;
      }
    }
    if (connectedPackage != null) {
      try {
        final intent = AndroidIntent(
          action: 'android.intent.action.MAIN',
          category: 'android.intent.category.LAUNCHER',
          package: connectedPackage,
          flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
        );
        await intent.launch();
        _addChatMessage('jarvis', 'Opening ${_connectedApps[connectedPackage]}');
        speak('Opening ${_connectedApps[connectedPackage]}');
      } catch (e) {
        _addChatMessage('jarvis',
            "I couldn't open ${_connectedApps[connectedPackage]}.");
        speak("I couldn't open ${_connectedApps[connectedPackage]}.");
      }
      return;
    }
    Map<String, String> appMap = {
      "chrome": "com.android.chrome",
      "whatsapp": "com.whatsapp",
      "camera": "com.android.camera",
      "gallery": "com.android.gallery3d",
      "photos": "com.google.android.apps.photos",
      "youtube": "com.google.android.youtube",
      "maps": "com.google.android.apps.maps",
      "gmail": "com.google.android.gm",
      "settings": "com.android.settings",
      "play store": "com.android.vending",
      "calculator": "com.android.calculator2",
      "calendar": "com.google.android.calendar",
      "clock": "com.android.deskclock",
      "contacts": "com.android.contacts",
      "phone": "com.android.dialer",
      "messages": "com.android.mms",
      "file manager": "com.android.documentsui",
      "files": "com.android.documentsui",
      "music": "com.android.music",
      "sound recorder": "com.android.soundrecorder",
      "notes": "com.android.notes",
      "notepad": "com.android.notes",
      "browser": "com.android.chrome",
      "internet": "com.android.chrome",
      "email": "com.google.android.gm",
      "mail": "com.google.android.gm",
      "camera app": "com.android.camera",
      "gallery app": "com.android.gallery3d",
      "photos app": "com.google.android.apps.photos",
      "youtube app": "com.google.android.youtube",
      "maps app": "com.google.android.apps.maps",
      "gmail app": "com.google.android.gm",
      "settings app": "com.android.settings",
      "play store app": "com.android.vending",
      "calculator app": "com.android.calculator2",
      "calendar app": "com.google.android.calendar",
      "clock app": "com.android.deskclock",
      "contacts app": "com.android.contacts",
      "phone app": "com.android.dialer",
      "messages app": "com.android.mms",
      "file manager app": "com.android.documentsui",
      "files app": "com.android.documentsui",
      "music app": "com.android.music",
      "sound recorder app": "com.android.soundrecorder",
      "notes app": "com.android.notes",
      "notepad app": "com.android.notes",
      "browser app": "com.android.chrome",
      "internet app": "com.android.chrome",
      "email app": "com.google.android.gm",
      "mail app": "com.google.android.gm",
      "instagram": "com.instagram.android",
      "facebook": "com.facebook.katana",
      "telegram": "org.telegram.messenger",
      "tiktok": "com.zhiliaoapp.musically",
      "spotify": "com.spotify.music",
      "snapchat": "com.snapchat.android",
      "instagram app": "com.instagram.android",
      "facebook app": "com.facebook.katana",
      "telegram app": "org.telegram.messenger",
      "tiktok app": "com.zhiliaoapp.musically",
      "spotify app": "com.spotify.music",
      "snapchat app": "com.snapchat.android"
    };

    debugPrint("Attempting to open app from query: '$cleanedQuery'");

    String? packageToOpen = appMap[cleanedQuery];

    if (packageToOpen == null) {
      for (var entry in appMap.entries) {
        if (cleanedQuery.contains(entry.key)) {
          packageToOpen = entry.value;
          break;
        }
      }
    }

    if (packageToOpen != null) {
      try {
        final intent = AndroidIntent(
          action: 'android.intent.action.MAIN',
          category: 'android.intent.category.LAUNCHER',
          package: packageToOpen,
          flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
        );

        await intent.launch();
        _addChatMessage('jarvis', 'Opening ${cleanedQuery.trim()}');
        speak("Opening ${cleanedQuery.trim()}");
      } catch (e) {
        debugPrint("Error launching app: $e");

        final playStoreUrl = Uri(scheme: 'market', host: 'search', queryParameters: {'q': cleanedQuery});
        try {
          await launchUrl(playStoreUrl, mode: LaunchMode.externalApplication);
          _addChatMessage('jarvis',
              "I couldn't open $cleanedQuery. Opening the Play Store to search for it.");
          speak(
              "I couldn't open $cleanedQuery. Opening the Play Store to search for it.");
        } catch (e) {
          _addChatMessage('jarvis',
              "I apologize, but I couldn't open ${cleanedQuery.trim()}. The app might not be installed.");
          speak(
              "I apologize, but I couldn't open ${cleanedQuery.trim()}. The app might not be installed.");
        }
      }
    } else {
      final playStoreUrl = Uri(scheme: 'market', host: 'search', queryParameters: {'q': cleanedQuery});
      try {
        await launchUrl(playStoreUrl, mode: LaunchMode.externalApplication);
        _addChatMessage('jarvis',
            "I couldn't find $cleanedQuery. Opening the Play Store to search for it.");
        speak(
            "I couldn't find $cleanedQuery. Opening the Play Store to search for it.");
      } catch (e) {
        _addChatMessage('jarvis',
            "I apologize, but I don't have access to open $cleanedQuery at the moment.");
        speak(
            "I apologize, but I don't have access to open $cleanedQuery at the moment.");
      }
    }
  }

  void _handleTimerCommand(String query, {bool allowPrompt = true}) {
    final totalSeconds = parseTimerDurationSeconds(query);
    if (totalSeconds > 0 && totalSeconds <= 7 * 24 * 3600) {
      _startTimer(totalSeconds);
      return;
    }
    if (allowPrompt) {
      _pendingCommand = 'timer';
      speak('How long should I set the timer for? You can say 5 minutes or 1 hour 20 minutes.').then((_) {
        if (mounted && !_isInConversationMode) startListening();
      });
    } else {
      speak('I could not understand that duration. Please say a valid duration, such as 5 minutes.');
    }
  }

  void _startTimer(int totalSeconds) {
    _timer?.cancel();
    if (totalSeconds <= 0) return;
    _timerEndsAt = DateTime.now().add(Duration(seconds: totalSeconds));
    if (mounted) {
      setState(() {
        _remainingSeconds = totalSeconds;
        _isTimerActive = true;
      });
    }
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) { timer.cancel(); return; }
      final remaining = _timerEndsAt!.difference(DateTime.now()).inSeconds;
      setState(() => _remainingSeconds = remaining > 0 ? remaining : 0);
      if (remaining <= 0) {
        timer.cancel();
        setState(() => _isTimerActive = false);
        speak('Timer completed, sir.');
      }
    });
    final duration = Duration(seconds: totalSeconds);
    final parts = <String>[];
    if (duration.inHours > 0) parts.add('${duration.inHours} hours');
    if (duration.inMinutes.remainder(60) > 0) parts.add('${duration.inMinutes.remainder(60)} minutes');
    if (duration.inSeconds.remainder(60) > 0) parts.add('${duration.inSeconds.remainder(60)} seconds');
    speak('Timer set for ${parts.join(' ')}. Keep Jarvis open for the countdown to run.');
  }

  Future<void> _handleAlarmCommand(String query, {bool allowPrompt = true}) async {
    final parsedTime = parseAlarmTime(query);
    if (parsedTime == null) {
      if (allowPrompt) {
        _pendingCommand = 'alarm';
        speak("What time should I set the alarm? For example, 7:30 AM.").then((_) {
          if (mounted && !_isInConversationMode) startListening();
        });
      } else {
        speak("I could not understand the time. Please say a time such as 7:30 AM.");
      }
      return;
    }

    final hour12 = parsedTime.hour12;
    final minute = parsedTime.minute;
    final meridiem = parsedTime.meridiem;
    final hour24 = parsedTime.hour24;
    try {
      final intent = AndroidIntent(
        action: 'android.intent.action.SET_ALARM',
        arguments: <String, dynamic>{
          'android.intent.extra.alarm.HOUR': hour24,
          'android.intent.extra.alarm.MINUTES': minute,
          'android.intent.extra.alarm.MESSAGE': 'J.A.R.V.I.S',
          'android.intent.extra.alarm.SKIP_UI': false,
        },
        flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      speak('Opening your clock app to create the alarm for $hour12:${minute.toString().padLeft(2, '0')} ${meridiem.toUpperCase()}. Confirm and save it in the Clock app.');
    } catch (_) {
      speak('I could not open a compatible Clock app. Please set the alarm manually.');
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _pendingCommand = '';
    _wakeWordTimer?.cancel();
    _backgroundAnimationTimer?.cancel();
    _chatInputController.dispose();
    _chatScrollController.dispose();
    _animationController.dispose();
    _colorAnimationController.dispose();
    _audioPlayer.dispose();
    model?.dispose();
    speech.stop();
    flutterTts.stop();
    super.dispose();
  }

  void startListening() async {
    try {
      final available = await speech.initialize();
      if (!mounted) return;
      if (!available) {
        _addChatMessage('jarvis',
            'Speech recognition is unavailable. Check your microphone permission and speech services.');
        speak('Speech recognition is unavailable. Check your microphone permission and speech services.');
        return;
      }
      setState(() => isListening = true);
      await speech.listen(
        onResult: (result) async {
          if (result.finalResult) {
            if (!mounted) return;
            String userInput = result.recognizedWords.toLowerCase();
            _addChatMessage('user', userInput);
            processQuery(userInput);
          }
        },
        listenFor: Duration(minutes: 5),
        pauseFor: Duration(seconds: 15),
        partialResults: true,
        listenMode: stt.ListenMode.deviceDefault,
        cancelOnError: false,
      );
    } catch (_) {
      if (mounted) setState(() => isListening = false);
      _addChatMessage('jarvis',
          'I could not start the microphone. Please check microphone permission.');
      speak('I could not start the microphone. Please check microphone permission.');
    }
  }

  void stopListening() {
    speech.stop();
    if (mounted) setState(() => isListening = false);
  }

  /// Stops Jarvis mid-sentence. Used by the orb tap, the on-screen STOP
  /// button, and the "stop / chup / khamosh" voice command.
  Future<void> _stopSpeaking() async {
    await flutterTts.stop();
    if (mounted) {
      setState(() {
        isSpeaking = false;
        _speakingSince = null;
      });
    }
  }

  /// Short version of an answer for speaking: code is never read aloud,
  /// long answers are cut to the first sentence or two. The full text is
  /// always in the chat for reading.
  String _shortSpoken(String answer) {
    if (answer.contains('```')) {
      return 'Done. The full answer is on your screen.';
    }
    if (answer.length <= 250) return answer;
    final cut = answer.substring(0, 250);
    final ends = <int>[
      cut.lastIndexOf('. '),
      cut.lastIndexOf('! '),
      cut.lastIndexOf('? '),
    ];
    final lastEnd = ends.reduce((a, b) => a > b ? a : b);
    return lastEnd > 60 ? cut.substring(0, lastEnd + 1) : cut;
  }

  Future<void> speak(String text) async {
    if (!mounted || text.trim().isEmpty) return;
    final cleanText = text.replaceAll(RegExp(r'\*'), '');
    await _ttsReady;
    if (!mounted) return;
    if (speech.isListening) speech.stop();
    // A new utterance cuts off whatever is still being spoken, so the user
    // can interrupt a long answer with a new question.
    await flutterTts.stop();
    if (mounted) {
      setState(() {
        isSpeaking = true;
        _speakingSince = DateTime.now();
      });
    }
    try {
      await flutterTts.speak(cleanText);
    } catch (_) {
      if (mounted) {
        setState(() {
          isSpeaking = false;
          _speakingSince = null;
        });
      }
      if (_isInConversationMode) _continueConversation();
    }
  }

  void _stopBackgroundListening() {
    if (_isBackgroundListening) {
      speech.stop();
      if (mounted) setState(() => _isBackgroundListening = false);
    }
  }

  Future<void> _playWakeSound() async {
    try {
      await _audioPlayer.play(AssetSource('sounds/wake.mp3'));
    } catch (e) {
      debugPrint('Error playing wake sound: $e');
    }
  }

  /// Starts a foreground service ("J.A.R.V.I.S is listening" notification)
  /// so Android keeps the app process alive when it is minimised and the
  /// microphone permission keeps working in the background. Started only
  /// while the app is in the foreground (Android 12+ rule). The user stops
  /// it by swiping the app away from recents.
  Future<void> _initForegroundService() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'jarvis_listening',
        channelName: 'Jarvis listening',
        channelDescription:
            'Jarvis keeps listening for "Hey Jarvis" while the app is in the background.',
        onlyAlertOnce: true,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: false,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(30000),
        autoRunOnBoot: false,
        autoRunOnMyPackageReplaced: false,
        allowWakeLock: true,
        allowWifiLock: false,
      ),
    );
    final notificationPermission =
        await FlutterForegroundTask.checkNotificationPermission();
    if (notificationPermission != NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }
    if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
    }
    if (!await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.startService(
        serviceId: 256,
        notificationTitle: 'J.A.R.V.I.S is listening',
        notificationText: 'Say "Hey Jarvis" any time — tap to open Jarvis.',
        callback: jarvisForegroundCallback,
      );
    }
  }

  static const MethodChannel _appsChannel =
      MethodChannel('com.jarvis.jarvis_app/apps');

  /// Apps the user connected in the Connected Apps screen (package -> label).
  /// Only these can be opened by voice or typing. Stored on this phone only.
  Map<String, String> _connectedApps = {};

  /// Default apps connected on first run (the well-known ones).
  static const List<String> _defaultConnectedPackages = <String>[
    'com.whatsapp',
    'com.google.android.youtube',
    'com.android.chrome',
    'com.google.android.gm',
    'com.google.android.apps.maps',
    'com.android.camera',
    'com.google.android.apps.photos',
    'com.android.settings',
    'com.android.vending',
    'com.android.calculator2',
    'com.google.android.calendar',
    'com.android.deskclock',
    'com.android.contacts',
    'com.android.dialer',
    'com.android.mms',
    'com.instagram.android',
    'com.facebook.katana',
    'org.telegram.messenger',
    'com.zhiliaoapp.musically',
    'com.spotify.music',
    'com.snapchat.android',
  ];

  Future<void> _loadConnectedApps() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final stored = prefs.getStringList('connected_apps');
      final apps =
          await _appsChannel.invokeListMethod<dynamic>('getInstalledApps');
      final installed = <String, String>{};
      for (final entry in apps ?? <dynamic>[]) {
        if (entry is Map) {
          final package = entry['package']?.toString() ?? '';
          final label = entry['label']?.toString() ?? package;
          if (package.isNotEmpty) installed[package] = label;
        }
      }
      final connected = stored ??
          _defaultConnectedPackages.where(installed.containsKey).toList();
      if (stored == null) {
        await prefs.setStringList('connected_apps', connected);
      }
      if (mounted) {
        setState(() {
          _connectedApps = {
            for (final package in connected)
              if (installed.containsKey(package)) package: installed[package]!,
          };
        });
      }
    } catch (e) {
      debugPrint('Could not load connected apps: $e');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _isAppInForeground = true;
      if (_isInConversationMode && !isSpeaking) {
        _continueConversation();
      } else if (_isBackgroundListening && !isSpeaking) {
        _startWakeWordDetection();
      }
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _isAppInForeground = false;
      // Keep listening in the background when the wake-word toggle is ON
      // (the foreground service keeps the mic allowed). Stop it only when
      // the toggle is OFF.
      if (!_isBackgroundListening) {
        speech.stop();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isIdleState =
        !_isWakeWordDetected && !isSpeaking && !_isInConversationMode;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: CircuitPatternPainter(
                isIdleState: isIdleState,
              ),
              key: ValueKey(
                  _backgroundAnimationCounter),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.7),
                  ],
                  center: Alignment.center,
                  radius: 1.5,
                ),
              ),
            ),
          ),
          Container(
            width: double.infinity,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isTimerActive && _remainingSeconds != null)
                  Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text(
                      'Timer: ${(_remainingSeconds! ~/ 3600).toString().padLeft(2, '0')}:${((_remainingSeconds! % 3600) ~/ 60).toString().padLeft(2, '0')}:${(_remainingSeconds! % 60).toString().padLeft(2, '0')}',
                      style: TextStyle(
                        color: Colors.orange,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        shadows: [
                          Shadow(
                            color: Colors.orange.withValues(alpha: 0.5),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                    ),
                  ),
                if (_isBackgroundListening)
                  Padding(
                    padding: EdgeInsets.only(bottom: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            color: _isInConversationMode
                                ? Colors.purple
                                : Colors.green,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: _isInConversationMode
                                    ? Colors.purple.withValues(alpha: 0.5)
                                    : Colors.green.withValues(alpha: 0.5),
                                blurRadius: 10,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(width: 8),
                        Text(
                          _isInConversationMode
                              ? "CONVERSATION ACTIVE"
                              : "ALWAYS LISTENING",
                          style: TextStyle(
                            color: _isInConversationMode
                                ? Colors.blueAccent
                                : Colors.green,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    _isInConversationMode
                        ? "ACTIVE CONVERSATION MODE"
                        : _isWakeWordDetected
                            ? "LISTENING FOR COMMAND..."
                            : isSpeaking
                                ? "JARVIS IS RESPONDING..."
                                : "SAY 'HEY JARVIS' TO START",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _isInConversationMode
                          ? Colors.blueAccent
                          : _isWakeWordDetected
                              ? Colors.green
                              : isSpeaking
                                  ? Colors.orange
                                  : Colors.cyan,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: _isInConversationMode
                              ? Colors.blueAccent
                              : _isWakeWordDetected
                                  ? Colors.green
                                  : isSpeaking
                                      ? Colors.orange
                                      : Colors.cyan,
                          blurRadius: 10,
                          offset: Offset(0, 0),
                        ),
                      ],
                    ),
                  ),
                ),
                if (isSpeaking)
                  Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: ElevatedButton.icon(
                      onPressed: _stopSpeaking,
                      icon: const Icon(Icons.stop),
                      label: const Text('STOP'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                // Manual way to start Active Conversation: no "Hey Jarvis"
                // needed. Works even when the mic toggle is off.
                if (!_isInConversationMode && !isSpeaking)
                  Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: ElevatedButton.icon(
                      onPressed: _startConversationMode,
                      icon: const Icon(Icons.mic),
                      label: const Text('START CONVERSATION'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.cyan,
                        foregroundColor: Colors.black,
                      ),
                    ),
                  ),
                SizedBox(height: 40),
                if (_chatMessages.isNotEmpty)
                  Container(
                    height: 180,
                    margin: EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 8.0),
                    padding: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.45),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: Colors.cyan.withValues(alpha: 0.3)),
                    ),
                    child: ListView.builder(
                      controller: _chatScrollController,
                      itemCount: _chatMessages.length,
                      itemBuilder: (context, index) {
                        final msg = _chatMessages[index];
                        final isUser = msg['role'] == 'user';
                        return Align(
                          alignment: isUser
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Container(
                            margin: EdgeInsets.symmetric(vertical: 3.0),
                            padding: EdgeInsets.symmetric(
                                horizontal: 10.0, vertical: 6.0),
                            decoration: BoxDecoration(
                              color: isUser
                                  ? Colors.cyan.withValues(alpha: 0.25)
                                  : Colors.white.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              msg['text'] ?? '',
                              style: TextStyle(
                                  color: Colors.white, fontSize: 14),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                AnimatedBuilder(
                  animation:
                      Listenable.merge([_bounceAnimation, _colorAnimation]),
                  builder: (context, child) {
                    final currentColor =
                        _colorAnimation.value ?? _ironManColors[0];
                    return Transform.scale(
                      scale: _isWakeWordDetected ||
                              isSpeaking ||
                              _isInConversationMode
                          ? _bounceAnimation.value
                          : 1.0,
                      child: GestureDetector(
                        onTapDown: (_) => setState(() => isListening = true),
                        onTapUp: (_) {
                          if (isSpeaking) {
                            // Tapping the orb while Jarvis talks silences it.
                            _stopSpeaking();
                          } else if (_isInConversationMode) {
                            _endConversationMode();
                            speak(
                                "Ending conversation mode. Just say 'Hey Jarvis' when you need me again.");
                          } else {
                            startListening();
                          }
                        },
                        onTapCancel: () => setState(() => isListening = false),
                        child: Container(
                          width: 180,
                          height: 180,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                currentColor.withValues(alpha: 0.9),
                                currentColor.withValues(alpha: 0.7),
                                currentColor.withValues(alpha: 0.5),
                              ],
                              center: Alignment.center,
                              radius: 0.8,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: currentColor.withValues(alpha: 0.7),
                                blurRadius: 35,
                                spreadRadius: 8,
                              ),
                              BoxShadow(
                                color: currentColor.withValues(alpha: 0.4),
                                blurRadius: 60,
                                spreadRadius: 15,
                              ),
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.8),
                                blurRadius: 15,
                                spreadRadius: -3,
                                offset: Offset(0, 5),
                              ),
                            ],
                            border: Border.all(
                              color: Colors.black,
                              width: 2.5,
                            ),
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Container(
                                width: 168,
                                height: 168,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: currentColor.withValues(alpha: 0.9),
                                    width: 4,
                                  ),
                                ),
                                child: CustomPaint(
                                  painter: ArcReactorSegmentsPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                  ),
                                ),
                              ),
                              Container(
                                width: 144,
                                height: 144,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: currentColor.withValues(alpha: 0.8),
                                    width: 3,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.8),
                                      blurRadius: 2,
                                      spreadRadius: 0.5,
                                    ),
                                  ],
                                ),
                                child: CustomPaint(
                                  painter: CircuitLinesPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                  ),
                                ),
                              ),
                              Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: currentColor.withValues(alpha: 0.7),
                                    width: 2.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.8),
                                      blurRadius: 2,
                                      spreadRadius: 0.5,
                                    ),
                                  ],
                                ),
                                child: CustomPaint(
                                  painter: TrianglePatternPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                  ),
                                ),
                              ),
                              Container(
                                width: 96,
                                height: 96,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: RadialGradient(
                                    colors: [
                                      currentColor.withValues(alpha: 0.9),
                                      currentColor.withValues(alpha: 0.7),
                                    ],
                                    center: Alignment.center,
                                    radius: 0.8,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: currentColor.withValues(alpha: 0.7),
                                      blurRadius: 25,
                                      spreadRadius: 4,
                                    ),
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.8),
                                      blurRadius: 8,
                                      spreadRadius: -2,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                  border: Border.all(
                                    color: Colors.black,
                                    width: 1.5,
                                  ),
                                ),
                                child: CustomPaint(
                                  painter: CorePatternPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                    showPurpleTriangle: true,
                                  ),
                                ),
                              ),
                              if (_isWakeWordDetected ||
                                  isSpeaking ||
                                  _isInConversationMode)
                                Container(
                                  width: 192,
                                  height: 192,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: currentColor.withValues(alpha: 0.5),
                                      width: 3,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
                SizedBox(height: 16),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                                color: Colors.cyan.withValues(alpha: 0.4)),
                          ),
                          child: TextField(
                            controller: _chatInputController,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              hintText: 'Type your message...',
                              hintStyle:
                                  TextStyle(color: Colors.white54),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 16.0, vertical: 10.0),
                            ),
                            textInputAction: TextInputAction.send,
                            onSubmitted: (_) => _sendTypedMessage(),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.cyan, shape: BoxShape.circle),
                        child: IconButton(
                          icon: Icon(Icons.send, color: Colors.black),
                          onPressed: _sendTypedMessage,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: Text(
          'J.A.R.V.I.S',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
            shadows: [
              Shadow(
                color: Colors.blue.withValues(alpha: 0.5),
                blurRadius: 10,
              ),
            ],
          ),
        ),
        backgroundColor: Colors.black.withValues(alpha: 0.3),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.apps, color: Colors.cyan, size: 28),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const ConnectedAppsScreen()),
              );
              _loadConnectedApps();
            },
            tooltip: 'Connected apps',
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.cyan, size: 28),
            onPressed: _showSettingsDialog,
            tooltip: "Settings - Gemini API key",
          ),
          IconButton(
            icon: Icon(
              _isBackgroundListening ? Icons.mic : Icons.mic_off,
              color: _isBackgroundListening
                  ? (_isInConversationMode ? Colors.purple : Colors.green)
                  : Colors.red,
              size: 28,
            ),
            onPressed: () {
              if (_isInConversationMode) {
                _endConversationMode();
                speak("Ending conversation mode.");
              }

              if (_isBackgroundListening) {
                _stopBackgroundListening();
                speak("Wake-word listening disabled.");
              } else {
                setState(() => _isBackgroundListening = true);
                _startWakeWordDetection();
                speak(
                    "Wake-word listening enabled while Jarvis is open. Android may stop listening in the background.");
              }
            },
            tooltip: _isBackgroundListening
                ? "Disable wake-word listening"
                : "Enable wake-word listening",
          ),
        ],
      ),
    );
  }
}

class CorePatternPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;
  final bool showPurpleTriangle;

  CorePatternPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
    this.showPurpleTriangle = false,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5;

    final path = Path();
    final triangleSize = radius * 0.8;
    final height = triangleSize * sqrt(3) / 2;

    path.moveTo(center.dx, center.dy - height / 2);
    path.lineTo(center.dx + triangleSize / 2, center.dy + height / 2);
    path.lineTo(center.dx - triangleSize / 2, center.dy + height / 2);
    path.close();

    canvas.drawPath(path, borderPaint); 
    canvas.drawPath(path, paint);

    final innerPaint = Paint()
      ..color = color.withValues(alpha: 0.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final innerBorderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final innerSize = triangleSize * 0.6;
    final innerHeight = innerSize * sqrt(3) / 2;

    path.reset();
    path.moveTo(center.dx, center.dy - innerHeight / 2);
    path.lineTo(center.dx + innerSize / 2, center.dy + innerHeight / 2);
    path.lineTo(center.dx - innerSize / 2, center.dy + innerHeight / 2);
    path.close();

    canvas.drawPath(path, innerBorderPaint); 
    canvas.drawPath(path, innerPaint); 

    final dotPaint = Paint()
      ..color = color.withValues(alpha: 0.9)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, radius * 0.12, dotPaint);

    if (showPurpleTriangle) {
      final purplePaint = Paint()
        ..color = Colors.purple.withValues(alpha: 0.8)
        ..style = PaintingStyle.fill;

      final purpleBorderPaint = Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;

      final purpleTrianglePath = Path();
      final purpleTriangleSize =
          radius * 0.5; 
      final purpleHeight = purpleTriangleSize * sqrt(3) / 2;

      purpleTrianglePath.moveTo(center.dx, center.dy - purpleHeight / 2);
      purpleTrianglePath.lineTo(
          center.dx + purpleTriangleSize / 2, center.dy + purpleHeight / 2);
      purpleTrianglePath.lineTo(
          center.dx - purpleTriangleSize / 2, center.dy + purpleHeight / 2);
      purpleTrianglePath.close();

      final purpleRect = Rect.fromCircle(center: center, radius: radius * 0.5);
      final purpleGradient = RadialGradient(
        colors: [
          Colors.purple.withValues(alpha: 0.9),
          Colors.deepPurple.withValues(alpha: 0.7),
        ],
        center: Alignment(0.2, -0.3), 
        radius: 0.8,
      );

      final gradientPaint = Paint()
        ..shader = purpleGradient.createShader(purpleRect)
        ..style = PaintingStyle.fill;

      canvas.drawPath(purpleTrianglePath, gradientPaint);
      canvas.drawPath(purpleTrianglePath, purpleBorderPaint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class TrianglePatternPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;

  TrianglePatternPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.7)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (var i = 0; i < 3; i++) {
      final angle = i * (2 * pi / 3);
      final path = Path();

      final triangleSize = radius * 0.8;
      final height = triangleSize * sqrt(3) / 2;

      final topPoint = Offset(
        center.dx + sin(angle) * height / 2,
        center.dy - cos(angle) * height / 2,
      );
      final bottomLeft = Offset(
        center.dx + sin(angle - 2 * pi / 3) * height / 2,
        center.dy - cos(angle - 2 * pi / 3) * height / 2,
      );
      final bottomRight = Offset(
        center.dx + sin(angle + 2 * pi / 3) * height / 2,
        center.dy - cos(angle + 2 * pi / 3) * height / 2,
      );

      path.moveTo(topPoint.dx, topPoint.dy);
      path.lineTo(bottomLeft.dx, bottomLeft.dy);
      path.lineTo(bottomRight.dx, bottomRight.dy);
      path.close();

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class CircuitLinesPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;

  CircuitLinesPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (var i = 0; i < 12; i++) {
      final angle = i * (2 * pi / 12);
      final path = Path();

      final startRadius = radius * 0.7;
      final endRadius = radius * 0.9;

      final startX = center.dx + cos(angle) * startRadius;
      final startY = center.dy + sin(angle) * startRadius;
      final endX = center.dx + cos(angle) * endRadius;
      final endY = center.dy + sin(angle) * endRadius;

      path.moveTo(startX, startY);
      path.lineTo(endX, endY);

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }

    for (var i = 0; i < 6; i++) {
      final angle = i * (2 * pi / 6);
      final path = Path();

      final radius1 = radius * 0.75;
      final radius2 = radius * 0.85;

      final x1 = center.dx + cos(angle) * radius1;
      final y1 = center.dy + sin(angle) * radius1;
      final x2 = center.dx + cos(angle + pi / 3) * radius2;
      final y2 = center.dy + sin(angle + pi / 3) * radius2;

      path.moveTo(x1, y1);
      path.lineTo(x2, y2);

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class ArcReactorSegmentsPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;

  ArcReactorSegmentsPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5;

    for (var i = 0; i < 8; i++) {
      final angle = i * (2 * pi / 8);
      final path = Path();

      final startRadius = radius * 0.9;
      final endRadius = radius;

      final startX = center.dx + cos(angle) * startRadius;
      final startY = center.dy + sin(angle) * startRadius;
      final endX = center.dx + cos(angle) * endRadius;
      final endY = center.dy + sin(angle) * endRadius;

      path.moveTo(startX, startY);
      path.lineTo(endX, endY);

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }

    final innerPaint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final innerBorderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (var i = 0; i < 16; i++) {
      final angle = i * (2 * pi / 16);
      final path = Path();

      final startRadius = radius * 0.85;
      final endRadius = radius * 0.95;

      final startX = center.dx + cos(angle) * startRadius;
      final startY = center.dy + sin(angle) * startRadius;
      final endX = center.dx + cos(angle) * endRadius;
      final endY = center.dy + sin(angle) * endRadius;

      path.moveTo(startX, startY);
      path.lineTo(endX, endY);

      canvas.drawPath(path, innerBorderPaint);
      canvas.drawPath(path, innerPaint);
    }

    final gradientPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.white.withValues(alpha: 0.1),
          Colors.transparent,
        ],
        center: Alignment(-0.2, -0.2), 
        radius: 0.8,
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, radius * 0.95, gradientPaint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

/// Connected Apps screen: lists every app installed on the phone and lets
/// the user switch each one on (Jarvis may open it) or off. The list is
/// stored only on this phone (SharedPreferences) and is never sent anywhere.
class ConnectedAppsScreen extends StatefulWidget {
  const ConnectedAppsScreen({super.key});

  @override
  State<ConnectedAppsScreen> createState() => _ConnectedAppsScreenState();
}

class _ConnectedAppsScreenState extends State<ConnectedAppsScreen> {
  static const MethodChannel _appsChannel =
      MethodChannel('com.jarvis.jarvis_app/apps');

  List<Map<String, String>> _allApps = [];
  Set<String> _connected = {};
  String _filter = '';
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final apps =
          await _appsChannel.invokeListMethod<dynamic>('getInstalledApps');
      final parsed = <Map<String, String>>[];
      for (final entry in apps ?? <dynamic>[]) {
        if (entry is Map) {
          final package = entry['package']?.toString() ?? '';
          final label = entry['label']?.toString() ?? package;
          if (package.isNotEmpty) {
            parsed.add({'label': label, 'package': package});
          }
        }
      }
      if (mounted) {
        setState(() {
          _allApps = parsed;
          _connected = prefs.getStringList('connected_apps')?.toSet() ?? {};
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Could not list apps: $e';
          _loading = false;
        });
      }
    }
  }

  Future<void> _toggle(String package, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (value) {
        _connected.add(package);
      } else {
        _connected.remove(package);
      }
    });
    await prefs.setStringList('connected_apps', _connected.toList());
  }

  @override
  Widget build(BuildContext context) {
    final visible = _filter.isEmpty
        ? _allApps
        : _allApps
            .where((a) =>
                a['label']!.toLowerCase().contains(_filter) ||
                a['package']!.toLowerCase().contains(_filter))
            .toList();
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Connected Apps'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.cyan,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.cyan))
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Text(_error!,
                        style: const TextStyle(color: Colors.white)),
                  ),
                )
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: TextField(
                        style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(
                          hintText: 'Search apps...',
                          hintStyle: TextStyle(color: Colors.grey),
                          prefixIcon: Icon(Icons.search, color: Colors.cyan),
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (v) =>
                            setState(() => _filter = v.trim().toLowerCase()),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Text(
                        '${_connected.length} of ${_allApps.length} apps connected. Only connected apps can be opened by Jarvis. This list stays on your phone.',
                        style: const TextStyle(
                            color: Colors.grey, fontSize: 13),
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: visible.length,
                        itemBuilder: (context, index) {
                          final app = visible[index];
                          final package = app['package']!;
                          final on = _connected.contains(package);
                          return SwitchListTile(
                            title: Text(app['label']!,
                                style:
                                    const TextStyle(color: Colors.white)),
                            subtitle: Text(package,
                                style: const TextStyle(
                                    color: Colors.grey, fontSize: 12)),
                            value: on,
                            activeColor: Colors.cyan,
                            onChanged: (v) => _toggle(package, v),
                          );
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}
