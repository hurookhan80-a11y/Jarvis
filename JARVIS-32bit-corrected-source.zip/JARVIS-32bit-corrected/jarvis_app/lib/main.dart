import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:url_launcher/url_launcher.dart';

import 'command_parser.dart';
import 'gemini_client.dart';

const MethodChannel _secureStorageChannel = MethodChannel('com.jarvis.jarvis_app/secure_storage');


void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterForegroundTask.initCommunicationPort();
  runApp(const JarvisApp());
}

/// Background-service callback: keeps the app process alive so wake-word
/// listening can continue while Jarvis is minimised. The service itself does
/// nothing but stay alive; the main isolate's 30-second timer re-arms
/// listening. Stops when the app is swiped away from recents
/// (stopWithTask in the manifest).
@pragma('vm:entry-point')
void jarvisForegroundCallback() {
  FlutterForegroundTask.setTaskHandler(JarvisForegroundTaskHandler());
}

class JarvisForegroundTaskHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {}

  @override
  void onRepeatEvent(DateTime timestamp) {}

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {}

  @override
  void onNotificationPressed() {
    FlutterForegroundTask.launchApp();
  }
}

/// Chat history storage (on this phone only — nothing leaves the phone).
/// Sessions are stored newest-last in SharedPreferences as JSON.
Future<List<Map<String, dynamic>>> loadChatHistory() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('jarvis_chat_history_v1');
    if (raw == null) return [];
    final list = jsonDecode(raw) as List<dynamic>;
    final sessions = list
        .whereType<Map>()
        .map((s) => Map<String, dynamic>.from(s))
        .toList();
    sessions.sort((a, b) => (b['startedAt'] as String? ?? '')
        .compareTo(a['startedAt'] as String? ?? ''));
    return sessions;
  } catch (_) {
    return [];
  }
}

Future<void> deleteChatHistorySession(int id) async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('jarvis_chat_history_v1');
    if (raw == null) return;
    final list = (jsonDecode(raw) as List<dynamic>).whereType<Map>().toList();
    list.removeWhere((s) => s['id'] == id);
    await prefs.setString('jarvis_chat_history_v1', jsonEncode(list));
  } catch (_) {}
}

Future<void> clearChatHistory() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('jarvis_chat_history_v1');
  } catch (_) {}
}

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  final AudioPlayer _audioPlayer = AudioPlayer();
  Timer? _navigationTimer;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
    );
    _fadeAnimation =
        Tween<double>(begin: 0.0, end: 1.0).animate(_fadeController);
    _fadeController.forward();

    _playStartupSound();

    _navigationTimer = Timer(const Duration(seconds: 5), () {
      if (!mounted) return;
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => JarvisScreen()));
    });
  }

  Future<void> _playStartupSound() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('sounds_enabled') == false) return;
      await _audioPlayer.play(AssetSource('sounds/startup.mp3'));
    } catch (e) {
      debugPrint('Error playing startup sound: $e');
    }
  }

  @override
  void dispose() {
    _navigationTimer?.cancel();
    _fadeController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: CircuitPatternPainter(),
            ),
          ),
          Center(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    colors: [
                      Colors.blue.withValues(alpha: 0.3),
                      Colors.transparent,
                    ],
                    radius: 1.2,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'J.A.R.V.I.S',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 52,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 4,
                        shadows: [
                          Shadow(
                            color: Colors.blue.withValues(alpha: 0.9),
                            blurRadius: 20,
                            offset: Offset(0, 0),
                          ),
                          Shadow(
                            color: Colors.white.withValues(alpha: 0.5),
                            blurRadius: 30,
                            offset: Offset(0, 0),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 25),
                    Container(
                      width: 180,
                      height: 180,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            Colors.blue.withValues(alpha: 0.4),
                            Colors.blue.withValues(alpha: 0.2),
                            Colors.transparent,
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.blue.withValues(alpha: 0.4),
                            blurRadius: 30,
                            spreadRadius: 8,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Icon(
                          Icons.power_settings_new,
                          size: 70,
                          color: Colors.blue.withValues(alpha: 0.9),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CircuitPatternPainter extends CustomPainter {
  final bool isIdleState;

  CircuitPatternPainter({this.isIdleState = true});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue.withValues(alpha: 0.2)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final random = Random();
    final numberOfLines = 120;
    final numberOfNodes = 25;

    final seedRandom = isIdleState ? Random(DateTime.now().millisecondsSinceEpoch ~/ (isIdleState ? 10000 : 1000)) : random;

    final nodes = List.generate(numberOfNodes, (index) {
      return Offset(
        seedRandom.nextDouble() * size.width,
        seedRandom.nextDouble() * size.height,
      );
    });

    for (var i = 0; i < nodes.length; i++) {
      for (var j = i + 1; j < nodes.length; j++) {
        if (seedRandom.nextDouble() < 0.35) {
          final path = Path();
          path.moveTo(nodes[i].dx, nodes[i].dy);
          path.lineTo(nodes[j].dx, nodes[j].dy);
          canvas.drawPath(path, paint);
        }
      }
    }

    for (var i = 0; i < numberOfLines; i++) {
      final startX = seedRandom.nextDouble() * size.width;
      final startY = seedRandom.nextDouble() * size.height;
      final path = Path();
      path.moveTo(startX, startY);

      var currentX = startX;
      var currentY = startY;
      var segments = seedRandom.nextInt(5) + 3; 

      for (var j = 0; j < segments; j++) {
        if (seedRandom.nextBool()) {
          currentX +=
              seedRandom.nextDouble() * 150 - 75; 
        } else {
          currentY += seedRandom.nextDouble() * 150 - 75;
        }
        path.lineTo(currentX, currentY);
      }

      if (seedRandom.nextDouble() < 0.3) {
        final controlPoint = Offset(
          (startX + currentX) / 2 + seedRandom.nextDouble() * 50 - 25,
          (startY + currentY) / 2 + seedRandom.nextDouble() * 50 - 25,
        );
        path.quadraticBezierTo(
          controlPoint.dx,
          controlPoint.dy,
          currentX,
          currentY,
        );
      }

      canvas.drawPath(path, paint);
    }

    final dotPaint = Paint()
      ..color = Colors.blue.withValues(alpha: 0.5)
      ..style = PaintingStyle.fill;

    for (var node in nodes) {
      canvas.drawCircle(node, 3, dotPaint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) =>
      true; 
}

class JarvisScreen extends StatefulWidget {
  @override
  _JarvisScreenState createState() => _JarvisScreenState();
}

class _JarvisScreenState extends State<JarvisScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  // Gemini API key / model are entered by the user in Settings (gear icon)
  // The API key is stored through a native Android Keystore-backed channel.
  String _apiKey = '';
  String _modelName = 'gemini-3.8-flash';
  String _pendingCommand = '';
  bool _isProcessingQuery = false;
  bool _isAppInForeground = true;
  DateTime? _timerEndsAt;
  GeminiRestClient? model;
  late stt.SpeechToText speech;
  late FlutterTts flutterTts;
  late Future<void> _ttsReady;
  bool isListening = false;
  bool isSpeaking = false;
  DateTime? _speakingSince;
  String responseText = "";
  // On-screen chat transcript: what the user said/typed + what Jarvis replied.
  final List<Map<String, String>> _chatMessages = [];
  final TextEditingController _chatInputController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();

  // v1.0.8 — sounds, voice diagnosis, history, reminders, calling.
  bool _soundsEnabled = true;
  DateTime? _lastWakeSoundAt;
  String _voiceStatus = '';
  String _lastVoiceProblem = '';
  DateTime? _lastVoiceProblemAt;
  DateTime? _lastVoiceProblemSpokenAt;
  int _listenRestartStreak = 0;
  DateTime? _lastListenRestartAt;
  String _ttsLanguage = 'en-GB';
  String? _ttsVoiceName;
  String? _ttsVoiceLocale;
  // Chat history (on this phone only): one session per app launch.
  int _currentSessionId = 0;
  String _currentSessionTitle = '';
  DateTime? _currentSessionStartedAt;
  // Reminders (fire while Jarvis is running in the background).
  List<Map<String, dynamic>> _reminders = [];
  final Map<int, Timer> _reminderTimers = {};
  // Voice calling: candidates when several contacts share a name.
  List<Map<String, String>> _pendingCallCandidates = [];

  void _addChatMessage(String role, String text) {
    if (!mounted || text.trim().isEmpty) return;
    setState(() {
      _chatMessages.add({'role': role, 'text': text});
      if (_chatMessages.length > 50) _chatMessages.removeAt(0);
    });
    _appendToHistorySession(role, text);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_chatScrollController.hasClients) {
        _chatScrollController.animateTo(
          _chatScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendTypedMessage() {
    final text = _chatInputController.text.trim();
    if (text.isEmpty) return;
    if (_isProcessingQuery) {
      _addChatMessage(
          'jarvis', 'Still working on your last question — one moment.');
      return;
    }
    _chatInputController.clear();
    _addChatMessage('user', text);
    processQuery(text);
  }
  final List<GeminiChatMessage> conversationHistory = [];
  late AnimationController _animationController;
  late Animation<double> _bounceAnimation;
  Timer? _timer;
  int? _remainingSeconds;
  bool _isTimerActive = false;
  bool _isWakeWordDetected = false;
  Timer? _wakeWordTimer;
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isBackgroundListening = false;
  bool _isInConversationMode =
      false; 

  late AnimationController _colorAnimationController;
  late Animation<Color?> _colorAnimation;
  int _currentColorIndex = 0;
  final List<Color> _ironManColors = [
    Colors.red,
    Colors.blue,
    Color(0xFF00B8D4), // greenish blue (cyan)
    Color(0xFFE91E63), // reddish blue (pink)
    Color(0xFFFFA000), // amber (gold)
  ];

  Timer? _backgroundAnimationTimer;
  int _backgroundAnimationCounter = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadSettings();
    _initForegroundService();
    _loadConnectedApps();
    _startNewHistorySession();
    _loadReminders();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkWidgetLaunch();
    });
    speech = stt.SpeechToText();
    flutterTts = FlutterTts();

    _ttsReady = _configureTextToSpeech();

    flutterTts.setCompletionHandler(() {
      if (!mounted) return;
      setState(() {
        isSpeaking = false;
        _speakingSince = null;
      });
      // After Jarvis finishes speaking, listen again right away instead of
      // waiting for the 30-second timer. No foreground check: the background
      // service keeps listening alive when the app is minimised.
      if (_isInConversationMode) {
        _continueConversation();
      } else if (_isBackgroundListening) {
        _startWakeWordDetection();
      }
    });

    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 500),
    )..repeat(reverse: true);
    _bounceAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _colorAnimationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 2000),
    );

    _setupColorAnimation();

    _colorAnimationController.forward();
    _colorAnimationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _currentColorIndex = (_currentColorIndex + 1) % _ironManColors.length;
        _setupColorAnimation();
        _colorAnimationController.reset();
        _colorAnimationController.forward();
      }
    });

    _startWakeWordDetection();

    _wakeWordTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (_isBackgroundListening &&
          !speech.isListening &&
          !_isWakeWordDetected &&
          !isSpeaking &&
          !_isInConversationMode) {
        _startWakeWordDetection();
      }
      // If conversation listening died after a reply, re-arm it so the
      // app does not go silent after the first exchange.
      if (_isInConversationMode &&
          !speech.isListening &&
          !isSpeaking &&
          !_isProcessingQuery) {
        _continueConversation();
      }
      // Safety net: if TTS never reported completion, speaking gets stuck
      // and listening never restarts. Force-stop it after 60 seconds.
      if (isSpeaking &&
          _speakingSince != null &&
          DateTime.now().difference(_speakingSince!).inSeconds > 60) {
        flutterTts.stop();
        if (mounted) {
          setState(() {
            isSpeaking = false;
            _speakingSince = null;
          });
        }
      }
    });

    _startBackgroundAnimationTimer();
  }

  Future<void> _configureTextToSpeech() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _ttsLanguage = prefs.getString('tts_language') ?? 'en-GB';
      _ttsVoiceName = prefs.getString('tts_voice_name');
      _ttsVoiceLocale = prefs.getString('tts_voice_locale');
      // A saved voice (name + locale) wins; otherwise use the saved
      // language. Default is en-GB — the old en-AU default sounded wrong.
      if (_ttsVoiceName != null && _ttsVoiceLocale != null) {
        await flutterTts.setVoice(
            {'name': _ttsVoiceName!, 'locale': _ttsVoiceLocale!});
      } else {
        await flutterTts.setLanguage(_ttsLanguage);
      }
      await flutterTts.setPitch(0.8);
      await flutterTts.setSpeechRate(0.6);
      await flutterTts.awaitSpeakCompletion(true);
    } catch (_) {
      // Keep the device's default TTS configuration if a setting is unsupported.
    }
  }

  /// Saves the voice the user picked in Settings and applies it at once.
  Future<void> _saveVoiceSettings({
    required String language,
    String? voiceName,
    String? voiceLocale,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tts_language', language);
    if (voiceName != null && voiceLocale != null) {
      await prefs.setString('tts_voice_name', voiceName);
      await prefs.setString('tts_voice_locale', voiceLocale);
    } else {
      await prefs.remove('tts_voice_name');
      await prefs.remove('tts_voice_locale');
    }
    if (mounted) {
      setState(() {
        _ttsLanguage = language;
        _ttsVoiceName = voiceName;
        _ttsVoiceLocale = voiceLocale;
      });
    }
    await _configureTextToSpeech();
  }

  Future<void> _saveSoundsSetting(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sounds_enabled', enabled);
    if (mounted) setState(() => _soundsEnabled = enabled);
  }

  GeminiRestClient _buildModel(String apiKey, String modelName) {
    return GeminiRestClient(apiKey: apiKey, modelName: modelName);
  }

  Future<void> _loadSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      var savedKey = '';
      try {
        savedKey = await _secureStorageChannel.invokeMethod<String>('readApiKey') ?? '';
      } catch (_) {
        savedKey = '';
      }
      final savedModel = prefs.getString('gemini_model') ?? 'gemini-3.8-flash';
      final savedSounds = prefs.getBool('sounds_enabled') ?? true;
      if (!mounted) return;
      model?.dispose();
      conversationHistory.clear();
      setState(() {
        _apiKey = savedKey;
        _modelName = savedModel;
        _soundsEnabled = savedSounds;
        model = _apiKey.isNotEmpty ? _buildModel(_apiKey, _modelName) : null;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _apiKey = '';
        model = null;
      });
    }
  }

  Future<void> _saveSettings(String key, String modelName) async {
    final prefs = await SharedPreferences.getInstance();
    final normalizedModel = modelName.trim().isEmpty ? 'gemini-3.8-flash' : modelName.trim();
    if (key.trim().isEmpty) {
      await _secureStorageChannel.invokeMethod<void>('clearApiKey');
    } else {
      await _secureStorageChannel.invokeMethod<void>('saveApiKey', {'apiKey': key.trim()});
    }
    await prefs.setString('gemini_model', normalizedModel);
    if (!mounted) return;
    model?.dispose();
    conversationHistory.clear();
    setState(() {
      _apiKey = key.trim();
      _modelName = normalizedModel;
      model = _apiKey.isNotEmpty ? _buildModel(_apiKey, _modelName) : null;
    });
  }

  void _showSettingsDialog() {
    final keyController = TextEditingController(text: _apiKey);
    final modelController = TextEditingController(text: _modelName);
    // Voice + sounds choices edited in this dialog; saved with Save.
    bool dialogSounds = _soundsEnabled;
    String dialogLanguage = _ttsLanguage;
    String dialogVoiceName = _ttsVoiceName ?? '';
    String dialogVoiceLocale = _ttsVoiceLocale ?? '';
    List<Map<String, String>> voiceOptions = [];
    bool voicesLoading = true;
    bool voicesRequested = false;

    Future<void> loadVoices() async {
      try {
        final voices = await flutterTts.getVoices;
        final parsed = <Map<String, String>>[];
        for (final v in voices) {
          if (v is Map) {
            final name = v['name']?.toString() ?? '';
            final locale = v['locale']?.toString() ?? '';
            if (name.isNotEmpty && locale.toLowerCase().startsWith('en')) {
              parsed.add({'name': name, 'locale': locale});
            }
          }
        }
        parsed.sort((a, b) => a['name']!.compareTo(b['name']!));
        voiceOptions = parsed;
      } catch (_) {
        voiceOptions = [];
      }
      voicesLoading = false;
    }

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          if (!voicesRequested) {
            voicesRequested = true;
            loadVoices().then((_) {
              if (context.mounted) setDialogState(() {});
            });
          }
          return AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('Settings',
            style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Paste your free Gemini API key from Google AI Studio (aistudio.google.com). Voice commands such as opening apps, telling the time, timers and alarms work without a key.',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: keyController,
                obscureText: true,
                enableSuggestions: false,
                autocorrect: false,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Gemini API key',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: modelController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Model name',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              const Text('App sounds',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              SwitchListTile(
                value: dialogSounds,
                activeColor: Colors.cyan,
                title: const Text('Startup and wake-up sounds',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Off silences the startup chime and the wake-up chime.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) => setDialogState(() => dialogSounds = v),
              ),
              const SizedBox(height: 8),
              const Text('Jarvis voice',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: dialogLanguage,
                dropdownColor: Colors.grey[900],
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Accent',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(
                      value: 'en-GB', child: Text('English (UK)')),
                  DropdownMenuItem(
                      value: 'en-US', child: Text('English (US)')),
                  DropdownMenuItem(
                      value: 'en-AU', child: Text('English (Australia)')),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setDialogState(() {
                    dialogLanguage = v;
                    dialogVoiceName = '';
                    dialogVoiceLocale = '';
                  });
                },
              ),
              const SizedBox(height: 12),
              if (voicesLoading)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text('Loading voices…',
                      style: TextStyle(color: Colors.grey, fontSize: 13)),
                )
              else if (voiceOptions.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                      'No English voices found on this phone. The accent above will be used.',
                      style: TextStyle(color: Colors.grey, fontSize: 13)),
                )
              else
                DropdownButtonFormField<String>(
                  value: voiceOptions.any(
                          (v) => v['name'] == dialogVoiceName)
                      ? dialogVoiceName
                      : '',
                  dropdownColor: Colors.grey[900],
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    labelText: 'Voice (from this phone)',
                    labelStyle: TextStyle(color: Colors.cyan),
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    const DropdownMenuItem(
                        value: '', child: Text('Default voice')),
                    for (final v in voiceOptions)
                      DropdownMenuItem(
                        value: v['name'],
                        child: Text('${v['name']} (${v['locale']})',
                            overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (v) {
                    final picked = v ?? '';
                    final match = voiceOptions.firstWhere(
                      (e) => e['name'] == picked,
                      orElse: () => {'name': '', 'locale': ''},
                    );
                    setDialogState(() {
                      dialogVoiceName = picked;
                      dialogVoiceLocale = match['locale'] ?? '';
                    });
                  },
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await _saveSettings('', 'gemini-3.8-flash');
              keyController.dispose();
              modelController.dispose();
              if (context.mounted) Navigator.of(context).pop();
            },
            child:
                const Text('Clear key', style: TextStyle(color: Colors.redAccent)),
          ),
          TextButton(
            onPressed: () {
              keyController.dispose();
              modelController.dispose();
              Navigator.of(context).pop();
            },
            child:
                const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _saveSettings(keyController.text.trim(), modelController.text.trim());
                await _saveSoundsSetting(dialogSounds);
                await _saveVoiceSettings(
                  language: dialogLanguage,
                  voiceName:
                      dialogVoiceName.isEmpty ? null : dialogVoiceName,
                  voiceLocale:
                      dialogVoiceLocale.isEmpty ? null : dialogVoiceLocale,
                );
                keyController.dispose();
                modelController.dispose();
                if (context.mounted) Navigator.of(context).pop();
                speak('Settings saved, sir.');
              } catch (_) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Could not save the settings. Please try again.')),
                  );
                }
              }
            },
            child: const Text('Save', style: TextStyle(color: Colors.cyan)),
          ),
        ],
          );
        },
      ),
    );
  }

  void _startBackgroundAnimationTimer() {
    _backgroundAnimationTimer = Timer.periodic(Duration(seconds: 5), (timer) {
      if (!_isWakeWordDetected && !isSpeaking && !_isInConversationMode) {
        setState(() {
          _backgroundAnimationCounter++;
        });
      }
    });
  }

  void _setupColorAnimation() {
    final nextColorIndex = (_currentColorIndex + 1) % _ironManColors.length;
    _colorAnimation = ColorTween(
      begin: _ironManColors[_currentColorIndex],
      end: _ironManColors[nextColorIndex],
    ).animate(_colorAnimationController);
  }

  Future<void> _startWakeWordDetection() async {
    if (!mounted || _isInConversationMode) return;
    try {
      final available = await speech.initialize();
      if (!mounted) return;
      if (!available) {
        // Speech service hiccup (no network / Google app busy). Keep the
        // toggle ON so the 30-second timer retries — never switch it off
        // by ourselves, or voice dies silently until the user re-toggles.
        debugPrint('Speech recognition unavailable; will retry.');
        _reportVoiceProblem(
            'Voice listening paused — speech service is busy or there is no internet. Retrying…');
        return;
      }
      setState(() => _isBackgroundListening = true);
      speech.statusListener = (status) {
        if (status == stt.SpeechToText.doneStatus ||
            status == stt.SpeechToText.notListeningStatus) {
          if (_isBackgroundListening &&
              !_isWakeWordDetected &&
              !_isInConversationMode) {
            // Back off when the recognizer keeps dying: every restart
            // plays the system's listening beep, so a tight restart loop
            // sounds like continuous ticking in the background.
            final delay = _listenRestartDelay();
            Future.delayed(delay, () {
              if (mounted &&
                  _isBackgroundListening &&
                  !_isWakeWordDetected &&
                  !_isInConversationMode) {
                _startListeningForWakeWord();
              }
            });
          }
        }
      };
      _startListeningForWakeWord();
    } catch (_) {
      // Same as above: keep the toggle ON; the timer retries.
      debugPrint('Wake-word start failed; will retry.');
      _reportVoiceProblem(
          'Voice listening paused — microphone or speech service had a problem. Retrying…');
    }
  }

  /// Delay before restarting the recognizer after it stops. Normally a
  /// third of a second; after three restarts within five seconds (the
  /// recognizer is dying on every start, e.g. when the app just went to
  /// the background) wait eight seconds instead, so the repeated
  /// listening beeps do not tick continuously.
  Duration _listenRestartDelay() {
    final now = DateTime.now();
    if (_lastListenRestartAt != null &&
        now.difference(_lastListenRestartAt!).inSeconds < 5) {
      _listenRestartStreak++;
    } else {
      _listenRestartStreak = 0;
    }
    _lastListenRestartAt = now;
    if (_listenRestartStreak >= 3) {
      _listenRestartStreak = 0;
      return const Duration(seconds: 8);
    }
    return const Duration(milliseconds: 350);
  }

  /// Tells the user WHY voice is not working (internet, mic, speech
  /// service) instead of going silent. Shows in the chat and on the
  /// background notification; speaks it once in a while when the app is
  /// in the background, where the chat cannot be seen. Same reason is
  /// never repeated within five minutes.
  void _reportVoiceProblem(String reason) {
    if (!mounted) return;
    final now = DateTime.now();
    if (_lastVoiceProblem == reason &&
        _lastVoiceProblemAt != null &&
        now.difference(_lastVoiceProblemAt!).inMinutes < 5) {
      return;
    }
    _lastVoiceProblem = reason;
    _lastVoiceProblemAt = now;
    setState(() => _voiceStatus = reason);
    _addChatMessage('jarvis', 'Voice: $reason');
    _updateListeningNotification(reason);
    if (!_isAppInForeground &&
        (_lastVoiceProblemSpokenAt == null ||
            now.difference(_lastVoiceProblemSpokenAt!).inSeconds > 60)) {
      _lastVoiceProblemSpokenAt = now;
      speak(reason);
    }
  }

  /// Short reason shown on the "J.A.R.V.I.S is listening" notification,
  /// so the user can see the voice status without opening the app.
  Future<void> _updateListeningNotification(String text) async {
    try {
      await FlutterForegroundTask.updateService(
        notificationTitle: 'J.A.R.V.I.S is listening',
        notificationText: text,
      );
    } catch (_) {}
  }

  /// True when the phone can reach Google's Gemini servers. Used before
  /// an AI request so "no internet" is reported plainly instead of
  /// looking like Jarvis ignored the command.
  Future<bool> _hasInternet() async {
    try {
      final result = await InternetAddress.lookup(
              'generativelanguage.googleapis.com')
          .timeout(const Duration(seconds: 5));
      return result.isNotEmpty && result.first.rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  void _startListeningForWakeWord() {
    if (!speech.isListening && mounted && !_isInConversationMode) {
      try {
        speech.listen(
          onResult: (result) {
            if (result.finalResult) {
              if (!mounted) return;
              String userInput = result.recognizedWords.toLowerCase();
              if (userInput.contains('jarvis') ||
                  userInput.contains('hey jarvis')) {
                _addChatMessage('user', userInput);
                setState(() => _isWakeWordDetected = true);
                _playWakeSound();

                _startConversationMode();
              }
            }
          },
          listenFor: Duration(minutes: 10), 
          pauseFor: Duration(seconds: 10), 
          partialResults: true,
          listenMode: stt.ListenMode.deviceDefault,
          cancelOnError: false,
          onSoundLevelChange: (level) {},
        );
      } catch (e) {
        debugPrint("Error starting speech recognition: $e");

        Future.delayed(Duration(seconds: 2), () {
          if (mounted && _isBackgroundListening && !_isInConversationMode) {
            _startListeningForWakeWord();
          }
        });
      }
    }
  }

  void _startConversationMode() {
    speech.stop();

    setState(() {
      _isInConversationMode = true;
      _isWakeWordDetected = true;
    });

    speak("I'm listening, sir. How can I assist you?");
    _addChatMessage('jarvis', "I'm listening, sir. How can I assist you?");
  }

  void _continueConversation() {
    if (!mounted || !_isInConversationMode || _isProcessingQuery) return;

    debugPrint("Continuing conversation...");

    if (!speech.isListening) {
      try {
        speech.listen(
          onResult: (result) async {
            if (result.finalResult) {
              if (!mounted) return;
              String userInput = result.recognizedWords.toLowerCase();
              _addChatMessage('user', userInput);

              if (userInput.contains("end conversation") ||
                  userInput.contains("goodbye") ||
                  userInput.contains("bye") ||
                  userInput.contains("that's all") ||
                  userInput.contains("exit conversation")) {
                _endConversationMode();
                speak(
                    "Ending conversation mode. Just say 'Hey Jarvis' when you need me again.");
                return;
              }

              processQuery(userInput);
            }
          },
          listenFor: Duration(minutes: 10),
          pauseFor: Duration(seconds: 10),
          partialResults: true,
          listenMode: stt.ListenMode.deviceDefault,
          cancelOnError: false,
          onSoundLevelChange: (level) {},
        );

        speech.statusListener = (status) {
          if ((status == stt.SpeechToText.doneStatus ||
                  status == stt.SpeechToText.notListeningStatus) &&
              _isInConversationMode &&
              !isSpeaking &&
              !_isProcessingQuery) {
            Future.delayed(Duration(milliseconds: 300), () {
              if (mounted &&
                  _isInConversationMode &&
                  !isSpeaking &&
                  !_isProcessingQuery &&
                  !speech.isListening) {
                debugPrint("Restarting conversation listening...");
                _continueConversation();
              }
            });
          }
        };
      } catch (e) {
        debugPrint("Error in conversation listening: $e");

        Future.delayed(Duration(seconds: 1), () {
          if (mounted && _isInConversationMode) {
            _continueConversation();
          }
        });
      }
    }
  }

  void _endConversationMode() {
    setState(() {
      _isInConversationMode = false;
      _isWakeWordDetected = false;
    });

    if (_isBackgroundListening) {
      _startWakeWordDetection();
    }
  }


  Future<void> processQuery(String query) async {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty || _isProcessingQuery) return;

    if (normalized.contains('cancel timer') || normalized.contains('stop timer')) {
      _pendingCommand = '';
      _timer?.cancel();
      _timerEndsAt = null;
      if (mounted) setState(() { _isTimerActive = false; _remainingSeconds = null; });
      speak('Timer cancelled.');
      return;
    }
    // "Stop" / "chup" / "khamosh": silence Jarvis immediately. Exact
    // phrases only, so questions like "how do I stop a nosebleed" still
    // get answered instead of silencing the app.
    const stopWords = <String>{
      'stop',
      'stop jarvis',
      'jarvis stop',
      'please stop',
      'stop please',
      'stop speaking',
      'stop talking',
      'chup',
      'chup ho jao',
      'chup kar',
      'khamosh',
      'khamosh ho jao',
      'bas',
      'bas karo',
      'ruk jao',
      'ruk',
      'band karo',
      'quiet',
      'shut up',
    };
    if (stopWords.contains(normalized)) {
      _stopSpeaking();
      _addChatMessage('jarvis', 'Stopped.');
      return;
    }
    // Choosing between several contacts with the same name.
    if (_pendingCommand == 'call' && _pendingCallCandidates.isNotEmpty) {
      _pendingCommand = '';
      await _pickCallCandidate(normalized);
      return;
    }
    if (_pendingCommand == 'alarm' && normalized.contains('cancel')) {
      _pendingCommand = '';
      speak('Alarm request cancelled.');
      return;
    }

    // A follow-up answer is routed to the command that requested it.
    if (_pendingCommand == 'timer') {
      _pendingCommand = '';
      _handleTimerCommand(normalized, allowPrompt: false);
      return;
    }
    if (_pendingCommand == 'alarm') {
      _pendingCommand = '';
      await _handleAlarmCommand(normalized, allowPrompt: false);
      return;
    }

    if (RegExp(r'\b(weather|forecast)\b').hasMatch(normalized)) {
      _searchWeather();
      return;
    }
    if (RegExp(r'\b(time|what time|current time|tell me the time|time now)\b').hasMatch(normalized)) {
      _tellTime();
      return;
    }
    if (normalized.contains('set timer') || normalized.contains('start timer') || normalized.contains('timer for')) {
      _handleTimerCommand(normalized);
      return;
    }
    if (normalized.contains('set alarm') || normalized.contains('alarm for')) {
      await _handleAlarmCommand(normalized);
      return;
    }
    // Device controls (checked before "open ..." so "open wifi settings"
    // does not fall through to the Play Store search).
    if (normalized == 'lock phone' ||
        normalized == 'lock my phone' ||
        normalized == 'lock the phone') {
      _lockPhone();
      return;
    }
    if (normalized == 'unlock phone' || normalized == 'unlock my phone') {
      _addChatMessage('jarvis',
          "I can't unlock the phone — Android does not allow any app to unlock the lock screen. Only you can unlock it with your PIN, pattern or fingerprint.");
      speak("I can't unlock the phone. Only you can unlock it.");
      return;
    }
    if (normalized.contains('flashlight on') ||
        normalized.contains('torch on')) {
      _setTorch(true);
      return;
    }
    if (normalized.contains('flashlight off') ||
        normalized.contains('torch off')) {
      _setTorch(false);
      return;
    }
    if (normalized.contains('volume up')) {
      _setVolume('up');
      return;
    }
    if (normalized.contains('volume down')) {
      _setVolume('down');
      return;
    }
    if (normalized == 'mute' ||
        normalized.contains('volume mute') ||
        normalized.contains('mute volume')) {
      _setVolume('mute');
      return;
    }
    if (normalized.contains('wifi settings') ||
        normalized.contains('wi-fi settings')) {
      _openSettingsPanel('android.settings.WIFI_SETTINGS', 'WiFi settings');
      return;
    }
    if (normalized.contains('bluetooth settings')) {
      _openSettingsPanel(
          'android.settings.BLUETOOTH_SETTINGS', 'Bluetooth settings');
      return;
    }
    if (normalized.contains('display settings') ||
        normalized.contains('brightness settings')) {
      _openSettingsPanel(
          'android.settings.DISPLAY_SETTINGS', 'Display settings');
      return;
    }
    // Voice calling: "call Ami" / "Ami ko call karo" / "call 03001234567".
    if (_isCallCommand(normalized)) {
      await _handleCallCommand(normalized);
      return;
    }
    // Reminders: "remind me at 7 to study" / "7 baje mujhe parhai yaad
    // dilao" / "10 minute baad mujhe paani yaad dilao". Reminders fire
    // while Jarvis is running in the background.
    if (_isReminderCommand(normalized)) {
      await _handleReminderCommand(normalized);
      return;
    }
    if (normalized == 'cancel reminder' ||
        normalized == 'cancel all reminders' ||
        normalized == 'reminder cancel karo' ||
        normalized == 'sab reminders cancel karo') {
      _cancelReminders(
          all: normalized.contains('all') || normalized.contains('sab'));
      return;
    }
    // Roman Urdu commands ("whatsapp kholo", "phone lock karo", ...).
    if (_tryUrduCommand(normalized)) return;

    if (normalized.startsWith('open ')) {
      _openApp(normalized);
      return;
    }

    final currentModel = model;
    if (currentModel == null) {
      _addChatMessage('jarvis',
          'AI chat needs a Gemini API key. Open Settings (gear icon) and add your key.');
      speak('AI chat needs a Gemini API key. Open Settings and add your key.');
      return;
    }

    // Say plainly when there is no internet, instead of looking like
    // Jarvis ignored the command.
    if (!await _hasInternet()) {
      _addChatMessage('jarvis',
          'No internet connection — I cannot reach Gemini. Check Wi-Fi or mobile data and try again.');
      speak('No internet connection. Check Wi-Fi or mobile data and try again.');
      return;
    }

    _isProcessingQuery = true;
    try {
      // Retry automatically when Google says the model is busy or the
      // request times out, so a temporary overload does not surface as an
      // error. Up to 3 tries with growing pauses (5s, then 10s).
      String answer = '';
      for (var attempt = 0; attempt < 3; attempt++) {
        try {
          answer = (await currentModel.sendMessage(
            message: query,
            history: conversationHistory,
          ))
              .trim();
          break;
        } on GeminiApiException catch (e) {
          final msg = e.message.toLowerCase();
          final retryable = msg.contains('overload') ||
              msg.contains('high demand') ||
              msg.contains('timed out') ||
              msg.contains('try again later');
          if (retryable && attempt < 2) {
            await Future.delayed(Duration(seconds: 5 * (attempt + 1)));
            continue;
          }
          rethrow;
        }
      }
      if (answer.isEmpty) {
        _addChatMessage('jarvis', "I didn't receive a usable response.");
        speak("I didn't receive a usable response.");
        return;
      }
      conversationHistory
        ..add(GeminiChatMessage(role: 'user', text: query))
        ..add(GeminiChatMessage(role: 'model', text: answer));
      if (conversationHistory.length > 20) {
        conversationHistory.removeRange(0, conversationHistory.length - 20);
      }
      if (mounted) setState(() => responseText = answer);
      _addChatMessage('jarvis', answer);
      speak(_shortSpoken(answer));
    } on GeminiApiException catch (e) {
      _addChatMessage('jarvis', 'Gemini request failed: ${e.message}');
      speak('Gemini request failed: ${e.message}');
    } catch (_) {
      _addChatMessage('jarvis',
          'Sorry, I could not complete that request. Check your internet connection and API settings.');
      speak('Sorry, I could not complete that request. Check your internet connection and API settings.');
    } finally {
      _isProcessingQuery = false;
    }
  }

  // ---- Chat history (on this phone only) ----

  void _startNewHistorySession() {
    _currentSessionId = DateTime.now().millisecondsSinceEpoch;
    _currentSessionTitle = '';
    _currentSessionStartedAt = DateTime.now();
  }

  void _appendToHistorySession(String role, String text) {
    if (_currentSessionId == 0) _startNewHistorySession();
    if (role == 'user' && _currentSessionTitle.isEmpty) {
      _currentSessionTitle =
          text.length > 40 ? '${text.substring(0, 40)}…' : text;
    }
    _saveHistorySession();
  }

  Future<void> _saveHistorySession() async {
    if (_currentSessionId == 0) return;
    // Build the session snapshot first: _chatMessages may be cleared by
    // "New chat" while the preferences write is still in flight.
    final session = <String, dynamic>{
      'id': _currentSessionId,
      'title': _currentSessionTitle.isEmpty ? 'Chat' : _currentSessionTitle,
      'startedAt':
          (_currentSessionStartedAt ?? DateTime.now()).toIso8601String(),
      'messages': _chatMessages
          .map((m) => {'role': m['role'], 'text': m['text']})
          .toList(),
    };
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('jarvis_chat_history_v1');
      final List<dynamic> stored =
          raw == null ? [] : (jsonDecode(raw) as List<dynamic>);
      stored.removeWhere(
          (s) => s is Map && s['id'] == _currentSessionId);
      stored.add(session);
      while (stored.length > 30) {
        stored.removeAt(0);
      }
      await prefs.setString(
          'jarvis_chat_history_v1', jsonEncode(stored));
    } catch (_) {}
  }

  /// Archives the current chat and starts a fresh one.
  void _startNewChat() {
    _saveHistorySession();
    setState(() => _chatMessages.clear());
    _startNewHistorySession();
  }

  // ---- Home-screen widget ----

  static const MethodChannel _launchChannel =
      MethodChannel('com.jarvis.jarvis_app/launch');

  /// The home-screen widget opens the app with a flag asking it to start
  /// a conversation right away (no "Hey Jarvis" needed).
  Future<void> _checkWidgetLaunch() async {
    try {
      final start =
          await _launchChannel.invokeMethod<bool>('getStartConversation');
      if (start == true && mounted && !_isInConversationMode) {
        if (!_isBackgroundListening) {
          setState(() => _isBackgroundListening = true);
        }
        _startConversationMode();
      }
    } catch (_) {}
  }

  // ---- Voice calling ----

  bool _isCallCommand(String normalized) {
    return normalized.startsWith('call ') ||
        normalized.startsWith('call karo ') ||
        normalized.contains(' ko call karo') ||
        normalized.contains(' ko call kar do') ||
        normalized.contains(' ko call karna');
  }

  Future<void> _handleCallCommand(String normalized) async {
    var name = normalized
        .replaceAll('call karo', '')
        .replaceAll('call kar do', '')
        .replaceAll('call karna', '')
        .replaceAll('call', '')
        .replaceAll(' ko ', ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    if (name.isEmpty) {
      _addChatMessage(
          'jarvis', 'Who should I call? Say for example: call Ami.');
      speak('Who should I call?');
      return;
    }
    // A bare number dials straight away (opens the dialer; you tap Call).
    final digits = name.replaceAll(RegExp(r'[^0-9+]'), '');
    if (digits.length >= 7 &&
        RegExp(r'^\+?[0-9]{7,15}$').hasMatch(digits)) {
      _dialNumber(digits, name);
      return;
    }
    bool granted = false;
    try {
      granted = await FlutterContacts.requestPermission(readonly: true);
    } catch (_) {
      granted = false;
    }
    if (!granted) {
      _addChatMessage('jarvis',
          'I need the Contacts permission to call someone by name. Allow Contacts in the app settings, then try again.');
      speak('I need the Contacts permission to call by name.');
      _openAppSettings();
      return;
    }
    List<Contact> contacts = [];
    try {
      contacts = await FlutterContacts.getContacts(withProperties: true);
    } catch (_) {
      contacts = [];
    }
    final query = name.toLowerCase();
    final matches = contacts.where((c) {
      final display = c.displayName.toLowerCase();
      return display.contains(query) || query.contains(display);
    }).toList();
    if (matches.isEmpty) {
      _addChatMessage('jarvis', 'I could not find a contact named "$name".');
      speak('I could not find a contact named $name.');
      return;
    }
    final withNumbers =
        matches.where((c) => c.phones.isNotEmpty).toList();
    if (withNumbers.isEmpty) {
      _addChatMessage('jarvis',
          '${matches.first.displayName} has no phone number saved.');
      speak('${matches.first.displayName} has no phone number saved.');
      return;
    }
    if (withNumbers.length == 1) {
      final c = withNumbers.first;
      _dialNumber(c.phones.first.number, c.displayName);
      return;
    }
    _pendingCallCandidates = withNumbers
        .map((c) => {
              'name': c.displayName,
              'number': c.phones.first.number,
            })
        .toList();
    _pendingCommand = 'call';
    final names = withNumbers.map((c) => c.displayName).join(', ');
    _addChatMessage('jarvis',
        'I found several: $names. Which one? Say the name.');
    speak('I found several contacts with that name. Which one?');
  }

  Future<void> _pickCallCandidate(String normalized) async {
    final candidates = _pendingCallCandidates;
    _pendingCallCandidates = [];
    final pick = int.tryParse(normalized.trim());
    if (pick != null && pick >= 1 && pick <= candidates.length) {
      final c = candidates[pick - 1];
      _dialNumber(c['number']!, c['name']!);
      return;
    }
    for (final c in candidates) {
      if (normalized.contains(c['name']!.toLowerCase())) {
        _dialNumber(c['number']!, c['name']!);
        return;
      }
    }
    _addChatMessage(
        'jarvis', 'I did not catch which one. Please say the name again.');
    speak('I did not catch which one.');
  }

  Future<void> _dialNumber(String number, String label) async {
    final clean = number.replaceAll(RegExp(r'[^0-9+]'), '');
    final uri = Uri(scheme: 'tel', path: clean);
    try {
      final opened =
          await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (opened) {
        _addChatMessage('jarvis', 'Calling $label…');
        speak('Calling $label.');
      } else {
        _addChatMessage('jarvis', 'I could not open the dialer.');
        speak('I could not open the dialer.');
      }
    } catch (_) {
      _addChatMessage('jarvis', 'I could not open the dialer.');
      speak('I could not open the dialer.');
    }
  }

  // ---- Reminders (fire while Jarvis is running in the background) ----

  bool _isReminderCommand(String normalized) {
    return normalized.contains('remind') ||
        normalized.contains('reminder') ||
        normalized.contains('yaad dilao') ||
        normalized.contains('yaad dila do');
  }

  Future<void> _handleReminderCommand(String normalized) async {
    final parsed = _parseReminder(normalized);
    if (parsed == null) {
      _addChatMessage('jarvis',
          'I could not understand the reminder time. Say for example: remind me at 7 to study, or remind me in 10 minutes to drink water.');
      speak(
          'I could not understand the reminder time. Please say a time, such as 7 o clock, or in 10 minutes.');
      return;
    }
    final id = DateTime.now().millisecondsSinceEpoch;
    _reminders.add({
      'id': id,
      'text': parsed.text,
      'fireAt': parsed.fireAt.toIso8601String(),
    });
    await _saveReminders();
    _armReminderTimer(id, parsed.text, parsed.fireAt);
    final time = DateFormat.jm().format(parsed.fireAt);
    _addChatMessage('jarvis', 'Reminder set for $time: ${parsed.text}');
    speak('Reminder set for $time.');
  }

  ({DateTime fireAt, String text})? _parseReminder(String normalized) {
    final now = DateTime.now();
    // Relative: "in 10 minutes remind me to drink water" /
    // "10 minute baad mujhe paani yaad dilao".
    final relative = RegExp(
            r'(\d+)\s*(minute|minutes|min|ghantay?|hour|hours|second|seconds)')
        .firstMatch(normalized);
    final hasRelativeWord = normalized.contains('baad') ||
        normalized.contains('after') ||
        normalized.contains('in ');
    if (relative != null && hasRelativeWord) {
      final value = int.tryParse(relative.group(1) ?? '') ?? 0;
      final unit = relative.group(2) ?? 'minute';
      if (value <= 0) return null;
      final seconds = unit.startsWith('ghant') || unit.startsWith('hour')
          ? value * 3600
          : unit.startsWith('second')
              ? value
              : value * 60;
      var text = normalized
          .replaceAll(relative.group(0)!, '')
          .replaceAll(
              RegExp(
                  r'\b(remind me|remind|reminder|mujhe|yaad dilao|yaad dila do|baad|after|in)\b'),
              '')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      if (text.startsWith('to ')) text = text.substring(3);
      if (text.isEmpty) text = 'Reminder';
      return (fireAt: now.add(Duration(seconds: seconds)), text: text);
    }
    // Absolute: "remind me at 7 to study" / "7 baje mujhe parhai yaad
    // dilao" / "7:30 pm".
    final absolute = RegExp(
      r'(\d{1,2})(?::(\d{1,2}))?\s*(a\.?m\.?|p\.?m\.?)?\s*(baje|bajay|am|pm)?',
    ).firstMatch(normalized);
    if (absolute != null) {
      final hour = int.tryParse(absolute.group(1) ?? '') ?? 0;
      final minute = int.tryParse(absolute.group(2) ?? '0') ?? 0;
      if (hour < 1 || hour > 12 || minute < 0 || minute > 59) return null;
      final marker =
          (absolute.group(3) ?? absolute.group(4) ?? '').toLowerCase();
      var hour24 = hour % 12;
      if (marker.contains('pm') ||
          normalized.contains('shaam') ||
          normalized.contains('raat')) {
        hour24 += 12;
      }
      var fireAt = DateTime(now.year, now.month, now.day, hour24, minute);
      if (fireAt.isBefore(now.add(const Duration(minutes: 1)))) {
        fireAt = fireAt.add(const Duration(days: 1));
      }
      var text = normalized
          .replaceAll(absolute.group(0)!, '')
          .replaceAll(
              RegExp(
                  r'\b(remind me|remind|reminder|mujhe|yaad dilao|yaad dila do|to|at|baje|bajay)\b'),
              '')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      if (text.isEmpty) text = 'Reminder';
      return (fireAt: fireAt, text: text);
    }
    return null;
  }

  Future<void> _loadReminders() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('jarvis_reminders_v1');
      if (raw == null) return;
      final list =
          (jsonDecode(raw) as List<dynamic>).whereType<Map>().toList();
      final now = DateTime.now();
      _reminders = [];
      for (final r in list) {
        final fireAt = DateTime.tryParse(r['fireAt']?.toString() ?? '');
        final text = r['text']?.toString() ?? '';
        final id = r['id'] is int ? r['id'] as int : 0;
        if (fireAt == null || text.isEmpty || id == 0) continue;
        if (fireAt.isBefore(now)) continue;
        _reminders.add(
            {'id': id, 'text': text, 'fireAt': fireAt.toIso8601String()});
        _armReminderTimer(id, text, fireAt);
      }
    } catch (_) {}
  }

  Future<void> _saveReminders() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('jarvis_reminders_v1', jsonEncode(_reminders));
    } catch (_) {}
  }

  void _armReminderTimer(int id, String text, DateTime fireAt) {
    _reminderTimers[id]?.cancel();
    final delay = fireAt.difference(DateTime.now());
    if (delay.isNegative) return;
    _reminderTimers[id] = Timer(delay, () => _fireReminder(id, text));
  }

  Future<void> _fireReminder(int id, String text) async {
    _reminderTimers.remove(id);
    _reminders.removeWhere((r) => r['id'] == id);
    await _saveReminders();
    _addChatMessage('jarvis', 'Reminder: $text');
    speak('Reminder, sir: $text');
    _updateListeningNotification('Reminder: $text');
  }

  void _cancelReminders({required bool all}) {
    if (_reminders.isEmpty) {
      _addChatMessage('jarvis', 'There are no reminders set.');
      speak('There are no reminders set.');
      return;
    }
    if (all) {
      for (final t in _reminderTimers.values) {
        t.cancel();
      }
      _reminderTimers.clear();
      _reminders.clear();
      _saveReminders();
      _addChatMessage('jarvis', 'All reminders cancelled.');
      speak('All reminders cancelled.');
    } else {
      final last = _reminders.last;
      _reminderTimers[last['id'] as int]?.cancel();
      _reminderTimers.remove(last['id'] as int);
      _reminders.removeLast();
      _saveReminders();
      _addChatMessage('jarvis', 'Reminder cancelled: ${last['text']}');
      speak('Reminder cancelled.');
    }
  }

  // ---- Roman Urdu commands ----

  /// Returns true when the command was handled.
  bool _tryUrduCommand(String normalized) {
    // "whatsapp kholo" / "X kholo" / "X open karo".
    if (normalized.endsWith(' kholo') ||
        normalized.endsWith(' open karo')) {
      final app = normalized
          .replaceAll(' kholo', '')
          .replaceAll(' open karo', '')
          .trim();
      if (app.isNotEmpty) {
        _openApp('open $app');
        return true;
      }
    }
    if (normalized == 'phone lock karo' ||
        normalized == 'mobile lock karo' ||
        normalized == 'lock karo' ||
        normalized == 'phone band karo') {
      _lockPhone();
      return true;
    }
    if (normalized.contains('torch on karo') ||
        normalized.contains('batti on karo') ||
        normalized.contains('flashlight on karo')) {
      _setTorch(true);
      return true;
    }
    if (normalized.contains('torch off karo') ||
        normalized.contains('batti off karo') ||
        normalized.contains('flashlight off karo')) {
      _setTorch(false);
      return true;
    }
    if (normalized.contains('awaz barhao') ||
        normalized.contains('volume upar karo') ||
        normalized.contains('awaz upar karo')) {
      _setVolume('up');
      return true;
    }
    if (normalized.contains('awaz kam karo') ||
        normalized.contains('volume neeche karo') ||
        normalized.contains('awaz neeche karo')) {
      _setVolume('down');
      return true;
    }
    if (normalized.contains('awaz band karo') ||
        normalized == 'khamosh karo') {
      _setVolume('mute');
      return true;
    }
    if (normalized.contains('wifi kholo') ||
        normalized.contains('wifi settings kholo')) {
      _openSettingsPanel('android.settings.WIFI_SETTINGS', 'WiFi settings');
      return true;
    }
    if (normalized.contains('bluetooth kholo')) {
      _openSettingsPanel(
          'android.settings.BLUETOOTH_SETTINGS', 'Bluetooth settings');
      return true;
    }
    if (normalized.contains('time kya hai') ||
        normalized.contains('kitne bajay hain') ||
        normalized == 'time batao') {
      _tellTime();
      return true;
    }
    return false;
  }

  void _searchWeather() async {
    final Uri url = Uri.https('www.google.com', '/search', {'q': 'weather near me'});
    try {
      final opened = await launchUrl(url, mode: LaunchMode.externalApplication);
      if (!opened) speak('I could not open the browser.');
    } catch (e) {
      speak(
          "I couldn't open the browser. Please check your internet connection.");
    }
  }

  void _tellTime() {
    String time = DateFormat.jm().format(DateTime.now());
    speak("The current time is $time");
  }

  static const MethodChannel _deviceChannel =
      MethodChannel('com.jarvis.jarvis_app/device');

  /// Locks the screen. Needs the app enabled as a device admin first
  /// (Android only allows device-admin apps to lock the screen).
  Future<void> _lockPhone() async {
    try {
      final active =
          await _deviceChannel.invokeMethod<bool>('isDeviceAdminActive');
      if (active != true) {
        _addChatMessage('jarvis',
            'To lock the phone, Jarvis needs device admin. Opening the setup — tap "Activate", then say "lock phone" again.');
        speak('Please activate device admin first.');
        await _deviceChannel.invokeMethod('requestDeviceAdmin');
        return;
      }
      await _deviceChannel.invokeMethod('lockPhone');
      _addChatMessage('jarvis', 'Phone locked.');
    } catch (e) {
      _addChatMessage('jarvis', 'Could not lock the phone: $e');
      speak('I could not lock the phone.');
    }
  }

  Future<void> _setTorch(bool on) async {
    try {
      final result = await _deviceChannel
          .invokeMethod<String>('setTorch', <String, dynamic>{'on': on});
      if (result == 'NO_PERMISSION') {
        _addChatMessage('jarvis',
            'Flashlight needs the Camera permission. Opening app settings — allow Camera, then try again.');
        speak('Flashlight needs the Camera permission.');
        _openAppSettings();
        return;
      }
      _addChatMessage('jarvis', on ? 'Flashlight on.' : 'Flashlight off.');
      speak(on ? 'Flashlight on.' : 'Flashlight off.');
    } catch (e) {
      _addChatMessage('jarvis', 'Could not change the flashlight: $e');
    }
  }

  Future<void> _setVolume(String direction) async {
    try {
      await _deviceChannel.invokeMethod(
          'setVolume', <String, dynamic>{'direction': direction});
      _addChatMessage('jarvis', 'Volume $direction.');
    } catch (e) {
      _addChatMessage('jarvis', 'Could not change the volume: $e');
    }
  }

  Future<void> _openSettingsPanel(String action, String label) async {
    try {
      final intent = AndroidIntent(
        action: action,
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      _addChatMessage('jarvis', 'Opening $label.');
    } catch (e) {
      _addChatMessage('jarvis', "I couldn't open $label.");
    }
  }

  Future<void> _openAppSettings() async {
    try {
      final intent = AndroidIntent(
        action: 'android.settings.APPLICATION_DETAILS_SETTINGS',
        data: 'package:com.jarvis.jarvis_app',
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
    } catch (_) {}
  }

  void _openApp(String query) async {
    String cleanedQuery = query.toLowerCase().replaceAll("open", "").trim();
    // 1. Apps the user connected (any app on the phone).
    String? connectedPackage;
    for (final entry in _connectedApps.entries) {
      final label = entry.value.toLowerCase();
      if (label == cleanedQuery || cleanedQuery.contains(label)) {
        connectedPackage = entry.key;
        break;
      }
    }
    if (connectedPackage != null) {
      try {
        final intent = AndroidIntent(
          action: 'android.intent.action.MAIN',
          category: 'android.intent.category.LAUNCHER',
          package: connectedPackage,
          flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
        );
        await intent.launch();
        _addChatMessage('jarvis', 'Opening ${_connectedApps[connectedPackage]}');
        speak('Opening ${_connectedApps[connectedPackage]}');
      } catch (e) {
        _addChatMessage('jarvis',
            "I couldn't open ${_connectedApps[connectedPackage]}.");
        speak("I couldn't open ${_connectedApps[connectedPackage]}.");
      }
      return;
    }
    Map<String, String> appMap = {
      "chrome": "com.android.chrome",
      "whatsapp": "com.whatsapp",
      "camera": "com.android.camera",
      "gallery": "com.android.gallery3d",
      "photos": "com.google.android.apps.photos",
      "youtube": "com.google.android.youtube",
      "maps": "com.google.android.apps.maps",
      "gmail": "com.google.android.gm",
      "settings": "com.android.settings",
      "play store": "com.android.vending",
      "calculator": "com.android.calculator2",
      "calendar": "com.google.android.calendar",
      "clock": "com.android.deskclock",
      "contacts": "com.android.contacts",
      "phone": "com.android.dialer",
      "messages": "com.android.mms",
      "file manager": "com.android.documentsui",
      "files": "com.android.documentsui",
      "music": "com.android.music",
      "sound recorder": "com.android.soundrecorder",
      "notes": "com.android.notes",
      "notepad": "com.android.notes",
      "browser": "com.android.chrome",
      "internet": "com.android.chrome",
      "email": "com.google.android.gm",
      "mail": "com.google.android.gm",
      "camera app": "com.android.camera",
      "gallery app": "com.android.gallery3d",
      "photos app": "com.google.android.apps.photos",
      "youtube app": "com.google.android.youtube",
      "maps app": "com.google.android.apps.maps",
      "gmail app": "com.google.android.gm",
      "settings app": "com.android.settings",
      "play store app": "com.android.vending",
      "calculator app": "com.android.calculator2",
      "calendar app": "com.google.android.calendar",
      "clock app": "com.android.deskclock",
      "contacts app": "com.android.contacts",
      "phone app": "com.android.dialer",
      "messages app": "com.android.mms",
      "file manager app": "com.android.documentsui",
      "files app": "com.android.documentsui",
      "music app": "com.android.music",
      "sound recorder app": "com.android.soundrecorder",
      "notes app": "com.android.notes",
      "notepad app": "com.android.notes",
      "browser app": "com.android.chrome",
      "internet app": "com.android.chrome",
      "email app": "com.google.android.gm",
      "mail app": "com.google.android.gm",
      "instagram": "com.instagram.android",
      "facebook": "com.facebook.katana",
      "telegram": "org.telegram.messenger",
      "tiktok": "com.zhiliaoapp.musically",
      "spotify": "com.spotify.music",
      "snapchat": "com.snapchat.android",
      "instagram app": "com.instagram.android",
      "facebook app": "com.facebook.katana",
      "telegram app": "org.telegram.messenger",
      "tiktok app": "com.zhiliaoapp.musically",
      "spotify app": "com.spotify.music",
      "snapchat app": "com.snapchat.android"
    };

    debugPrint("Attempting to open app from query: '$cleanedQuery'");

    String? packageToOpen = appMap[cleanedQuery];

    if (packageToOpen == null) {
      for (var entry in appMap.entries) {
        if (cleanedQuery.contains(entry.key)) {
          packageToOpen = entry.value;
          break;
        }
      }
    }

    if (packageToOpen != null) {
      try {
        final intent = AndroidIntent(
          action: 'android.intent.action.MAIN',
          category: 'android.intent.category.LAUNCHER',
          package: packageToOpen,
          flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
        );

        await intent.launch();
        _addChatMessage('jarvis', 'Opening ${cleanedQuery.trim()}');
        speak("Opening ${cleanedQuery.trim()}");
      } catch (e) {
        debugPrint("Error launching app: $e");

        final playStoreUrl = Uri(scheme: 'market', host: 'search', queryParameters: {'q': cleanedQuery});
        try {
          await launchUrl(playStoreUrl, mode: LaunchMode.externalApplication);
          _addChatMessage('jarvis',
              "I couldn't open $cleanedQuery. Opening the Play Store to search for it.");
          speak(
              "I couldn't open $cleanedQuery. Opening the Play Store to search for it.");
        } catch (e) {
          _addChatMessage('jarvis',
              "I apologize, but I couldn't open ${cleanedQuery.trim()}. The app might not be installed.");
          speak(
              "I apologize, but I couldn't open ${cleanedQuery.trim()}. The app might not be installed.");
        }
      }
    } else {
      final playStoreUrl = Uri(scheme: 'market', host: 'search', queryParameters: {'q': cleanedQuery});
      try {
        await launchUrl(playStoreUrl, mode: LaunchMode.externalApplication);
        _addChatMessage('jarvis',
            "I couldn't find $cleanedQuery. Opening the Play Store to search for it.");
        speak(
            "I couldn't find $cleanedQuery. Opening the Play Store to search for it.");
      } catch (e) {
        _addChatMessage('jarvis',
            "I apologize, but I don't have access to open $cleanedQuery at the moment.");
        speak(
            "I apologize, but I don't have access to open $cleanedQuery at the moment.");
      }
    }
  }

  void _handleTimerCommand(String query, {bool allowPrompt = true}) {
    final totalSeconds = parseTimerDurationSeconds(query);
    if (totalSeconds > 0 && totalSeconds <= 7 * 24 * 3600) {
      _startTimer(totalSeconds);
      return;
    }
    if (allowPrompt) {
      _pendingCommand = 'timer';
      speak('How long should I set the timer for? You can say 5 minutes or 1 hour 20 minutes.').then((_) {
        if (mounted && !_isInConversationMode) startListening();
      });
    } else {
      speak('I could not understand that duration. Please say a valid duration, such as 5 minutes.');
    }
  }

  void _startTimer(int totalSeconds) {
    _timer?.cancel();
    if (totalSeconds <= 0) return;
    _timerEndsAt = DateTime.now().add(Duration(seconds: totalSeconds));
    if (mounted) {
      setState(() {
        _remainingSeconds = totalSeconds;
        _isTimerActive = true;
      });
    }
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) { timer.cancel(); return; }
      final remaining = _timerEndsAt!.difference(DateTime.now()).inSeconds;
      setState(() => _remainingSeconds = remaining > 0 ? remaining : 0);
      if (remaining <= 0) {
        timer.cancel();
        setState(() => _isTimerActive = false);
        speak('Timer completed, sir.');
      }
    });
    final duration = Duration(seconds: totalSeconds);
    final parts = <String>[];
    if (duration.inHours > 0) parts.add('${duration.inHours} hours');
    if (duration.inMinutes.remainder(60) > 0) parts.add('${duration.inMinutes.remainder(60)} minutes');
    if (duration.inSeconds.remainder(60) > 0) parts.add('${duration.inSeconds.remainder(60)} seconds');
    speak('Timer set for ${parts.join(' ')}. Keep Jarvis open for the countdown to run.');
  }

  Future<void> _handleAlarmCommand(String query, {bool allowPrompt = true}) async {
    final parsedTime = parseAlarmTime(query);
    if (parsedTime == null) {
      if (allowPrompt) {
        _pendingCommand = 'alarm';
        speak("What time should I set the alarm? For example, 7:30 AM.").then((_) {
          if (mounted && !_isInConversationMode) startListening();
        });
      } else {
        speak("I could not understand the time. Please say a time such as 7:30 AM.");
      }
      return;
    }

    final hour12 = parsedTime.hour12;
    final minute = parsedTime.minute;
    final meridiem = parsedTime.meridiem;
    final hour24 = parsedTime.hour24;
    try {
      final intent = AndroidIntent(
        action: 'android.intent.action.SET_ALARM',
        arguments: <String, dynamic>{
          'android.intent.extra.alarm.HOUR': hour24,
          'android.intent.extra.alarm.MINUTES': minute,
          'android.intent.extra.alarm.MESSAGE': 'J.A.R.V.I.S',
          'android.intent.extra.alarm.SKIP_UI': false,
        },
        flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      speak('Opening your clock app to create the alarm for $hour12:${minute.toString().padLeft(2, '0')} ${meridiem.toUpperCase()}. Confirm and save it in the Clock app.');
    } catch (_) {
      speak('I could not open a compatible Clock app. Please set the alarm manually.');
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    for (final t in _reminderTimers.values) {
      t.cancel();
    }
    _pendingCommand = '';
    _wakeWordTimer?.cancel();
    _backgroundAnimationTimer?.cancel();
    _chatInputController.dispose();
    _chatScrollController.dispose();
    _animationController.dispose();
    _colorAnimationController.dispose();
    _audioPlayer.dispose();
    model?.dispose();
    speech.stop();
    flutterTts.stop();
    super.dispose();
  }

  void startListening() async {
    try {
      final available = await speech.initialize();
      if (!mounted) return;
      if (!available) {
        _addChatMessage('jarvis',
            'Speech recognition is unavailable. Check your microphone permission and speech services.');
        _reportVoiceProblem(
            'Speech recognition is unavailable — check the microphone permission and speech services.');
        speak('Speech recognition is unavailable. Check your microphone permission and speech services.');
        return;
      }
      setState(() => isListening = true);
      await speech.listen(
        onResult: (result) async {
          if (result.finalResult) {
            if (!mounted) return;
            String userInput = result.recognizedWords.toLowerCase();
            _addChatMessage('user', userInput);
            processQuery(userInput);
          }
        },
        listenFor: Duration(minutes: 5),
        pauseFor: Duration(seconds: 15),
        partialResults: true,
        listenMode: stt.ListenMode.deviceDefault,
        cancelOnError: false,
      );
    } catch (_) {
      if (mounted) setState(() => isListening = false);
      _addChatMessage('jarvis',
          'I could not start the microphone. Please check microphone permission.');
      speak('I could not start the microphone. Please check microphone permission.');
    }
  }

  void stopListening() {
    speech.stop();
    if (mounted) setState(() => isListening = false);
  }

  /// Stops Jarvis mid-sentence. Used by the orb tap, the on-screen STOP
  /// button, and the "stop / chup / khamosh" voice command.
  Future<void> _stopSpeaking() async {
    await flutterTts.stop();
    if (mounted) {
      setState(() {
        isSpeaking = false;
        _speakingSince = null;
      });
    }
  }

  /// Short version of an answer for speaking: code is never read aloud,
  /// long answers are cut to the first sentence or two. The full text is
  /// always in the chat for reading.
  String _shortSpoken(String answer) {
    if (answer.contains('```')) {
      return 'Done. The full answer is on your screen.';
    }
    if (answer.length <= 250) return answer;
    final cut = answer.substring(0, 250);
    final ends = <int>[
      cut.lastIndexOf('. '),
      cut.lastIndexOf('! '),
      cut.lastIndexOf('? '),
    ];
    final lastEnd = ends.reduce((a, b) => a > b ? a : b);
    return lastEnd > 60 ? cut.substring(0, lastEnd + 1) : cut;
  }

  Future<void> speak(String text) async {
    if (!mounted || text.trim().isEmpty) return;
    final cleanText = text.replaceAll(RegExp(r'\*'), '');
    await _ttsReady;
    if (!mounted) return;
    if (speech.isListening) speech.stop();
    // A new utterance cuts off whatever is still being spoken, so the user
    // can interrupt a long answer with a new question.
    await flutterTts.stop();
    if (mounted) {
      setState(() {
        isSpeaking = true;
        _speakingSince = DateTime.now();
      });
    }
    try {
      await flutterTts.speak(cleanText);
    } catch (_) {
      if (mounted) {
        setState(() {
          isSpeaking = false;
          _speakingSince = null;
        });
      }
      if (_isInConversationMode) _continueConversation();
    }
  }

  void _stopBackgroundListening() {
    if (_isBackgroundListening) {
      speech.stop();
      if (mounted) setState(() => _isBackgroundListening = false);
    }
  }

  Future<void> _playWakeSound() async {
    // Sounds switch off, or a wake-up within ten seconds of the last one
    // (false triggers in background noise) — never replay the chime.
    if (!_soundsEnabled) return;
    final now = DateTime.now();
    if (_lastWakeSoundAt != null &&
        now.difference(_lastWakeSoundAt!).inSeconds < 10) {
      return;
    }
    _lastWakeSoundAt = now;
    try {
      await _audioPlayer.play(AssetSource('sounds/wake.mp3'));
    } catch (e) {
      debugPrint('Error playing wake sound: $e');
    }
  }

  /// Starts a foreground service ("J.A.R.V.I.S is listening" notification)
  /// so Android keeps the app process alive when it is minimised and the
  /// microphone permission keeps working in the background. Started only
  /// while the app is in the foreground (Android 12+ rule). The user stops
  /// it by swiping the app away from recents.
  Future<void> _initForegroundService() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'jarvis_listening',
        channelName: 'Jarvis listening',
        channelDescription:
            'Jarvis keeps listening for "Hey Jarvis" while the app is in the background.',
        onlyAlertOnce: true,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: false,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(30000),
        autoRunOnBoot: false,
        autoRunOnMyPackageReplaced: false,
        allowWakeLock: true,
        allowWifiLock: false,
      ),
    );
    final notificationPermission =
        await FlutterForegroundTask.checkNotificationPermission();
    if (notificationPermission != NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }
    if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
    }
    if (!await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.startService(
        serviceId: 256,
        notificationTitle: 'J.A.R.V.I.S is listening',
        notificationText: 'Say "Hey Jarvis" any time — tap to open Jarvis.',
        callback: jarvisForegroundCallback,
      );
    }
  }

  static const MethodChannel _appsChannel =
      MethodChannel('com.jarvis.jarvis_app/apps');

  /// Apps the user connected in the Connected Apps screen (package -> label).
  /// Only these can be opened by voice or typing. Stored on this phone only.
  Map<String, String> _connectedApps = {};

  /// Default apps connected on first run (the well-known ones).
  static const List<String> _defaultConnectedPackages = <String>[
    'com.whatsapp',
    'com.google.android.youtube',
    'com.android.chrome',
    'com.google.android.gm',
    'com.google.android.apps.maps',
    'com.android.camera',
    'com.google.android.apps.photos',
    'com.android.settings',
    'com.android.vending',
    'com.android.calculator2',
    'com.google.android.calendar',
    'com.android.deskclock',
    'com.android.contacts',
    'com.android.dialer',
    'com.android.mms',
    'com.instagram.android',
    'com.facebook.katana',
    'org.telegram.messenger',
    'com.zhiliaoapp.musically',
    'com.spotify.music',
    'com.snapchat.android',
  ];

  Future<void> _loadConnectedApps() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final stored = prefs.getStringList('connected_apps');
      final apps =
          await _appsChannel.invokeListMethod<dynamic>('getInstalledApps');
      final installed = <String, String>{};
      for (final entry in apps ?? <dynamic>[]) {
        if (entry is Map) {
          final package = entry['package']?.toString() ?? '';
          final label = entry['label']?.toString() ?? package;
          if (package.isNotEmpty) installed[package] = label;
        }
      }
      final connected = stored ??
          _defaultConnectedPackages.where(installed.containsKey).toList();
      if (stored == null) {
        await prefs.setStringList('connected_apps', connected);
      }
      if (mounted) {
        setState(() {
          _connectedApps = {
            for (final package in connected)
              if (installed.containsKey(package)) package: installed[package]!,
          };
        });
      }
    } catch (e) {
      debugPrint('Could not load connected apps: $e');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _isAppInForeground = true;
      // The home-screen widget may have asked for a conversation.
      _checkWidgetLaunch();
      if (_isInConversationMode && !isSpeaking) {
        _continueConversation();
      } else if (_isBackgroundListening && !isSpeaking) {
        _startWakeWordDetection();
      }
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _isAppInForeground = false;
      // Keep listening in the background when the wake-word toggle is ON
      // (the foreground service keeps the mic allowed). Stop it only when
      // the toggle is OFF.
      if (!_isBackgroundListening) {
        speech.stop();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isIdleState =
        !_isWakeWordDetected && !isSpeaking && !_isInConversationMode;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: CircuitPatternPainter(
                isIdleState: isIdleState,
              ),
              key: ValueKey(
                  _backgroundAnimationCounter),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.7),
                  ],
                  center: Alignment.center,
                  radius: 1.5,
                ),
              ),
            ),
          ),
          Container(
            width: double.infinity,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isTimerActive && _remainingSeconds != null)
                  Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text(
                      'Timer: ${(_remainingSeconds! ~/ 3600).toString().padLeft(2, '0')}:${((_remainingSeconds! % 3600) ~/ 60).toString().padLeft(2, '0')}:${(_remainingSeconds! % 60).toString().padLeft(2, '0')}',
                      style: TextStyle(
                        color: Colors.orange,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        shadows: [
                          Shadow(
                            color: Colors.orange.withValues(alpha: 0.5),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                    ),
                  ),
                if (_isBackgroundListening)
                  Padding(
                    padding: EdgeInsets.only(bottom: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            color: _isInConversationMode
                                ? Colors.purple
                                : Colors.green,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: _isInConversationMode
                                    ? Colors.purple.withValues(alpha: 0.5)
                                    : Colors.green.withValues(alpha: 0.5),
                                blurRadius: 10,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(width: 8),
                        Text(
                          _isInConversationMode
                              ? "CONVERSATION ACTIVE"
                              : "ALWAYS LISTENING",
                          style: TextStyle(
                            color: _isInConversationMode
                                ? Colors.blueAccent
                                : Colors.green,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    _isInConversationMode
                        ? "ACTIVE CONVERSATION MODE"
                        : _isWakeWordDetected
                            ? "LISTENING FOR COMMAND..."
                            : isSpeaking
                                ? "JARVIS IS RESPONDING..."
                                : "SAY 'HEY JARVIS' TO START",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _isInConversationMode
                          ? Colors.blueAccent
                          : _isWakeWordDetected
                              ? Colors.green
                              : isSpeaking
                                  ? Colors.orange
                                  : Colors.cyan,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: _isInConversationMode
                              ? Colors.blueAccent
                              : _isWakeWordDetected
                                  ? Colors.green
                                  : isSpeaking
                                      ? Colors.orange
                                      : Colors.cyan,
                          blurRadius: 10,
                          offset: Offset(0, 0),
                        ),
                      ],
                    ),
                  ),
                ),
                if (isSpeaking)
                  Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: ElevatedButton.icon(
                      onPressed: _stopSpeaking,
                      icon: const Icon(Icons.stop),
                      label: const Text('STOP'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                // Why voice is not working right now (internet, mic, …).
                if (_voiceStatus.isNotEmpty)
                  Padding(
                    padding: EdgeInsets.only(
                        top: 10.0, left: 24.0, right: 24.0),
                    child: Text(
                      _voiceStatus,
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(color: Colors.orange, fontSize: 12),
                    ),
                  ),
                // Manual way to start Active Conversation: no "Hey Jarvis"
                // needed. Works even when the mic toggle is off.
                if (!_isInConversationMode && !isSpeaking)
                  Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: ElevatedButton.icon(
                      onPressed: _startConversationMode,
                      icon: const Icon(Icons.mic),
                      label: const Text('START CONVERSATION'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.cyan,
                        foregroundColor: Colors.black,
                      ),
                    ),
                  ),
                SizedBox(height: 40),
                if (_chatMessages.isNotEmpty)
                  Container(
                    height: 180,
                    margin: EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 8.0),
                    padding: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.45),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: Colors.cyan.withValues(alpha: 0.3)),
                    ),
                    child: ListView.builder(
                      controller: _chatScrollController,
                      itemCount: _chatMessages.length,
                      itemBuilder: (context, index) {
                        final msg = _chatMessages[index];
                        final isUser = msg['role'] == 'user';
                        return Align(
                          alignment: isUser
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Container(
                            margin: EdgeInsets.symmetric(vertical: 3.0),
                            padding: EdgeInsets.symmetric(
                                horizontal: 10.0, vertical: 6.0),
                            decoration: BoxDecoration(
                              color: isUser
                                  ? Colors.cyan.withValues(alpha: 0.25)
                                  : Colors.white.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              msg['text'] ?? '',
                              style: TextStyle(
                                  color: Colors.white, fontSize: 14),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                AnimatedBuilder(
                  animation:
                      Listenable.merge([_bounceAnimation, _colorAnimation]),
                  builder: (context, child) {
                    final currentColor =
                        _colorAnimation.value ?? _ironManColors[0];
                    return Transform.scale(
                      scale: _isWakeWordDetected ||
                              isSpeaking ||
                              _isInConversationMode
                          ? _bounceAnimation.value
                          : 1.0,
                      child: GestureDetector(
                        onTapDown: (_) => setState(() => isListening = true),
                        onTapUp: (_) {
                          if (isSpeaking) {
                            // Tapping the orb while Jarvis talks silences it.
                            _stopSpeaking();
                          } else if (_isInConversationMode) {
                            _endConversationMode();
                            speak(
                                "Ending conversation mode. Just say 'Hey Jarvis' when you need me again.");
                          } else {
                            startListening();
                          }
                        },
                        onTapCancel: () => setState(() => isListening = false),
                        child: Container(
                          width: 180,
                          height: 180,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                currentColor.withValues(alpha: 0.9),
                                currentColor.withValues(alpha: 0.7),
                                currentColor.withValues(alpha: 0.5),
                              ],
                              center: Alignment.center,
                              radius: 0.8,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: currentColor.withValues(alpha: 0.7),
                                blurRadius: 35,
                                spreadRadius: 8,
                              ),
                              BoxShadow(
                                color: currentColor.withValues(alpha: 0.4),
                                blurRadius: 60,
                                spreadRadius: 15,
                              ),
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.8),
                                blurRadius: 15,
                                spreadRadius: -3,
                                offset: Offset(0, 5),
                              ),
                            ],
                            border: Border.all(
                              color: Colors.black,
                              width: 2.5,
                            ),
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Container(
                                width: 168,
                                height: 168,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: currentColor.withValues(alpha: 0.9),
                                    width: 4,
                                  ),
                                ),
                                child: CustomPaint(
                                  painter: ArcReactorSegmentsPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                  ),
                                ),
                              ),
                              Container(
                                width: 144,
                                height: 144,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: currentColor.withValues(alpha: 0.8),
                                    width: 3,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.8),
                                      blurRadius: 2,
                                      spreadRadius: 0.5,
                                    ),
                                  ],
                                ),
                                child: CustomPaint(
                                  painter: CircuitLinesPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                  ),
                                ),
                              ),
                              Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: currentColor.withValues(alpha: 0.7),
                                    width: 2.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.8),
                                      blurRadius: 2,
                                      spreadRadius: 0.5,
                                    ),
                                  ],
                                ),
                                child: CustomPaint(
                                  painter: TrianglePatternPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                  ),
                                ),
                              ),
                              Container(
                                width: 96,
                                height: 96,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: RadialGradient(
                                    colors: [
                                      currentColor.withValues(alpha: 0.9),
                                      currentColor.withValues(alpha: 0.7),
                                    ],
                                    center: Alignment.center,
                                    radius: 0.8,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: currentColor.withValues(alpha: 0.7),
                                      blurRadius: 25,
                                      spreadRadius: 4,
                                    ),
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.8),
                                      blurRadius: 8,
                                      spreadRadius: -2,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                  border: Border.all(
                                    color: Colors.black,
                                    width: 1.5,
                                  ),
                                ),
                                child: CustomPaint(
                                  painter: CorePatternPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                    showPurpleTriangle: true,
                                  ),
                                ),
                              ),
                              if (_isWakeWordDetected ||
                                  isSpeaking ||
                                  _isInConversationMode)
                                Container(
                                  width: 192,
                                  height: 192,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: currentColor.withValues(alpha: 0.5),
                                      width: 3,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
                SizedBox(height: 16),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                                color: Colors.cyan.withValues(alpha: 0.4)),
                          ),
                          child: TextField(
                            controller: _chatInputController,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              hintText: 'Type your message...',
                              hintStyle:
                                  TextStyle(color: Colors.white54),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 16.0, vertical: 10.0),
                            ),
                            textInputAction: TextInputAction.send,
                            onSubmitted: (_) => _sendTypedMessage(),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.cyan, shape: BoxShape.circle),
                        child: IconButton(
                          icon: Icon(Icons.send, color: Colors.black),
                          onPressed: _sendTypedMessage,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: Text(
          'J.A.R.V.I.S',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
            shadows: [
              Shadow(
                color: Colors.blue.withValues(alpha: 0.5),
                blurRadius: 10,
              ),
            ],
          ),
        ),
        backgroundColor: Colors.black.withValues(alpha: 0.3),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.history, color: Colors.cyan, size: 28),
            onPressed: () async {
              final startNew = await Navigator.push<bool>(
                context,
                MaterialPageRoute(
                    builder: (context) => const HistoryScreen()),
              );
              if (startNew == true) _startNewChat();
            },
            tooltip: 'Chat history',
          ),
          IconButton(
            icon: const Icon(Icons.apps, color: Colors.cyan, size: 28),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const ConnectedAppsScreen()),
              );
              _loadConnectedApps();
            },
            tooltip: 'Connected apps',
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.cyan, size: 28),
            onPressed: _showSettingsDialog,
            tooltip: "Settings - Gemini API key",
          ),
          IconButton(
            icon: Icon(
              _isBackgroundListening ? Icons.mic : Icons.mic_off,
              color: _isBackgroundListening
                  ? (_isInConversationMode ? Colors.purple : Colors.green)
                  : Colors.red,
              size: 28,
            ),
            onPressed: () {
              if (_isInConversationMode) {
                _endConversationMode();
                speak("Ending conversation mode.");
              }

              if (_isBackgroundListening) {
                _stopBackgroundListening();
                speak("Wake-word listening disabled.");
              } else {
                setState(() => _isBackgroundListening = true);
                _startWakeWordDetection();
                speak(
                    "Wake-word listening enabled while Jarvis is open. Android may stop listening in the background.");
              }
            },
            tooltip: _isBackgroundListening
                ? "Disable wake-word listening"
                : "Enable wake-word listening",
          ),
        ],
      ),
    );
  }
}

class CorePatternPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;
  final bool showPurpleTriangle;

  CorePatternPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
    this.showPurpleTriangle = false,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5;

    final path = Path();
    final triangleSize = radius * 0.8;
    final height = triangleSize * sqrt(3) / 2;

    path.moveTo(center.dx, center.dy - height / 2);
    path.lineTo(center.dx + triangleSize / 2, center.dy + height / 2);
    path.lineTo(center.dx - triangleSize / 2, center.dy + height / 2);
    path.close();

    canvas.drawPath(path, borderPaint); 
    canvas.drawPath(path, paint);

    final innerPaint = Paint()
      ..color = color.withValues(alpha: 0.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final innerBorderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final innerSize = triangleSize * 0.6;
    final innerHeight = innerSize * sqrt(3) / 2;

    path.reset();
    path.moveTo(center.dx, center.dy - innerHeight / 2);
    path.lineTo(center.dx + innerSize / 2, center.dy + innerHeight / 2);
    path.lineTo(center.dx - innerSize / 2, center.dy + innerHeight / 2);
    path.close();

    canvas.drawPath(path, innerBorderPaint); 
    canvas.drawPath(path, innerPaint); 

    final dotPaint = Paint()
      ..color = color.withValues(alpha: 0.9)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, radius * 0.12, dotPaint);

    if (showPurpleTriangle) {
      final purplePaint = Paint()
        ..color = Colors.purple.withValues(alpha: 0.8)
        ..style = PaintingStyle.fill;

      final purpleBorderPaint = Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;

      final purpleTrianglePath = Path();
      final purpleTriangleSize =
          radius * 0.5; 
      final purpleHeight = purpleTriangleSize * sqrt(3) / 2;

      purpleTrianglePath.moveTo(center.dx, center.dy - purpleHeight / 2);
      purpleTrianglePath.lineTo(
          center.dx + purpleTriangleSize / 2, center.dy + purpleHeight / 2);
      purpleTrianglePath.lineTo(
          center.dx - purpleTriangleSize / 2, center.dy + purpleHeight / 2);
      purpleTrianglePath.close();

      final purpleRect = Rect.fromCircle(center: center, radius: radius * 0.5);
      final purpleGradient = RadialGradient(
        colors: [
          Colors.purple.withValues(alpha: 0.9),
          Colors.deepPurple.withValues(alpha: 0.7),
        ],
        center: Alignment(0.2, -0.3), 
        radius: 0.8,
      );

      final gradientPaint = Paint()
        ..shader = purpleGradient.createShader(purpleRect)
        ..style = PaintingStyle.fill;

      canvas.drawPath(purpleTrianglePath, gradientPaint);
      canvas.drawPath(purpleTrianglePath, purpleBorderPaint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class TrianglePatternPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;

  TrianglePatternPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.7)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (var i = 0; i < 3; i++) {
      final angle = i * (2 * pi / 3);
      final path = Path();

      final triangleSize = radius * 0.8;
      final height = triangleSize * sqrt(3) / 2;

      final topPoint = Offset(
        center.dx + sin(angle) * height / 2,
        center.dy - cos(angle) * height / 2,
      );
      final bottomLeft = Offset(
        center.dx + sin(angle - 2 * pi / 3) * height / 2,
        center.dy - cos(angle - 2 * pi / 3) * height / 2,
      );
      final bottomRight = Offset(
        center.dx + sin(angle + 2 * pi / 3) * height / 2,
        center.dy - cos(angle + 2 * pi / 3) * height / 2,
      );

      path.moveTo(topPoint.dx, topPoint.dy);
      path.lineTo(bottomLeft.dx, bottomLeft.dy);
      path.lineTo(bottomRight.dx, bottomRight.dy);
      path.close();

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class CircuitLinesPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;

  CircuitLinesPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (var i = 0; i < 12; i++) {
      final angle = i * (2 * pi / 12);
      final path = Path();

      final startRadius = radius * 0.7;
      final endRadius = radius * 0.9;

      final startX = center.dx + cos(angle) * startRadius;
      final startY = center.dy + sin(angle) * startRadius;
      final endX = center.dx + cos(angle) * endRadius;
      final endY = center.dy + sin(angle) * endRadius;

      path.moveTo(startX, startY);
      path.lineTo(endX, endY);

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }

    for (var i = 0; i < 6; i++) {
      final angle = i * (2 * pi / 6);
      final path = Path();

      final radius1 = radius * 0.75;
      final radius2 = radius * 0.85;

      final x1 = center.dx + cos(angle) * radius1;
      final y1 = center.dy + sin(angle) * radius1;
      final x2 = center.dx + cos(angle + pi / 3) * radius2;
      final y2 = center.dy + sin(angle + pi / 3) * radius2;

      path.moveTo(x1, y1);
      path.lineTo(x2, y2);

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class ArcReactorSegmentsPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;

  ArcReactorSegmentsPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5;

    for (var i = 0; i < 8; i++) {
      final angle = i * (2 * pi / 8);
      final path = Path();

      final startRadius = radius * 0.9;
      final endRadius = radius;

      final startX = center.dx + cos(angle) * startRadius;
      final startY = center.dy + sin(angle) * startRadius;
      final endX = center.dx + cos(angle) * endRadius;
      final endY = center.dy + sin(angle) * endRadius;

      path.moveTo(startX, startY);
      path.lineTo(endX, endY);

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }

    final innerPaint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final innerBorderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (var i = 0; i < 16; i++) {
      final angle = i * (2 * pi / 16);
      final path = Path();

      final startRadius = radius * 0.85;
      final endRadius = radius * 0.95;

      final startX = center.dx + cos(angle) * startRadius;
      final startY = center.dy + sin(angle) * startRadius;
      final endX = center.dx + cos(angle) * endRadius;
      final endY = center.dy + sin(angle) * endRadius;

      path.moveTo(startX, startY);
      path.lineTo(endX, endY);

      canvas.drawPath(path, innerBorderPaint);
      canvas.drawPath(path, innerPaint);
    }

    final gradientPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.white.withValues(alpha: 0.1),
          Colors.transparent,
        ],
        center: Alignment(-0.2, -0.2), 
        radius: 0.8,
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, radius * 0.95, gradientPaint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

/// Connected Apps screen: lists every app installed on the phone and lets
/// the user switch each one on (Jarvis may open it) or off. The list is
/// stored only on this phone (SharedPreferences) and is never sent anywhere.
class ConnectedAppsScreen extends StatefulWidget {
  const ConnectedAppsScreen({super.key});

  @override
  State<ConnectedAppsScreen> createState() => _ConnectedAppsScreenState();
}

class _ConnectedAppsScreenState extends State<ConnectedAppsScreen> {
  static const MethodChannel _appsChannel =
      MethodChannel('com.jarvis.jarvis_app/apps');

  List<Map<String, String>> _allApps = [];
  Set<String> _connected = {};
  String _filter = '';
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final apps =
          await _appsChannel.invokeListMethod<dynamic>('getInstalledApps');
      final parsed = <Map<String, String>>[];
      for (final entry in apps ?? <dynamic>[]) {
        if (entry is Map) {
          final package = entry['package']?.toString() ?? '';
          final label = entry['label']?.toString() ?? package;
          if (package.isNotEmpty) {
            parsed.add({'label': label, 'package': package});
          }
        }
      }
      if (mounted) {
        setState(() {
          _allApps = parsed;
          _connected = prefs.getStringList('connected_apps')?.toSet() ?? {};
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Could not list apps: $e';
          _loading = false;
        });
      }
    }
  }

  Future<void> _toggle(String package, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (value) {
        _connected.add(package);
      } else {
        _connected.remove(package);
      }
    });
    await prefs.setStringList('connected_apps', _connected.toList());
  }

  @override
  Widget build(BuildContext context) {
    final visible = _filter.isEmpty
        ? _allApps
        : _allApps
            .where((a) =>
                a['label']!.toLowerCase().contains(_filter) ||
                a['package']!.toLowerCase().contains(_filter))
            .toList();
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Connected Apps'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.cyan,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.cyan))
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Text(_error!,
                        style: const TextStyle(color: Colors.white)),
                  ),
                )
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: TextField(
                        style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(
                          hintText: 'Search apps...',
                          hintStyle: TextStyle(color: Colors.grey),
                          prefixIcon: Icon(Icons.search, color: Colors.cyan),
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (v) =>
                            setState(() => _filter = v.trim().toLowerCase()),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Text(
                        '${_connected.length} of ${_allApps.length} apps connected. Only connected apps can be opened by Jarvis. This list stays on your phone.',
                        style: const TextStyle(
                            color: Colors.grey, fontSize: 13),
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: visible.length,
                        itemBuilder: (context, index) {
                          final app = visible[index];
                          final package = app['package']!;
                          final on = _connected.contains(package);
                          return SwitchListTile(
                            title: Text(app['label']!,
                                style:
                                    const TextStyle(color: Colors.white)),
                            subtitle: Text(package,
                                style: const TextStyle(
                                    color: Colors.grey, fontSize: 12)),
                            value: on,
                            activeColor: Colors.cyan,
                            onChanged: (v) => _toggle(package, v),
                          );
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}

/// Chat history: past conversations saved on this phone only. Open one to
/// read it again, delete one, or clear them all. Nothing leaves the phone.
class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Map<String, dynamic>> _sessions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final sessions = await loadChatHistory();
    if (mounted) {
      setState(() {
        _sessions = sessions;
        _loading = false;
      });
    }
  }

  Future<void> _delete(int id) async {
    await deleteChatHistorySession(id);
    _reload();
  }

  Future<void> _clearAll() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('Clear all history?',
            style: TextStyle(color: Colors.white)),
        content: const Text(
            'Every saved chat will be deleted from this phone.',
            style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel',
                style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Clear all',
                style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await clearChatHistory();
      _reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Chat History'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.cyan,
        actions: [
          IconButton(
            icon: const Icon(Icons.add_comment, color: Colors.cyan),
            tooltip: 'Start a new chat',
            onPressed: () => Navigator.of(context).pop(true),
          ),
          IconButton(
            icon: const Icon(Icons.delete_sweep, color: Colors.redAccent),
            tooltip: 'Clear all history',
            onPressed: _sessions.isEmpty ? null : _clearAll,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.cyan))
          : _sessions.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24.0),
                    child: Text(
                      'No saved chats yet. Your conversations will appear here.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: _sessions.length,
                  itemBuilder: (context, index) {
                    final session = _sessions[index];
                    final id = session['id'] as int? ?? 0;
                    final title = session['title']?.toString() ?? 'Chat';
                    final startedAt = DateTime.tryParse(
                        session['startedAt']?.toString() ?? '');
                    final messages =
                        (session['messages'] as List<dynamic>?) ?? [];
                    return ListTile(
                      title: Text(title,
                          style: const TextStyle(color: Colors.white)),
                      subtitle: Text(
                        '${messages.length} messages'
                        '${startedAt != null ? ' · ${DateFormat.yMMMd().add_jm().format(startedAt)}' : ''}',
                        style: const TextStyle(color: Colors.grey),
                      ),
                      trailing: IconButton(
                        icon:
                            const Icon(Icons.delete, color: Colors.redAccent),
                        tooltip: 'Delete this chat',
                        onPressed: () => _delete(id),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                HistoryChatView(session: session),
                          ),
                        );
                      },
                    );
                  },
                ),
    );
  }
}

/// Read-only view of one saved conversation.
class HistoryChatView extends StatelessWidget {
  const HistoryChatView({super.key, required this.session});

  final Map<String, dynamic> session;

  @override
  Widget build(BuildContext context) {
    final messages = (session['messages'] as List<dynamic>?) ?? [];
    final title = session['title']?.toString() ?? 'Chat';
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(title, overflow: TextOverflow.ellipsis),
        backgroundColor: Colors.black,
        foregroundColor: Colors.cyan,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12.0),
        itemCount: messages.length,
        itemBuilder: (context, index) {
          final msg = messages[index];
          if (msg is! Map) return const SizedBox.shrink();
          final isUser = msg['role'] == 'user';
          return Align(
            alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 3.0),
              padding: const EdgeInsets.symmetric(
                  horizontal: 10.0, vertical: 6.0),
              decoration: BoxDecoration(
                color: isUser
                    ? Colors.cyan.withValues(alpha: 0.25)
                    : Colors.white.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                msg['text']?.toString() ?? '',
                style: const TextStyle(color: Colors.white, fontSize: 14),
              ),
            ),
          );
        },
      ),
    );
  }
}
