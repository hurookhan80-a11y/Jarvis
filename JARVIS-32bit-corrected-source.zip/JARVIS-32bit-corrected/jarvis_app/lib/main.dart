import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart' hide PermissionStatus;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:url_launcher/url_launcher.dart';

import 'accessibility_service.dart';
import 'agent_loop.dart';
import 'air_gesture_service.dart';
import 'assistant_role_service.dart';
import 'calendar_service.dart';
import 'command_parser.dart';
import 'confirmation_gate.dart';
import 'chat_provider.dart';
import 'commute_service.dart';
import 'connector_hub.dart';
import 'edge_tts_service.dart';
import 'finance_service.dart';
import 'form_draft_service.dart';
import 'gemini_client.dart';
import 'gmail_service.dart';
import 'knowledge_service.dart';
import 'local_router.dart';
import 'macro_service.dart';
import 'memory_service.dart';
import 'message_draft_service.dart';
import 'multi_task_service.dart';
import 'network_audit.dart';
import 'nvidia_nim_client.dart';
import 'onboarding.dart';
import 'overlay_service.dart';
import 'phase6_screens.dart';
import 'phase7_screens.dart';
import 'phase7b_screens.dart';
import 'phase8_screens.dart';
import 'reminder_service.dart';
import 'session_recorder.dart';
import 'shizuku_service.dart';
import 'telemetry_service.dart';
import 'wake_word_service.dart';

const MethodChannel _secureStorageChannel = MethodChannel('com.jarvis.jarvis_app/secure_storage');

/// Exact phrases that silence Jarvis immediately ("stop" / "chup" /
/// "khamosh" ...). Exact phrases only, so questions like "how do I stop a
/// nosebleed" still get answered instead of silencing the app.
const Set<String> kJarvisStopWords = <String>{
  'stop',
  'stop jarvis',
  'jarvis stop',
  'please stop',
  'stop please',
  'stop speaking',
  'stop talking',
  'chup',
  'chup ho jao',
  'chup kar',
  'khamosh',
  'khamosh ho jao',
  'bas',
  'bas karo',
  'ruk jao',
  'ruk',
  'band karo',
  'quiet',
  'shut up',
};


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterForegroundTask.initCommunicationPort();
  // F7 (v1.1.0): durable reminders — Workmanager backstop + local
  // notifications, so reminders fire after the app is swiped away or the
  // phone restarts. Never throws; if it cannot start, the in-app Timer
  // path in this file keeps working on its own.
  await ReminderService.init();
  runApp(const JarvisApp());
}

/// Phase 7 (v1.1.0) — F23 floating bubble entry point. The overlay
/// plugin runs this in its own engine when the bubble is shown; it
/// draws only the bubble (JarvisBubbleWidget in lib/overlay_service.dart).
/// Tapping the bubble sends 'bubble_tap' to the main isolate, which
/// opens the app and starts a conversation.
@pragma('vm:entry-point')
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: JarvisBubbleWidget(),
    ),
  );
}

/// Background-service callback: keeps the app process alive so wake-word
/// listening can continue while Jarvis is minimised. The service itself does
/// nothing but stay alive; the main isolate's 30-second timer re-arms
/// listening. Stops when the app is swiped away from recents
/// (stopWithTask in the manifest).
@pragma('vm:entry-point')
void jarvisForegroundCallback() {
  FlutterForegroundTask.setTaskHandler(JarvisForegroundTaskHandler());
}

class JarvisForegroundTaskHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {}

  @override
  void onRepeatEvent(DateTime timestamp) {}

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {}

  @override
  void onNotificationPressed() {
    FlutterForegroundTask.launchApp();
  }
}

/// Chat history storage (on this phone only — nothing leaves the phone).
/// Sessions are stored newest-last in SharedPreferences as JSON.
Future<List<Map<String, dynamic>>> loadChatHistory() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('jarvis_chat_history_v1');
    if (raw == null) return [];
    final list = jsonDecode(raw) as List<dynamic>;
    final sessions = list
        .whereType<Map>()
        .map((s) => Map<String, dynamic>.from(s))
        .toList();
    sessions.sort((a, b) => (b['startedAt'] as String? ?? '')
        .compareTo(a['startedAt'] as String? ?? ''));
    return sessions;
  } catch (_) {
    return [];
  }
}

Future<void> deleteChatHistorySession(int id) async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('jarvis_chat_history_v1');
    if (raw == null) return;
    final list = (jsonDecode(raw) as List<dynamic>).whereType<Map>().toList();
    list.removeWhere((s) => s['id'] == id);
    await prefs.setString('jarvis_chat_history_v1', jsonEncode(list));
  } catch (_) {}
}

Future<void> clearChatHistory() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('jarvis_chat_history_v1');
  } catch (_) {}
}

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const OnboardingGate(),
    );
  }
}

/// Phase 7 (v1.1.0) — F25: first run shows the onboarding walkthrough
/// once; afterwards the splash screen runs as before. Skipping the
/// walkthrough's permissions never blocks the app.
class OnboardingGate extends StatefulWidget {
  const OnboardingGate({super.key});

  @override
  State<OnboardingGate> createState() => _OnboardingGateState();
}

class _OnboardingGateState extends State<OnboardingGate> {
  bool? _onboardingDone;

  @override
  void initState() {
    super.initState();
    const OnboardingService().isDone().then((done) {
      if (mounted) setState(() => _onboardingDone = done);
    });
  }

  @override
  Widget build(BuildContext context) {
    final done = _onboardingDone;
    if (done == null) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: CircularProgressIndicator(color: Colors.cyan),
        ),
      );
    }
    if (!done) {
      return OnboardingScreen(
        onFinished: () {
          if (mounted) setState(() => _onboardingDone = true);
        },
      );
    }
    return SplashScreen();
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  final AudioPlayer _audioPlayer = AudioPlayer();
  Timer? _navigationTimer;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
    );
    _fadeAnimation =
        Tween<double>(begin: 0.0, end: 1.0).animate(_fadeController);
    _fadeController.forward();

    _playStartupSound();

    _navigationTimer = Timer(const Duration(seconds: 5), () {
      if (!mounted) return;
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => JarvisScreen()));
    });
  }

  Future<void> _playStartupSound() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('sounds_enabled') == false) return;
      await _audioPlayer.play(AssetSource('sounds/startup.mp3'));
    } catch (e) {
      debugPrint('Error playing startup sound: $e');
    }
  }

  @override
  void dispose() {
    _navigationTimer?.cancel();
    _fadeController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: CircuitPatternPainter(),
            ),
          ),
          Center(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    colors: [
                      Colors.blue.withValues(alpha: 0.3),
                      Colors.transparent,
                    ],
                    radius: 1.2,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'J.A.R.V.I.S',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 52,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 4,
                        shadows: [
                          Shadow(
                            color: Colors.blue.withValues(alpha: 0.9),
                            blurRadius: 20,
                            offset: Offset(0, 0),
                          ),
                          Shadow(
                            color: Colors.white.withValues(alpha: 0.5),
                            blurRadius: 30,
                            offset: Offset(0, 0),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 25),
                    Container(
                      width: 180,
                      height: 180,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            Colors.blue.withValues(alpha: 0.4),
                            Colors.blue.withValues(alpha: 0.2),
                            Colors.transparent,
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.blue.withValues(alpha: 0.4),
                            blurRadius: 30,
                            spreadRadius: 8,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Icon(
                          Icons.power_settings_new,
                          size: 70,
                          color: Colors.blue.withValues(alpha: 0.9),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CircuitPatternPainter extends CustomPainter {
  final bool isIdleState;

  CircuitPatternPainter({this.isIdleState = true});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue.withValues(alpha: 0.2)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final random = Random();
    final numberOfLines = 120;
    final numberOfNodes = 25;

    final seedRandom = isIdleState ? Random(DateTime.now().millisecondsSinceEpoch ~/ (isIdleState ? 10000 : 1000)) : random;

    final nodes = List.generate(numberOfNodes, (index) {
      return Offset(
        seedRandom.nextDouble() * size.width,
        seedRandom.nextDouble() * size.height,
      );
    });

    for (var i = 0; i < nodes.length; i++) {
      for (var j = i + 1; j < nodes.length; j++) {
        if (seedRandom.nextDouble() < 0.35) {
          final path = Path();
          path.moveTo(nodes[i].dx, nodes[i].dy);
          path.lineTo(nodes[j].dx, nodes[j].dy);
          canvas.drawPath(path, paint);
        }
      }
    }

    for (var i = 0; i < numberOfLines; i++) {
      final startX = seedRandom.nextDouble() * size.width;
      final startY = seedRandom.nextDouble() * size.height;
      final path = Path();
      path.moveTo(startX, startY);

      var currentX = startX;
      var currentY = startY;
      var segments = seedRandom.nextInt(5) + 3; 

      for (var j = 0; j < segments; j++) {
        if (seedRandom.nextBool()) {
          currentX +=
              seedRandom.nextDouble() * 150 - 75; 
        } else {
          currentY += seedRandom.nextDouble() * 150 - 75;
        }
        path.lineTo(currentX, currentY);
      }

      if (seedRandom.nextDouble() < 0.3) {
        final controlPoint = Offset(
          (startX + currentX) / 2 + seedRandom.nextDouble() * 50 - 25,
          (startY + currentY) / 2 + seedRandom.nextDouble() * 50 - 25,
        );
        path.quadraticBezierTo(
          controlPoint.dx,
          controlPoint.dy,
          currentX,
          currentY,
        );
      }

      canvas.drawPath(path, paint);
    }

    final dotPaint = Paint()
      ..color = Colors.blue.withValues(alpha: 0.5)
      ..style = PaintingStyle.fill;

    for (var node in nodes) {
      canvas.drawCircle(node, 3, dotPaint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) =>
      true; 
}

class JarvisScreen extends StatefulWidget {
  @override
  _JarvisScreenState createState() => _JarvisScreenState();
}

class _JarvisScreenState extends State<JarvisScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  // Gemini API key / model are entered by the user in Settings (gear icon)
  // The API key is stored through a native Android Keystore-backed channel.
  String _apiKey = '';
  String _modelName = 'gemini-3.8-flash';
  String _pendingCommand = '';
  bool _isProcessingQuery = false;
  bool _isAppInForeground = true;
  DateTime? _timerEndsAt;
  // Phase 6 (v1.1.0): processQuery talks to this interface, never to a
  // concrete client (F18). It is the Gemini provider wrapped in the
  // NIM fallback router when a free NVIDIA key is set up (F20).
  ChatProvider? model;
  late stt.SpeechToText speech;
  late FlutterTts flutterTts;
  late Future<void> _ttsReady;
  bool isListening = false;
  bool isSpeaking = false;
  DateTime? _speakingSince;
  // Generation counter for speech (v1.1.0 STOP fix): _stopSpeaking() bumps
  // it, and speak() checks it after every await, so a STOP can never be
  // followed by a late answer starting to speak.
  int _speakGeneration = 0;
  String responseText = "";
  // On-screen chat transcript: what the user said/typed + what Jarvis replied.
  final List<Map<String, String>> _chatMessages = [];
  final TextEditingController _chatInputController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();

  // v1.0.8 — sounds, voice diagnosis, history, reminders, calling.
  bool _soundsEnabled = true;
  DateTime? _lastWakeSoundAt;
  String _voiceStatus = '';
  String _lastVoiceProblem = '';
  DateTime? _lastVoiceProblemAt;
  DateTime? _lastVoiceProblemSpokenAt;
  int _listenRestartStreak = 0;
  DateTime? _lastListenRestartAt;
  String _ttsLanguage = 'en-GB';
  String? _ttsVoiceName;
  String? _ttsVoiceLocale;
  // Phase 4 (v1.1.0): Edge TTS + streaming + session recording.
  final EdgeTtsService _edgeTts = EdgeTtsService();
  bool _edgeTtsEnabled = true;
  bool _streamingEnabled = true;
  // While a streamed reply is arriving, the TTS completion handler must
  // not re-arm listening between sentences — more speech is coming.
  bool _isStreamingReply = false;
  final SessionRecorder _sessionRecorder = SessionRecorder();
  bool _recordSessionsEnabled = false;
  bool _isSessionRecording = false;
  // Phase 5 (v1.1.0): offline "Hey Jarvis" wake word (F14) + barge-in /
  // follow-up listening (F16). The offline engine owns the mic while the
  // app is idle or Jarvis is speaking; the system recogniser owns it
  // while a conversation is being listened to. Never both at once.
  final WakeWordService _wakeWordService = WakeWordService();
  StreamSubscription<void>? _wakeWordSubscription;
  final WakeWordStateMachine _wakeWordMachine = WakeWordStateMachine();
  bool _offlineWakeWordEnabled = true;
  bool _offlineWakeWordReady = false;
  bool _bargeInEnabled = true;
  Timer? _followUpTimer;
  bool _isInFollowUpWindow = false;
  // Set when the user has spoken (or typed) a command in this
  // conversation; only then does an answer finishing open the ~8 s
  // follow-up window — the opening greeting must not start it.
  bool _hasAnsweredCommand = false;
  // Ack tones (F12) get their own player so they never cut the
  // wake-up/startup chimes playing on _audioPlayer.
  final AudioPlayer _ackPlayer = AudioPlayer();
  // Chat history (on this phone only): one session per app launch.
  int _currentSessionId = 0;
  String _currentSessionTitle = '';
  DateTime? _currentSessionStartedAt;
  // Reminders (fire while Jarvis is running in the background).
  List<Map<String, dynamic>> _reminders = [];
  final Map<int, Timer> _reminderTimers = {};
  // Phase 6 (v1.1.0): long-term memory (F17), the connector hub (F19:
  // the free NVIDIA NIM fallback key + switch), and knowledge files
  // (F22). The provider chain is rebuilt from these whenever they
  // change, so a new fact or key takes effect without restarting.
  final MemoryService _memoryService = const MemoryService();
  List<SavedFact> _savedFacts = [];
  final ConnectorHubService _connectorHub = const ConnectorHubService();
  String _nvidiaApiKey = '';
  bool _nimEnabled = false;
  final KnowledgeService _knowledgeService = const KnowledgeService();
  List<KnowledgeFile> _knowledgeFiles = [];
  // Phase 7 (v1.1.0): everyday tools (F23–F31). All services are
  // on-device; Gmail triage (F28) stays disabled until the user pastes
  // an access token (see lib/gmail_service.dart).
  final OverlayService _overlayService = const OverlayService();
  final AssistantRoleService _assistantRoleService =
      const AssistantRoleService();
  final CalendarService _calendarService = const CalendarService();
  final FinanceService _financeService = const FinanceService();
  final GmailService _gmailService = GmailService();
  final NetworkAuditService _networkService = const NetworkAuditService();
  final TelemetryService _telemetryService = const TelemetryService();
  // Phase 7 toggles (defaults: bubble OFF, SMS parsing OFF).
  bool _floatingBubbleEnabled = false;
  bool _smsParsingEnabled = false;
  StreamSubscription<dynamic>? _overlayTapSubscription;
  // Voice calling: candidates when several contacts share a name.
  List<Map<String, String>> _pendingCallCandidates = [];
  // Phase 7b (v1.1.0): everyday tools (F32–F39). All services are
  // on-device; the F32/F39 toggles default OFF.
  final AirGestureService _airGestureService = AirGestureService();
  final MacroService _macroService = const MacroService();
  final MessageDraftService _messageDraftService =
      const MessageDraftService();
  final FormDraftService _formDraftService = const FormDraftService();
  final CommuteService _commuteService = CommuteService();
  final ShizukuService _shizukuService = ShizukuService();
  bool _airGestureEnabled = false;
  bool _shizukuEnabled = false;
  // F33 macro recording: the name ('' when the user did not give one
  // yet) and the commands captured so far, in order.
  bool _macroRecording = false;
  String _macroRecordName = '';
  final List<String> _macroRecordSteps = [];
  // F34 message drafting: the request being built + candidates when
  // several contacts match the name.
  MessageDraftRequest? _pendingDraftRequest;
  List<DraftContact> _pendingDraftCandidates = [];
  DraftContact? _pendingDraftContact;
  // F35 form drafting: the template being filled, the answers so far,
  // and which field Jarvis is asking about.
  FormTemplate? _formTemplate;
  final Map<String, String> _formAnswers = {};
  int _formFieldIndex = 0;
  // F37 commute: the destination waiting for a starting place, when
  // the phone's location could not be read.
  ({String destination, CommuteMode mode})? _pendingCommute;
  // Phase 8 (v1.1.0) — F40 agent loop, F41 Accessibility service,
  // F42 confirmation gate.
  // F40: the per-step log of the last agent-loop run, shown on
  // screen while the loop runs (one chat line per step too) and in
  // the ⋮ menu → Agent loop log afterwards.
  final List<AgentStepLogEntry> _agentLoopLog = [];
  bool _agentLoopRunning = false;
  // F41: the Accessibility service (toggle default OFF) + its
  // on-screen action log. The service never acts unless this toggle
  // is on AND Android has Jarvis enabled in Accessibility settings.
  final AccessibilityService _accessibilityService = AccessibilityService();
  bool _accessibilityEnabled = false;
  // F42: one confirmation can be live at a time. The gate owns the
  // state machine (pending → confirmed → executed / timed-out /
  // cancelled); [_pendingConfirmationAction] is the action that runs
  // only after the user says yes, and [_confirmationTimer] is the
  // ~15 s window after which it is cancelled.
  final ConfirmationGate _confirmationGate = ConfirmationGate();
  Timer? _confirmationTimer;
  Future<void> Function()? _pendingConfirmationAction;

  void _addChatMessage(String role, String text) {
    if (!mounted || text.trim().isEmpty) return;
    // F13: a running debug session records the transcript line too.
    _sessionRecorder.addTranscript(role, text);
    setState(() {
      _chatMessages.add({'role': role, 'text': text});
      if (_chatMessages.length > 50) _chatMessages.removeAt(0);
    });
    _appendToHistorySession(role, text);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_chatScrollController.hasClients) {
        _chatScrollController.animateTo(
          _chatScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendTypedMessage() {
    final text = _chatInputController.text.trim();
    if (text.isEmpty) return;
    // A typed "stop" must work even while an answer is loading.
    if (_isProcessingQuery &&
        !kJarvisStopWords.contains(text.toLowerCase())) {
      _addChatMessage(
          'jarvis', 'Still working on your last question — one moment.');
      return;
    }
    _chatInputController.clear();
    _addChatMessage('user', text);
    processQuery(text);
  }
  final List<GeminiChatMessage> conversationHistory = [];
  late AnimationController _animationController;
  late Animation<double> _bounceAnimation;
  Timer? _timer;
  int? _remainingSeconds;
  bool _isTimerActive = false;
  bool _isWakeWordDetected = false;
  Timer? _wakeWordTimer;
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isBackgroundListening = false;
  bool _isInConversationMode =
      false; 

  late AnimationController _colorAnimationController;
  late Animation<Color?> _colorAnimation;
  int _currentColorIndex = 0;
  final List<Color> _ironManColors = [
    Colors.red,
    Colors.blue,
    Color(0xFF00B8D4), // greenish blue (cyan)
    Color(0xFFE91E63), // reddish blue (pink)
    Color(0xFFFFA000), // amber (gold)
  ];

  Timer? _backgroundAnimationTimer;
  int _backgroundAnimationCounter = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadSettings();
    _initForegroundService();
    _loadConnectedApps();
    _startNewHistorySession();
    _loadReminders();
    // F7 (v1.1.0): Android 13+ needs the notification permission granted
    // before a reminder fired while the app is dead can be seen. The
    // system only prompts the first time.
    ReminderService.requestNotificationPermission();
    // Phase 7 (F23): listen for bubble taps while the app is alive;
    // a tap opens the app and starts a conversation.
    _initOverlayBubble();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkWidgetLaunch();
    });
    speech = stt.SpeechToText();
    flutterTts = FlutterTts();

    _ttsReady = _configureTextToSpeech();

    flutterTts.setCompletionHandler(() {
      _finishSpeaking();
    });

    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 500),
    )..repeat(reverse: true);
    _bounceAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _colorAnimationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 2000),
    );

    _setupColorAnimation();

    _colorAnimationController.forward();
    _colorAnimationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _currentColorIndex = (_currentColorIndex + 1) % _ironManColors.length;
        _setupColorAnimation();
        _colorAnimationController.reset();
        _colorAnimationController.forward();
      }
    });

    _startWakeWordDetection();

    // F14: load the offline "Hey Jarvis" models in the background; when
    // they are ready the offline engine takes over wake-word listening
    // from the system recogniser (see _initOfflineWakeWord).
    _initOfflineWakeWord();

    _wakeWordTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (_isBackgroundListening &&
          !speech.isListening &&
          !_isWakeWordDetected &&
          !isSpeaking &&
          !_isInConversationMode) {
        _startWakeWordDetection();
      }
      // If conversation listening died after a reply, re-arm it so the
      // app does not go silent after the first exchange.
      if (_isInConversationMode &&
          !speech.isListening &&
          !isSpeaking &&
          !_isProcessingQuery) {
        _continueConversation();
      }
      // Safety net: if TTS never reported completion, speaking gets stuck
      // and listening never restarts. Stop it through the same path as the
      // STOP button so a late answer cannot start speaking afterwards.
      if (isSpeaking &&
          _speakingSince != null &&
          DateTime.now().difference(_speakingSince!).inSeconds > 60) {
        _stopSpeaking();
      }
    });

    _startBackgroundAnimationTimer();
  }

  Future<void> _configureTextToSpeech() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _ttsLanguage = prefs.getString('tts_language') ?? 'en-GB';
      _ttsVoiceName = prefs.getString('tts_voice_name');
      _ttsVoiceLocale = prefs.getString('tts_voice_locale');
      // A saved voice (name + locale) wins; otherwise use the saved
      // language. Default is en-GB — the old en-AU default sounded wrong.
      if (_ttsVoiceName != null && _ttsVoiceLocale != null) {
        await flutterTts.setVoice(
            {'name': _ttsVoiceName!, 'locale': _ttsVoiceLocale!});
      } else {
        await flutterTts.setLanguage(_ttsLanguage);
      }
      await flutterTts.setPitch(0.8);
      await flutterTts.setSpeechRate(0.6);
      await flutterTts.awaitSpeakCompletion(true);
    } catch (_) {
      // Keep the device's default TTS configuration if a setting is unsupported.
    }
  }

  /// Saves the voice the user picked in Settings and applies it at once.
  Future<void> _saveVoiceSettings({
    required String language,
    String? voiceName,
    String? voiceLocale,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tts_language', language);
    if (voiceName != null && voiceLocale != null) {
      await prefs.setString('tts_voice_name', voiceName);
      await prefs.setString('tts_voice_locale', voiceLocale);
    } else {
      await prefs.remove('tts_voice_name');
      await prefs.remove('tts_voice_locale');
    }
    if (mounted) {
      setState(() {
        _ttsLanguage = language;
        _ttsVoiceName = voiceName;
        _ttsVoiceLocale = voiceLocale;
      });
    }
    await _configureTextToSpeech();
  }

  Future<void> _saveSoundsSetting(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sounds_enabled', enabled);
    if (mounted) setState(() => _soundsEnabled = enabled);
  }

  /// Saves the Phase 4 toggles (F10 Edge TTS, F11 streaming, F13 debug
  /// recording). Turning recording off stops a running session at once.
  Future<void> _savePhase4Settings({
    required bool edgeTts,
    required bool streaming,
    required bool recordSessions,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('edge_tts_enabled', edgeTts);
    await prefs.setBool('streaming_enabled', streaming);
    await prefs.setBool('record_sessions', recordSessions);
    final wasRecording = _isSessionRecording;
    if (mounted) {
      setState(() {
        _edgeTtsEnabled = edgeTts;
        _streamingEnabled = streaming;
        _recordSessionsEnabled = recordSessions;
      });
    } else {
      _edgeTtsEnabled = edgeTts;
      _streamingEnabled = streaming;
      _recordSessionsEnabled = recordSessions;
    }
    if (!recordSessions && wasRecording) await _stopSessionRecording();
  }

  /// Saves the Phase 5 toggles (F14 offline wake word, F16 barge-in)
  /// and applies them at once. Turning the offline engine off stops it
  /// and falls back to the system recogniser for the wake word; turning
  /// it on (re)loads the models and takes over wake-word listening.
  /// Turning barge-in off stops any barge-in listening in progress.
  Future<void> _savePhase5Settings({
    required bool offlineWakeWord,
    required bool bargeIn,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('offline_wake_word_enabled', offlineWakeWord);
    await prefs.setBool('barge_in_enabled', bargeIn);
    final wasOffline = _offlineWakeWordEnabled;
    if (mounted) {
      setState(() {
        _offlineWakeWordEnabled = offlineWakeWord;
        _bargeInEnabled = bargeIn;
      });
    } else {
      _offlineWakeWordEnabled = offlineWakeWord;
      _bargeInEnabled = bargeIn;
    }
    _wakeWordMachine.bargeInEnabled = bargeIn;
    if (!bargeIn) await _stopBargeInListening();
    if (!offlineWakeWord && wasOffline) {
      await _stopOfflineWakeWord();
      if (_isBackgroundListening &&
          !_isInConversationMode &&
          !isSpeaking) {
        _startWakeWordDetection();
      }
    } else if (offlineWakeWord && !wasOffline) {
      _initOfflineWakeWord();
    }
  }

  /// Saves the Phase 7 toggles (F23 floating bubble, F29 SMS expense
  /// parsing) and applies them at once. The bubble only appears when
  /// the overlay permission is granted; otherwise the toggle stays on
  /// and the bubble appears once the permission is granted.
  Future<void> _savePhase7Settings({
    required bool floatingBubble,
    required bool smsParsing,
  }) async {
    await _overlayService.setBubbleEnabled(floatingBubble);
    await _financeService.setSmsParsingEnabled(smsParsing);
    if (mounted) {
      setState(() {
        _floatingBubbleEnabled = floatingBubble;
        _smsParsingEnabled = smsParsing;
      });
    } else {
      _floatingBubbleEnabled = floatingBubble;
      _smsParsingEnabled = smsParsing;
    }
    await _applyBubbleSetting();
  }

  /// Shows the bubble when it is switched on and the overlay
  /// permission is granted; hides it otherwise.
  Future<void> _applyBubbleSetting() async {
    if (_floatingBubbleEnabled) {
      await _overlayService.showBubble();
    } else {
      await _overlayService.hideBubble();
    }
  }

  /// Phase 7b (F32): starts the proximity listener when the air
  /// gesture is switched on (and the phone has a proximity sensor);
  /// stops it otherwise. A wave while Jarvis is speaking stops it;
  /// a wave while idle starts a conversation (see _onAirGestureWave).
  Future<void> _applyAirGestureSetting() async {
    if (_airGestureEnabled) {
      await _airGestureService.startListening(_onAirGestureWave);
    } else {
      await _airGestureService.stopListening();
    }
  }

  /// Saves the Phase 7b toggles (F32 air gesture, F39 Shizuku
  /// controls) and applies them at once.
  Future<void> _savePhase7bSettings({
    required bool airGesture,
    required bool shizuku,
  }) async {
    await _airGestureService.setEnabled(airGesture);
    await _shizukuService.setEnabled(shizuku);
    if (mounted) {
      setState(() {
        _airGestureEnabled = airGesture;
        _shizukuEnabled = shizuku;
      });
    } else {
      _airGestureEnabled = airGesture;
      _shizukuEnabled = shizuku;
    }
    await _applyAirGestureSetting();
  }

  /// Saves the Phase 8 toggle (F41 Accessibility service, default
  /// OFF). Turning it off here stops every accessibility action at
  /// once — the service refuses to run while the toggle is off, even
  /// if Android still has Jarvis enabled in Accessibility settings.
  Future<void> _savePhase8Settings({
    required bool accessibility,
  }) async {
    await _accessibilityService.setEnabled(accessibility);
    if (mounted) {
      setState(() => _accessibilityEnabled = accessibility);
    } else {
      _accessibilityEnabled = accessibility;
    }
  }

  /// A wave over the proximity sensor (F32). While Jarvis is speaking
  /// it stops the speech (same path as the STOP button, so a late
  /// answer cannot start speaking afterwards). While idle with
  /// wake-word listening on, it starts a conversation instead.
  Future<void> _onAirGestureWave() async {
    if (isSpeaking) {
      await _stopSpeaking();
      _addChatMessage('jarvis', 'Stopped by a wave.');
      return;
    }
    if (_isBackgroundListening && !_isInConversationMode) {
      _startConversationMode();
    }
  }

  /// Listens for taps on the floating bubble (F23) while the app is
  /// alive. A tap opens the app and starts a conversation.
  void _initOverlayBubble() {
    try {
      _overlayTapSubscription =
          FlutterOverlayWindow.overlayListener.listen((data) {
        if (data == 'bubble_tap') _openFromBubble();
      });
    } catch (_) {}
  }

  /// Opens the app from a bubble tap, asking it to start a conversation
  /// right away (the same launch path the home-screen widget uses).
  Future<void> _openFromBubble() async {
    try {
      final intent = AndroidIntent(
        action: 'android.intent.action.MAIN',
        category: 'android.intent.category.LAUNCHER',
        package: 'com.jarvis.jarvis_app',
        flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
        arguments: <String, dynamic>{'jarvis_start_conversation': true},
      );
      await intent.launch();
    } catch (_) {}
  }

  /// Edge TTS voice matching the accent picked in Settings. The device
  /// voice picker still applies to the flutter_tts fallback.
  String _edgeVoiceForLanguage(String language) {
    switch (language) {
      case 'en-US':
        return 'en-US-AriaNeural';
      case 'en-AU':
        return 'en-AU-NatashaNeural';
      default:
        return 'en-GB-SoniaNeural';
    }
  }

  /// Shared end-of-speech step for device TTS and Edge TTS: clear the
  /// speaking flag, then listen again right away instead of waiting for
  /// the 30-second timer. Skipped while a streamed reply is still
  /// arriving — more sentences are coming and listening re-arms at the
  /// end of the stream, not between sentences.
  ///
  /// F16: the offline engine stops barge-in listening here (the
  /// conversation listener takes the mic next), the state machine moves
  /// into the follow-up window, and — when the speech was an answer to
  /// a command, not the opening greeting — the ~8 s follow-up timer
  /// starts. Silence after that ends the conversation.
  void _finishSpeaking() {
    if (!mounted) return;
    setState(() {
      isSpeaking = false;
      _speakingSince = null;
    });
    _wakeWordMachine.onSpeechEnded();
    if (_isStreamingReply) return;
    if (_isInConversationMode) {
      _stopBargeInListening();
      if (_hasAnsweredCommand) _startFollowUpWindow();
      _continueConversation();
    } else if (_isBackgroundListening) {
      _startWakeWordDetection();
    }
  }

  /// Plays one short acknowledgment tone (F12). Own player, so it never
  /// cuts the startup/wake chimes. Silent when sounds are off.
  Future<void> _playAckSound(String asset) async {
    if (!_soundsEnabled) return;
    try {
      await _ackPlayer.play(AssetSource(asset));
    } catch (_) {}
  }

  /// Starts debug session recording (F13) when the toggle is on.
  Future<void> _startSessionRecording() async {
    if (!_recordSessionsEnabled || _isSessionRecording) return;
    await _sessionRecorder.startSession();
    if (mounted) setState(() => _isSessionRecording = true);
  }

  /// Stops debug session recording (F13) if one is running.
  Future<void> _stopSessionRecording() async {
    if (!_isSessionRecording) return;
    await _sessionRecorder.stopSession();
    if (mounted) setState(() => _isSessionRecording = false);
  }

  /// Builds the chat provider chain (F18/F20): the Gemini provider
  /// (model stays gemini-3.8-flash) wrapped in the NIM fallback router.
  /// Long-term memory facts (F17) are baked into the system instruction
  /// of both providers when they are created. The NIM fallback is only
  /// built when it is switched on AND a free NVIDIA key is stored —
  /// otherwise it stays disabled and nothing changes.
  ChatProvider _buildModel(String apiKey, String modelName) {
    final memorySection = buildMemorySection(_savedFacts);
    final gemini = GeminiChatProvider(
      apiKey: apiKey,
      modelName: modelName,
      systemInstruction: mergeSystemInstruction(
        jarvisSystemInstruction,
        memorySection.isEmpty ? null : memorySection,
      ),
    );
    final nim = (_nimEnabled && _nvidiaApiKey.isNotEmpty)
        ? NvidiaNimChatProvider(
            apiKey: _nvidiaApiKey,
            systemInstruction: memorySection,
          )
        : null;
    return FallbackChatProvider(primary: gemini, fallback: nim);
  }

  /// Rebuilds the chat provider from the current facts, NIM key/switch
  /// and knowledge files. Called after a fact is remembered/forgotten
  /// (voice or Saved facts screen), after a connector-hub change, and
  /// after a knowledge file changes. It never clears the short-term
  /// conversation history (unlike _loadSettings).
  Future<void> _rebuildChatProvider() async {
    _savedFacts = await _memoryService.loadFacts();
    _nvidiaApiKey = await _connectorHub.readNimKey();
    _nimEnabled = await _connectorHub.isNimEnabled();
    _knowledgeFiles = await _knowledgeService.listFiles();
    if (!mounted) return;
    model?.dispose();
    setState(() {
      model = _apiKey.isNotEmpty ? _buildModel(_apiKey, _modelName) : null;
    });
  }

  /// Provider-neutral view of the short-term conversation history, for
  /// the [ChatProvider] calls in processQuery.
  List<ChatMessage> get _providerHistory =>
      conversationHistory.map(ChatMessage.fromGemini).toList();

  Future<void> _loadSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      var savedKey = '';
      try {
        savedKey = await _secureStorageChannel.invokeMethod<String>('readApiKey') ?? '';
      } catch (_) {
        savedKey = '';
      }
      final savedModel = prefs.getString('gemini_model') ?? 'gemini-3.8-flash';
      final savedSounds = prefs.getBool('sounds_enabled') ?? true;
      // Phase 4 toggles (defaults: Edge TTS on, streaming on, recording off).
      final savedEdgeTts = prefs.getBool('edge_tts_enabled') ?? true;
      final savedStreaming = prefs.getBool('streaming_enabled') ?? true;
      final savedRecordSessions = prefs.getBool('record_sessions') ?? false;
      // Phase 5 toggles (defaults: offline wake word on, barge-in on).
      final savedOfflineWakeWord =
          prefs.getBool('offline_wake_word_enabled') ?? true;
      final savedBargeIn = prefs.getBool('barge_in_enabled') ?? true;
      // Phase 6 (v1.1.0): long-term memory facts (F17), the free NVIDIA
      // NIM key + switch (F19/F20), and the knowledge files (F22) —
      // loaded before the provider chain is built, so the facts are in
      // the system instruction from the first answer.
      _savedFacts = await _memoryService.loadFacts();
      _nvidiaApiKey = await _connectorHub.readNimKey();
      _nimEnabled = await _connectorHub.isNimEnabled();
      _knowledgeFiles = await _knowledgeService.listFiles();
      // Phase 7 (v1.1.0): floating bubble (F23, default OFF) and SMS
      // expense parsing (F29, default OFF).
      final savedBubble =
          prefs.getBool(kJarvisFloatingBubbleKey) ?? false;
      final savedSmsParsing =
          prefs.getBool(kJarvisFinanceSmsParsingKey) ?? false;
      // Phase 7b (v1.1.0): air gesture (F32, default OFF) and Shizuku
      // controls (F39, default OFF).
      final savedAirGesture =
          prefs.getBool(kJarvisAirGestureKey) ?? false;
      final savedShizuku =
          prefs.getBool(kJarvisShizukuEnabledKey) ?? false;
      // Phase 8 (v1.1.0): F41 Accessibility service, default OFF.
      final savedAccessibility =
          prefs.getBool(kJarvisAccessibilityKey) ?? false;
      if (!mounted) return;
      model?.dispose();
      conversationHistory.clear();
      setState(() {
        _apiKey = savedKey;
        _modelName = savedModel;
        _soundsEnabled = savedSounds;
        _edgeTtsEnabled = savedEdgeTts;
        _streamingEnabled = savedStreaming;
        _recordSessionsEnabled = savedRecordSessions;
        _offlineWakeWordEnabled = savedOfflineWakeWord;
        _bargeInEnabled = savedBargeIn;
        _floatingBubbleEnabled = savedBubble;
        _smsParsingEnabled = savedSmsParsing;
        _airGestureEnabled = savedAirGesture;
        _shizukuEnabled = savedShizuku;
        _accessibilityEnabled = savedAccessibility;
        _wakeWordMachine.bargeInEnabled = savedBargeIn;
        model = _apiKey.isNotEmpty ? _buildModel(_apiKey, _modelName) : null;
      });
      await _applyBubbleSetting();
      await _applyAirGestureSetting();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _apiKey = '';
        model = null;
      });
    }
  }

  Future<void> _saveSettings(String key, String modelName) async {
    final prefs = await SharedPreferences.getInstance();
    final normalizedModel = modelName.trim().isEmpty ? 'gemini-3.8-flash' : modelName.trim();
    if (key.trim().isEmpty) {
      await _secureStorageChannel.invokeMethod<void>('clearApiKey');
    } else {
      await _secureStorageChannel.invokeMethod<void>('saveApiKey', {'apiKey': key.trim()});
    }
    await prefs.setString('gemini_model', normalizedModel);
    if (!mounted) return;
    model?.dispose();
    conversationHistory.clear();
    setState(() {
      _apiKey = key.trim();
      _modelName = normalizedModel;
      model = _apiKey.isNotEmpty ? _buildModel(_apiKey, _modelName) : null;
    });
  }

  void _showSettingsDialog() {
    final keyController = TextEditingController(text: _apiKey);
    final modelController = TextEditingController(text: _modelName);
    // Voice + sounds choices edited in this dialog; saved with Save.
    bool dialogSounds = _soundsEnabled;
    bool dialogEdgeTts = _edgeTtsEnabled;
    bool dialogStreaming = _streamingEnabled;
    bool dialogRecordSessions = _recordSessionsEnabled;
    bool dialogOfflineWakeWord = _offlineWakeWordEnabled;
    bool dialogBargeIn = _bargeInEnabled;
    // Phase 7 choices edited in this dialog; saved with Save.
    bool dialogFloatingBubble = _floatingBubbleEnabled;
    bool dialogSmsParsing = _smsParsingEnabled;
    // Phase 7b choices edited in this dialog; saved with Save.
    bool dialogAirGesture = _airGestureEnabled;
    bool dialogShizuku = _shizukuEnabled;
    // Phase 8 choice edited in this dialog; saved with Save.
    bool dialogAccessibility = _accessibilityEnabled;
    bool dialogAssistantRoleHeld = false;
    bool dialogAssistantRoleLoading = true;
    bool assistantRoleRequested = false;
    String dialogLanguage = _ttsLanguage;
    String dialogVoiceName = _ttsVoiceName ?? '';
    String dialogVoiceLocale = _ttsVoiceLocale ?? '';
    List<Map<String, String>> voiceOptions = [];
    bool voicesLoading = true;
    bool voicesRequested = false;

    Future<void> loadVoices() async {
      try {
        final voices = await flutterTts.getVoices;
        final parsed = <Map<String, String>>[];
        for (final v in voices) {
          if (v is Map) {
            final name = v['name']?.toString() ?? '';
            final locale = v['locale']?.toString() ?? '';
            if (name.isNotEmpty && locale.toLowerCase().startsWith('en')) {
              parsed.add({'name': name, 'locale': locale});
            }
          }
        }
        parsed.sort((a, b) => a['name']!.compareTo(b['name']!));
        voiceOptions = parsed;
      } catch (_) {
        voiceOptions = [];
      }
      voicesLoading = false;
    }

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          if (!voicesRequested) {
            voicesRequested = true;
            loadVoices().then((_) {
              if (context.mounted) setDialogState(() {});
            });
          }
          if (!assistantRoleRequested) {
            assistantRoleRequested = true;
            _assistantRoleService.isHeld().then((held) {
              if (context.mounted) {
                setDialogState(() {
                  dialogAssistantRoleHeld = held;
                  dialogAssistantRoleLoading = false;
                });
              }
            });
          }
          return AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('Settings',
            style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Paste your free Gemini API key from Google AI Studio (aistudio.google.com). Voice commands such as opening apps, telling the time, timers and alarms work without a key.',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: keyController,
                obscureText: true,
                enableSuggestions: false,
                autocorrect: false,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Gemini API key',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: modelController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Model name',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              const Text('App sounds',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              SwitchListTile(
                value: dialogSounds,
                activeColor: Colors.cyan,
                title: const Text('Startup and wake-up sounds',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Off silences the startup chime and the wake-up chime.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) => setDialogState(() => dialogSounds = v),
              ),
              const SizedBox(height: 8),
              const Text('Jarvis voice',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: dialogLanguage,
                dropdownColor: Colors.grey[900],
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Accent',
                  labelStyle: TextStyle(color: Colors.cyan),
                  border: OutlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(
                      value: 'en-GB', child: Text('English (UK)')),
                  DropdownMenuItem(
                      value: 'en-US', child: Text('English (US)')),
                  DropdownMenuItem(
                      value: 'en-AU', child: Text('English (Australia)')),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setDialogState(() {
                    dialogLanguage = v;
                    dialogVoiceName = '';
                    dialogVoiceLocale = '';
                  });
                },
              ),
              const SizedBox(height: 12),
              if (voicesLoading)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text('Loading voices…',
                      style: TextStyle(color: Colors.grey, fontSize: 13)),
                )
              else if (voiceOptions.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                      'No English voices found on this phone. The accent above will be used.',
                      style: TextStyle(color: Colors.grey, fontSize: 13)),
                )
              else
                DropdownButtonFormField<String>(
                  value: voiceOptions.any(
                          (v) => v['name'] == dialogVoiceName)
                      ? dialogVoiceName
                      : '',
                  dropdownColor: Colors.grey[900],
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    labelText: 'Voice (from this phone)',
                    labelStyle: TextStyle(color: Colors.cyan),
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    const DropdownMenuItem(
                        value: '', child: Text('Default voice')),
                    for (final v in voiceOptions)
                      DropdownMenuItem(
                        value: v['name'],
                        child: Text('${v['name']} (${v['locale']})',
                            overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (v) {
                    final picked = v ?? '';
                    final match = voiceOptions.firstWhere(
                      (e) => e['name'] == picked,
                      orElse: () => {'name': '', 'locale': ''},
                    );
                    setDialogState(() {
                      dialogVoiceName = picked;
                      dialogVoiceLocale = match['locale'] ?? '';
                    });
                  },
                ),
              const SizedBox(height: 8),
              SwitchListTile(
                value: dialogEdgeTts,
                activeThumbColor: Colors.cyan,
                title: const Text('Edge TTS (natural voice)',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Free natural voice from Microsoft Edge. Falls back to this phone\'s voice when it is unavailable.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) => setDialogState(() => dialogEdgeTts = v),
              ),
              const SizedBox(height: 8),
              const Text('Replies',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              SwitchListTile(
                value: dialogStreaming,
                activeThumbColor: Colors.cyan,
                title: const Text('Streaming replies',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Answers start speaking sooner, sentence by sentence. Off waits for the full answer.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) => setDialogState(() => dialogStreaming = v),
              ),
              const SizedBox(height: 8),
              const Text('Debug',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              SwitchListTile(
                value: dialogRecordSessions,
                activeThumbColor: Colors.cyan,
                title: const Text('Record sessions (debug)',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Saves the microphone audio and transcript of each conversation on this phone only, for fixing voice problems. Nothing is uploaded.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) =>
                    setDialogState(() => dialogRecordSessions = v),
              ),
              const SizedBox(height: 8),
              const Text('Wake word',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              SwitchListTile(
                value: dialogOfflineWakeWord,
                activeThumbColor: Colors.cyan,
                title: const Text('Offline wake word (Hey Jarvis)',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: Text(
                    _offlineWakeWordReady
                        ? 'On-device listening is ready. Off falls back to the system listener.'
                        : 'Listens on this phone, no internet needed. Falls back to the system listener when unavailable.',
                    style:
                        const TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) =>
                    setDialogState(() => dialogOfflineWakeWord = v),
              ),
              SwitchListTile(
                value: dialogBargeIn,
                activeThumbColor: Colors.cyan,
                title: const Text('Barge-in (interrupt while speaking)',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Say "Hey Jarvis" while Jarvis is answering to stop it and give a new command.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) => setDialogState(() => dialogBargeIn = v),
              ),
              const SizedBox(height: 8),
              const Text('Everyday tools',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              SwitchListTile(
                value: dialogFloatingBubble,
                activeThumbColor: Colors.cyan,
                title: const Text('Floating bubble',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'A small Jarvis bubble over other apps — tap it to talk. Needs the overlay permission.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) =>
                    setDialogState(() => dialogFloatingBubble = v),
              ),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        final granted =
                            await _overlayService.requestPermission();
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(granted
                                  ? 'Overlay permission granted.'
                                  : 'Overlay permission not granted.'),
                            ),
                          );
                        }
                      },
                      child: const Text('Allow overlay permission',
                          style: TextStyle(color: Colors.cyan)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                value: dialogSmsParsing,
                activeThumbColor: Colors.cyan,
                title: const Text('SMS expense parsing',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Reads bank SMS on this phone to log expenses. Off by default; nothing is uploaded. Needs the SMS permission.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) =>
                    setDialogState(() => dialogSmsParsing = v),
              ),
              SwitchListTile(
                value: dialogAirGesture,
                activeThumbColor: Colors.cyan,
                title: const Text('Air gesture (wave to silence)',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Wave a hand over the proximity sensor: stops Jarvis while it is speaking, or starts a conversation while it is idle. Off by default; does nothing on a phone without a proximity sensor.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) =>
                    setDialogState(() => dialogAirGesture = v),
              ),
              SwitchListTile(
                value: dialogShizuku,
                activeThumbColor: Colors.cyan,
                title: const Text('Shizuku controls',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Extra system controls (force-stop, mobile data) through the free Shizuku app. Off by default; nothing runs unless Shizuku is installed, running and authorised.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) =>
                    setDialogState(() => dialogShizuku = v),
              ),
              SwitchListTile(
                value: dialogAccessibility,
                activeThumbColor: Colors.cyan,
                title: const Text('Accessibility service (tap / type)',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                subtitle: const Text(
                    'Lets Jarvis tap, type, go back and scroll inside other apps — ONLY when you tell it to by voice, for example "tap Send". Off by default. Also needs Jarvis switched on in Android Settings → Accessibility. Turn it off here (and there) to stop it completely; every action is logged in the ⋮ menu → Accessibility actions.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
                contentPadding: EdgeInsets.zero,
                onChanged: (v) =>
                    setDialogState(() => dialogAccessibility = v),
              ),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        await _openSettingsPanel(
                          'android.settings.ACCESSIBILITY_SETTINGS',
                          'Accessibility settings',
                        );
                      },
                      child: const Text('Open Android Accessibility settings',
                          style: TextStyle(color: Colors.cyan)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text('Default assistant',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                dialogAssistantRoleLoading
                    ? 'Checking…'
                    : dialogAssistantRoleHeld
                        ? 'Jarvis is your default assistant.'
                        : 'Jarvis is not your default assistant.',
                style: const TextStyle(color: Colors.grey, fontSize: 12),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        final granted =
                            await _assistantRoleService.request();
                        if (context.mounted) {
                          setDialogState(
                              () => dialogAssistantRoleHeld = granted);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(granted
                                  ? 'Jarvis is now your default assistant.'
                                  : 'Not set — you can try again anytime. Nothing changed.'),
                            ),
                          );
                        }
                      },
                      child: const Text('Set as default assistant',
                          style: TextStyle(color: Colors.cyan)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await _saveSettings('', 'gemini-3.8-flash');
              keyController.dispose();
              modelController.dispose();
              if (context.mounted) Navigator.of(context).pop();
            },
            child:
                const Text('Clear key', style: TextStyle(color: Colors.redAccent)),
          ),
          TextButton(
            onPressed: () {
              keyController.dispose();
              modelController.dispose();
              Navigator.of(context).pop();
            },
            child:
                const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _saveSettings(keyController.text.trim(), modelController.text.trim());
                await _saveSoundsSetting(dialogSounds);
                await _savePhase4Settings(
                  edgeTts: dialogEdgeTts,
                  streaming: dialogStreaming,
                  recordSessions: dialogRecordSessions,
                );
                await _savePhase5Settings(
                  offlineWakeWord: dialogOfflineWakeWord,
                  bargeIn: dialogBargeIn,
                );
                await _saveVoiceSettings(
                  language: dialogLanguage,
                  voiceName:
                      dialogVoiceName.isEmpty ? null : dialogVoiceName,
                  voiceLocale:
                      dialogVoiceLocale.isEmpty ? null : dialogVoiceLocale,
                );
                await _savePhase7Settings(
                  floatingBubble: dialogFloatingBubble,
                  smsParsing: dialogSmsParsing,
                );
                await _savePhase7bSettings(
                  airGesture: dialogAirGesture,
                  shizuku: dialogShizuku,
                );
                await _savePhase8Settings(
                  accessibility: dialogAccessibility,
                );
                keyController.dispose();
                modelController.dispose();
                if (context.mounted) Navigator.of(context).pop();
                speak('Settings saved, sir.');
              } catch (_) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Could not save the settings. Please try again.')),
                  );
                }
              }
            },
            child: const Text('Save', style: TextStyle(color: Colors.cyan)),
          ),
        ],
          );
        },
      ),
    );
  }

  void _startBackgroundAnimationTimer() {
    _backgroundAnimationTimer = Timer.periodic(Duration(seconds: 5), (timer) {
      if (!_isWakeWordDetected && !isSpeaking && !_isInConversationMode) {
        setState(() {
          _backgroundAnimationCounter++;
        });
      }
    });
  }

  void _setupColorAnimation() {
    final nextColorIndex = (_currentColorIndex + 1) % _ironManColors.length;
    _colorAnimation = ColorTween(
      begin: _ironManColors[_currentColorIndex],
      end: _ironManColors[nextColorIndex],
    ).animate(_colorAnimationController);
  }

  // ---- Phase 5 (v1.1.0): offline wake word (F14) + barge-in /
  // follow-up listening (F16) ----

  /// Loads the offline "Hey Jarvis" models in the background. When they
  /// are ready the offline engine takes over wake-word listening from
  /// the system recogniser; when loading fails (model missing, native
  /// lib unavailable) the app silently stays on the system recogniser
  /// and the user never sees an error.
  Future<void> _initOfflineWakeWord() async {
    if (!_offlineWakeWordEnabled) return;
    final ready = await _wakeWordService.ensureReady();
    if (!mounted) return;
    if (!ready) {
      debugPrint('Offline wake word unavailable; using system listener.');
      return;
    }
    _wakeWordSubscription ??=
        _wakeWordService.detections.listen((_) {
      _onOfflineWakeWordDetected();
    });
    if (mounted) setState(() => _offlineWakeWordReady = true);
    if (_isBackgroundListening && !_isInConversationMode && !isSpeaking) {
      if (!await _startOfflineWakeWord()) _startWakeWordDetection();
    }
  }

  /// Starts the offline engine as the wake-word listener, releasing the
  /// system recogniser's mic first. Returns true when it is listening;
  /// false (mic busy/denied) lets the caller fall back to the system
  /// recogniser instead of leaving the app deaf. No-op when it is
  /// already running.
  Future<bool> _startOfflineWakeWord() async {
    if (!_offlineWakeWordEnabled || !_offlineWakeWordReady) return false;
    if (_wakeWordService.isRunning) return true;
    try {
      speech.stop();
    } catch (_) {}
    final started = await _wakeWordService.start();
    if (started && mounted) setState(() => _isBackgroundListening = true);
    return started;
  }

  /// Stops the offline engine. The models stay loaded for a fast restart.
  Future<void> _stopOfflineWakeWord() async {
    await _wakeWordService.stop();
  }

  /// One "Hey Jarvis" heard by the offline engine. The state machine
  /// decides what it means: a fresh wake-up, a barge-in while speaking,
  /// or nothing (already listening — the recogniser hears the command).
  void _onOfflineWakeWordDetected() {
    if (!mounted) return;
    final action = _wakeWordMachine.onWakeWord();
    switch (action) {
      case WakeWordAction.enterConversation:
        _addChatMessage('user', 'Hey Jarvis');
        setState(() => _isWakeWordDetected = true);
        _playWakeSound();
        // F12: short blip — the wake word was heard.
        _playAckSound('sounds/ack_wake.wav');
        _startConversationMode();
      case WakeWordAction.bargeIn:
        // F16: stop through the same path as the STOP button, so the
        // generation token keeps a late answer from speaking afterwards.
        _stopSpeaking();
      case WakeWordAction.none:
      case WakeWordAction.endConversation:
        break;
    }
  }

  /// Starts the offline engine as the barge-in listener while Jarvis
  /// speaks. The system recogniser is stopped by speak() before this
  /// runs, so the engine has the mic to itself. No-op when barge-in is
  /// off, the engine is unavailable, or it is already running (it may
  /// already be the wake-word listener).
  Future<void> _startBargeInListening() async {
    if (!_bargeInEnabled || !_offlineWakeWordReady) return;
    if (_wakeWordService.isRunning) return;
    await _wakeWordService.start();
  }

  /// Stops barge-in listening (engine off; the conversation listener
  /// takes the mic next). No-op when the engine is not running.
  Future<void> _stopBargeInListening() async {
    if (_wakeWordService.isRunning) await _wakeWordService.stop();
  }

  /// Opens the ~8 s follow-up window after an answer finishes: the
  /// status line says so, and silence until the timer fires ends the
  /// conversation. Any command heard restarts the window's logic by
  /// cancelling this timer (see _continueConversation).
  void _startFollowUpWindow() {
    _followUpTimer?.cancel();
    if (mounted) setState(() => _isInFollowUpWindow = true);
    _followUpTimer = Timer(kFollowUpWindow, _onFollowUpExpired);
  }

  /// Cancels the follow-up window (a command was heard, the
  /// conversation ended, or a new one started).
  void _cancelFollowUpWindow() {
    _followUpTimer?.cancel();
    _followUpTimer = null;
    if (mounted && _isInFollowUpWindow) {
      setState(() => _isInFollowUpWindow = false);
    }
  }

  /// The follow-up window expired with no command. While an answer is
  /// still loading the user may yet speak, so the window is extended
  /// instead of ending the conversation mid-answer.
  void _onFollowUpExpired() {
    _followUpTimer = null;
    if (!mounted || !_isInConversationMode) return;
    if (_isProcessingQuery) {
      _startFollowUpWindow();
      return;
    }
    if (mounted) setState(() => _isInFollowUpWindow = false);
    if (_wakeWordMachine.onFollowUpExpired() ==
        WakeWordAction.endConversation) {
      _endConversationMode();
    }
  }

  Future<void> _startWakeWordDetection() async {
    if (!mounted || _isInConversationMode) return;
    // F14: the offline engine is the primary wake-word listener when it
    // is enabled and ready — it hears "Hey Jarvis" without internet and
    // without the system recogniser's listening beep (the tick sound).
    // The system recogniser below is the fallback only; if the engine
    // will not start (mic busy/denied), fall through to it instead of
    // leaving the app deaf.
    if (_offlineWakeWordEnabled && _offlineWakeWordReady) {
      if (await _startOfflineWakeWord()) return;
    }
    try {
      final available = await speech.initialize();
      if (!mounted) return;
      if (!available) {
        // Speech service hiccup (no network / Google app busy). Keep the
        // toggle ON so the 30-second timer retries — never switch it off
        // by ourselves, or voice dies silently until the user re-toggles.
        debugPrint('Speech recognition unavailable; will retry.');
        _reportVoiceProblem(
            'Voice listening paused — speech service is busy or there is no internet. Retrying…');
        return;
      }
      setState(() => _isBackgroundListening = true);
      // F14: the offline models may have finished loading while
      // speech.initialize() was awaiting — re-check before starting
      // the system recogniser, or the engine would never take over
      // until the 30-second timer (and _startListeningForWakeWord
      // below would no-op against the offline guard).
      if (_offlineWakeWordEnabled && _offlineWakeWordReady) {
        if (await _startOfflineWakeWord()) return;
      }
      speech.statusListener = (status) {
        if (status == stt.SpeechToText.doneStatus ||
            status == stt.SpeechToText.notListeningStatus) {
          if (_isBackgroundListening &&
              !_isWakeWordDetected &&
              !_isInConversationMode) {
            // Back off when the recognizer keeps dying: every restart
            // plays the system's listening beep, so a tight restart loop
            // sounds like continuous ticking in the background.
            final delay = _listenRestartDelay();
            Future.delayed(delay, () {
              if (mounted &&
                  _isBackgroundListening &&
                  !_isWakeWordDetected &&
                  !_isInConversationMode) {
                _startListeningForWakeWord();
              }
            });
          }
        }
      };
      _startListeningForWakeWord();
    } catch (_) {
      // Same as above: keep the toggle ON; the timer retries.
      debugPrint('Wake-word start failed; will retry.');
      _reportVoiceProblem(
          'Voice listening paused — microphone or speech service had a problem. Retrying…');
    }
  }

  /// Delay before restarting the recognizer after it stops. Normally a
  /// third of a second; after three restarts within five seconds (the
  /// recognizer is dying on every start, e.g. when the app just went to
  /// the background) wait eight seconds instead, so the repeated
  /// listening beeps do not tick continuously.
  Duration _listenRestartDelay() {
    final now = DateTime.now();
    if (_lastListenRestartAt != null &&
        now.difference(_lastListenRestartAt!).inSeconds < 5) {
      _listenRestartStreak++;
    } else {
      _listenRestartStreak = 0;
    }
    _lastListenRestartAt = now;
    if (_listenRestartStreak >= 3) {
      _listenRestartStreak = 0;
      return const Duration(seconds: 8);
    }
    return const Duration(milliseconds: 350);
  }

  /// Tells the user WHY voice is not working (internet, mic, speech
  /// service) instead of going silent. Shows in the chat and on the
  /// background notification; speaks it once in a while when the app is
  /// in the background, where the chat cannot be seen. Same reason is
  /// never repeated within five minutes.
  void _reportVoiceProblem(String reason) {
    if (!mounted) return;
    final now = DateTime.now();
    if (_lastVoiceProblem == reason &&
        _lastVoiceProblemAt != null &&
        now.difference(_lastVoiceProblemAt!).inMinutes < 5) {
      return;
    }
    _lastVoiceProblem = reason;
    _lastVoiceProblemAt = now;
    setState(() => _voiceStatus = reason);
    _addChatMessage('jarvis', 'Voice: $reason');
    _updateListeningNotification(reason);
    if (!_isAppInForeground &&
        (_lastVoiceProblemSpokenAt == null ||
            now.difference(_lastVoiceProblemSpokenAt!).inSeconds > 60)) {
      _lastVoiceProblemSpokenAt = now;
      speak(reason);
    }
  }

  /// Short reason shown on the "J.A.R.V.I.S is listening" notification,
  /// so the user can see the voice status without opening the app.
  Future<void> _updateListeningNotification(String text) async {
    try {
      await FlutterForegroundTask.updateService(
        notificationTitle: 'J.A.R.V.I.S is listening',
        notificationText: text,
      );
    } catch (_) {}
  }

  /// True when the phone can reach Google's Gemini servers. Used before
  /// an AI request so "no internet" is reported plainly instead of
  /// looking like Jarvis ignored the command.
  Future<bool> _hasInternet() async {
    try {
      final result = await InternetAddress.lookup(
              'generativelanguage.googleapis.com')
          .timeout(const Duration(seconds: 5));
      return result.isNotEmpty && result.first.rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  void _startListeningForWakeWord() {
    // F14: when the offline engine is available and enabled, it owns
    // wake-word listening — never run the system recogniser alongside
    // it (two mic clients, plus the recogniser's beep is the tick
    // sound F14 removes).
    if (_offlineWakeWordEnabled && _offlineWakeWordReady) return;
    if (!speech.isListening && mounted && !_isInConversationMode) {
      try {
        speech.listen(
          onResult: (result) {
            if (result.finalResult) {
              if (!mounted) return;
              String userInput = result.recognizedWords.toLowerCase();
              if (userInput.contains('jarvis') ||
                  userInput.contains('hey jarvis')) {
                _addChatMessage('user', userInput);
                setState(() => _isWakeWordDetected = true);
                _playWakeSound();
                // F12: short blip — the wake word was heard.
                _playAckSound('sounds/ack_wake.wav');

                _startConversationMode();
              }
            }
          },
          listenFor: Duration(minutes: 10), 
          pauseFor: Duration(seconds: 10), 
          partialResults: true,
          listenMode: stt.ListenMode.deviceDefault,
          cancelOnError: false,
          onSoundLevelChange: (level) {},
        );
      } catch (e) {
        debugPrint("Error starting speech recognition: $e");

        Future.delayed(Duration(seconds: 2), () {
          if (mounted && _isBackgroundListening && !_isInConversationMode) {
            _startListeningForWakeWord();
          }
        });
      }
    }
  }

  void _startConversationMode() {
    speech.stop();

    setState(() {
      _isInConversationMode = true;
      _isWakeWordDetected = true;
    });

    // F16: fresh conversation — no answer has been given yet, so the
    // follow-up window must not start when the greeting finishes.
    // (The offline engine, if running, keeps the mic through the
    // greeting as the barge-in listener; speak() re-arms it as such.)
    _hasAnsweredCommand = false;
    _cancelFollowUpWindow();
    _wakeWordMachine.onConversationStarted();

    // F13: a debug recording starts with the conversation when on.
    _startSessionRecording();
    speak("I'm listening, sir. How can I assist you?");
    _addChatMessage('jarvis', "I'm listening, sir. How can I assist you?");
  }

  void _continueConversation() {
    if (!mounted || !_isInConversationMode || _isProcessingQuery) return;

    debugPrint("Continuing conversation...");

    if (!speech.isListening) {
      try {
        speech.listen(
          onResult: (result) async {
            if (result.finalResult) {
              if (!mounted) return;
              String userInput = result.recognizedWords.toLowerCase();
              _addChatMessage('user', userInput);
              // F16: a command was heard — the follow-up window closes
              // (a new one opens when this command's answer finishes).
              _cancelFollowUpWindow();
              _wakeWordMachine.onCommandHeard();
              // F12: short ding — the command was heard.
              _playAckSound('sounds/ack_command.wav');

              if (userInput.contains("end conversation") ||
                  userInput.contains("goodbye") ||
                  userInput.contains("bye") ||
                  userInput.contains("that's all") ||
                  userInput.contains("exit conversation")) {
                _endConversationMode();
                speak(
                    "Ending conversation mode. Just say 'Hey Jarvis' when you need me again.");
                return;
              }

              processQuery(userInput);
            }
          },
          listenFor: Duration(minutes: 10),
          pauseFor: Duration(seconds: 10),
          partialResults: true,
          listenMode: stt.ListenMode.deviceDefault,
          cancelOnError: false,
          onSoundLevelChange: (level) {},
        );

        speech.statusListener = (status) {
          if ((status == stt.SpeechToText.doneStatus ||
                  status == stt.SpeechToText.notListeningStatus) &&
              _isInConversationMode &&
              !isSpeaking &&
              !_isProcessingQuery) {
            Future.delayed(Duration(milliseconds: 300), () {
              if (mounted &&
                  _isInConversationMode &&
                  !isSpeaking &&
                  !_isProcessingQuery &&
                  !speech.isListening) {
                debugPrint("Restarting conversation listening...");
                _continueConversation();
              }
            });
          }
        };
      } catch (e) {
        debugPrint("Error in conversation listening: $e");

        Future.delayed(Duration(seconds: 1), () {
          if (mounted && _isInConversationMode) {
            _continueConversation();
          }
        });
      }
    }
  }

  void _endConversationMode() {
    setState(() {
      _isInConversationMode = false;
      _isWakeWordDetected = false;
    });

    // F13: the debug recording ends with the conversation.
    _stopSessionRecording();
    // F16: the conversation is over — no follow-up window, no pending
    // "answered" state, state machine back to idle.
    _cancelFollowUpWindow();
    _hasAnsweredCommand = false;
    _wakeWordMachine.reset();
    if (_isBackgroundListening) {
      _startWakeWordDetection();
    }
  }


  Future<void> processQuery(String query) async {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty) return;

    // STOP must work even while another answer is loading (v1.1.0 fix):
    // check it BEFORE the _isProcessingQuery guard below. Exact phrases
    // only, so questions like "how do I stop a nosebleed" still get
    // answered instead of silencing the app.
    if (kJarvisStopWords.contains(normalized)) {
      await _stopSpeaking();
      // A STOP also abandons a half-finished Phase 7b follow-up
      // (form filling, message draft, macro naming, commute start),
      // so the next thing the user says is a fresh command, not an
      // answer to a question that is no longer being asked. Macro
      // recording is NOT stopped here — "stop recording" does that.
      if (_pendingCommand == 'form' ||
          _pendingCommand == 'message_pick' ||
          _pendingCommand == 'message_body' ||
          _pendingCommand == 'message_channel' ||
          _pendingCommand == 'macro_name' ||
          _pendingCommand == 'commute_start' ||
          _pendingCommand == 'confirm_action') {
        _pendingCommand = '';
        _pendingDraftRequest = null;
        _pendingDraftCandidates = [];
        _pendingDraftContact = null;
        _formTemplate = null;
        _formAnswers.clear();
        _pendingCommute = null;
        // F42: a STOP also abandons a confirmation waiting for a
        // yes — nothing is sent or called afterwards.
        _confirmationTimer?.cancel();
        _confirmationTimer = null;
        _confirmationGate.cancel();
        _confirmationGate.reset();
        _pendingConfirmationAction = null;
      }
      _addChatMessage('jarvis', 'Stopped.');
      return;
    }
    if (_isProcessingQuery) return;

    // F42: a confirmation is waiting for a yes/no. This answer goes
    // to the gate, not to a new command — except STOP, handled above.
    if (_pendingCommand == 'confirm_action' &&
        _confirmationGate.isPending) {
      await _handleConfirmationAnswer(normalized);
      return;
    }

    // F16: an accepted command — when its answer finishes speaking, the
    // ~8 s follow-up window opens.
    _hasAnsweredCommand = true;

    if (normalized.contains('cancel timer') || normalized.contains('stop timer')) {
      _pendingCommand = '';
      _timer?.cancel();
      _timerEndsAt = null;
      if (mounted) setState(() { _isTimerActive = false; _remainingSeconds = null; });
      speak('Timer cancelled.');
      return;
    }
    // Choosing between several contacts with the same name.
    if (_pendingCommand == 'call' && _pendingCallCandidates.isNotEmpty) {
      _pendingCommand = '';
      await _pickCallCandidate(normalized);
      return;
    }
    if (_pendingCommand == 'alarm' && normalized.contains('cancel')) {
      _pendingCommand = '';
      speak('Alarm request cancelled.');
      return;
    }

    // A follow-up answer is routed to the command that requested it.
    if (_pendingCommand == 'timer') {
      _pendingCommand = '';
      _handleTimerCommand(normalized, allowPrompt: false);
      return;
    }
    if (_pendingCommand == 'alarm') {
      _pendingCommand = '';
      await _handleAlarmCommand(normalized, allowPrompt: false);
      return;
    }
    // Phase 7b (v1.1.0) — follow-up answers for macros (F33),
    // message drafts (F34), form drafting (F35) and commute (F37).
    if (_pendingCommand == 'macro_name') {
      _pendingCommand = '';
      await _finishMacroRecording(normalized);
      return;
    }
    if (_pendingCommand == 'message_pick' &&
        _pendingDraftCandidates.isNotEmpty) {
      _pendingCommand = '';
      await _pickDraftCandidate(normalized);
      return;
    }
    if (_pendingCommand == 'message_body' &&
        _pendingDraftRequest != null) {
      _pendingCommand = '';
      await _setDraftBody(query);
      return;
    }
    if (_pendingCommand == 'message_channel' &&
        _pendingDraftRequest != null &&
        _pendingDraftContact != null) {
      _pendingCommand = '';
      await _setDraftChannel(normalized);
      return;
    }
    if (_pendingCommand == 'form' && _formTemplate != null) {
      await _handleFormAnswer(query);
      return;
    }
    if (_pendingCommand == 'commute_start' &&
        _pendingCommute != null) {
      final pending = _pendingCommute!;
      _pendingCommand = '';
      _pendingCommute = null;
      await _handleCommuteWithStart(pending, query);
      return;
    }

    // F33: while a macro is being recorded, every command is captured
    // (and still runs normally). "stop recording" finishes and saves
    // it; "cancel recording" drops it. Macro-control commands
    // themselves are never captured.
    if (_macroRecording) {
      if (normalized == 'stop recording' ||
          normalized == 'stop recording macro') {
        await _finishMacroRecording(_macroRecordName);
        return;
      }
      if (normalized == 'cancel recording') {
        _macroRecording = false;
        _macroRecordName = '';
        _macroRecordSteps.clear();
        _addChatMessage('jarvis', 'Recording cancelled — nothing was saved.');
        speak('Recording cancelled.');
        return;
      }
      final routeForCapture = classifyCommand(normalized);
      if (routeForCapture != LocalRoute.macro) {
        _macroRecordSteps.add(query.trim());
        if (_macroRecordSteps.length > kJarvisMaxMacroSteps) {
          _macroRecordSteps.removeAt(0);
        }
      }
    }

    // F38: the local router runs first. Instant answers (time/date)
    // and the Phase 7b commands are handled here without ever
    // reaching Gemini; every other local route falls through to the
    // existing branch chain below, and only LocalRoute.gemini
    // continues past it to the Gemini path.
    switch (classifyCommand(normalized)) {
      case LocalRoute.time:
        _tellTime();
        return;
      case LocalRoute.date:
        _tellDate();
        return;
      case LocalRoute.multiTask:
        // F40: multi-step requests run through the agent loop
        // (understand → plan → act → verify → honest report) instead
        // of the plain F36 queue. Simple Q&A never reaches this
        // branch — it takes the DIRECT fast path to Gemini below.
        await _handleAgentLoopCommand(normalized);
        return;
      case LocalRoute.macro:
        await _handleMacroCommand(normalized);
        return;
      case LocalRoute.messageDraft:
        await _handleMessageDraft(query);
        return;
      case LocalRoute.formDraft:
        await _handleFormStart(query);
        return;
      case LocalRoute.commute:
        await _handleCommute(query);
        return;
      case LocalRoute.shizuku:
        await _handleShizukuCommand(normalized);
        return;
      case LocalRoute.weather:
      case LocalRoute.timer:
      case LocalRoute.alarm:
      case LocalRoute.call:
      case LocalRoute.reminder:
      case LocalRoute.openApp:
      case LocalRoute.finance:
      case LocalRoute.calendar:
      case LocalRoute.mail:
      case LocalRoute.memory:
      case LocalRoute.deviceControl:
      case LocalRoute.localOther:
      case LocalRoute.gemini:
        break;
    }

    // F41: Accessibility voice commands ("tap Send", "type hello",
    // "go back", "scroll down"). Only recognised at all while the
    // service is switched on — "type of diabetes" must stay a Gemini
    // question when it is off. The handler itself also refuses when
    // Android has the service switched off, and logs every action.
    if (_accessibilityEnabled) {
      final accessibilityCommand = parseAccessibilityCommand(normalized);
      if (accessibilityCommand != null) {
        await _handleAccessibilityCommand(accessibilityCommand);
        return;
      }
    }

    if (RegExp(r'\b(weather|forecast)\b').hasMatch(normalized)) {
      _searchWeather();
      return;
    }
    if (RegExp(r'\b(time|what time|current time|tell me the time|time now)\b').hasMatch(normalized)) {
      _tellTime();
      return;
    }
    if (normalized.contains('set timer') || normalized.contains('start timer') || normalized.contains('timer for')) {
      _handleTimerCommand(normalized);
      return;
    }
    if (normalized.contains('set alarm') || normalized.contains('alarm for')) {
      await _handleAlarmCommand(normalized);
      return;
    }
    // Device controls (checked before "open ..." so "open wifi settings"
    // does not fall through to the Play Store search).
    if (normalized == 'lock phone' ||
        normalized == 'lock my phone' ||
        normalized == 'lock the phone') {
      _lockPhone();
      return;
    }
    if (normalized == 'unlock phone' || normalized == 'unlock my phone') {
      _addChatMessage('jarvis',
          "I can't unlock the phone — Android does not allow any app to unlock the lock screen. Only you can unlock it with your PIN, pattern or fingerprint.");
      speak("I can't unlock the phone. Only you can unlock it.");
      return;
    }
    if (normalized.contains('flashlight on') ||
        normalized.contains('torch on')) {
      _setTorch(true);
      return;
    }
    if (normalized.contains('flashlight off') ||
        normalized.contains('torch off')) {
      _setTorch(false);
      return;
    }
    if (normalized.contains('volume up')) {
      _setVolume('up');
      return;
    }
    if (normalized.contains('volume down')) {
      _setVolume('down');
      return;
    }
    if (normalized == 'mute' ||
        normalized.contains('volume mute') ||
        normalized.contains('mute volume')) {
      _setVolume('mute');
      return;
    }
    // Phase 7 (v1.1.0) — everyday tools.
    // Code Black (F26): "code black" locks the phone at once.
    if (normalized == 'code black') {
      _triggerCodeBlack();
      return;
    }
    // Finance (F29): "spent 500 on groceries".
    final expense = parseExpenseCommand(normalized);
    if (expense != null) {
      await _handleExpenseCommand(expense);
      return;
    }
    if (normalized.contains('my expenses') ||
        normalized.contains('show expenses') ||
        normalized == 'finance' ||
        normalized.contains('how much did i spend')) {
      if (!mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              FinanceScreen(financeService: _financeService),
        ),
      );
      return;
    }
    // Calendar (F27): "what is on my calendar today".
    if (normalized.contains('calendar') ||
        normalized.contains('my events today') ||
        normalized.contains('what is on today')) {
      await _handleCalendarQuery();
      return;
    }
    // Email triage (F28): "any important mail?"
    if (normalized.contains('important mail') ||
        normalized.contains('any mail') ||
        normalized.contains('check my email') ||
        normalized.contains('check my mail')) {
      await _handleMailQuery();
      return;
    }
    if (normalized.contains('wifi settings') ||
        normalized.contains('wi-fi settings')) {
      _openSettingsPanel('android.settings.WIFI_SETTINGS', 'WiFi settings');
      return;
    }
    if (normalized.contains('bluetooth settings')) {
      _openSettingsPanel(
          'android.settings.BLUETOOTH_SETTINGS', 'Bluetooth settings');
      return;
    }
    if (normalized.contains('display settings') ||
        normalized.contains('brightness settings')) {
      _openSettingsPanel(
          'android.settings.DISPLAY_SETTINGS', 'Display settings');
      return;
    }
    // Voice calling: "call Ami" / "Ami ko call karo" / "call 03001234567".
    if (_isCallCommand(normalized)) {
      await _handleCallCommand(normalized);
      return;
    }
    // Reminders: "remind me at 7 to study" / "7 baje mujhe parhai yaad
    // dilao" / "10 minute baad mujhe paani yaad dilao". Reminders fire
    // while Jarvis is running in the background.
    if (_isReminderCommand(normalized)) {
      await _handleReminderCommand(normalized);
      return;
    }
    if (normalized == 'cancel reminder' ||
        normalized == 'cancel all reminders' ||
        normalized == 'reminder cancel karo' ||
        normalized == 'sab reminders cancel karo') {
      _cancelReminders(
          all: normalized.contains('all') || normalized.contains('sab'));
      return;
    }
    // Phase 6 (F17): long-term memory voice commands. Handled locally,
    // like reminders — no Gemini call. The provider is rebuilt after
    // every change so the new facts are in the next answer's system
    // instruction right away.
    final rememberFact = parseRememberCommand(query);
    if (rememberFact != null) {
      await _memoryService.addFact(rememberFact);
      await _rebuildChatProvider();
      _addChatMessage('jarvis', 'Remembered: $rememberFact');
      speak('Got it. I will remember that.');
      return;
    }
    if (isForgetAllCommand(query)) {
      await _memoryService.clearAll();
      await _rebuildChatProvider();
      _addChatMessage(
          'jarvis', 'I forgot everything you asked me to remember.');
      speak('Done. I forgot everything you asked me to remember.');
      return;
    }
    final forgetPhrase = parseForgetCommand(query);
    if (forgetPhrase != null) {
      final removed = await _memoryService.forgetMatching(forgetPhrase);
      await _rebuildChatProvider();
      if (removed == 0) {
        _addChatMessage('jarvis',
            'I could not find anything about "$forgetPhrase" in my saved facts.');
        speak('I could not find anything about that in my saved facts.');
      } else {
        _addChatMessage('jarvis',
            'Forgot $removed ${removed == 1 ? 'fact' : 'facts'} about "$forgetPhrase".');
        speak('Done. I forgot that.');
      }
      return;
    }
    if (isWhatDoYouRememberCommand(query)) {
      final facts = await _memoryService.loadFacts();
      if (facts.isEmpty) {
        _addChatMessage('jarvis',
            'You have not asked me to remember anything yet. Say "remember that ..." and I will keep it.');
        speak('You have not asked me to remember anything yet.');
      } else {
        final listed = facts.map((fact) => '• ${fact.text}').join('\n');
        _addChatMessage('jarvis', 'Here is what I remember:\n$listed');
        final spoken = facts.length == 1
            ? 'I remember one thing: ${facts.first.text}.'
            : 'I remember ${facts.length} things. The latest is: ${facts.last.text}.';
        speak(spoken);
      }
      return;
    }
    // Roman Urdu commands ("whatsapp kholo", "phone lock karo", ...).
    if (_tryUrduCommand(normalized)) return;

    if (normalized.startsWith('open ')) {
      _openApp(normalized);
      return;
    }

    final currentModel = model;
    if (currentModel == null) {
      _addChatMessage('jarvis',
          'AI chat needs a Gemini API key. Open Settings (gear icon) and add your key.');
      speak('AI chat needs a Gemini API key. Open Settings and add your key.');
      return;
    }

    // Say plainly when there is no internet, instead of looking like
    // Jarvis ignored the command.
    if (!await _hasInternet()) {
      _addChatMessage('jarvis',
          'No internet connection — I cannot reach Gemini. Check Wi-Fi or mobile data and try again.');
      speak('No internet connection. Check Wi-Fi or mobile data and try again.');
      return;
    }

    _isProcessingQuery = true;
    // Generation at the start of this request: if STOP is pressed while
    // the answer is loading, the generation changes and the answer is
    // never spoken (v1.1.0 STOP fix).
    final requestGeneration = _speakGeneration;
    // Phase 6 (F22): a relevant knowledge-file excerpt goes into this
    // one request's context only (quoted, file cited as the source).
    final knowledgeContext = buildKnowledgeContext(query, _knowledgeFiles);
    final extraSystemContext =
        knowledgeContext.isEmpty ? null : knowledgeContext;
    try {
      // Retry automatically when Google says the model is busy or the
      // request times out, so a temporary overload does not surface as an
      // error. Up to 3 tries with growing pauses (5s, then 10s).
      String answer = '';
      // F11: stream first when enabled — text appears and speech starts
      // sooner. A null result means streaming produced no text, so the
      // non-streaming path below runs as the fallback.
      var answeredByStreaming = false;
      if (_streamingEnabled) {
        final streamed = await _runStreamingQuery(
          query: query,
          requestGeneration: requestGeneration,
          extraSystemContext: extraSystemContext,
        );
        if (requestGeneration != _speakGeneration) return;
        if (streamed != null) {
          answer = streamed;
          answeredByStreaming = true;
        }
      }
      for (var attempt = 0;
          !answeredByStreaming && attempt < 3;
          attempt++) {
        // STOP pressed while waiting: stop retrying and stay silent.
        if (requestGeneration != _speakGeneration) return;
        try {
          answer = (await currentModel.sendMessage(
            message: query,
            history: _providerHistory,
            extraSystemContext: extraSystemContext,
          ))
              .trim();
          break;
        } on ChatProviderException catch (e) {
          if (requestGeneration != _speakGeneration) return;
          final msg = e.message.toLowerCase();
          final retryable = e.fallbackEligible ||
              msg.contains('overload') ||
              msg.contains('high demand') ||
              msg.contains('timed out') ||
              msg.contains('try again later');
          if (retryable && attempt < 2) {
            await Future.delayed(Duration(seconds: 5 * (attempt + 1)));
            continue;
          }
          rethrow;
        }
      }
      if (answer.isEmpty) {
        if (requestGeneration == _speakGeneration) {
          _addChatMessage('jarvis', "I didn't receive a usable response.");
          speak("I didn't receive a usable response.");
        }
        return;
      }
      conversationHistory
        ..add(GeminiChatMessage(role: 'user', text: query))
        ..add(GeminiChatMessage(role: 'model', text: answer));
      if (conversationHistory.length > 20) {
        conversationHistory.removeRange(0, conversationHistory.length - 20);
      }
      if (mounted) setState(() => responseText = answer);
      // Phase 6 (F20): when the NVIDIA NIM fallback answered, label it
      // in the chat so the user always knows which model answered. The
      // spoken answer stays plain — the label is for the screen only.
      final answeredByFallback = currentModel is FallbackChatProvider &&
          currentModel.lastAnswerWasFallback;
      _addChatMessage(
        'jarvis',
        answeredByFallback
            ? '$answer\n\n— Answered by fallback model (NVIDIA NIM)'
            : answer,
      );
      // STOP pressed while the answer was loading: the text is shown (the
      // user can read it) but it is never spoken. Streamed answers were
      // already spoken sentence by sentence, so they are not re-spoken.
      if (requestGeneration == _speakGeneration && !answeredByStreaming) {
        speak(_shortSpoken(answer));
      }
    } on ChatProviderException catch (e) {
      // A cancelled request (STOP pressed) reports nothing.
      if (requestGeneration != _speakGeneration) return;
      _addChatMessage('jarvis', 'Gemini request failed: ${e.message}');
      // F12: low thud — the request failed.
      _playAckSound('sounds/ack_error.wav');
      speak('Gemini request failed: ${e.message}');
    } catch (_) {
      if (requestGeneration != _speakGeneration) return;
      _addChatMessage('jarvis',
          'Sorry, I could not complete that request. Check your internet connection and API settings.');
      // F12: low thud — the request failed.
      _playAckSound('sounds/ack_error.wav');
      speak('Sorry, I could not complete that request. Check your internet connection and API settings.');
    } finally {
      _isProcessingQuery = false;
      // F16: a STOP pressed while this answer was loading left the
      // conversation without a listener; re-arm it now that the request
      // is gone, so the new command after a STOP is heard. No-op when
      // speech or listening already re-armed it.
      if (mounted && _isInConversationMode && !isSpeaking) {
        _continueConversation();
      }
    }
  }

  /// F11: streams one answer, speaking each complete sentence as it
  /// arrives and showing the partial text live. Returns the full answer,
  /// or null when streaming produced no text (the caller then falls back
  /// to the non-streaming path). STOP works mid-stream: the generation
  /// check returns from the `await for`, which cancels the stream
  /// subscription, and [_stopSpeaking] also closes the Gemini client.
  /// Spoken output is capped (about 500 characters) so a long streamed
  /// answer is not read aloud in full; the whole text stays on screen.
  Future<String?> _runStreamingQuery({
    required String query,
    required int requestGeneration,
    String? extraSystemContext,
  }) async {
    final currentModel = model;
    if (currentModel == null) return null;
    _isStreamingReply = true;
    final buffer = StringBuffer();
    var remainder = '';
    var spokenChars = 0;
    const maxStreamSpokenChars = 500;
    try {
      await for (final delta in currentModel.sendMessageStream(
        message: query,
        history: _providerHistory,
        extraSystemContext: extraSystemContext,
      )) {
        if (requestGeneration != _speakGeneration) return null;
        if (delta.isEmpty) continue;
        buffer.write(delta);
        if (mounted) setState(() => responseText = buffer.toString());
        final split = splitCompleteSentences(remainder + delta);
        remainder = split.remainder;
        for (final sentence in split.sentences) {
          if (requestGeneration != _speakGeneration) return null;
          if (spokenChars >= maxStreamSpokenChars) break;
          spokenChars += sentence.length;
          await speak(sentence);
          if (requestGeneration != _speakGeneration) return null;
        }
      }
    } on ChatProviderException {
      // A partial answer still counts; an empty one falls back.
      if (buffer.isEmpty) return null;
    } catch (_) {
      if (buffer.isEmpty) return null;
    } finally {
      _isStreamingReply = false;
    }
    final answer = buffer.toString().trim();
    if (answer.isEmpty) return null;
    // Speak the trailing partial sentence when it fits the cap.
    if (requestGeneration == _speakGeneration &&
        remainder.trim().isNotEmpty &&
        spokenChars < maxStreamSpokenChars) {
      await speak(remainder.trim());
    }
    // F16: the last spoken sentence finished while _isStreamingReply was
    // still true, so its _finishSpeaking() returned early and never
    // re-armed listening or the follow-up window. Run it once now that
    // the stream is done (harmless when the remainder was just spoken —
    // it only re-arms listening and restarts the window).
    if (mounted && requestGeneration == _speakGeneration) _finishSpeaking();
    return answer;
  }

  // ---- Chat history (on this phone only) ----

  void _startNewHistorySession() {
    _currentSessionId = DateTime.now().millisecondsSinceEpoch;
    _currentSessionTitle = '';
    _currentSessionStartedAt = DateTime.now();
  }

  void _appendToHistorySession(String role, String text) {
    if (_currentSessionId == 0) _startNewHistorySession();
    if (role == 'user' && _currentSessionTitle.isEmpty) {
      _currentSessionTitle =
          text.length > 40 ? '${text.substring(0, 40)}…' : text;
    }
    _saveHistorySession();
  }

  Future<void> _saveHistorySession() async {
    if (_currentSessionId == 0) return;
    // Build the session snapshot first: _chatMessages may be cleared by
    // "New chat" while the preferences write is still in flight.
    final session = <String, dynamic>{
      'id': _currentSessionId,
      'title': _currentSessionTitle.isEmpty ? 'Chat' : _currentSessionTitle,
      'startedAt':
          (_currentSessionStartedAt ?? DateTime.now()).toIso8601String(),
      'messages': _chatMessages
          .map((m) => {'role': m['role'], 'text': m['text']})
          .toList(),
    };
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('jarvis_chat_history_v1');
      final List<dynamic> stored =
          raw == null ? [] : (jsonDecode(raw) as List<dynamic>);
      stored.removeWhere(
          (s) => s is Map && s['id'] == _currentSessionId);
      stored.add(session);
      while (stored.length > 20) {
        stored.removeAt(0);
      }
      await prefs.setString(
          'jarvis_chat_history_v1', jsonEncode(stored));
    } catch (_) {}
  }

  /// Archives the current chat and starts a fresh one.
  void _startNewChat() {
    _saveHistorySession();
    setState(() => _chatMessages.clear());
    _startNewHistorySession();
  }

  /// Phase 6 (F21): loads every on-device source fresh and opens the
  /// search screen. A chat result opens that saved conversation.
  Future<void> _openSearch() async {
    final sessions = await loadChatHistory();
    final prefs = await SharedPreferences.getInstance();
    final reminders =
        parseStoredReminders(prefs.getString(kJarvisRemindersKey));
    final facts = await _memoryService.loadFacts();
    final files = await _knowledgeService.listFiles();
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SearchScreen(
          sessions: sessions,
          reminders: reminders,
          facts: facts,
          files: files,
          onOpenSession: (session) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => HistoryChatView(session: session),
              ),
            );
          },
        ),
      ),
    );
  }

  // ---- Home-screen widget ----

  static const MethodChannel _launchChannel =
      MethodChannel('com.jarvis.jarvis_app/launch');

  /// The home-screen widget opens the app with a flag asking it to start
  /// a conversation right away (no "Hey Jarvis" needed).
  Future<void> _checkWidgetLaunch() async {
    try {
      final start =
          await _launchChannel.invokeMethod<bool>('getStartConversation');
      if (start == true && mounted && !_isInConversationMode) {
        if (!_isBackgroundListening) {
          setState(() => _isBackgroundListening = true);
        }
        _startConversationMode();
      }
    } catch (_) {}
  }

  // ---- Voice calling ----

  bool _isCallCommand(String normalized) {
    return normalized.startsWith('call ') ||
        normalized.startsWith('call karo ') ||
        normalized.contains(' ko call karo') ||
        normalized.contains(' ko call kar do') ||
        normalized.contains(' ko call karna');
  }

  Future<void> _handleCallCommand(String normalized) async {
    var name = normalized
        .replaceAll('call karo', '')
        .replaceAll('call kar do', '')
        .replaceAll('call karna', '')
        .replaceAll('call', '')
        .replaceAll(' ko ', ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    if (name.isEmpty) {
      _addChatMessage(
          'jarvis', 'Who should I call? Say for example: call Ami.');
      speak('Who should I call?');
      return;
    }
    // A bare number goes through the F42 confirmation gate first —
    // Jarvis shows the number and waits for a yes before opening the
    // dialer (where you still tap Call yourself).
    final digits = name.replaceAll(RegExp(r'[^0-9+]'), '');
    if (digits.length >= 7 &&
        RegExp(r'^\+?[0-9]{7,15}$').hasMatch(digits)) {
      await _requestCallConfirmation(digits, name);
      return;
    }
    bool granted = false;
    try {
      // flutter_contacts 2.x: permissions moved to the permissions API;
      // read-only is PermissionType.read.
      granted = await FlutterContacts.permissions
              .request(PermissionType.read) ==
          PermissionStatus.granted;
    } catch (_) {
      granted = false;
    }
    if (!granted) {
      _addChatMessage('jarvis',
          'I need the Contacts permission to call someone by name. Allow Contacts in the app settings, then try again.');
      speak('I need the Contacts permission to call by name.');
      _openAppSettings();
      return;
    }
    List<Contact> contacts = [];
    try {
      // flutter_contacts 2.x: getContacts() is now getAll() with the
      // properties the call needs (name + phone).
      contacts = await FlutterContacts.getAll(
        properties: {ContactProperty.name, ContactProperty.phone},
      );
    } catch (_) {
      contacts = [];
    }
    final query = name.toLowerCase();
    final matches = contacts.where((c) {
      // displayName is nullable in flutter_contacts 2.x.
      final display = (c.displayName ?? '').toLowerCase();
      return display.contains(query) || query.contains(display);
    }).toList();
    if (matches.isEmpty) {
      _addChatMessage('jarvis', 'I could not find a contact named "$name".');
      speak('I could not find a contact named $name.');
      return;
    }
    final withNumbers =
        matches.where((c) => c.phones.isNotEmpty).toList();
    if (withNumbers.isEmpty) {
      final firstName = matches.first.displayName ?? 'That contact';
      _addChatMessage(
          'jarvis', '$firstName has no phone number saved.');
      speak('$firstName has no phone number saved.');
      return;
    }
    if (withNumbers.length == 1) {
      final c = withNumbers.first;
      // F42: confirm by voice first — the dialer opens only after a yes.
      await _requestCallConfirmation(
        c.phones.first.number,
        c.displayName ?? '',
      );
      return;
    }
    _pendingCallCandidates = withNumbers
        .map((c) => {
              'name': c.displayName ?? '',
              'number': c.phones.first.number,
            })
        .toList();
    _pendingCommand = 'call';
    final names =
        withNumbers.map((c) => c.displayName ?? '').join(', ');
    _addChatMessage('jarvis',
        'I found several: $names. Which one? Say the name.');
    speak('I found several contacts with that name. Which one?');
  }

  Future<void> _pickCallCandidate(String normalized) async {
    final candidates = _pendingCallCandidates;
    _pendingCallCandidates = [];
    final pick = int.tryParse(normalized.trim());
    if (pick != null && pick >= 1 && pick <= candidates.length) {
      final c = candidates[pick - 1];
      await _requestCallConfirmation(c['number']!, c['name']!);
      return;
    }
    for (final c in candidates) {
      if (normalized.contains(c['name']!.toLowerCase())) {
        await _requestCallConfirmation(c['number']!, c['name']!);
        return;
      }
    }
    _addChatMessage(
        'jarvis', 'I did not catch which one. Please say the name again.');
    speak('I did not catch which one.');
  }

  Future<void> _dialNumber(String number, String label) async {
    final clean = number.replaceAll(RegExp(r'[^0-9+]'), '');
    final uri = Uri(scheme: 'tel', path: clean);
    try {
      final opened =
          await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (opened) {
        _addChatMessage('jarvis', 'Calling $label…');
        speak('Calling $label.');
      } else {
        _addChatMessage('jarvis', 'I could not open the dialer.');
        speak('I could not open the dialer.');
      }
    } catch (_) {
      _addChatMessage('jarvis', 'I could not open the dialer.');
      speak('I could not open the dialer.');
    }
  }

  // ---- Reminders (fire while Jarvis is running in the background) ----

  bool _isReminderCommand(String normalized) {
    return normalized.contains('remind') ||
        normalized.contains('reminder') ||
        normalized.contains('yaad dilao') ||
        normalized.contains('yaad dila do');
  }

  Future<void> _handleReminderCommand(String normalized) async {
    final parsed = _parseReminder(normalized);
    if (parsed == null) {
      _addChatMessage('jarvis',
          'I could not understand the reminder time. Say for example: remind me at 7 to study, or remind me in 10 minutes to drink water.');
      speak(
          'I could not understand the reminder time. Please say a time, such as 7 o clock, or in 10 minutes.');
      return;
    }
    final id = DateTime.now().millisecondsSinceEpoch;
    _reminders.add({
      'id': id,
      'text': parsed.text,
      'fireAt': parsed.fireAt.toIso8601String(),
    });
    await _saveReminders();
    _armReminderTimer(id, parsed.text, parsed.fireAt);
    // F7 (v1.1.0): durable backstop — fires even if the app is swiped
    // away or the phone restarts. No-ops if already fired/cancelled.
    await ReminderService.schedule(id, parsed.text, parsed.fireAt);
    final time = DateFormat.jm().format(parsed.fireAt);
    _addChatMessage('jarvis', 'Reminder set for $time: ${parsed.text}');
    speak('Reminder set for $time.');
  }

  ({DateTime fireAt, String text})? _parseReminder(String normalized) {
    final now = DateTime.now();
    // Relative: "in 10 minutes remind me to drink water" /
    // "10 minute baad mujhe paani yaad dilao".
    final relative = RegExp(
            r'(\d+)\s*(minute|minutes|min|ghantay?|hour|hours|second|seconds)')
        .firstMatch(normalized);
    final hasRelativeWord = normalized.contains('baad') ||
        normalized.contains('after') ||
        normalized.contains('in ');
    if (relative != null && hasRelativeWord) {
      final value = int.tryParse(relative.group(1) ?? '') ?? 0;
      final unit = relative.group(2) ?? 'minute';
      if (value <= 0) return null;
      final seconds = unit.startsWith('ghant') || unit.startsWith('hour')
          ? value * 3600
          : unit.startsWith('second')
              ? value
              : value * 60;
      var text = normalized
          .replaceAll(relative.group(0)!, '')
          .replaceAll(
              RegExp(
                  r'\b(remind me|remind|reminder|mujhe|yaad dilao|yaad dila do|baad|after|in)\b'),
              '')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      if (text.startsWith('to ')) text = text.substring(3);
      if (text.isEmpty) text = 'Reminder';
      return (fireAt: now.add(Duration(seconds: seconds)), text: text);
    }
    // Absolute: "remind me at 7 to study" / "7 baje mujhe parhai yaad
    // dilao" / "7:30 pm".
    final absolute = RegExp(
      r'(\d{1,2})(?::(\d{1,2}))?\s*(a\.?m\.?|p\.?m\.?)?\s*(baje|bajay|am|pm)?',
    ).firstMatch(normalized);
    if (absolute != null) {
      final hour = int.tryParse(absolute.group(1) ?? '') ?? 0;
      final minute = int.tryParse(absolute.group(2) ?? '0') ?? 0;
      if (hour < 1 || hour > 12 || minute < 0 || minute > 59) return null;
      final marker =
          (absolute.group(3) ?? absolute.group(4) ?? '').toLowerCase();
      var hour24 = hour % 12;
      if (marker.contains('pm') ||
          normalized.contains('shaam') ||
          normalized.contains('raat')) {
        hour24 += 12;
      }
      var fireAt = DateTime(now.year, now.month, now.day, hour24, minute);
      if (fireAt.isBefore(now.add(const Duration(minutes: 1)))) {
        fireAt = fireAt.add(const Duration(days: 1));
      }
      var text = normalized
          .replaceAll(absolute.group(0)!, '')
          .replaceAll(
              RegExp(
                  r'\b(remind me|remind|reminder|mujhe|yaad dilao|yaad dila do|to|at|baje|bajay)\b'),
              '')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      if (text.isEmpty) text = 'Reminder';
      return (fireAt: fireAt, text: text);
    }
    return null;
  }

  Future<void> _loadReminders() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('jarvis_reminders_v1');
      if (raw == null) return;
      final list =
          (jsonDecode(raw) as List<dynamic>).whereType<Map>().toList();
      final now = DateTime.now();
      _reminders = [];
      for (final r in list) {
        final fireAt = DateTime.tryParse(r['fireAt']?.toString() ?? '');
        final text = r['text']?.toString() ?? '';
        final id = r['id'] is int ? r['id'] as int : 0;
        if (fireAt == null || text.isEmpty || id == 0) continue;
        if (fireAt.isBefore(now)) continue;
        _reminders.add(
            {'id': id, 'text': text, 'fireAt': fireAt.toIso8601String()});
        _armReminderTimer(id, text, fireAt);
        // F7 (v1.1.0): re-arm the durable backstop on every launch, so a
        // reminder still fires after a phone restart (Workmanager
        // reschedules its own work, this just keeps it in sync).
        ReminderService.schedule(id, text, fireAt);
      }
    } catch (_) {}
  }

  Future<void> _saveReminders() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('jarvis_reminders_v1', jsonEncode(_reminders));
    } catch (_) {}
  }

  void _armReminderTimer(int id, String text, DateTime fireAt) {
    _reminderTimers[id]?.cancel();
    final delay = fireAt.difference(DateTime.now());
    if (delay.isNegative) return;
    _reminderTimers[id] = Timer(delay, () => _fireReminder(id, text));
  }

  Future<void> _fireReminder(int id, String text) async {
    _reminderTimers.remove(id);
    _reminders.removeWhere((r) => r['id'] == id);
    await _saveReminders();
    // F7 (v1.1.0): the in-app path fired, so the durable backstop is no
    // longer needed for this reminder.
    ReminderService.cancel(id);
    _addChatMessage('jarvis', 'Reminder: $text');
    speak('Reminder, sir: $text');
    _updateListeningNotification('Reminder: $text');
  }

  void _cancelReminders({required bool all}) {
    if (_reminders.isEmpty) {
      _addChatMessage('jarvis', 'There are no reminders set.');
      speak('There are no reminders set.');
      return;
    }
    if (all) {
      for (final t in _reminderTimers.values) {
        t.cancel();
      }
      _reminderTimers.clear();
      _reminders.clear();
      _saveReminders();
      // F7 (v1.1.0): drop the durable backstop for every reminder too.
      ReminderService.cancelAll();
      _addChatMessage('jarvis', 'All reminders cancelled.');
      speak('All reminders cancelled.');
    } else {
      final last = _reminders.last;
      _reminderTimers[last['id'] as int]?.cancel();
      _reminderTimers.remove(last['id'] as int);
      _reminders.removeLast();
      _saveReminders();
      // F7 (v1.1.0): drop the durable backstop for this reminder too.
      ReminderService.cancel(last['id'] as int);
      _addChatMessage('jarvis', 'Reminder cancelled: ${last['text']}');
      speak('Reminder cancelled.');
    }
  }

  // ---- Roman Urdu commands ----

  /// Returns true when the command was handled.
  bool _tryUrduCommand(String normalized) {
    // "whatsapp kholo" / "X kholo" / "X open karo".
    if (normalized.endsWith(' kholo') ||
        normalized.endsWith(' open karo')) {
      final app = normalized
          .replaceAll(' kholo', '')
          .replaceAll(' open karo', '')
          .trim();
      if (app.isNotEmpty) {
        _openApp('open $app');
        return true;
      }
    }
    if (normalized == 'phone lock karo' ||
        normalized == 'mobile lock karo' ||
        normalized == 'lock karo' ||
        normalized == 'phone band karo') {
      _lockPhone();
      return true;
    }
    if (normalized.contains('torch on karo') ||
        normalized.contains('batti on karo') ||
        normalized.contains('flashlight on karo')) {
      _setTorch(true);
      return true;
    }
    if (normalized.contains('torch off karo') ||
        normalized.contains('batti off karo') ||
        normalized.contains('flashlight off karo')) {
      _setTorch(false);
      return true;
    }
    if (normalized.contains('awaz barhao') ||
        normalized.contains('volume upar karo') ||
        normalized.contains('awaz upar karo')) {
      _setVolume('up');
      return true;
    }
    if (normalized.contains('awaz kam karo') ||
        normalized.contains('volume neeche karo') ||
        normalized.contains('awaz neeche karo')) {
      _setVolume('down');
      return true;
    }
    if (normalized.contains('awaz band karo') ||
        normalized == 'khamosh karo') {
      _setVolume('mute');
      return true;
    }
    if (normalized.contains('wifi kholo') ||
        normalized.contains('wifi settings kholo')) {
      _openSettingsPanel('android.settings.WIFI_SETTINGS', 'WiFi settings');
      return true;
    }
    if (normalized.contains('bluetooth kholo')) {
      _openSettingsPanel(
          'android.settings.BLUETOOTH_SETTINGS', 'Bluetooth settings');
      return true;
    }
    if (normalized.contains('time kya hai') ||
        normalized.contains('kitne bajay hain') ||
        normalized == 'time batao') {
      _tellTime();
      return true;
    }
    return false;
  }

  void _searchWeather() async {
    final Uri url = Uri.https('www.google.com', '/search', {'q': 'weather near me'});
    try {
      final opened = await launchUrl(url, mode: LaunchMode.externalApplication);
      // F40: written to the chat too (not just spoken) so the agent
      // loop's verifier can see whether the browser actually opened.
      if (opened) {
        _addChatMessage('jarvis', 'Opening the weather search in your browser.');
      } else {
        _addChatMessage('jarvis', 'I could not open the browser.');
        speak('I could not open the browser.');
      }
    } catch (e) {
      _addChatMessage('jarvis', "I couldn't open the browser. Please check your internet connection.");
      speak(
          "I couldn't open the browser. Please check your internet connection.");
    }
  }

  void _tellTime() {
    String time = DateFormat.jm().format(DateTime.now());
    // F40: also written to the chat (not just spoken) so the agent
    // loop's verifier can see the step's result.
    _addChatMessage('jarvis', 'The current time is $time.');
    speak("The current time is $time");
  }

  /// F38: "what is the date today" — answered instantly, no network.
  void _tellDate() {
    final date = DateFormat.yMMMMEEEEd().format(DateTime.now());
    _addChatMessage('jarvis', 'Today is $date.');
    speak('Today is $date.');
  }

  static const MethodChannel _deviceChannel =
      MethodChannel('com.jarvis.jarvis_app/device');

  /// Locks the screen. Needs the app enabled as a device admin first
  /// (Android only allows device-admin apps to lock the screen).
  Future<void> _lockPhone() async {
    try {
      final active =
          await _deviceChannel.invokeMethod<bool>('isDeviceAdminActive');
      if (active != true) {
        _addChatMessage('jarvis',
            'To lock the phone, Jarvis needs device admin. Opening the setup — tap "Activate", then say "lock phone" again.');
        speak('Please activate device admin first.');
        await _deviceChannel.invokeMethod('requestDeviceAdmin');
        return;
      }
      await _deviceChannel.invokeMethod('lockPhone');
      _addChatMessage('jarvis', 'Phone locked.');
    } catch (e) {
      _addChatMessage('jarvis', 'Could not lock the phone: $e');
      speak('I could not lock the phone.');
    }
  }

  /// F26: "code black" — show the Code Black screen and lock the phone
  /// at once. If device admin is not active yet, the screen stays up
  /// with the setup flow instead of failing silently.
  Future<void> _triggerCodeBlack() async {
    _addChatMessage('jarvis', 'Code black. Locking the phone.');
    speak('Code black. Locking the phone.');
    if (!mounted) return;
    unawaited(
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => CodeBlackScreen(onLock: _lockPhone),
        ),
      ),
    );
    await _lockPhone();
  }

  /// F29: logs one voice expense ("spent 500 on groceries").
  Future<void> _handleExpenseCommand(ParsedExpense parsed) async {
    final entry = await _financeService.addExpense(parsed);
    _addChatMessage(
      'jarvis',
      'Logged Rs ${entry.amount.toStringAsFixed(0)} on ${entry.category} (${entry.note}).',
    );
    speak(
      'Logged ${entry.amount.toStringAsFixed(0)} rupees on ${entry.category}.',
    );
  }

  // ---- Phase 7b (v1.1.0) — F33–F39 ----

  /// F40 (replacing the plain F36 queue handler): runs a compound
  /// command through the agent loop — understand (the router already
  /// classified it as multi-step) → plan (split into steps) → act
  /// (each step through processQuery) → verify (the loop's verifier,
  /// which only counts a step done when its own success signal
  /// appeared) → honest report in the chat and by voice. A failed
  /// step never stops the loop, and the per-step log is on screen
  /// while it runs (one chat line per step + the ⋮ menu log).
  Future<void> _handleAgentLoopCommand(String normalized) async {
    final steps = planAgentSteps(normalized);
    if (steps.isEmpty) return;
    if (mounted) setState(() => _agentLoopRunning = true);
    _agentLoopLog.clear();
    _addChatMessage(
      'jarvis',
      'Agent loop — doing ${steps.length} things, one by one:\n${steps.map((s) => '• $s').join('\n')}',
    );
    final results = await runAgentLoop(
      steps,
      _executeAgentStep,
      onLog: (entry) {
        if (!mounted) return;
        setState(() => _agentLoopLog.add(entry));
        _addChatMessage(
          'jarvis',
          'Agent loop ${entry.index + 1}/${steps.length}: ${entry.command} — ${entry.detail}',
        );
      },
    );
    if (mounted) setState(() => _agentLoopRunning = false);
    final report = formatAgentReport(results);
    _addChatMessage('jarvis', report);
    speak(formatAgentSpokenSummary(results));
  }

  /// F40/F36 shared step executor: runs one command through the
  /// existing processQuery path and verifies it with the agent
  /// loop's verifier — the step only counts as done when
  /// processQuery completes without throwing AND the Jarvis messages
  /// it produced carry the step's expected success signal with no
  /// failure marker. Gemini steps with no API key fail before they
  /// run, with the reason said plainly. A step that asks for a
  /// confirmation (message/call) waits for the user's yes/no (or the
  /// 15 s timeout) before it is judged, so the step's result
  /// reflects what actually happened after confirmation — the loop
  /// never moves on while a confirmation is still open.
  Future<StepResult> _executeAgentStep(String step) async {
    final normalized = step.trim().toLowerCase();
    if (classifyCommand(normalized) == LocalRoute.gemini && model == null) {
      return StepResult.failed(
        step,
        'No Gemini API key — add one in Settings first.',
      );
    }
    final chatBefore = _chatMessages.length;
    try {
      await processQuery(step);
      // Let fire-and-forget local handlers (open app, weather)
      // finish speaking their result before judging the step.
      await Future.delayed(const Duration(milliseconds: 500));
    } catch (e) {
      return StepResult.failed(step, 'Error: $e');
    }
    if (_confirmationGate.isPending) {
      // Wait for the yes/no/timeout (max ~17 s), and keep waiting
      // while a confirmed action is still running — the step is only
      // judged once the gate reaches a terminal state (executed /
      // failed / timed out / cancelled), so a step is never judged
      // on a confirmation that has not finished yet. The wait yields,
      // so the user's answer is still heard and processed while the
      // loop waits — the loop never starts the next step meanwhile.
      for (var waited = 0;
          waited < 68 &&
              (_confirmationGate.isPending ||
                  _confirmationGate.state == ConfirmationState.confirmed);
          waited++) {
        await Future.delayed(const Duration(milliseconds: 250));
      }
    }
    final newJarvisMessages = _chatMessages
        .sublist(chatBefore)
        .where((m) => m['role'] == 'jarvis')
        .map((m) => m['text'] ?? '')
        .toList();
    return verifyAgentStep(step, newJarvisMessages);
  }

  /// F36/F33 executor kept for the macro runner — same agent-loop
  /// verification as [_executeAgentStep].
  Future<StepResult> _executeQueuedStep(String step) =>
      _executeAgentStep(step);

  // ---- Phase 8 (v1.1.0) — F42 confirmation gate + F41 Accessibility ----

  /// F42: opens a confirmation for a do-the-task action. Shows the
  /// exact action on screen, speaks it, and waits for a yes (voice
  /// or the on-screen Confirm button) before [action] runs. The
  /// action NEVER runs from this method — only from
  /// [_handleConfirmationAnswer] after a yes, or from
  /// [_confirmPendingAction] after a tap. A previous pending
  /// confirmation is cancelled first (only one can be live).
  Future<void> _requestConfirmation(
    ConfirmationRequest request,
    Future<void> Function() action,
  ) async {
    _cancelConfirmationSilently();
    _confirmationGate.request(request);
    _pendingConfirmationAction = action;
    _pendingCommand = 'confirm_action';
    _addChatMessage('jarvis', request.prompt);
    speak(request.prompt.replaceAll('\n', ' '));
    _confirmationTimer?.cancel();
    _confirmationTimer = Timer(kConfirmationTimeout, _onConfirmationTimeout);
    if (mounted) setState(() {});
  }

  /// F42: the user's answer while a confirmation is pending. Yes →
  /// run the action and report honestly (sent / opened / could not
  /// …). No → cancel, nothing happens. Anything else → stay pending
  /// and re-ask (the gate does not guess).
  Future<void> _handleConfirmationAnswer(String normalized) async {
    final request = _confirmationGate.pendingRequest;
    final action = _pendingConfirmationAction;
    switch (parseConfirmationAnswer(normalized)) {
      case ConfirmationAnswer.yes:
        if (!_confirmationGate.confirm()) {
          await _finishConfirmationCancelled(
            request,
            'Too late — the confirmation had already expired. Nothing was sent or called.',
          );
          return;
        }
        _confirmationTimer?.cancel();
        _confirmationTimer = null;
        _pendingCommand = '';
        final run = action;
        _pendingConfirmationAction = null;
        var success = false;
        try {
          if (run != null) {
            await run();
            success = true;
          }
        } catch (_) {
          success = false;
        }
        // The action reports its own result in the chat (opened /
        // could not open …); the gate records whether it ran. A
        // false here means the action itself reported failure.
        _confirmationGate.markExecuted(success);
        if (mounted) setState(() {});
      case ConfirmationAnswer.no:
        await _finishConfirmationCancelled(request, null);
      case ConfirmationAnswer.other:
        _addChatMessage(
          'jarvis',
          'Say "yes" to confirm, or "no" to cancel. I will cancel on my own if you do not answer within 15 seconds.',
        );
        speak('Say yes to confirm, or no to cancel.');
    }
  }

  /// F42: the on-screen Confirm button — same path as saying yes.
  Future<void> _confirmPendingAction() async {
    if (_pendingCommand == 'confirm_action' &&
        _confirmationGate.isPending) {
      await _handleConfirmationAnswer('yes');
    }
  }

  /// F42: the on-screen Cancel button — same path as saying no.
  Future<void> _declinePendingAction() async {
    if (_pendingCommand == 'confirm_action' &&
        _confirmationGate.isPending) {
      await _handleConfirmationAnswer('no');
    }
  }

  /// F42: the 15 s timer fired with no answer — cancel, say so, and
  /// never run the action.
  void _onConfirmationTimeout() {
    final request = _confirmationGate.pendingRequest;
    if (!_confirmationGate.markTimedOut()) return;
    _confirmationTimer = null;
    _pendingCommand = '';
    _pendingConfirmationAction = null;
    final text = request == null
        ? 'Confirmation timed out — nothing was sent or called.'
        : 'Confirmation timed out. ${request.cancelledText}';
    _addChatMessage('jarvis', text);
    speak(text);
    if (mounted) setState(() {});
  }

  /// F42: shared cancel path (no / timeout / STOP). Reports the
  /// cancellation in the chat and by voice, then clears the gate.
  Future<void> _finishConfirmationCancelled(
    ConfirmationRequest? request,
    String? overrideText,
  ) async {
    _confirmationTimer?.cancel();
    _confirmationTimer = null;
    _confirmationGate.decline();
    _pendingCommand = '';
    _pendingConfirmationAction = null;
    final text = overrideText ??
        (request == null
            ? 'Cancelled — nothing was sent or called.'
            : 'Cancelled. ${request.cancelledText}');
    _addChatMessage('jarvis', text);
    speak(text);
    if (mounted) setState(() {});
  }

  /// F42: drops a pending confirmation silently (a new confirmation
  /// supersedes it, or the flow is being reset). Never runs the
  /// action.
  void _cancelConfirmationSilently() {
    _confirmationTimer?.cancel();
    _confirmationTimer = null;
    _confirmationGate.cancel();
    _confirmationGate.reset();
    _pendingConfirmationAction = null;
    if (_pendingCommand == 'confirm_action') _pendingCommand = '';
  }

  /// F42: a call goes through the confirmation gate instead of
  /// opening the dialer at once. The user sees the name + number,
  /// says yes (or taps Confirm), and only then does [_dialNumber]
  /// open the dialer — where the user still has to tap Call.
  Future<void> _requestCallConfirmation(String number, String label) async {
    final clean = number.replaceAll(RegExp(r'[^0-9+]'), '');
    await _requestConfirmation(
      ConfirmationRequest(
        kind: ConfirmationKind.call,
        summary: 'Call $label ($clean)',
        detail: clean,
      ),
      () => _dialNumber(number, label),
    );
  }

  /// F41: runs one accessibility action (tap by text / type / go
  /// back / scroll). Only ever called when the Jarvis toggle is on
  /// (see the processQuery branch); the service also refuses when
  /// Android has Jarvis switched off. Every attempt is logged on
  /// screen with the prefix "Accessibility:" so the agent loop's
  /// verifier can tell it happened, and the log screen shows it too.
  Future<void> _handleAccessibilityCommand(
    AccessibilityCommand command,
  ) async {
    final done = await _accessibilityService.performAction(
      command.action,
      text: command.text,
    );
    final entry = _accessibilityService.log.lastOrNull;
    final detail = entry?.reason.isNotEmpty == true
        ? entry!.reason
        : (done ? 'done' : 'failed');
    final label = command.action.label;
    final target = command.text == null ? '' : ' "${command.text}"';
    _addChatMessage(
      'jarvis',
      'Accessibility: $label$target — $detail',
    );
    speak(done
        ? '${label.toLowerCase()} done.'
        : 'I could not do that. $detail');
    if (mounted) setState(() {});
  }

  /// F33: macro voice commands — start/stop recording, run, delete,
  /// list. Recording captures the commands that follow (see the
  /// capture block in processQuery) and still runs them normally.
  Future<void> _handleMacroCommand(String normalized) async {
    if (normalized == 'show my macros' || normalized == 'list macros') {
      if (!mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => MacrosScreen(
            macroService: _macroService,
            onRunMacro: _runMacro,
          ),
        ),
      );
      return;
    }
    final deleteName = parseMacroDeleteName(normalized);
    if (deleteName != null) {
      final deleted = await _macroService.deleteMacro(deleteName);
      if (deleted) {
        _addChatMessage('jarvis', 'Deleted the macro "$deleteName".');
        speak('Macro deleted.');
      } else {
        _addChatMessage('jarvis', 'I could not find a macro called "$deleteName".');
        speak('I could not find a macro by that name.');
      }
      return;
    }
    final recordName = parseMacroRecordName(normalized);
    if (recordName != null || normalized == 'record macro' || normalized == 'start recording macro') {
      final name = (recordName ?? '').trim();
      if (_macroRecording) {
        _addChatMessage('jarvis', 'I am already recording a macro. Say "stop recording" to finish it first.');
        speak('Already recording a macro.');
        return;
      }
      _macroRecording = true;
      _macroRecordName = name;
      _macroRecordSteps.clear();
      if (name.isEmpty) {
        _pendingCommand = 'macro_name';
        _addChatMessage('jarvis', 'Recording. Say the commands one by one, then say "stop recording". What should this macro be called?');
        speak('Recording. What should this macro be called?');
      } else {
        _addChatMessage('jarvis', 'Recording macro "$name". Say the commands one by one, then say "stop recording".');
        speak('Recording macro $name. Say your commands.');
      }
      return;
    }
    final runName = parseMacroRunName(normalized);
    if (runName != null) {
      final macros = await _macroService.loadMacros();
      final macro = findMacro(macros, runName);
      if (macro == null) {
        _addChatMessage('jarvis', 'I could not find a macro called "$runName". Say "record macro $runName" to make one, or "show my macros" to see them.');
        speak('I could not find a macro by that name.');
        return;
      }
      await _runMacro(macro);
      return;
    }
  }

  /// F33: replays a macro's steps through the queue runner, with the
  /// same honest per-step report as F36.
  Future<void> _runMacro(Macro macro) async {
    _addChatMessage(
      'jarvis',
      'Running macro "${macro.name}" (${macro.steps.length} steps).',
    );
    final results = await runTaskQueue(macro.steps, _executeQueuedStep);
    final report = formatQueueReport(results);
    _addChatMessage('jarvis', report);
    speak(formatQueueSpokenSummary(results));
  }

  /// F33: finishes a recording. With no name, or no steps captured,
  /// nothing is saved and Jarvis says so.
  Future<void> _finishMacroRecording(String name) async {
    if (!_macroRecording) return;
    final resolvedName = name.trim().isEmpty ? _macroRecordName : name.trim();
    final steps = List<String>.from(_macroRecordSteps);
    _macroRecording = false;
    _macroRecordName = '';
    _macroRecordSteps.clear();
    if (resolvedName.isEmpty) {
      _addChatMessage('jarvis', 'Recording stopped, but no name was given — nothing was saved. Say "record macro" and give it a name to try again.');
      speak('No name given, so nothing was saved.');
      return;
    }
    if (steps.isEmpty) {
      _addChatMessage('jarvis', 'Recording stopped, but no commands were captured — nothing was saved for "$resolvedName".');
      speak('No commands were captured, so nothing was saved.');
      return;
    }
    await _macroService.saveMacro(
      Macro(name: resolvedName, steps: steps, createdAt: DateTime.now()),
    );
    _addChatMessage(
      'jarvis',
      'Saved macro "$resolvedName" with ${steps.length} steps:\n${steps.map((s) => '• $s').join('\n')}\nSay "run $resolvedName" to replay it.',
    );
    speak('Macro $resolvedName saved with ${steps.length} steps.');
  }

  /// F34: starts a message draft — finds the contact, then either
  /// asks which one (several matches), asks what to say (no text),
  /// asks SMS or WhatsApp (no channel named), or opens the draft.
  /// Jarvis never sends anything itself.
  Future<void> _handleMessageDraft(String query) async {
    final request = parseMessageDraft(query);
    if (request == null) return;
    if (request.body.isEmpty) {
      _pendingDraftRequest = request;
      _pendingCommand = 'message_body';
      _addChatMessage('jarvis', 'What should the message to ${request.recipientName} say?');
      speak('What should the message say?');
      return;
    }
    final candidates =
        await _messageDraftService.findContacts(request.recipientName);
    if (candidates.isEmpty) {
      _addChatMessage('jarvis', 'I could not find a contact named "${request.recipientName}".');
      speak('I could not find a contact by that name.');
      return;
    }
    if (candidates.length == 1) {
      await _continueDraftWithContact(request, candidates.first);
      return;
    }
    _pendingDraftRequest = request;
    _pendingDraftCandidates = candidates;
    _pendingCommand = 'message_pick';
    final names = candidates
        .asMap()
        .entries
        .map((e) => '${e.key + 1}. ${e.value.name} (${e.value.number})')
        .join('\n');
    _addChatMessage(
      'jarvis',
      'I found several contacts for "${request.recipientName}":\n$names\nWhich one? Say the name or the number.',
    );
    speak('I found several contacts. Which one?');
  }

  /// F34: the user picked one of several matching contacts.
  Future<void> _pickDraftCandidate(String normalized) async {
    final request = _pendingDraftRequest;
    final candidates = _pendingDraftCandidates;
    _pendingDraftRequest = null;
    _pendingDraftCandidates = [];
    if (request == null) return;
    final pick = int.tryParse(normalized.trim());
    if (pick != null && pick >= 1 && pick <= candidates.length) {
      await _continueDraftWithContact(request, candidates[pick - 1]);
      return;
    }
    final matches = matchDraftContacts(candidates, normalized);
    if (matches.length == 1) {
      await _continueDraftWithContact(request, matches.first);
      return;
    }
    if (matches.length > 1) {
      _pendingDraftRequest = request;
      _pendingDraftCandidates = matches;
      _pendingCommand = 'message_pick';
      _addChatMessage('jarvis', 'Still several matches — say the full name or the number of the list.');
      speak('Which one exactly?');
      return;
    }
    _addChatMessage('jarvis', 'I did not catch which one. The draft was not opened — say "message ${request.recipientName} that ..." again to retry.');
    speak('I did not catch which one.');
  }

  /// F34: the message text, when the first command had none.
  Future<void> _setDraftBody(String query) async {
    final request = _pendingDraftRequest;
    _pendingDraftRequest = null;
    if (request == null) return;
    final body = query.trim();
    if (body.isEmpty) {
      _addChatMessage('jarvis', 'No message text given — the draft was not made.');
      speak('No message text given.');
      return;
    }
    final withBody = MessageDraftRequest(
      recipientName: request.recipientName,
      body: body,
      channel: request.channel,
    );
    final candidates =
        await _messageDraftService.findContacts(withBody.recipientName);
    if (candidates.isEmpty) {
      _addChatMessage('jarvis', 'I could not find a contact named "${withBody.recipientName}".');
      speak('I could not find a contact by that name.');
      return;
    }
    if (candidates.length == 1) {
      await _continueDraftWithContact(withBody, candidates.first);
      return;
    }
    _pendingDraftRequest = withBody;
    _pendingDraftCandidates = candidates;
    _pendingCommand = 'message_pick';
    final names = candidates
        .asMap()
        .entries
        .map((e) => '${e.key + 1}. ${e.value.name} (${e.value.number})')
        .join('\n');
    _addChatMessage('jarvis', 'I found several contacts:\n$names\nWhich one?');
    speak('I found several contacts. Which one?');
  }

  /// F34: with a contact settled, either ask SMS vs WhatsApp or
  /// open the draft in the named app.
  Future<void> _continueDraftWithContact(
    MessageDraftRequest request,
    DraftContact contact,
  ) async {
    if (request.channel == DraftChannel.unspecified) {
      _pendingDraftRequest = request;
      _pendingDraftContact = contact;
      _pendingCommand = 'message_channel';
      _addChatMessage(
        'jarvis',
        'Message to ${contact.name} (${contact.number}):\n"${request.body}"\n\nSMS or WhatsApp?',
      );
      speak('SMS or WhatsApp?');
      return;
    }
    await _openMessageDraft(request, contact);
  }

  /// F34: the user picked SMS or WhatsApp for a pending draft.
  Future<void> _setDraftChannel(String normalized) async {
    final request = _pendingDraftRequest;
    final contact = _pendingDraftContact;
    _pendingDraftRequest = null;
    _pendingDraftContact = null;
    if (request == null || contact == null) return;
    if (normalized.contains('whatsapp') || normalized.contains('whats app')) {
      await _openMessageDraft(
        MessageDraftRequest(
          recipientName: request.recipientName,
          body: request.body,
          channel: DraftChannel.whatsapp,
        ),
        contact,
      );
      return;
    }
    if (normalized.contains('sms') || normalized.contains('text message')) {
      await _openMessageDraft(
        MessageDraftRequest(
          recipientName: request.recipientName,
          body: request.body,
          channel: DraftChannel.sms,
        ),
        contact,
      );
      return;
    }
    _addChatMessage('jarvis', 'I did not catch that — SMS or WhatsApp? The draft is still ready; say which app to open it in.');
    speak('SMS or WhatsApp?');
    _pendingDraftRequest = request;
    _pendingDraftContact = contact;
    _pendingCommand = 'message_channel';
  }

  /// F42: with the contact and channel settled, Jarvis shows the
  /// typed message on screen and WAITS for a yes before opening the
  /// app — it never opens the draft (let alone sends anything)
  /// without the user's explicit confirmation in this moment. After
  /// a yes, [_executeMessageDraft] opens the app with the text
  /// prefilled and the user still presses send themselves. After a
  /// no, or 15 s of silence, nothing opens.
  Future<void> _openMessageDraft(
    MessageDraftRequest request,
    DraftContact contact,
  ) async {
    final isWhatsApp = request.channel == DraftChannel.whatsapp;
    await _requestConfirmation(
      ConfirmationRequest(
        kind: ConfirmationKind.message,
        summary:
            'Message ${contact.name} (${contact.number}) via ${isWhatsApp ? 'WhatsApp' : 'SMS'}',
        detail: request.body,
      ),
      () => _executeMessageDraft(request, contact),
    );
  }

  /// F42: the confirmed half of [_openMessageDraft] — shows the draft
  /// on screen and opens the messaging app with it prefilled. The
  /// user presses send themselves — this method never sends anything.
  Future<void> _executeMessageDraft(
    MessageDraftRequest request,
    DraftContact contact,
  ) async {
    final isWhatsApp = request.channel == DraftChannel.whatsapp;
    final uri = isWhatsApp
        ? buildWhatsAppDraftUri(contact.number, request.body)
        : buildSmsDraftUri(contact.number, request.body);
    _addChatMessage(
      'jarvis',
      'Draft for ${contact.name} (${isWhatsApp ? 'WhatsApp' : 'SMS'}):\n"${request.body}"\n\nOpening the app now — press send yourself. I did not send anything.',
    );
    speak('Draft ready. Opening ${isWhatsApp ? 'WhatsApp' : 'messages'} — press send yourself.');
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened) {
        _addChatMessage('jarvis', 'I could not open ${isWhatsApp ? 'WhatsApp' : 'the messaging app'}. The draft is above — copy it and send it yourself.');
        speak('I could not open the app.');
      }
    } catch (_) {
      _addChatMessage('jarvis', 'I could not open ${isWhatsApp ? 'WhatsApp' : 'the messaging app'}. The draft is above — copy it and send it yourself.');
      speak('I could not open the app.');
    }
  }

  /// F35: starts a voice-guided form. Jarvis asks the first field;
  /// each later utterance is an answer (see _handleFormAnswer).
  Future<void> _handleFormStart(String query) async {
    final template = parseFormStart(query);
    if (template == null) return;
    _formTemplate = template;
    _formAnswers.clear();
    _formFieldIndex = 0;
    _pendingCommand = 'form';
    final first = template.fields.first;
    _addChatMessage(
      'jarvis',
      'Let\'s fill in a ${template.title.toLowerCase()}. ${first.prompt}',
    );
    speak(first.prompt);
  }

  /// F35: one field's answer. The answer is repeated back, then the
  /// next field is asked. "no" / "change that" re-asks the same
  /// field; "cancel" abandons the draft. When the last field is
  /// answered the draft is rendered, saved locally, and shown —
  /// never submitted anywhere.
  Future<void> _handleFormAnswer(String query) async {
    final template = _formTemplate;
    if (template == null) {
      _pendingCommand = '';
      return;
    }
    final normalized = query.trim().toLowerCase();
    if (normalized == 'cancel' || normalized == 'stop filling' || normalized == 'cancel form') {
      _pendingCommand = '';
      _formTemplate = null;
      _formAnswers.clear();
      _addChatMessage('jarvis', 'Form cancelled — nothing was saved.');
      speak('Form cancelled.');
      return;
    }
    final field = template.fields[_formFieldIndex];
    if (normalized == 'no' ||
        normalized.startsWith('no ') ||
        normalized.contains('change that') ||
        normalized.contains('wrong') ||
        normalized == 'repeat') {
      _addChatMessage('jarvis', 'No problem — ${field.prompt}');
      speak(field.prompt);
      return;
    }
    final answer = query.trim();
    if (answer.isEmpty) {
      _addChatMessage('jarvis', 'I did not catch that — ${field.prompt}');
      speak(field.prompt);
      return;
    }
    _formAnswers[field.key] = answer;
    _addChatMessage('jarvis', '${field.label}: $answer');
    _formFieldIndex++;
    if (_formFieldIndex >= template.fields.length) {
      _pendingCommand = '';
      _formTemplate = null;
      final body = renderFormDraft(template, _formAnswers);
      _formAnswers.clear();
      await _formDraftService.saveDraft(template.title, body);
      _addChatMessage(
        'jarvis',
        'Here is your ${template.title.toLowerCase()} draft (saved in Forms — copy or share it from there):\n\n$body',
      );
      speak('Draft ready. It is saved in Forms — you can copy or share it from there.');
      return;
    }
    final next = template.fields[_formFieldIndex];
    _addChatMessage('jarvis', 'Got it. ${next.prompt}');
    speak(next.prompt);
  }

  /// F37: "how long to X?" — resolves the start point (the phone's
  /// last known location, with the location permission), geocodes
  /// the destination, routes with free OSRM, and reports distance +
  /// ETA. No live traffic, no key.
  Future<void> _handleCommute(String query) async {
    final parsed = parseCommuteDestination(query);
    if (parsed == null) return;
    var locationGranted = false;
    try {
      locationGranted =
          await Permission.location.request().isGranted;
    } catch (_) {
      locationGranted = false;
    }
    LatLng? from;
    if (locationGranted) {
      from = await _commuteService.getLastKnownLocation();
    }
    if (from == null) {
      _pendingCommute = parsed;
      _pendingCommand = 'commute_start';
      _addChatMessage(
        'jarvis',
        'I could not read this phone\'s location${locationGranted ? '' : ' (the location permission is not granted)'}. Where are you starting from? Say a place, for example "Faisalabad".',
      );
      speak('I could not read your location. Where are you starting from?');
      return;
    }
    await _runCommute(from, parsed);
  }

  /// F37: the user gave a starting place after the location could
  /// not be read — geocode it, then route as usual.
  Future<void> _handleCommuteWithStart(
    ({String destination, CommuteMode mode}) pending,
    String startQuery,
  ) async {
    final from = await _commuteService.geocode(startQuery.trim());
    if (from == null) {
      _addChatMessage(
        'jarvis',
        'I could not find "$startQuery" as a starting place. Say "how long to ${pending.destination}" again with a different starting place.',
      );
      speak('I could not find that starting place.');
      return;
    }
    await _runCommute(from, pending);
  }

  /// F37: geocodes the destination, routes, and reports. A
  /// destination found through Nominatim is saved as a place, so
  /// the next "how long to FMU" needs no network lookup for it.
  Future<void> _runCommute(
    LatLng from,
    ({String destination, CommuteMode mode}) parsed,
  ) async {
    final to = await _commuteService.geocode(parsed.destination);
    if (to == null) {
      _addChatMessage(
        'jarvis',
        'I could not find "${parsed.destination}". Check the spelling and try again.',
      );
      speak('I could not find that place.');
      return;
    }
    if (to.label.isNotEmpty) {
      await _commuteService.savePlace(parsed.destination, to);
    }
    final route = await _commuteService.getRoute(from, to, parsed.mode);
    if (route == null) {
      _addChatMessage(
        'jarvis',
        'Routing failed — check the internet connection and try again.',
      );
      speak('Routing failed. Check the internet connection.');
      return;
    }
    final summary = _commuteService.formatRouteSummary(
      fromLabel: from.label.isEmpty ? 'your location' : from.label,
      toLabel: to.label.isEmpty ? parsed.destination : to.label,
      route: route,
    );
    _addChatMessage('jarvis', summary);
    speak(summary);
  }

  /// F39: Shizuku voice controls — force-stop / disable / enable an
  /// app, or toggle mobile data. Only runs when the Shizuku toggle
  /// is on AND Shizuku is installed, running and authorised;
  /// otherwise the reason is said plainly and nothing runs.
  Future<void> _handleShizukuCommand(String normalized) async {
    final parsed = parseShizukuCommand(normalized);
    if (parsed == null) return;
    if (!await _shizukuService.isEnabled()) {
      _addChatMessage(
        'jarvis',
        'Shizuku controls are switched off. Switch them on in Settings first — they also need the free Shizuku app installed, running and authorised.',
      );
      speak('Shizuku controls are switched off. Turn them on in Settings first.');
      return;
    }
    final status = await _shizukuService.getStatus();
    if (status != ShizukuStatus.ready) {
      final reason = switch (status) {
        ShizukuStatus.notInstalled =>
          'Shizuku is not installed. Install the free Shizuku app first.',
        ShizukuStatus.notRunning =>
          'Shizuku is installed but its service is not running. Open the Shizuku app and start it.',
        ShizukuStatus.notAuthorised =>
          'Shizuku is running, but Jarvis is not authorised yet. Open the Shizuku screen and tap "Authorise Jarvis".',
        ShizukuStatus.ready => '',
        ShizukuStatus.unknown =>
          'I could not check Shizuku right now. Try again.',
      };
      _addChatMessage('jarvis', reason);
      speak(reason);
      return;
    }
    if (parsed.control == ShizukuControl.toggleMobileData) {
      final output = await _shizukuService.runControl(
        ShizukuControl.toggleMobileData,
        enable: parsed.enable,
      );
      if (output == null) {
        _addChatMessage('jarvis', 'Mobile data could not be changed through Shizuku.');
        speak('Mobile data could not be changed.');
      } else {
        final on = parsed.enable == true;
        _addChatMessage('jarvis', 'Mobile data ${on ? 'on' : 'off'}.');
        speak('Mobile data ${on ? 'on' : 'off'}.');
      }
      return;
    }
    final package = _resolveAppPackage(parsed.appName ?? '');
    if (package == null) {
      _addChatMessage(
        'jarvis',
        'I could not find an app called "${parsed.appName}". Open the Connected apps screen to see which apps Jarvis knows.',
      );
      speak('I could not find an app by that name.');
      return;
    }
    final output = await _shizukuService.runControl(
      parsed.control,
      package: package,
    );
    final label = _connectedApps[package] ?? package;
    if (output == null) {
      _addChatMessage('jarvis', 'Shizuku could not do that to $label. The app may not allow it, or Shizuku lost authorisation.');
      speak('Shizuku could not do that.');
      return;
    }
    final verb = switch (parsed.control) {
      ShizukuControl.forceStopApp => 'Force-stopped $label.',
      ShizukuControl.disableApp => 'Disabled $label.',
      ShizukuControl.enableApp => 'Enabled $label.',
      ShizukuControl.toggleMobileData => '',
    };
    _addChatMessage('jarvis', verb);
    speak(verb);
  }

  /// Resolves a spoken app name to a package from the connected-apps
  /// map (label match, case-insensitive). Null when no app matches.
  String? _resolveAppPackage(String appName) {
    final wanted = appName.trim().toLowerCase();
    if (wanted.isEmpty) return null;
    for (final entry in _connectedApps.entries) {
      final label = entry.value.toLowerCase();
      if (label == wanted || label.contains(wanted) || wanted.contains(label)) {
        return entry.key;
      }
    }
    return null;
  }

  /// F27: reads today's calendar and speaks the summary, then opens
  /// the Calendar screen (which offers the permission when missing).
  Future<void> _handleCalendarQuery() async {
    final events = await _calendarService.getTodayEvents();
    if (events.isEmpty) {
      _addChatMessage(
        'jarvis',
        'No events today — or I cannot read the calendar yet. Opening the Calendar screen so you can grant the permission.',
      );
      speak('No events today, or I cannot read the calendar yet.');
    } else {
      final next = nextEvent(events);
      final count = events.length;
      final summary = next == null
          ? 'You have $count event${count == 1 ? '' : 's'} today, all finished.'
          : 'You have $count event${count == 1 ? '' : 's'} today. Next: ${formatEventLine(next)}.';
      _addChatMessage('jarvis', summary);
      speak(summary);
    }
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            CalendarScreen(calendarService: _calendarService),
      ),
    );
  }

  /// F28: reads unread Gmail (when connected) and speaks a short
  /// summary, then opens the triage screen. When Gmail is not
  /// connected, it says so and opens the setup instead.
  Future<void> _handleMailQuery() async {
    final connected = await _gmailService.hasToken();
    final enabled = await _gmailService.isEnabled();
    if (!connected || !enabled) {
      _addChatMessage(
        'jarvis',
        'Email triage is not connected yet — it needs a Gmail access token. Opening the Email triage screen for the setup.',
      );
      speak('Email triage is not connected yet. Opening the setup screen.');
    } else {
      try {
        final messages = await _gmailService.listUnread(maxResults: 5);
        final summary = messages.isEmpty
            ? 'No unread messages.'
            : 'You have ${messages.length} unread message${messages.length == 1 ? '' : 's'}. The newest is from ${messages.first.sender}: ${messages.first.subject}.';
        _addChatMessage('jarvis', summary);
        speak(summary);
      } on GmailException catch (e) {
        _addChatMessage('jarvis', e.message);
        speak('Gmail triage is not working right now.');
      }
    }
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            GmailTriageScreen(gmailService: _gmailService),
      ),
    );
  }

  Future<void> _setTorch(bool on) async {
    try {
      final result = await _deviceChannel
          .invokeMethod<String>('setTorch', <String, dynamic>{'on': on});
      if (result == 'NO_PERMISSION') {
        _addChatMessage('jarvis',
            'Flashlight needs the Camera permission. Opening app settings — allow Camera, then try again.');
        speak('Flashlight needs the Camera permission.');
        _openAppSettings();
        return;
      }
      _addChatMessage('jarvis', on ? 'Flashlight on.' : 'Flashlight off.');
      speak(on ? 'Flashlight on.' : 'Flashlight off.');
    } catch (e) {
      _addChatMessage('jarvis', 'Could not change the flashlight: $e');
    }
  }

  Future<void> _setVolume(String direction) async {
    try {
      await _deviceChannel.invokeMethod(
          'setVolume', <String, dynamic>{'direction': direction});
      _addChatMessage('jarvis', 'Volume $direction.');
    } catch (e) {
      _addChatMessage('jarvis', 'Could not change the volume: $e');
    }
  }

  Future<void> _openSettingsPanel(String action, String label) async {
    try {
      final intent = AndroidIntent(
        action: action,
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      _addChatMessage('jarvis', 'Opening $label.');
    } catch (e) {
      _addChatMessage('jarvis', "I couldn't open $label.");
    }
  }

  Future<void> _openAppSettings() async {
    try {
      final intent = AndroidIntent(
        action: 'android.settings.APPLICATION_DETAILS_SETTINGS',
        data: 'package:com.jarvis.jarvis_app',
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
    } catch (_) {}
  }

  void _openApp(String query) async {
    String cleanedQuery = query.toLowerCase().replaceAll("open", "").trim();
    // 1. Apps the user connected (any app on the phone).
    String? connectedPackage;
    for (final entry in _connectedApps.entries) {
      final label = entry.value.toLowerCase();
      if (label == cleanedQuery || cleanedQuery.contains(label)) {
        connectedPackage = entry.key;
        break;
      }
    }
    if (connectedPackage != null) {
      try {
        final intent = AndroidIntent(
          action: 'android.intent.action.MAIN',
          category: 'android.intent.category.LAUNCHER',
          package: connectedPackage,
          flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
        );
        await intent.launch();
        _addChatMessage('jarvis', 'Opening ${_connectedApps[connectedPackage]}');
        speak('Opening ${_connectedApps[connectedPackage]}');
      } catch (e) {
        _addChatMessage('jarvis',
            "I couldn't open ${_connectedApps[connectedPackage]}.");
        speak("I couldn't open ${_connectedApps[connectedPackage]}.");
      }
      return;
    }
    Map<String, String> appMap = {
      "chrome": "com.android.chrome",
      "whatsapp": "com.whatsapp",
      "camera": "com.android.camera",
      "gallery": "com.android.gallery3d",
      "photos": "com.google.android.apps.photos",
      "youtube": "com.google.android.youtube",
      "maps": "com.google.android.apps.maps",
      "gmail": "com.google.android.gm",
      "settings": "com.android.settings",
      "play store": "com.android.vending",
      "calculator": "com.android.calculator2",
      "calendar": "com.google.android.calendar",
      "clock": "com.android.deskclock",
      "contacts": "com.android.contacts",
      "phone": "com.android.dialer",
      "messages": "com.android.mms",
      "file manager": "com.android.documentsui",
      "files": "com.android.documentsui",
      "music": "com.android.music",
      "sound recorder": "com.android.soundrecorder",
      "notes": "com.android.notes",
      "notepad": "com.android.notes",
      "browser": "com.android.chrome",
      "internet": "com.android.chrome",
      "email": "com.google.android.gm",
      "mail": "com.google.android.gm",
      "camera app": "com.android.camera",
      "gallery app": "com.android.gallery3d",
      "photos app": "com.google.android.apps.photos",
      "youtube app": "com.google.android.youtube",
      "maps app": "com.google.android.apps.maps",
      "gmail app": "com.google.android.gm",
      "settings app": "com.android.settings",
      "play store app": "com.android.vending",
      "calculator app": "com.android.calculator2",
      "calendar app": "com.google.android.calendar",
      "clock app": "com.android.deskclock",
      "contacts app": "com.android.contacts",
      "phone app": "com.android.dialer",
      "messages app": "com.android.mms",
      "file manager app": "com.android.documentsui",
      "files app": "com.android.documentsui",
      "music app": "com.android.music",
      "sound recorder app": "com.android.soundrecorder",
      "notes app": "com.android.notes",
      "notepad app": "com.android.notes",
      "browser app": "com.android.chrome",
      "internet app": "com.android.chrome",
      "email app": "com.google.android.gm",
      "mail app": "com.google.android.gm",
      "instagram": "com.instagram.android",
      "facebook": "com.facebook.katana",
      "telegram": "org.telegram.messenger",
      "tiktok": "com.zhiliaoapp.musically",
      "spotify": "com.spotify.music",
      "snapchat": "com.snapchat.android",
      "instagram app": "com.instagram.android",
      "facebook app": "com.facebook.katana",
      "telegram app": "org.telegram.messenger",
      "tiktok app": "com.zhiliaoapp.musically",
      "spotify app": "com.spotify.music",
      "snapchat app": "com.snapchat.android"
    };

    debugPrint("Attempting to open app from query: '$cleanedQuery'");

    String? packageToOpen = appMap[cleanedQuery];

    if (packageToOpen == null) {
      for (var entry in appMap.entries) {
        if (cleanedQuery.contains(entry.key)) {
          packageToOpen = entry.value;
          break;
        }
      }
    }

    if (packageToOpen != null) {
      try {
        final intent = AndroidIntent(
          action: 'android.intent.action.MAIN',
          category: 'android.intent.category.LAUNCHER',
          package: packageToOpen,
          flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
        );

        await intent.launch();
        _addChatMessage('jarvis', 'Opening ${cleanedQuery.trim()}');
        speak("Opening ${cleanedQuery.trim()}");
      } catch (e) {
        debugPrint("Error launching app: $e");

        final playStoreUrl = Uri(scheme: 'market', host: 'search', queryParameters: {'q': cleanedQuery});
        try {
          await launchUrl(playStoreUrl, mode: LaunchMode.externalApplication);
          _addChatMessage('jarvis',
              "I couldn't open $cleanedQuery. Opening the Play Store to search for it.");
          speak(
              "I couldn't open $cleanedQuery. Opening the Play Store to search for it.");
        } catch (e) {
          _addChatMessage('jarvis',
              "I apologize, but I couldn't open ${cleanedQuery.trim()}. The app might not be installed.");
          speak(
              "I apologize, but I couldn't open ${cleanedQuery.trim()}. The app might not be installed.");
        }
      }
    } else {
      final playStoreUrl = Uri(scheme: 'market', host: 'search', queryParameters: {'q': cleanedQuery});
      try {
        await launchUrl(playStoreUrl, mode: LaunchMode.externalApplication);
        _addChatMessage('jarvis',
            "I couldn't find $cleanedQuery. Opening the Play Store to search for it.");
        speak(
            "I couldn't find $cleanedQuery. Opening the Play Store to search for it.");
      } catch (e) {
        _addChatMessage('jarvis',
            "I apologize, but I don't have access to open $cleanedQuery at the moment.");
        speak(
            "I apologize, but I don't have access to open $cleanedQuery at the moment.");
      }
    }
  }

  void _handleTimerCommand(String query, {bool allowPrompt = true}) {
    final totalSeconds = parseTimerDurationSeconds(query);
    if (totalSeconds > 0 && totalSeconds <= 7 * 24 * 3600) {
      _startTimer(totalSeconds);
      return;
    }
    if (allowPrompt) {
      _pendingCommand = 'timer';
      speak('How long should I set the timer for? You can say 5 minutes or 1 hour 20 minutes.').then((_) {
        if (mounted && !_isInConversationMode) startListening();
      });
    } else {
      // F40: the failure is written to the chat too, so the agent
      // loop's verifier sees it instead of assuming the timer was set.
      _addChatMessage('jarvis', 'I could not understand that duration. Please say a valid duration, such as 5 minutes.');
      speak('I could not understand that duration. Please say a valid duration, such as 5 minutes.');
    }
  }

  void _startTimer(int totalSeconds) {
    _timer?.cancel();
    if (totalSeconds <= 0) return;
    _timerEndsAt = DateTime.now().add(Duration(seconds: totalSeconds));
    if (mounted) {
      setState(() {
        _remainingSeconds = totalSeconds;
        _isTimerActive = true;
      });
    }
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) { timer.cancel(); return; }
      final remaining = _timerEndsAt!.difference(DateTime.now()).inSeconds;
      setState(() => _remainingSeconds = remaining > 0 ? remaining : 0);
      if (remaining <= 0) {
        timer.cancel();
        setState(() => _isTimerActive = false);
        speak('Timer completed, sir.');
      }
    });
    final duration = Duration(seconds: totalSeconds);
    final parts = <String>[];
    if (duration.inHours > 0) parts.add('${duration.inHours} hours');
    if (duration.inMinutes.remainder(60) > 0) parts.add('${duration.inMinutes.remainder(60)} minutes');
    if (duration.inSeconds.remainder(60) > 0) parts.add('${duration.inSeconds.remainder(60)} seconds');
    // F40: also written to the chat (not just spoken) so the agent
    // loop's verifier can see the step's result.
    _addChatMessage('jarvis', 'Timer set for ${parts.join(' ')}. Keep Jarvis open for the countdown to run.');
    speak('Timer set for ${parts.join(' ')}. Keep Jarvis open for the countdown to run.');
  }

  /// F42 — alarm, verified end to end in code review (22 Nov 2026):
  /// this launches the standard Android SET_ALARM intent with
  /// SKIP_UI = false, so the Clock app opens showing the alarm for
  /// the user to confirm and save there. Jarvis never sets an alarm
  /// silently — the Clock app is the confirmation step, which is why
  /// this path is exempt from the F42 voice-confirmation gate (the
  /// user confirms in the Clock app instead). The chat lines below
  /// say exactly that: "opened the Clock app", never "alarm set".
  Future<void> _handleAlarmCommand(String query, {bool allowPrompt = true}) async {
    final parsedTime = parseAlarmTime(query);
    if (parsedTime == null) {
      if (allowPrompt) {
        _pendingCommand = 'alarm';
        speak("What time should I set the alarm? For example, 7:30 AM.").then((_) {
          if (mounted && !_isInConversationMode) startListening();
        });
      } else {
        _addChatMessage('jarvis', 'I could not understand the time. Please say a time such as 7:30 AM.');
        speak("I could not understand the time. Please say a time such as 7:30 AM.");
      }
      return;
    }

    final hour12 = parsedTime.hour12;
    final minute = parsedTime.minute;
    final meridiem = parsedTime.meridiem;
    final hour24 = parsedTime.hour24;
    try {
      final intent = AndroidIntent(
        action: 'android.intent.action.SET_ALARM',
        arguments: <String, dynamic>{
          'android.intent.extra.alarm.HOUR': hour24,
          'android.intent.extra.alarm.MINUTES': minute,
          'android.intent.extra.alarm.MESSAGE': 'J.A.R.V.I.S',
          'android.intent.extra.alarm.SKIP_UI': false,
        },
        flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      // F40: written to the chat too — this is the evidence the
      // agent loop's verifier looks for, and it honestly says the
      // Clock app was opened for the user to confirm, not that the
      // alarm is set (only saving it in the Clock app sets it).
      _addChatMessage('jarvis', 'Opening your clock app to create the alarm for $hour12:${minute.toString().padLeft(2, '0')} ${meridiem.toUpperCase()}. Confirm and save it in the Clock app.');
      speak('Opening your clock app to create the alarm for $hour12:${minute.toString().padLeft(2, '0')} ${meridiem.toUpperCase()}. Confirm and save it in the Clock app.');
    } catch (_) {
      _addChatMessage('jarvis', 'I could not open a compatible Clock app. Please set the alarm manually.');
      speak('I could not open a compatible Clock app. Please set the alarm manually.');
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    // F42: a pending confirmation dies with the screen — its action
    // never runs after dispose.
    _confirmationTimer?.cancel();
    _confirmationTimer = null;
    _pendingConfirmationAction = null;
    for (final t in _reminderTimers.values) {
      t.cancel();
    }
    _pendingCommand = '';
    _wakeWordTimer?.cancel();
    // F14/F16: follow-up timer, offline wake-word subscription + engine.
    _followUpTimer?.cancel();
    _wakeWordSubscription?.cancel();
    _overlayTapSubscription?.cancel();
    _wakeWordService.dispose();
    _airGestureService.stopListening();
    _backgroundAnimationTimer?.cancel();
    _chatInputController.dispose();
    _chatScrollController.dispose();
    _animationController.dispose();
    _colorAnimationController.dispose();
    _audioPlayer.dispose();
    _ackPlayer.dispose();
    _edgeTts.dispose();
    _sessionRecorder.dispose();
    model?.dispose();
    speech.stop();
    flutterTts.stop();
    super.dispose();
  }

  void startListening() async {
    try {
      final available = await speech.initialize();
      if (!mounted) return;
      if (!available) {
        _addChatMessage('jarvis',
            'Speech recognition is unavailable. Check your microphone permission and speech services.');
        _reportVoiceProblem(
            'Speech recognition is unavailable — check the microphone permission and speech services.');
        speak('Speech recognition is unavailable. Check your microphone permission and speech services.');
        // F12: low thud — something went wrong.
        _playAckSound('sounds/ack_error.wav');
        return;
      }
      setState(() => isListening = true);
      await speech.listen(
        onResult: (result) async {
          if (result.finalResult) {
            if (!mounted) return;
            String userInput = result.recognizedWords.toLowerCase();
            _addChatMessage('user', userInput);
            // F12: short ding — the command was heard.
            _playAckSound('sounds/ack_command.wav');
            processQuery(userInput);
          }
        },
        listenFor: Duration(minutes: 5),
        pauseFor: Duration(seconds: 15),
        partialResults: true,
        listenMode: stt.ListenMode.deviceDefault,
        cancelOnError: false,
      );
    } catch (_) {
      if (mounted) setState(() => isListening = false);
      _addChatMessage('jarvis',
          'I could not start the microphone. Please check microphone permission.');
      speak('I could not start the microphone. Please check microphone permission.');
    }
  }

  void stopListening() {
    speech.stop();
    if (mounted) setState(() => isListening = false);
  }

  /// Stops Jarvis mid-sentence. Used by the orb tap, the on-screen STOP
  /// button, and the "stop / chup / khamosh" voice command.
  Future<void> _stopSpeaking() async {
    // Bump the generation first: any speak() or answer already in flight
    // sees the change and stays silent (v1.1.0 STOP fix).
    _speakGeneration++;
    // Abort the in-flight Gemini request so its answer never arrives to
    // be spoken after the user pressed STOP.
    model?.cancel();
    // F10/F11: also stop Edge TTS audio and any streamed reply in flight
    // (the generation bump above already keeps speak() from restarting).
    _edgeTts.stop();
    try {
      await flutterTts.stop();
    } catch (_) {}
    if (mounted) {
      setState(() {
        isSpeaking = false;
        _speakingSince = null;
      });
    }
    // F16: stop barge-in listening too. In a conversation, listen right
    // away for the next command and open the ~8 s follow-up window, so
    // the new command after a STOP is heard instead of waiting for the
    // 30-second timer; silence after that ends the conversation. While
    // an answer is still loading, listening re-arms when it returns
    // (see the finally block in processQuery). Outside a conversation,
    // go back to wake-word listening.
    _stopBargeInListening();
    _wakeWordMachine.onStopPressed();
    if (_isInConversationMode) {
      _cancelFollowUpWindow();
      if (_hasAnsweredCommand) _startFollowUpWindow();
      if (!_isProcessingQuery) _continueConversation();
    } else if (_isBackgroundListening) {
      _startWakeWordDetection();
    }
  }

  /// Short version of an answer for speaking: code is never read aloud,
  /// long answers are cut to the first sentence or two. The full text is
  /// always in the chat for reading.
  String _shortSpoken(String answer) {
    if (answer.contains('```')) {
      return 'Done. The full answer is on your screen.';
    }
    if (answer.length <= 250) return answer;
    final cut = answer.substring(0, 250);
    final ends = <int>[
      cut.lastIndexOf('. '),
      cut.lastIndexOf('! '),
      cut.lastIndexOf('? '),
    ];
    final lastEnd = ends.reduce((a, b) => a > b ? a : b);
    return lastEnd > 60 ? cut.substring(0, lastEnd + 1) : cut;
  }

  Future<void> speak(String text) async {
    if (!mounted || text.trim().isEmpty) return;
    // Capture the generation: if STOP is pressed while this speak is
    // waiting, the generation changes and we stay silent.
    final generation = _speakGeneration;
    final cleanText = text.replaceAll(RegExp(r'\*'), '');
    await _ttsReady;
    if (!mounted || generation != _speakGeneration) return;
    if (speech.isListening) speech.stop();
    // A new utterance cuts off whatever is still being spoken, so the user
    // can interrupt a long answer with a new question.
    await flutterTts.stop();
    _edgeTts.stop();
    if (!mounted || generation != _speakGeneration) return;
    if (mounted) {
      setState(() {
        isSpeaking = true;
        _speakingSince = DateTime.now();
      });
    }
    // F16: speech started — the state machine tracks it so a wake word
    // now means barge-in, and the offline engine keeps listening while
    // Jarvis speaks so "Hey Jarvis" can interrupt mid-answer. The
    // system recogniser was stopped above, so the engine has the mic.
    _wakeWordMachine.onSpeechStarted();
    _startBargeInListening();
    // F10: Edge TTS first when enabled; any failure falls back silently
    // to the device voice below, so speech never breaks because Edge did.
    if (_edgeTtsEnabled) {
      final played = await _edgeTts.speak(
        cleanText,
        voice: _edgeVoiceForLanguage(_ttsLanguage),
      );
      if (!mounted || generation != _speakGeneration) return;
      if (played) {
        _finishSpeaking();
        return;
      }
      if (!mounted || generation != _speakGeneration) return;
    }
    try {
      await flutterTts.speak(cleanText);
    } catch (_) {
      if (mounted) {
        setState(() {
          isSpeaking = false;
          _speakingSince = null;
        });
      }
      if (_isInConversationMode) _continueConversation();
    }
  }

  void _stopBackgroundListening() {
    if (_isBackgroundListening) {
      speech.stop();
      // F14: the offline engine stops too — it is the wake-word
      // listener while background listening is on.
      _stopOfflineWakeWord();
      if (mounted) setState(() => _isBackgroundListening = false);
    }
  }

  Future<void> _playWakeSound() async {
    // Sounds switch off, or a wake-up within ten seconds of the last one
    // (false triggers in background noise) — never replay the chime.
    if (!_soundsEnabled) return;
    final now = DateTime.now();
    if (_lastWakeSoundAt != null &&
        now.difference(_lastWakeSoundAt!).inSeconds < 10) {
      return;
    }
    _lastWakeSoundAt = now;
    try {
      await _audioPlayer.play(AssetSource('sounds/wake.mp3'));
    } catch (e) {
      debugPrint('Error playing wake sound: $e');
    }
  }

  /// Starts a foreground service ("J.A.R.V.I.S is listening" notification)
  /// so Android keeps the app process alive when it is minimised and the
  /// microphone permission keeps working in the background. Started only
  /// while the app is in the foreground (Android 12+ rule). The user stops
  /// it by swiping the app away from recents.
  Future<void> _initForegroundService() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'jarvis_listening',
        channelName: 'Jarvis listening',
        channelDescription:
            'Jarvis keeps listening for "Hey Jarvis" while the app is in the background.',
        onlyAlertOnce: true,
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: false,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(30000),
        autoRunOnBoot: false,
        autoRunOnMyPackageReplaced: false,
        allowWakeLock: true,
        allowWifiLock: false,
      ),
    );
    final notificationPermission =
        await FlutterForegroundTask.checkNotificationPermission();
    if (notificationPermission != NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }
    if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
    }
    if (!await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.startService(
        serviceId: 256,
        notificationTitle: 'J.A.R.V.I.S is listening',
        notificationText: 'Say "Hey Jarvis" any time — tap to open Jarvis.',
        callback: jarvisForegroundCallback,
      );
    }
  }

  static const MethodChannel _appsChannel =
      MethodChannel('com.jarvis.jarvis_app/apps');

  /// Apps the user connected in the Connected Apps screen (package -> label).
  /// Only these can be opened by voice or typing. Stored on this phone only.
  Map<String, String> _connectedApps = {};

  /// Default apps connected on first run (the well-known ones).
  static const List<String> _defaultConnectedPackages = <String>[
    'com.whatsapp',
    'com.google.android.youtube',
    'com.android.chrome',
    'com.google.android.gm',
    'com.google.android.apps.maps',
    'com.android.camera',
    'com.google.android.apps.photos',
    'com.android.settings',
    'com.android.vending',
    'com.android.calculator2',
    'com.google.android.calendar',
    'com.android.deskclock',
    'com.android.contacts',
    'com.android.dialer',
    'com.android.mms',
    'com.instagram.android',
    'com.facebook.katana',
    'org.telegram.messenger',
    'com.zhiliaoapp.musically',
    'com.spotify.music',
    'com.snapchat.android',
  ];

  Future<void> _loadConnectedApps() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final stored = prefs.getStringList('connected_apps');
      final apps =
          await _appsChannel.invokeListMethod<dynamic>('getInstalledApps');
      final installed = <String, String>{};
      for (final entry in apps ?? <dynamic>[]) {
        if (entry is Map) {
          final package = entry['package']?.toString() ?? '';
          final label = entry['label']?.toString() ?? package;
          if (package.isNotEmpty) installed[package] = label;
        }
      }
      final connected = stored ??
          _defaultConnectedPackages.where(installed.containsKey).toList();
      if (stored == null) {
        await prefs.setStringList('connected_apps', connected);
      }
      if (mounted) {
        setState(() {
          _connectedApps = {
            for (final package in connected)
              if (installed.containsKey(package)) package: installed[package]!,
          };
        });
      }
    } catch (e) {
      debugPrint('Could not load connected apps: $e');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _isAppInForeground = true;
      // The home-screen widget may have asked for a conversation.
      _checkWidgetLaunch();
      if (_isInConversationMode && !isSpeaking) {
        _continueConversation();
      } else if (_isBackgroundListening && !isSpeaking) {
        _startWakeWordDetection();
      }
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _isAppInForeground = false;
      // Keep listening in the background when the wake-word toggle is ON
      // (the foreground service keeps the mic allowed). Stop it only when
      // the toggle is OFF.
      if (!_isBackgroundListening) {
        speech.stop();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isIdleState =
        !_isWakeWordDetected && !isSpeaking && !_isInConversationMode;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: CircuitPatternPainter(
                isIdleState: isIdleState,
              ),
              key: ValueKey(
                  _backgroundAnimationCounter),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.7),
                  ],
                  center: Alignment.center,
                  radius: 1.5,
                ),
              ),
            ),
          ),
          Container(
            width: double.infinity,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isTimerActive && _remainingSeconds != null)
                  Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text(
                      'Timer: ${(_remainingSeconds! ~/ 3600).toString().padLeft(2, '0')}:${((_remainingSeconds! % 3600) ~/ 60).toString().padLeft(2, '0')}:${(_remainingSeconds! % 60).toString().padLeft(2, '0')}',
                      style: TextStyle(
                        color: Colors.orange,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        shadows: [
                          Shadow(
                            color: Colors.orange.withValues(alpha: 0.5),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                    ),
                  ),
                if (_isBackgroundListening)
                  Padding(
                    padding: EdgeInsets.only(bottom: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            color: _isInConversationMode
                                ? Colors.purple
                                : Colors.green,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: _isInConversationMode
                                    ? Colors.purple.withValues(alpha: 0.5)
                                    : Colors.green.withValues(alpha: 0.5),
                                blurRadius: 10,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(width: 8),
                        Text(
                          _isInConversationMode
                              ? "CONVERSATION ACTIVE"
                              : "ALWAYS LISTENING",
                          style: TextStyle(
                            color: _isInConversationMode
                                ? Colors.blueAccent
                                : Colors.green,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    _isInConversationMode
                        ? (_isInFollowUpWindow && !isSpeaking
                            ? "LISTENING FOR A FOLLOW-UP…"
                            : "ACTIVE CONVERSATION MODE")
                        : _isWakeWordDetected
                            ? "LISTENING FOR COMMAND..."
                            : isSpeaking
                                ? "JARVIS IS RESPONDING..."
                                : "SAY 'HEY JARVIS' TO START",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _isInConversationMode
                          ? Colors.blueAccent
                          : _isWakeWordDetected
                              ? Colors.green
                              : isSpeaking
                                  ? Colors.orange
                                  : Colors.cyan,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: _isInConversationMode
                              ? Colors.blueAccent
                              : _isWakeWordDetected
                                  ? Colors.green
                                  : isSpeaking
                                      ? Colors.orange
                                      : Colors.cyan,
                          blurRadius: 10,
                          offset: Offset(0, 0),
                        ),
                      ],
                    ),
                  ),
                ),
                if (isSpeaking)
                  Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: ElevatedButton.icon(
                      onPressed: _stopSpeaking,
                      icon: const Icon(Icons.stop),
                      label: const Text('STOP'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                // F42: a confirmation is waiting — tap Yes to run the
                // action, or No to cancel it. Same as saying "yes" /
                // "no" out loud. Nothing runs without one of these.
                if (_confirmationGate.isPending)
                  Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton.icon(
                          onPressed: _confirmPendingAction,
                          icon: const Icon(Icons.check),
                          label: const Text('Yes, confirm'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 12),
                        ElevatedButton.icon(
                          onPressed: _declinePendingAction,
                          icon: const Icon(Icons.close),
                          label: const Text('No, cancel'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey,
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                // F40: the agent loop is running — its per-step log is
                // in the chat below and in the ⋮ menu → Agent loop log.
                if (_agentLoopRunning)
                  const Padding(
                    padding: EdgeInsets.only(top: 10.0),
                    child: Text(
                      'Agent loop running — see each step below.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.orange,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                // F13: debug recording state, shown only while recording.
                if (_isSessionRecording)
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text(
                      _sessionRecorder.audioFailed
                          ? '● RECORDING — TRANSCRIPT ONLY (DEBUG)'
                          : '● RECORDING (DEBUG)',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.red,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                // Why voice is not working right now (internet, mic, …).
                if (_voiceStatus.isNotEmpty)
                  Padding(
                    padding: EdgeInsets.only(
                        top: 10.0, left: 24.0, right: 24.0),
                    child: Text(
                      _voiceStatus,
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(color: Colors.orange, fontSize: 12),
                    ),
                  ),
                // Manual way to start Active Conversation: no "Hey Jarvis"
                // needed. Works even when the mic toggle is off.
                if (!_isInConversationMode && !isSpeaking)
                  Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: ElevatedButton.icon(
                      onPressed: _startConversationMode,
                      icon: const Icon(Icons.mic),
                      label: const Text('START CONVERSATION'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.cyan,
                        foregroundColor: Colors.black,
                      ),
                    ),
                  ),
                SizedBox(height: 40),
                if (_chatMessages.isNotEmpty)
                  Container(
                    height: 180,
                    margin: EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 8.0),
                    padding: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.45),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: Colors.cyan.withValues(alpha: 0.3)),
                    ),
                    child: ListView.builder(
                      controller: _chatScrollController,
                      itemCount: _chatMessages.length,
                      itemBuilder: (context, index) {
                        final msg = _chatMessages[index];
                        final isUser = msg['role'] == 'user';
                        return Align(
                          alignment: isUser
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Container(
                            margin: EdgeInsets.symmetric(vertical: 3.0),
                            padding: EdgeInsets.symmetric(
                                horizontal: 10.0, vertical: 6.0),
                            decoration: BoxDecoration(
                              color: isUser
                                  ? Colors.cyan.withValues(alpha: 0.25)
                                  : Colors.white.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              msg['text'] ?? '',
                              style: TextStyle(
                                  color: Colors.white, fontSize: 14),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                AnimatedBuilder(
                  animation:
                      Listenable.merge([_bounceAnimation, _colorAnimation]),
                  builder: (context, child) {
                    final currentColor =
                        _colorAnimation.value ?? _ironManColors[0];
                    return Transform.scale(
                      scale: _isWakeWordDetected ||
                              isSpeaking ||
                              _isInConversationMode
                          ? _bounceAnimation.value
                          : 1.0,
                      child: GestureDetector(
                        onTapDown: (_) => setState(() => isListening = true),
                        onTapUp: (_) {
                          if (isSpeaking) {
                            // Tapping the orb while Jarvis talks silences it.
                            _stopSpeaking();
                          } else if (_isInConversationMode) {
                            _endConversationMode();
                            speak(
                                "Ending conversation mode. Just say 'Hey Jarvis' when you need me again.");
                          } else {
                            startListening();
                          }
                        },
                        onTapCancel: () => setState(() => isListening = false),
                        child: Container(
                          width: 180,
                          height: 180,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                currentColor.withValues(alpha: 0.9),
                                currentColor.withValues(alpha: 0.7),
                                currentColor.withValues(alpha: 0.5),
                              ],
                              center: Alignment.center,
                              radius: 0.8,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: currentColor.withValues(alpha: 0.7),
                                blurRadius: 35,
                                spreadRadius: 8,
                              ),
                              BoxShadow(
                                color: currentColor.withValues(alpha: 0.4),
                                blurRadius: 60,
                                spreadRadius: 15,
                              ),
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.8),
                                blurRadius: 15,
                                spreadRadius: -3,
                                offset: Offset(0, 5),
                              ),
                            ],
                            border: Border.all(
                              color: Colors.black,
                              width: 2.5,
                            ),
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Container(
                                width: 168,
                                height: 168,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: currentColor.withValues(alpha: 0.9),
                                    width: 4,
                                  ),
                                ),
                                child: CustomPaint(
                                  painter: ArcReactorSegmentsPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                  ),
                                ),
                              ),
                              Container(
                                width: 144,
                                height: 144,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: currentColor.withValues(alpha: 0.8),
                                    width: 3,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.8),
                                      blurRadius: 2,
                                      spreadRadius: 0.5,
                                    ),
                                  ],
                                ),
                                child: CustomPaint(
                                  painter: CircuitLinesPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                  ),
                                ),
                              ),
                              Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: currentColor.withValues(alpha: 0.7),
                                    width: 2.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.8),
                                      blurRadius: 2,
                                      spreadRadius: 0.5,
                                    ),
                                  ],
                                ),
                                child: CustomPaint(
                                  painter: TrianglePatternPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                  ),
                                ),
                              ),
                              Container(
                                width: 96,
                                height: 96,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: RadialGradient(
                                    colors: [
                                      currentColor.withValues(alpha: 0.9),
                                      currentColor.withValues(alpha: 0.7),
                                    ],
                                    center: Alignment.center,
                                    radius: 0.8,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: currentColor.withValues(alpha: 0.7),
                                      blurRadius: 25,
                                      spreadRadius: 4,
                                    ),
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.8),
                                      blurRadius: 8,
                                      spreadRadius: -2,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                  border: Border.all(
                                    color: Colors.black,
                                    width: 1.5,
                                  ),
                                ),
                                child: CustomPaint(
                                  painter: CorePatternPainter(
                                    isActive: _isWakeWordDetected ||
                                        isSpeaking ||
                                        _isInConversationMode,
                                    isConversation: _isInConversationMode,
                                    color: currentColor,
                                    showPurpleTriangle: true,
                                  ),
                                ),
                              ),
                              if (_isWakeWordDetected ||
                                  isSpeaking ||
                                  _isInConversationMode)
                                Container(
                                  width: 192,
                                  height: 192,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: currentColor.withValues(alpha: 0.5),
                                      width: 3,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
                SizedBox(height: 16),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                                color: Colors.cyan.withValues(alpha: 0.4)),
                          ),
                          child: TextField(
                            controller: _chatInputController,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              hintText: 'Type your message...',
                              hintStyle:
                                  TextStyle(color: Colors.white54),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 16.0, vertical: 10.0),
                            ),
                            textInputAction: TextInputAction.send,
                            onSubmitted: (_) => _sendTypedMessage(),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.cyan, shape: BoxShape.circle),
                        child: IconButton(
                          icon: Icon(Icons.send, color: Colors.black),
                          onPressed: _sendTypedMessage,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: Text(
          'J.A.R.V.I.S',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
            shadows: [
              Shadow(
                color: Colors.blue.withValues(alpha: 0.5),
                blurRadius: 10,
              ),
            ],
          ),
        ),
        backgroundColor: Colors.black.withValues(alpha: 0.3),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.history, color: Colors.cyan, size: 28),
            onPressed: () async {
              final startNew = await Navigator.push<bool>(
                context,
                MaterialPageRoute(
                    builder: (context) => const HistoryScreen()),
              );
              if (startNew == true) _startNewChat();
            },
            tooltip: 'Chat history',
          ),
          IconButton(
            icon: const Icon(Icons.apps, color: Colors.cyan, size: 28),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const ConnectedAppsScreen()),
              );
              _loadConnectedApps();
            },
            tooltip: 'Connected apps',
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.cyan, size: 28),
            onPressed: _showSettingsDialog,
            tooltip: "Settings - Gemini API key",
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Colors.cyan, size: 28),
            tooltip: 'Memory, search, knowledge & everyday tools',
            onSelected: (value) async {
              switch (value) {
                case 'search':
                  await _openSearch();
                case 'facts':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SavedFactsScreen(
                        memoryService: _memoryService,
                      ),
                    ),
                  );
                  await _rebuildChatProvider();
                case 'knowledge':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => KnowledgeFilesScreen(
                        knowledgeService: _knowledgeService,
                      ),
                    ),
                  );
                  await _rebuildChatProvider();
                case 'connectors':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ConnectorHubScreen(
                        hub: _connectorHub,
                        onChanged: _rebuildChatProvider,
                      ),
                    ),
                  );
                // Phase 7 (v1.1.0) — everyday tools (F26–F31).
                case 'calendar':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CalendarScreen(
                        calendarService: _calendarService,
                      ),
                    ),
                  );
                case 'email':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => GmailTriageScreen(
                        gmailService: _gmailService,
                      ),
                    ),
                  );
                case 'finance':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FinanceScreen(
                        financeService: _financeService,
                      ),
                    ),
                  );
                case 'network':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => NetworkScreen(
                        networkService: _networkService,
                      ),
                    ),
                  );
                case 'telemetry':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TelemetryScreen(
                        telemetryService: _telemetryService,
                      ),
                    ),
                  );
                case 'codeblack':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          CodeBlackScreen(onLock: _lockPhone),
                    ),
                  );
                // Phase 7b (v1.1.0) — everyday tools (F33/F35/F37/F39).
                case 'macros':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MacrosScreen(
                        macroService: _macroService,
                        onRunMacro: _runMacro,
                      ),
                    ),
                  );
                // Phase 8 (v1.1.0) — agent (F40/F41).
                case 'agentlog':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AgentLoopLogScreen(
                        log: List<AgentStepLogEntry>.from(_agentLoopLog),
                        running: _agentLoopRunning,
                      ),
                    ),
                  );
                case 'accessibility':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AccessibilityScreen(
                        enabled: _accessibilityEnabled,
                        log: List<AccessibilityActionLogEntry>.from(
                          _accessibilityService.log,
                        ),
                        onToggle: (value) async {
                          await _savePhase8Settings(
                            accessibility: value,
                          );
                          if (context.mounted) {
                            Navigator.of(context).pop();
                          }
                        },
                        onOpenAndroidSettings: () async {
                          await _accessibilityService
                              .openAccessibilitySettings();
                        },
                        onClearLog: () {
                          _accessibilityService.clearLog();
                          if (mounted) setState(() {});
                          if (context.mounted) {
                            Navigator.of(context).pop();
                          }
                        },
                      ),
                    ),
                  );
                case 'forms':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FormsScreen(
                        formDraftService: _formDraftService,
                      ),
                    ),
                  );
                case 'commute':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CommuteScreen(
                        commuteService: _commuteService,
                      ),
                    ),
                  );
                case 'shizuku':
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ShizukuScreen(
                        shizukuService: _shizukuService,
                        onForceStopApp: (appName) async {
                          await _handleShizukuCommand(
                            'force stop $appName',
                          );
                        },
                      ),
                    ),
                  );
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(
                value: 'search',
                child: Text('Search this phone'),
              ),
              PopupMenuItem(
                value: 'facts',
                child: Text('Saved facts'),
              ),
              PopupMenuItem(
                value: 'knowledge',
                child: Text('Knowledge files'),
              ),
              PopupMenuItem(
                value: 'connectors',
                child: Text('Connected apps & providers'),
              ),
              PopupMenuItem(
                value: 'calendar',
                child: Text('Calendar — today'),
              ),
              PopupMenuItem(
                value: 'email',
                child: Text('Email triage'),
              ),
              PopupMenuItem(
                value: 'finance',
                child: Text('Finance'),
              ),
              PopupMenuItem(
                value: 'network',
                child: Text('Network'),
              ),
              PopupMenuItem(
                value: 'telemetry',
                child: Text('Telemetry'),
              ),
              PopupMenuItem(
                value: 'codeblack',
                child: Text('Code Black (lock phone)'),
              ),
              PopupMenuItem(
                value: 'macros',
                child: Text('Macros'),
              ),
              PopupMenuItem(
                value: 'forms',
                child: Text('Form drafts'),
              ),
              PopupMenuItem(
                value: 'commute',
                child: Text('Commute'),
              ),
              PopupMenuItem(
                value: 'shizuku',
                child: Text('Shizuku controls'),
              ),
              PopupMenuItem(
                value: 'agentlog',
                child: Text('Agent loop log'),
              ),
              PopupMenuItem(
                value: 'accessibility',
                child: Text('Accessibility actions'),
              ),
            ],
          ),
          IconButton(
            icon: Icon(
              _isBackgroundListening ? Icons.mic : Icons.mic_off,
              color: _isBackgroundListening
                  ? (_isInConversationMode ? Colors.purple : Colors.green)
                  : Colors.red,
              size: 28,
            ),
            onPressed: () {
              if (_isInConversationMode) {
                _endConversationMode();
                speak("Ending conversation mode.");
              }

              if (_isBackgroundListening) {
                _stopBackgroundListening();
                speak("Wake-word listening disabled.");
              } else {
                setState(() => _isBackgroundListening = true);
                _startWakeWordDetection();
                speak(
                    "Wake-word listening enabled while Jarvis is open. Android may stop listening in the background.");
              }
            },
            tooltip: _isBackgroundListening
                ? "Disable wake-word listening"
                : "Enable wake-word listening",
          ),
        ],
      ),
    );
  }
}

class CorePatternPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;
  final bool showPurpleTriangle;

  CorePatternPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
    this.showPurpleTriangle = false,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5;

    final path = Path();
    final triangleSize = radius * 0.8;
    final height = triangleSize * sqrt(3) / 2;

    path.moveTo(center.dx, center.dy - height / 2);
    path.lineTo(center.dx + triangleSize / 2, center.dy + height / 2);
    path.lineTo(center.dx - triangleSize / 2, center.dy + height / 2);
    path.close();

    canvas.drawPath(path, borderPaint); 
    canvas.drawPath(path, paint);

    final innerPaint = Paint()
      ..color = color.withValues(alpha: 0.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final innerBorderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final innerSize = triangleSize * 0.6;
    final innerHeight = innerSize * sqrt(3) / 2;

    path.reset();
    path.moveTo(center.dx, center.dy - innerHeight / 2);
    path.lineTo(center.dx + innerSize / 2, center.dy + innerHeight / 2);
    path.lineTo(center.dx - innerSize / 2, center.dy + innerHeight / 2);
    path.close();

    canvas.drawPath(path, innerBorderPaint); 
    canvas.drawPath(path, innerPaint); 

    final dotPaint = Paint()
      ..color = color.withValues(alpha: 0.9)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, radius * 0.12, dotPaint);

    if (showPurpleTriangle) {
      final purplePaint = Paint()
        ..color = Colors.purple.withValues(alpha: 0.8)
        ..style = PaintingStyle.fill;

      final purpleBorderPaint = Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;

      final purpleTrianglePath = Path();
      final purpleTriangleSize =
          radius * 0.5; 
      final purpleHeight = purpleTriangleSize * sqrt(3) / 2;

      purpleTrianglePath.moveTo(center.dx, center.dy - purpleHeight / 2);
      purpleTrianglePath.lineTo(
          center.dx + purpleTriangleSize / 2, center.dy + purpleHeight / 2);
      purpleTrianglePath.lineTo(
          center.dx - purpleTriangleSize / 2, center.dy + purpleHeight / 2);
      purpleTrianglePath.close();

      final purpleRect = Rect.fromCircle(center: center, radius: radius * 0.5);
      final purpleGradient = RadialGradient(
        colors: [
          Colors.purple.withValues(alpha: 0.9),
          Colors.deepPurple.withValues(alpha: 0.7),
        ],
        center: Alignment(0.2, -0.3), 
        radius: 0.8,
      );

      final gradientPaint = Paint()
        ..shader = purpleGradient.createShader(purpleRect)
        ..style = PaintingStyle.fill;

      canvas.drawPath(purpleTrianglePath, gradientPaint);
      canvas.drawPath(purpleTrianglePath, purpleBorderPaint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class TrianglePatternPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;

  TrianglePatternPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.7)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (var i = 0; i < 3; i++) {
      final angle = i * (2 * pi / 3);
      final path = Path();

      final triangleSize = radius * 0.8;
      final height = triangleSize * sqrt(3) / 2;

      final topPoint = Offset(
        center.dx + sin(angle) * height / 2,
        center.dy - cos(angle) * height / 2,
      );
      final bottomLeft = Offset(
        center.dx + sin(angle - 2 * pi / 3) * height / 2,
        center.dy - cos(angle - 2 * pi / 3) * height / 2,
      );
      final bottomRight = Offset(
        center.dx + sin(angle + 2 * pi / 3) * height / 2,
        center.dy - cos(angle + 2 * pi / 3) * height / 2,
      );

      path.moveTo(topPoint.dx, topPoint.dy);
      path.lineTo(bottomLeft.dx, bottomLeft.dy);
      path.lineTo(bottomRight.dx, bottomRight.dy);
      path.close();

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class CircuitLinesPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;

  CircuitLinesPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (var i = 0; i < 12; i++) {
      final angle = i * (2 * pi / 12);
      final path = Path();

      final startRadius = radius * 0.7;
      final endRadius = radius * 0.9;

      final startX = center.dx + cos(angle) * startRadius;
      final startY = center.dy + sin(angle) * startRadius;
      final endX = center.dx + cos(angle) * endRadius;
      final endY = center.dy + sin(angle) * endRadius;

      path.moveTo(startX, startY);
      path.lineTo(endX, endY);

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }

    for (var i = 0; i < 6; i++) {
      final angle = i * (2 * pi / 6);
      final path = Path();

      final radius1 = radius * 0.75;
      final radius2 = radius * 0.85;

      final x1 = center.dx + cos(angle) * radius1;
      final y1 = center.dy + sin(angle) * radius1;
      final x2 = center.dx + cos(angle + pi / 3) * radius2;
      final y2 = center.dy + sin(angle + pi / 3) * radius2;

      path.moveTo(x1, y1);
      path.lineTo(x2, y2);

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class ArcReactorSegmentsPainter extends CustomPainter {
  final bool isActive;
  final bool isConversation;
  final Color color;

  ArcReactorSegmentsPainter({
    this.isActive = false,
    this.isConversation = false,
    this.color = Colors.blue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final paint = Paint()
      ..color = color.withValues(alpha: 0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final borderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5;

    for (var i = 0; i < 8; i++) {
      final angle = i * (2 * pi / 8);
      final path = Path();

      final startRadius = radius * 0.9;
      final endRadius = radius;

      final startX = center.dx + cos(angle) * startRadius;
      final startY = center.dy + sin(angle) * startRadius;
      final endX = center.dx + cos(angle) * endRadius;
      final endY = center.dy + sin(angle) * endRadius;

      path.moveTo(startX, startY);
      path.lineTo(endX, endY);

      canvas.drawPath(path, borderPaint);
      canvas.drawPath(path, paint);
    }

    final innerPaint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final innerBorderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    for (var i = 0; i < 16; i++) {
      final angle = i * (2 * pi / 16);
      final path = Path();

      final startRadius = radius * 0.85;
      final endRadius = radius * 0.95;

      final startX = center.dx + cos(angle) * startRadius;
      final startY = center.dy + sin(angle) * startRadius;
      final endX = center.dx + cos(angle) * endRadius;
      final endY = center.dy + sin(angle) * endRadius;

      path.moveTo(startX, startY);
      path.lineTo(endX, endY);

      canvas.drawPath(path, innerBorderPaint);
      canvas.drawPath(path, innerPaint);
    }

    final gradientPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.white.withValues(alpha: 0.1),
          Colors.transparent,
        ],
        center: Alignment(-0.2, -0.2), 
        radius: 0.8,
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, radius * 0.95, gradientPaint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

/// Connected Apps screen: lists every app installed on the phone and lets
/// the user switch each one on (Jarvis may open it) or off. The list is
/// stored only on this phone (SharedPreferences) and is never sent anywhere.
class ConnectedAppsScreen extends StatefulWidget {
  const ConnectedAppsScreen({super.key});

  @override
  State<ConnectedAppsScreen> createState() => _ConnectedAppsScreenState();
}

class _ConnectedAppsScreenState extends State<ConnectedAppsScreen> {
  static const MethodChannel _appsChannel =
      MethodChannel('com.jarvis.jarvis_app/apps');

  List<Map<String, String>> _allApps = [];
  Set<String> _connected = {};
  String _filter = '';
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final apps =
          await _appsChannel.invokeListMethod<dynamic>('getInstalledApps');
      final parsed = <Map<String, String>>[];
      for (final entry in apps ?? <dynamic>[]) {
        if (entry is Map) {
          final package = entry['package']?.toString() ?? '';
          final label = entry['label']?.toString() ?? package;
          if (package.isNotEmpty) {
            parsed.add({'label': label, 'package': package});
          }
        }
      }
      if (mounted) {
        setState(() {
          _allApps = parsed;
          _connected = prefs.getStringList('connected_apps')?.toSet() ?? {};
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Could not list apps: $e';
          _loading = false;
        });
      }
    }
  }

  Future<void> _toggle(String package, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (value) {
        _connected.add(package);
      } else {
        _connected.remove(package);
      }
    });
    await prefs.setStringList('connected_apps', _connected.toList());
  }

  @override
  Widget build(BuildContext context) {
    final visible = _filter.isEmpty
        ? _allApps
        : _allApps
            .where((a) =>
                a['label']!.toLowerCase().contains(_filter) ||
                a['package']!.toLowerCase().contains(_filter))
            .toList();
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Connected Apps'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.cyan,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.cyan))
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Text(_error!,
                        style: const TextStyle(color: Colors.white)),
                  ),
                )
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: TextField(
                        style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(
                          hintText: 'Search apps...',
                          hintStyle: TextStyle(color: Colors.grey),
                          prefixIcon: Icon(Icons.search, color: Colors.cyan),
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (v) =>
                            setState(() => _filter = v.trim().toLowerCase()),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Text(
                        '${_connected.length} of ${_allApps.length} apps connected. Only connected apps can be opened by Jarvis. This list stays on your phone.',
                        style: const TextStyle(
                            color: Colors.grey, fontSize: 13),
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: visible.length,
                        itemBuilder: (context, index) {
                          final app = visible[index];
                          final package = app['package']!;
                          final on = _connected.contains(package);
                          return SwitchListTile(
                            title: Text(app['label']!,
                                style:
                                    const TextStyle(color: Colors.white)),
                            subtitle: Text(package,
                                style: const TextStyle(
                                    color: Colors.grey, fontSize: 12)),
                            value: on,
                            activeColor: Colors.cyan,
                            onChanged: (v) => _toggle(package, v),
                          );
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}

/// Chat history: past conversations saved on this phone only. Open one to
/// read it again, delete one, or clear them all. Nothing leaves the phone.
class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Map<String, dynamic>> _sessions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final sessions = await loadChatHistory();
    if (mounted) {
      setState(() {
        _sessions = sessions;
        _loading = false;
      });
    }
  }

  Future<void> _delete(int id) async {
    await deleteChatHistorySession(id);
    _reload();
  }

  Future<void> _clearAll() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('Clear all history?',
            style: TextStyle(color: Colors.white)),
        content: const Text(
            'Every saved chat will be deleted from this phone.',
            style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel',
                style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Clear all',
                style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await clearChatHistory();
      _reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Chat History'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.cyan,
        actions: [
          IconButton(
            icon: const Icon(Icons.add_comment, color: Colors.cyan),
            tooltip: 'Start a new chat',
            onPressed: () => Navigator.of(context).pop(true),
          ),
          IconButton(
            icon: const Icon(Icons.delete_sweep, color: Colors.redAccent),
            tooltip: 'Clear all history',
            onPressed: _sessions.isEmpty ? null : _clearAll,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.cyan))
          : _sessions.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24.0),
                    child: Text(
                      'No saved chats yet. Your conversations will appear here.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: _sessions.length,
                  itemBuilder: (context, index) {
                    final session = _sessions[index];
                    final id = session['id'] as int? ?? 0;
                    final title = session['title']?.toString() ?? 'Chat';
                    final startedAt = DateTime.tryParse(
                        session['startedAt']?.toString() ?? '');
                    final messages =
                        (session['messages'] as List<dynamic>?) ?? [];
                    return ListTile(
                      title: Text(title,
                          style: const TextStyle(color: Colors.white)),
                      subtitle: Text(
                        '${messages.length} messages'
                        '${startedAt != null ? ' · ${DateFormat.yMMMd().add_jm().format(startedAt)}' : ''}',
                        style: const TextStyle(color: Colors.grey),
                      ),
                      trailing: IconButton(
                        icon:
                            const Icon(Icons.delete, color: Colors.redAccent),
                        tooltip: 'Delete this chat',
                        onPressed: () => _delete(id),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                HistoryChatView(session: session),
                          ),
                        );
                      },
                    );
                  },
                ),
    );
  }
}

/// Read-only view of one saved conversation.
class HistoryChatView extends StatelessWidget {
  const HistoryChatView({super.key, required this.session});

  final Map<String, dynamic> session;

  @override
  Widget build(BuildContext context) {
    final messages = (session['messages'] as List<dynamic>?) ?? [];
    final title = session['title']?.toString() ?? 'Chat';
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(title, overflow: TextOverflow.ellipsis),
        backgroundColor: Colors.black,
        foregroundColor: Colors.cyan,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12.0),
        itemCount: messages.length,
        itemBuilder: (context, index) {
          final msg = messages[index];
          if (msg is! Map) return const SizedBox.shrink();
          final isUser = msg['role'] == 'user';
          return Align(
            alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 3.0),
              padding: const EdgeInsets.symmetric(
                  horizontal: 10.0, vertical: 6.0),
              decoration: BoxDecoration(
                color: isUser
                    ? Colors.cyan.withValues(alpha: 0.25)
                    : Colors.white.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                msg['text']?.toString() ?? '',
                style: const TextStyle(color: Colors.white, fontSize: 14),
              ),
            ),
          );
        },
      ),
    );
  }
}
