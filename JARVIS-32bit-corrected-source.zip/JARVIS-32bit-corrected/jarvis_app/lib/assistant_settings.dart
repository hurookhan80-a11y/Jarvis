// v1.2.0 (G10) — assistant personality settings.
//
// The user picks a display name, an answer tone, and optional custom
// instructions. Stored on this phone only (SharedPreferences), as one
// JSON object. Main.dart merges buildPersonalitySection() into the
// Gemini system instruction when the chat provider is built — this
// file only holds the data + the helper, it sends nothing itself.
//
// Fresh implementation — no code copied.

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// SharedPreferences key holding the assistant settings as JSON.
const String kJarvisAssistantSettingsKey = 'jarvis_assistant_settings_v1';

/// The tones the user can pick. 'short' is the default — Jarvis's
/// usual concise voice.
const Set<String> kAssistantTones = <String>{
  'short',
  'detailed',
  'friendly',
  'formal',
};

const String kAssistantDefaultDisplayName = 'Jarvis';
const String kAssistantDefaultTone = 'short';

/// The assistant's personality: what it calls itself, how it answers,
/// and any extra instructions the user wrote.
class AssistantSettings {
  const AssistantSettings({
    this.displayName = kAssistantDefaultDisplayName,
    this.tone = kAssistantDefaultTone,
    this.customInstructions = '',
  });

  /// The name Jarvis uses for itself (default 'Jarvis').
  final String displayName;

  /// One of [kAssistantTones] (default 'short').
  final String tone;

  /// Free-text instructions from the user (default '').
  final String customInstructions;

  /// True when nothing differs from the defaults — in that case
  /// [buildPersonalitySection] returns '' and the system instruction
  /// is left untouched.
  bool get isDefault =>
      displayName == kAssistantDefaultDisplayName &&
      tone == kAssistantDefaultTone &&
      customInstructions.trim().isEmpty;

  AssistantSettings copyWith({
    String? displayName,
    String? tone,
    String? customInstructions,
  }) =>
      AssistantSettings(
        displayName: displayName ?? this.displayName,
        tone: tone ?? this.tone,
        customInstructions: customInstructions ?? this.customInstructions,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'displayName': displayName,
        'tone': tone,
        'customInstructions': customInstructions,
      };

  factory AssistantSettings.fromJson(Map<String, dynamic> json) {
    final rawTone = json['tone']?.toString() ?? '';
    final rawName = json['displayName']?.toString().trim() ?? '';
    return AssistantSettings(
      displayName:
          rawName.isNotEmpty ? rawName : kAssistantDefaultDisplayName,
      tone: kAssistantTones.contains(rawTone) ? rawTone : kAssistantDefaultTone,
      customInstructions: json['customInstructions'] is String
          ? json['customInstructions'] as String
          : '',
    );
  }

  @override
  bool operator ==(Object other) =>
      other is AssistantSettings &&
      other.displayName == displayName &&
      other.tone == tone &&
      other.customInstructions == customInstructions;

  @override
  int get hashCode =>
      Object.hash(displayName, tone, customInstructions);
}

/// Parses stored settings JSON. Tolerant: missing keys, unknown tones
/// and malformed JSON all fall back to the defaults.
AssistantSettings parseAssistantSettings(String? raw) {
  if (raw == null || raw.isEmpty) return const AssistantSettings();
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! Map) return const AssistantSettings();
    return AssistantSettings.fromJson(Map<String, dynamic>.from(decoded));
  } catch (_) {
    return const AssistantSettings();
  }
}

String encodeAssistantSettings(AssistantSettings settings) =>
    jsonEncode(settings.toJson());

/// The system-instruction section carrying the personality, or '' when
/// the settings are all defaults. Main.dart appends this to the base
/// system instruction.
String buildPersonalitySection(AssistantSettings settings) {
  if (settings.isDefault) return '';
  final lines = <String>[];
  if (settings.displayName != kAssistantDefaultDisplayName) {
    lines.add('Your name is ${settings.displayName.trim()}.');
  }
  if (settings.tone != kAssistantDefaultTone) {
    const toneLines = <String, String>{
      'detailed': 'Answer in a detailed, thorough style.',
      'friendly': 'Answer in a friendly, warm style.',
      'formal': 'Answer in a formal, professional style.',
    };
    final toneLine = toneLines[settings.tone];
    if (toneLine != null) lines.add(toneLine);
  }
  final custom = settings.customInstructions.trim();
  if (custom.isNotEmpty) lines.add(custom);
  if (lines.isEmpty) return '';
  return 'Assistant personality (the user chose this — follow it):\n'
      '${lines.join('\n')}';
}

/// On-device store for the assistant personality settings.
class AssistantSettingsService {
  const AssistantSettingsService();

  Future<AssistantSettings> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    return parseAssistantSettings(prefs.getString(kJarvisAssistantSettingsKey));
  }

  Future<void> saveSettings(AssistantSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      kJarvisAssistantSettingsKey,
      encodeAssistantSettings(settings),
    );
  }
}
