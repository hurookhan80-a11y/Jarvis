// Phase 8 (v1.1.0) — screens for F40/F41.
//
//   AgentLoopLogScreen — F40: the per-step log of the last agent-loop
//     run (each step + its outcome), so the user can see what the
//     loop did even after the chat has scrolled past it.
//   AccessibilityScreen — F41: the toggle (default OFF, with a plain
//     explanation of what the service does and how to turn it off),
//     a button into Android Settings → Accessibility, and the
//     "Accessibility actions" log — every action the service took.
//
// All data stays on this phone. The screens take their state as
// constructor arguments so the home screen stays the only place that
// wires them together.

import 'package:flutter/material.dart';

import 'accessibility_service.dart';
import 'agent_loop.dart';

const _screenBackground = Colors.black;
const _screenAccent = Colors.cyan;

/// F40: the agent loop's per-step log, newest run at the top of the
/// list as stored (main.dart appends in run order; the screen shows
/// them in that order, grouped by run via the step index restarting
/// at 0 — the header line above the list names the run).
class AgentLoopLogScreen extends StatelessWidget {
  const AgentLoopLogScreen({
    super.key,
    required this.log,
    required this.running,
  });

  final List<AgentStepLogEntry> log;
  final bool running;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Agent loop log'),
        backgroundColor: _screenBackground,
        foregroundColor: Colors.white,
      ),
      body: log.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24.0),
                child: Text(
                  'No agent loop has run yet.\n\nSay a multi-step command such as "open WhatsApp and remind me at 7 to study" and each step will be logged here with its outcome.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            )
          : ListView.builder(
              itemCount: log.length + 1,
              itemBuilder: (context, index) {
                if (index == 0) {
                  return Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      running
                          ? 'Agent loop running…'
                          : 'Last agent loop run — steps in order:',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  );
                }
                final entry = log[index - 1];
                final icon = switch (entry.status) {
                  AgentStepStatus.done => Icons.check_circle,
                  AgentStepStatus.failed => Icons.error,
                  AgentStepStatus.running => Icons.hourglass_top,
                  AgentStepStatus.pending => Icons.radio_button_unchecked,
                };
                final color = switch (entry.status) {
                  AgentStepStatus.done => Colors.green,
                  AgentStepStatus.failed => Colors.redAccent,
                  AgentStepStatus.running => Colors.orange,
                  AgentStepStatus.pending => Colors.grey,
                };
                return ListTile(
                  leading: Icon(icon, color: color),
                  title: Text(
                    '${entry.index + 1}. ${entry.command}',
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    entry.detail,
                    style: const TextStyle(color: Colors.grey),
                  ),
                );
              },
            ),
    );
  }
}

/// F41: the Accessibility service — toggle, explanation, Android
/// Settings shortcut, and the action log.
class AccessibilityScreen extends StatelessWidget {
  const AccessibilityScreen({
    super.key,
    required this.enabled,
    required this.log,
    required this.onToggle,
    required this.onOpenAndroidSettings,
    required this.onClearLog,
  });

  /// The Jarvis-side toggle (Settings). The Android-side switch is
  /// separate — both must be on for any action to run.
  final bool enabled;

  /// Every action the service took, newest last.
  final List<AccessibilityActionLogEntry> log;
  final ValueChanged<bool> onToggle;
  final VoidCallback onOpenAndroidSettings;
  final VoidCallback onClearLog;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _screenBackground,
      appBar: AppBar(
        title: const Text('Accessibility actions'),
        backgroundColor: _screenBackground,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Clear the action log',
            onPressed: onClearLog,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text(
            'What this does',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'When switched on, Jarvis can tap, type, go back and scroll inside other apps — but ONLY when you tell it to by voice in that moment, for example "tap Send" or "type hello". It never acts on its own, and every action is written in the log below.\n\nTo use it, switch it on here AND switch Jarvis on in Android Settings → Accessibility. To turn it off completely, switch it off here and switch Jarvis off in Android Settings → Accessibility.',
            style: TextStyle(color: Colors.white70, fontSize: 13),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            value: enabled,
            activeThumbColor: _screenAccent,
            title: const Text(
              'Accessibility service',
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
            subtitle: const Text(
              'Off by default. Jarvis only taps or types when you say so.',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
            contentPadding: EdgeInsets.zero,
            onChanged: onToggle,
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: onOpenAndroidSettings,
                  child: const Text(
                    'Open Android Accessibility settings',
                    style: TextStyle(color: Colors.cyan),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Accessibility actions',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          if (log.isEmpty)
            const Text(
              'No actions yet. Nothing has been tapped or typed.',
              style: TextStyle(color: Colors.grey, fontSize: 13),
            )
          else
            for (final entry in log)
              ListTile(
                leading: Icon(
                  entry.succeeded
                      ? Icons.check_circle
                      : Icons.error,
                  color: entry.succeeded
                      ? Colors.green
                      : Colors.redAccent,
                ),
                title: Text(
                  entry.line,
                  style: const TextStyle(color: Colors.white),
                ),
                subtitle: Text(
                  entry.at.toLocal().toString().split('.').first,
                  style: const TextStyle(color: Colors.grey),
                ),
                contentPadding: EdgeInsets.zero,
              ),
        ],
      ),
    );
  }
}
