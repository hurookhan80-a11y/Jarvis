// Phase 7 (v1.1.0) — F37 commute (free routing + ETA).
//
// "How long to Faisalabad Medical University?" — free OSRM routing
// (router.project-osrm.org, no key, no account) + ETA and distance,
// no live traffic. The destination is geocoded with Nominatim
// (nominatim.openstreetmap.org, free, no key, with a proper
// User-Agent identifying this app). The start point comes from the
// phone's last known location (small Kotlin channel in
// MainActivity.kt — LocationManager, no new dependency) or, when
// that is unavailable, from a starting place the user says (which is
// geocoded too). Saved places (home, FMU, work) are stored locally.
//
// Live Google traffic is SKIP S2 — it needs a billing-enabled API
// key. Nothing here needs a key, a card, or an account.
//
// Pattern: AbuZar-Ansarii/Jarvis
// lib/services/commute_traffic_service.dart (routing part only).
// Fresh implementation — no code copied.

import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Nominatim + OSRM want to know who is calling. No key, just an
/// identifying User-Agent, per Nominatim's usage policy.
const String kJarvisCommuteUserAgent =
    'JarvisApp/1.1.0 (personal voice assistant; contact: jarvis-app)';

/// SharedPreferences key holding the saved places, as a JSON map of
/// `name -> {lat, lon, label}`.
const String kJarvisSavedPlacesKey = 'jarvis_saved_places_v1';

/// A point on the map.
class LatLng {
  const LatLng({required this.lat, required this.lon, this.label = ''});

  final double lat;
  final double lon;

  /// Display name (from Nominatim, or the saved-place name).
  final String label;

  @override
  String toString() => '$lat,$lon';
}

/// A route summary from OSRM.
class RouteSummary {
  const RouteSummary({
    required this.distanceKm,
    required this.durationMinutes,
    required this.mode,
  });

  /// Distance in kilometres, one decimal in display.
  final double distanceKm;

  /// Driving/walking time in minutes.
  final double durationMinutes;
  final CommuteMode mode;

  String get distanceText => '${distanceKm.toStringAsFixed(1)} km';

  String get etaText {
    final minutes = durationMinutes.round();
    if (minutes < 60) return '$minutes min';
    final hours = minutes ~/ 60;
    final rest = minutes % 60;
    return rest == 0 ? '$hours h' : '$hours h $rest min';
  }
}

enum CommuteMode { driving, walking, cycling }

extension CommuteModeOsrm on CommuteMode {
  /// OSRM profile name in the route URL.
  String get profile {
    switch (this) {
      case CommuteMode.driving:
        return 'driving';
      case CommuteMode.walking:
        return 'foot';
      case CommuteMode.cycling:
        return 'bike';
    }
  }

  String get label {
    switch (this) {
      case CommuteMode.driving:
        return 'driving';
      case CommuteMode.walking:
        return 'walking';
      case CommuteMode.cycling:
        return 'cycling';
    }
  }
}

/// Parses one Nominatim search response (a JSON list). Returns the
/// first result, or null when there is none. Pure — unit-tested.
LatLng? parseNominatimResponse(String raw) {
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! List || decoded.isEmpty) return null;
    final first = decoded.first;
    if (first is! Map) return null;
    final lat = double.tryParse(first['lat']?.toString() ?? '');
    final lon = double.tryParse(first['lon']?.toString() ?? '');
    if (lat == null || lon == null) return null;
    return LatLng(
      lat: lat,
      lon: lon,
      label: first['display_name']?.toString() ?? '',
    );
  } catch (_) {
    return null;
  }
}

/// Parses one OSRM route response. Returns the first route's summary,
/// or null when the response has no usable route. Pure — unit-tested.
RouteSummary? parseOsrmResponse(String raw, CommuteMode mode) {
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! Map) return null;
    if (decoded['code']?.toString().toLowerCase() != 'ok') return null;
    final routes = decoded['routes'];
    if (routes is! List || routes.isEmpty) return null;
    final first = routes.first;
    if (first is! Map) return null;
    final distance = (first['distance'] as num?)?.toDouble();
    final duration = (first['duration'] as num?)?.toDouble();
    if (distance == null || duration == null) return null;
    return RouteSummary(
      distanceKm: distance / 1000,
      durationMinutes: duration / 60,
      mode: mode,
    );
  } catch (_) {
    return null;
  }
}

/// Extracts the destination from "how long to X", "how long does it
/// take to get to X", "distance to X", "how far is X", "commute to X",
/// "directions to X". Returns (destination, mode). Null when this is
/// not a commute question.
({String destination, CommuteMode mode})? parseCommuteDestination(
  String utterance,
) {
  final lower = utterance.trim().toLowerCase();
  var mode = CommuteMode.driving;
  if (lower.contains('walk')) mode = CommuteMode.walking;
  if (lower.contains('cycle') || lower.contains('bike')) {
    mode = CommuteMode.cycling;
  }
  final patterns = <RegExp>[
    RegExp(r'how long (?:does it take )?to (?:get to )?(.+)$'),
    RegExp(r'how far (?:is|to) (.+)$'),
    RegExp(r'(?:distance|commute|directions?) to (.+)$'),
    RegExp(r'how long to (.+)$'),
  ];
  for (final pattern in patterns) {
    final match = pattern.firstMatch(lower);
    if (match == null) continue;
    var destination = (match.group(1) ?? '').trim();
    // Strip trailing filler the recogniser adds, and trailing
    // punctuation ("...University?").
    destination = destination
        .replaceAll(RegExp(r'\s+(by car|by bike|on foot|please)$'), '')
        .replaceAll(RegExp(r'[?.!]+$'), '')
        .trim();
    if (destination.isEmpty) return null;
    // Keep the user's casing for display: re-extract from the
    // original utterance at the same position.
    final original = utterance.trim();
    final index = original.toLowerCase().indexOf(destination);
    if (index >= 0) {
      destination = original.substring(index, index + destination.length);
    }
    return (destination: destination, mode: mode);
  }
  return null;
}

/// Saved places: name -> point. No built-in coordinates — the
/// coordinates of a place are only ever what the user saved or what
/// Nominatim returned for that name, never a guessed value.
Map<String, LatLng> parseSavedPlaces(String? raw) {
  final places = <String, LatLng>{};
  if (raw == null || raw.isEmpty) return places;
  try {
    final decoded = jsonDecode(raw);
    if (decoded is! Map) return places;
    for (final entry in decoded.entries) {
      final value = entry.value;
      if (value is! Map) continue;
      final lat = (value['lat'] as num?)?.toDouble();
      final lon = (value['lon'] as num?)?.toDouble();
      if (lat == null || lon == null) continue;
      places[entry.key.toString().toLowerCase()] = LatLng(
        lat: lat,
        lon: lon,
        label: value['label']?.toString() ?? entry.key.toString(),
      );
    }
  } catch (_) {}
  return places;
}

/// Free routing + geocoding. The [http.Client] is injectable so the
/// response parsers can be tested without a network call.
class CommuteService {
  CommuteService({http.Client? httpClient})
    : _httpClient = httpClient ?? http.Client();

  final http.Client _httpClient;

  static const MethodChannel _locationChannel =
      MethodChannel('com.jarvis.jarvis_app/location');

  /// The phone's last known location (GPS, then network). Returns
  /// null when the location permission is missing, location is off,
  /// or no fix has ever been recorded. Never requests a fresh fix —
  /// last-known is enough for a route start, and it costs no battery.
  Future<LatLng?> getLastKnownLocation() async {
    try {
      final raw = await _locationChannel.invokeMethod<Map<dynamic, dynamic>>(
        'getLastLocation',
      );
      if (raw == null) return null;
      final lat = (raw['latitude'] as num?)?.toDouble();
      final lon = (raw['longitude'] as num?)?.toDouble();
      if (lat == null || lon == null) return null;
      return LatLng(lat: lat, lon: lon, label: 'Current location');
    } catch (_) {
      return null;
    }
  }

  Future<Map<String, LatLng>> loadSavedPlaces() async {
    final prefs = await SharedPreferences.getInstance();
    return parseSavedPlaces(prefs.getString(kJarvisSavedPlacesKey));
  }

  Future<void> savePlace(String name, LatLng point) async {
    final places = await loadSavedPlaces();
    places[name.trim().toLowerCase()] = LatLng(
      lat: point.lat,
      lon: point.lon,
      label: name.trim(),
    );
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      kJarvisSavedPlacesKey,
      jsonEncode(
        places.map(
          (key, value) => MapEntry(key, <String, dynamic>{
            'lat': value.lat,
            'lon': value.lon,
            'label': value.label,
          }),
        ),
      ),
    );
  }

  /// Geocodes [query] with Nominatim. Saved places match first, so
  /// "FMU" never needs a network call. Returns null when nothing is
  /// found or the request fails.
  Future<LatLng?> geocode(String query) async {
    final places = await loadSavedPlaces();
    final saved = places[query.trim().toLowerCase()];
    if (saved != null) return saved;
    try {
      final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
        'q': query,
        'format': 'json',
        'limit': '1',
      });
      final response = await _httpClient
          .get(uri, headers: {'User-Agent': kJarvisCommuteUserAgent})
          .timeout(const Duration(seconds: 15));
      if (response.statusCode != 200) return null;
      return parseNominatimResponse(response.body);
    } catch (_) {
      return null;
    }
  }

  /// Routes [from] -> [to] with OSRM. Returns null when routing fails.
  Future<RouteSummary?> getRoute(
    LatLng from,
    LatLng to,
    CommuteMode mode,
  ) async {
    try {
      final uri = Uri.https(
        'router.project-osrm.org',
        '/route/v1/${mode.profile}/${from.lon},${from.lat};${to.lon},${to.lat}',
        {'overview': 'false'},
      );
      final response = await _httpClient
          .get(uri, headers: {'User-Agent': kJarvisCommuteUserAgent})
          .timeout(const Duration(seconds: 15));
      if (response.statusCode != 200) return null;
      return parseOsrmResponse(response.body, mode);
    } catch (_) {
      return null;
    }
  }

  /// One-line spoken + on-screen summary, or null when either leg
  /// failed (the caller then says which leg failed).
  String formatRouteSummary({
    required String fromLabel,
    required String toLabel,
    required RouteSummary route,
  }) {
    return '$toLabel is ${route.distanceText} away, about '
        '${route.etaText} ${route.mode.label} from $fromLabel. '
        'No live traffic — this is the usual route time.';
  }
}
