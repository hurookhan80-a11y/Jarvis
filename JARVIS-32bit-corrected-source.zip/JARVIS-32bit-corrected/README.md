# J.A.R.V.I.S — 32-bit Android source

The Flutter Android project is in [`jarvis_app/`](jarvis_app/). It is configured for **ARMv7 (`armeabi-v7a`) only**, with Android API 24 as the minimum supported level. Start with `jarvis_app/README.md` for prerequisites, build instructions, key setup, and known platform limitations.

The project includes Android Keystore-backed encryption for the Gemini API key, restored Android/Gradle project scaffolding, bundled sound assets, command parsing fixes, and unit tests. It does **not** include an APK, release keystore, API key, or proof of a successful build on a real phone. Run the Flutter analyzer/tests and build workflow before distributing it.
