# J.A.R.V.I.S source correction notes

## Changes made in this source revision

- Restored `android/settings.gradle.kts`, `android/gradle.properties`, Android app resources, and complete Android application Gradle configuration aligned with Flutter 3.50.0 defaults: AGP 9.3.1, Gradle 9.5.0, Kotlin Gradle Plugin 2.4.20, API 36, Java 17. Legacy Kotlin / Android DSL compatibility flags remain enabled for the current third-party plugin set.
- Added an explicit ARMv7 ABI filter (`armeabi-v7a`), API 24 minimum, Java 17, and a consistent Flutter 3.50-compatible Android Gradle Plugin 9.3.1 / Gradle 9.5.0 / Kotlin Gradle Plugin 2.4.20 configuration.
- Made release signing conditional. A missing `key.properties` no longer causes Gradle configuration to fail; a debug signing key is used only as a local testing fallback.
- Added a native Android Keystore AES/GCM implementation for storing the Gemini API key. The Dart layer no longer stores the key in plain `SharedPreferences`.
- Added the missing startup and wake MP3 assets.
- Fixed the timer and alarm follow-up flow: the next recognized utterance is now parsed as the requested duration/time.
- Added compound timer parsing, duration bounds, wall-clock-based countdown calculations, alarm input validation, and Android `ACTION_SET_ALARM` extras.
- Replaced the archived `google_generative_ai` Dart package with a direct Gemini `generateContent` REST client using `http`, the `x-goog-api-key` header, a request timeout, response validation, and API error handling.
- Corrected Gemini chat history so model replies are stored as model-role content, added a single system instruction, and capped retained history at 20 messages.
- Changed the default model from the shut-down `gemini-2.0-flash` to `gemini-3.8-flash`.
- Added pure command parsers and unit tests.
- Replaced the old temporary-APK emulator workflow with a source-based ARMv7 CI build workflow.

## Important limitations

- The editing environment did not contain Flutter, Dart, Android SDK, Gradle, or an Android emulator. Therefore `flutter analyze`, `flutter test`, Gradle build, APK verification, and real-device testing could not be executed here.
- The previous archive's build notes documented that prior APKs crashed on launch, and the crash cause was not proven. This source correction does not establish that a new APK is crash-free until it is built and tested on the actual ARMv7 device.
- Wake-word listening is not a persistent Android background microphone service. Android can suspend microphone access while the app is backgrounded or the screen is off.
- The in-app timer is not a reboot-persistent Android alarm. It needs the app process to remain alive.
- Gemini is called through the documented REST API so the app can retain user-supplied API keys without relying on the archived Dart SDK. For a managed multi-user production deployment, evaluate Firebase AI Logic or a secured backend.
- Android's `ACTION_SET_ALARM` intent opens a compatible Clock app and requests alarm creation; device/OEM clock apps can vary and may require the user to confirm the alarm.

## Required verification before release

1. Run `flutter pub get`, `flutter analyze`, and `flutter test`.
2. Generate the Gradle wrapper with Gradle 9.5.0 if wrapper scripts are not already present.
3. Build with `flutter build apk --release --target-platform android-arm`.
4. Confirm the APK contains `lib/armeabi-v7a/` native libraries and no required `arm64-v8a` library.
5. Install on the target 32-bit Android phone; test cold launch, microphone permission, speech recognition, TTS, Gemini key save/reload, Gemini response, timer, alarm intent, and app opening.
6. Capture `adb logcat` during cold launch and after each native plugin test.
7. Configure the original release keystore before distributing an update. A newly generated/debug keystore cannot update an app signed with a different key.
